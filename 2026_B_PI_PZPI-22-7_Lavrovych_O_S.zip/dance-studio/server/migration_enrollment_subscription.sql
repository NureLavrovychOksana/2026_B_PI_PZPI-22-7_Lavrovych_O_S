-- Run once to add subscription tracking to enrollments
ALTER TABLE enrollments
  ADD COLUMN subscription_id INT UNSIGNED NULL,
  ADD CONSTRAINT fk_enrollments_subscription
    FOREIGN KEY (subscription_id) REFERENCES student_subscriptions(id)
    ON DELETE SET NULL;
