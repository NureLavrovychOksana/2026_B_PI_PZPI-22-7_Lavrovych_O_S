const { overlaps, validateHardConstraints } = require('../../src/services/schedule.service.js');

const slot = (overrides) => ({
  group_id:   1,
  teacher_id: 10,
  hall_id:    1,
  dayIdx:     0,
  startMin:   600,  // 10:00
  endMin:     720,  // 12:00
  ...overrides,
});

describe('overlaps()', () => {

  it('returns true for identical intervals', () => {
    // [10:00–12:00] vs [10:00–12:00]
    expect(overlaps(600, 720, 600, 720)).toBe(true);
  });

  it('returns true when intervals partially overlap from the start', () => {
    // [10:00–12:00] vs [09:00–11:00]
    expect(overlaps(600, 720, 540, 660)).toBe(true);
  });

  it('returns true when one interval starts inside the other', () => {
    // [10:00–12:00] vs [11:00–13:00]
    expect(overlaps(600, 720, 660, 780)).toBe(true);
  });

  it('returns false for adjacent (touching) intervals', () => {
    // [10:00–12:00] → [12:00–14:00]
    expect(overlaps(600, 720, 720, 840)).toBe(false);
  });

  it('reports no violations when hall, teacher and group are all distinct', () => {
    const assignment = slot({ hall_id: 2, teacher_id: 20, group_id: 2 });
    const existing   = [slot({ hall_id: 1, teacher_id: 10, group_id: 1 })];
    const { valid, violations } = validateHardConstraints(assignment, existing);
    expect(valid).toBe(true);
    expect(violations).toHaveLength(0);
  });

  it('reports teacher_conflict when the same teacher is double-booked in the same slot', () => {
    const assignment = slot({ hall_id: 2, teacher_id: 10, group_id: 2 });
    const existing   = [slot({ hall_id: 1, teacher_id: 10, group_id: 1 })];
    const { valid, violations } = validateHardConstraints(assignment, existing);
    expect(valid).toBe(false);
    expect(violations.some((v) => v.type === 'teacher_conflict')).toBe(true);
    expect(violations.some((v) => v.type === 'hall_conflict')).toBe(false);
  });

});
