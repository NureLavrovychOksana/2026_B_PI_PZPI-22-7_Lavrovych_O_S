const { calculateScheduleScore } = require('../../src/services/schedule.service');

const slot = (overrides = {}) => ({
  group_id:   1,
  teacher_id: 10,
  hall_id:    1,
  dayIdx:     0,
  startMin:   18 * 60,
  endMin:     19 * 60,
  ...overrides,
});

const req = (overrides = {}) => ({
  is_children:      false,
  lessons_per_week: 1,
  typical_students: 10,
  ...overrides,
});

describe('calculateScheduleScore() — soft constraints', () => {

  it('returns 100 for an adult group in evening hours on a weekday', () => {
    const { score, warnings } = calculateScheduleScore(slot(), [], req(), null);
    expect(score).toBe(100);
    expect(warnings).toHaveLength(0);
  });

  it('penalises an adult group scheduled during daytime on a weekday', () => {
    const { score, warnings } = calculateScheduleScore(
      slot({ startMin: 10 * 60, endMin: 11 * 60 }),
      [], req(), null
    );
    expect(score).toBeLessThan(100);
    expect(warnings.some(w => w.type === 'timing')).toBe(true);
  });

  it('penalises a children group placed in evening hours on a weekday', () => {
    const { score, warnings } = calculateScheduleScore(
      slot(), [], req({ is_children: true }), null
    );
    expect(score).toBeLessThan(100);
    expect(warnings.some(w => w.type === 'timing')).toBe(true);
  });

  it('penalises consecutive-day scheduling for a group', () => {
    const { score, warnings } = calculateScheduleScore(
      slot({ dayIdx: 1 }),
      [slot({ dayIdx: 0 })],
      req({ lessons_per_week: 2 }),
      null
    );
    expect(score).toBeLessThan(100);
    expect(warnings.some(w => w.type === 'day_spread')).toBe(true);
  });

  it('does not penalise the classic Mon/Wed pair for twice-a-week groups', () => {
    const { score } = calculateScheduleScore(
      slot({ dayIdx: 2 }),
      [slot({ dayIdx: 0 })],
      req({ lessons_per_week: 2 }),
      null
    );
    expect(score).toBe(100);
  });

  it('penalises a hall that is too small for the group', () => {
    const { score, warnings } = calculateScheduleScore(
      slot(), [], req({ typical_students: 25 }), { id: 1, capacity: 10 }
    );
    expect(score).toBeLessThan(100);
    expect(warnings.some(w => w.type === 'hall_capacity')).toBe(true);
  });

});
