const { applySessionDeduction } = require('../../src/utils/subscriptionUtils.js');

const countSub = (sessions_left) => ({
  id:            1,
  plan_type:     'COUNT',
  sessions_left,
  status:        'active',
});

const unlimitedSub = () => ({
  id:            2,
  plan_type:     'UNLIMITED',
  sessions_left: null,
  status:        'active',
});

describe('applySessionDeduction()', () => {

  it('decrements sessions_left by one and keeps status active', () => {
    const result = applySessionDeduction(countSub(5));
    expect(result.sessions_left).toBe(4);
    expect(result.status).toBe('active');
  });

  it('sets status to exhausted when the last session is consumed', () => {
    const result = applySessionDeduction(countSub(1));
    expect(result.sessions_left).toBe(0);
    expect(result.status).toBe('exhausted');
  });

  it('leaves sessions_left and status unchanged for an UNLIMITED subscription', () => {
    const result = applySessionDeduction(unlimitedSub());
    expect(result.sessions_left).toBeNull();
    expect(result.status).toBe('active');
  });

  it('returns null when subscription is not provided', () => {
    expect(applySessionDeduction(null)).toBeNull();
  });

});
