require('dotenv').config();
const pool = require('../../src/config/db');
const { mark } = require('../../src/services/attendance.service');

const ADMIN = { id: 1, role: 'admin' };

let testStudentId;
let testLessonId;
let testSubId;
let testEnrollId;
let testPlanId;

const INITIAL_LEFT = 8;

beforeAll(async () => {
  const [userRes] = await pool.query(
    `INSERT INTO users (email, password_hash, role, first_name, last_name)
     VALUES ('concurrent_test@test.internal', 'x', 'student', 'Test', 'Concurrent')`
  );
  testStudentId = userRes.insertId;

  const [planRes] = await pool.query(
    `INSERT INTO subscription_plans (name, type, sessions_count, validity_days, price)
     VALUES ('Test COUNT Plan', 'COUNT', 10, 60, 100.00)`
  );
  testPlanId = planRes.insertId;

  const [subRes] = await pool.query(
    `INSERT INTO student_subscriptions
       (student_id, plan_id, purchase_date, activation_date, expiry_date, sessions_left, status)
     VALUES (?, ?, '2026-01-01', '2026-01-01', '2030-12-31', ?, 'active')`,
    [testStudentId, testPlanId, INITIAL_LEFT]
  );
  testSubId = subRes.insertId;

  const [lesRes] = await pool.query(
    `INSERT INTO lessons (group_id, hall_id, lesson_date, start_time, end_time)
     VALUES (1, 1, '2026-01-15', '10:00:00', '11:30:00')`
  );
  testLessonId = lesRes.insertId;

  const [enrRes] = await pool.query(
    `INSERT INTO enrollments (student_id, lesson_id) VALUES (?, ?)`,
    [testStudentId, testLessonId]
  );
  testEnrollId = enrRes.insertId;
});

afterAll(async () => {
  await pool.query('DELETE FROM attendance          WHERE lesson_id = ?', [testLessonId]);
  await pool.query('DELETE FROM enrollments         WHERE id = ?',       [testEnrollId]);
  await pool.query('DELETE FROM lessons             WHERE id = ?',       [testLessonId]);
  await pool.query('DELETE FROM student_subscriptions WHERE id = ?',     [testSubId]);
  await pool.query('DELETE FROM subscription_plans  WHERE id = ?',       [testPlanId]);
  await pool.query('DELETE FROM users               WHERE id = ?',       [testStudentId]);
  await pool.end();
});

describe('attendance mark — concurrent request safety', () => {

  it(
    'two concurrent requests produce exactly one successful session deduction',
    async () => {
      const [[before]] = await pool.query(
        'SELECT sessions_left FROM student_subscriptions WHERE id = ?',
        [testSubId]
      );
      expect(before.sessions_left).toBe(INITIAL_LEFT);

      const [result1, result2] = await Promise.allSettled([
        mark({ lessonId: testLessonId, studentId: testStudentId, status: 'present' }, ADMIN),
        mark({ lessonId: testLessonId, studentId: testStudentId, status: 'present' }, ADMIN),
      ]);

      const succeeded = [result1, result2].filter(r => r.status === 'fulfilled');
      const failed    = [result1, result2].filter(r => r.status === 'rejected');
      expect(succeeded).toHaveLength(1);
      expect(failed).toHaveLength(1);

      const rejectedReason = failed[0].reason;
      const isExpectedError =
        rejectedReason.status === 409 ||
        (rejectedReason.message && rejectedReason.message.includes('Duplicate'));
      expect(isExpectedError).toBe(true);

      const [[after]] = await pool.query(
        'SELECT sessions_left FROM student_subscriptions WHERE id = ?',
        [testSubId]
      );
      expect(after.sessions_left).toBe(INITIAL_LEFT - 1);
    },
    10_000
  );

});
