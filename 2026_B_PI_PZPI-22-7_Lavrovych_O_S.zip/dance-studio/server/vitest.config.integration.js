/** @type {import('vitest/config').UserConfig} */
module.exports = {
  test: {
    environment: 'node',
    globals: true,
    include: ['tests/integration/**/*.test.js'],
    reporters: ['verbose'],
    testTimeout: 15_000,
    hookTimeout: 15_000,
  },
};
