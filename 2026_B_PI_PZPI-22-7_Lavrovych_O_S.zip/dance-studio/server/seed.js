'use strict';
require('dotenv').config();
const bcrypt = require('bcrypt');
const pool   = require('./src/config/db');

const GROUP_MEMBERS = {
  1:  [9, 10, 11, 14, 15, 16, 20, 22],
  2:  [10, 11, 19, 23, 24, 25],
  3:  [9, 10, 12, 13, 18, 20, 22, 26, 27, 29],
  4:  [9, 10, 11, 12, 13, 14, 15],
  5:  [10, 11, 12, 15, 25],
  6:  [9, 11, 13, 19, 26, 27],
  7:  [9, 14, 16, 21, 28],
  8:  [9, 11, 13, 18, 20, 22, 29],
  9:  [10, 12, 18, 19, 24, 26, 27, 29],
  10: [10, 14, 20, 21, 22, 28],
  11: [11, 15, 23, 25],
  12: [9, 13, 19, 24, 28],
  13: [12, 15, 16, 18, 20, 21, 22, 26, 29],
  14: [10, 16, 19, 23, 25, 27],
  15: [13, 14, 22, 24, 28],
  16: [9, 11, 14, 20, 23, 27],
};

// dayOffset: 0=Mon … 5=Sat
const GROUP_SCHEDULE = {
  1:  { hid: 1, slots: [[0,'18:00:00','19:30:00'],[2,'18:00:00','19:30:00']] },
  2:  { hid: 2, slots: [[1,'19:30:00','21:00:00'],[3,'19:30:00','21:00:00']] },
  3:  { hid: 1, slots: [[0,'16:30:00','18:00:00'],[4,'16:30:00','18:00:00']] },
  4:  { hid: 3, slots: [[0,'20:00:00','21:30:00'],[3,'20:00:00','21:30:00']] },
  5:  { hid: 3, slots: [[1,'20:00:00','21:30:00'],[4,'20:00:00','21:30:00']] },
  6:  { hid: 1, slots: [[2,'10:00:00','11:30:00'],[5,'10:00:00','11:30:00']] },
  7:  { hid: 3, slots: [[1,'18:00:00','19:30:00'],[3,'18:00:00','19:30:00']] },
  8:  { hid: 2, slots: [[2,'19:30:00','21:00:00'],[5,'19:30:00','21:00:00']] },
  9:  { hid: 1, slots: [[0,'15:00:00','16:30:00'],[3,'15:00:00','16:30:00']] },
  10: { hid: 2, slots: [[2,'18:00:00','19:30:00'],[5,'18:00:00','19:30:00']] },
  11: { hid: 1, slots: [[4,'18:00:00','19:30:00']] },
  12: { hid: 3, slots: [[0,'11:00:00','12:30:00'],[4,'11:00:00','12:30:00']] },
  13: { hid: 1, slots: [[1,'16:00:00','17:30:00'],[5,'16:00:00','17:30:00']] },
  14: { hid: 2, slots: [[3,'17:30:00','19:00:00']] },
  15: { hid: 3, slots: [[2,'16:30:00','18:00:00']] },
  16: { hid: 1, slots: [[4,'14:30:00','16:00:00']] },
};

const WEEKS = ['2026-06-09', '2026-06-16', '2026-06-23', '2026-06-30'];
const TODAY  = '2026-06-16';

function makeDate(baseMonday, dayOffset) {
  const [y, m, d] = baseMonday.split('-').map(Number);
  const dt = new Date(y, m - 1, d + dayOffset);
  return `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`;
}

const RAND_STATUS = () => {
  const pick = Math.random();
  if (pick < 0.72) return 'present';
  if (pick < 0.90) return 'absent';
  return 'excused';
};

(async () => {
  try {
    await pool.query(`UPDATE halls SET name='Великий зал', capacity=25 WHERE id=1`);
    await pool.query(`UPDATE halls SET name='Зал дзеркал', capacity=15 WHERE id=2`);
    await pool.query(`UPDATE halls SET name='Студія',      capacity=10 WHERE id=3`);
    console.log('✓ Halls');

    await pool.query(`UPDATE dance_styles SET name='Контемп', description='Сучасна хореографія та пластика тіла' WHERE id=2`);
    await pool.query(`UPDATE dance_styles SET name='Брейк',   description='Акробатика, фліксі та б-бой культура' WHERE id=3`);
    await pool.query(`UPDATE dance_styles SET name='Афро',    description='Африканські ритми та рухи тіла' WHERE id=4`);
    await pool.query(`UPDATE dance_styles SET name='Vogue',   description='Ballroom culture та runway техніка' WHERE id=5`);
    console.log('✓ Styles');

    await pool.query(
      `ALTER TABLE dance_groups MODIFY level ENUM('first_steps','beginner','intermediate','advanced','pro','first_step','starter','learner','master') NOT NULL DEFAULT 'starter'`
    );
    await pool.query(`UPDATE dance_groups SET level='first_step' WHERE level='first_steps'`);
    await pool.query(`UPDATE dance_groups SET level='starter'    WHERE level='beginner'`);
    await pool.query(`UPDATE dance_groups SET level='learner'    WHERE level='intermediate'`);
    await pool.query(`UPDATE dance_groups SET level='master'     WHERE level='advanced'`);
    await pool.query(
      `ALTER TABLE dance_groups MODIFY level ENUM('first_step','starter','learner','master','pro') NOT NULL DEFAULT 'starter'`
    );
    console.log('✓ Level ENUM');

    await pool.query(`UPDATE dance_groups SET name='Хіп-хоп: First Step', level='first_step',  hall_id=1 WHERE id=1`);
    await pool.query(`UPDATE dance_groups SET name='Хіп-хоп: Learner',    level='learner',     hall_id=2 WHERE id=2`);
    await pool.query(`UPDATE dance_groups SET name='K-Pop: Starter',       level='starter',     hall_id=1 WHERE id=3`);
    await pool.query(`UPDATE dance_groups SET name='Бачата: First Step',   level='first_step',  hall_id=3 WHERE id=4`);
    await pool.query(`UPDATE dance_groups SET name='Бачата: Master',       level='master',      hall_id=3 WHERE id=5`);
    await pool.query(`UPDATE dance_groups SET name='Контемп: Learner',     level='learner',     hall_id=1, style_id=2 WHERE id=6`);
    await pool.query(`UPDATE dance_groups SET name='Джаз-фанк: Starter',   level='starter',     hall_id=3 WHERE id=7`);
    console.log('✓ Groups updated');

    const pw = await bcrypt.hash('Studio2026!', 10);

    await pool.query(
      `INSERT IGNORE INTO users (id, role, first_name, last_name, email, password_hash, phone)
       VALUES (17, 'teacher', 'Дмитро', 'Черненко', 'dmytro@movestudio.ua', ?, '+380671234567')`,
      [pw]
    );
    await pool.query(
      `INSERT IGNORE INTO teacher_profiles (user_id, bio, experience_years)
       VALUES (17, 'Брейкер та Афро-танцівник, переможець Ukrainian Street Dance Cup 2024. Навчався у Варшаві та Берліні.', 6)`
    );
    for (const sid of [3, 4, 5]) {
      await pool.query(`INSERT IGNORE INTO teacher_styles (teacher_id, style_id) VALUES (17, ?)`, [sid]);
    }
    console.log('✓ Teacher Дмитро Черненко');

    const newStudents = [
      [18, 'Соломія',  'Василенко',   'sofiia.vasylenko@gmail.com',    '+380671000018'],
      [19, 'Тарас',    'Кравченко',   'taras.kravchenko@gmail.com',    '+380671000019'],
      [20, 'Аліна',    'Шевченко',    'alina.shevchenko@gmail.com',    '+380671000020'],
      [21, 'Богдан',   'Мельник',     'bohdan.melnyk@gmail.com',       '+380671000021'],
      [22, 'Поліна',   'Захаренко',   'polina.zakharenko@gmail.com',   '+380671000022'],
      [23, 'Олег',     'Дорошенко',   'oleg.doroshenko@gmail.com',     '+380671000023'],
      [24, 'Вікторія', 'Романова',    'viktoriya.romanova@gmail.com',  '+380671000024'],
      [25, 'Максим',   'Нечипоренко', 'maksym.nechyporenko@gmail.com', '+380671000025'],
      [26, 'Діана',    'Федоренко',   'diana.fedorenko@gmail.com',     '+380671000026'],
      [27, 'Роман',    'Ткаченко',    'roman.tkachenko@gmail.com',     '+380671000027'],
      [28, 'Ніна',     'Білоус',      'nina.bilous@gmail.com',         '+380671000028'],
      [29, 'Євген',    'Карпенко',    'yevhen.karpenko@gmail.com',     '+380671000029'],
    ];
    for (const [id, fn, ln, email, phone] of newStudents) {
      await pool.query(
        `INSERT IGNORE INTO users (id, role, first_name, last_name, email, password_hash, phone)
         VALUES (?, 'student', ?, ?, ?, ?, ?)`,
        [id, fn, ln, email, pw, phone]
      );
    }
    console.log('✓ 12 students (18-29)');

    const newGroups = [
      [8,  'Хіп-хоп: Starter',   1, 'starter',    6,  2],
      [9,  'K-Pop: Learner',      7, 'learner',     6,  1],
      [10, 'Бачата: Starter',     6, 'starter',     7,  2],
      [11, 'Контемп: Master',     2, 'master',      8,  1],
      [12, 'Джаз-фанк: Learner',  8, 'learner',     8,  3],
      [13, 'Брейк: First Step',   3, 'first_step',  17, 1],
      [14, 'Брейк: Starter',      3, 'starter',     17, 2],
      [15, 'Афро: Learner',       4, 'learner',     17, 3],
      [16, 'Vogue: Starter',      5, 'starter',     17, 1],
    ];
    for (const [id, name, style_id, level, teacher_id, hall_id] of newGroups) {
      await pool.query(
        `INSERT IGNORE INTO dance_groups (id, name, style_id, level, teacher_id, hall_id)
         VALUES (?,?,?,?,?,?)`,
        [id, name, style_id, level, teacher_id, hall_id]
      );
    }
    console.log('✓ 9 groups (8-16)');

    const missingSubs = [
      [14, 3, '2026-05-15', '2026-07-15', 6,  'active'],
      [15, 4, '2026-05-20', '2026-08-20', 11, 'active'],
      [16, 2, '2026-06-01', '2026-07-01', 2,  'active'],
    ];
    for (const [sid, planId, pdate, edate, left, status] of missingSubs) {
      const [[{ cnt }]] = await pool.query(
        `SELECT COUNT(*) AS cnt FROM student_subscriptions WHERE student_id=?`, [sid]
      );
      if (cnt === 0) {
        await pool.query(
          `INSERT INTO student_subscriptions (student_id, plan_id, purchase_date, activation_date, expiry_date, sessions_left, status)
           VALUES (?,?,?,?,?,?,?)`,
          [sid, planId, pdate, pdate, edate, left, status]
        );
      }
    }

    const newSubs = [
      [18, 4, '2026-06-01', '2026-09-01', 11,   'active'],
      [19, 3, '2026-06-01', '2026-08-01', 7,    'active'],
      [20, 5, '2026-06-01', '2026-09-01', null,  'active'],
      [21, 2, '2026-06-01', '2026-07-01', 3,    'active'],
      [22, 4, '2026-06-01', '2026-09-01', 10,   'active'],
      [23, 3, '2026-06-10', '2026-08-10', 6,    'active'],
      [24, 4, '2026-06-10', '2026-09-10', 12,   'active'],
      [25, 5, '2026-06-10', '2026-09-10', null,  'active'],
      [26, 2, '2026-06-10', '2026-07-10', 2,    'active'],
      [27, 3, '2026-06-01', '2026-08-01', 5,    'active'],
      [28, 4, '2026-06-01', '2026-09-01', 9,    'active'],
      [29, 6, '2026-06-16', '2026-07-16', 1,    'active'],
    ];
    for (const [sid, planId, pdate, edate, left, status] of newSubs) {
      await pool.query(
        `INSERT INTO student_subscriptions (student_id, plan_id, purchase_date, activation_date, expiry_date, sessions_left, status)
         VALUES (?,?,?,?,?,?,?)`,
        [sid, planId, pdate, pdate, edate, left, status]
      );
    }
    console.log('✓ Subscriptions');

    const insertedLessons = [];
    for (const [gidStr, { hid, slots }] of Object.entries(GROUP_SCHEDULE)) {
      const gid = Number(gidStr);
      const weekFrom = gid <= 7 ? 1 : 0;
      for (let wi = weekFrom; wi < WEEKS.length; wi++) {
        for (const [dayOff, startTime, endTime] of slots) {
          const dateStr = makeDate(WEEKS[wi], dayOff);
          await pool.query(
            `INSERT IGNORE INTO lessons (group_id, hall_id, lesson_date, start_time, end_time)
             VALUES (?,?,?,?,?)`,
            [gid, hid, dateStr, startTime, endTime]
          );
          const [[row]] = await pool.query(
            `SELECT id FROM lessons WHERE group_id=? AND lesson_date=? AND start_time=?`,
            [gid, dateStr, startTime]
          );
          if (row) {
            insertedLessons.push({ id: row.id, gid, dateStr, startTime, isPast: dateStr < TODAY });
          }
        }
      }
    }
    console.log(`✓ Lessons: ${insertedLessons.length}`);

    const [existingLessons] = await pool.query(
      `SELECT id, group_id AS gid, lesson_date AS dateStr FROM lessons WHERE group_id BETWEEN 1 AND 7`
    );
    const allLessonsToEnroll = [
      ...existingLessons.map(r => ({
        id: r.id,
        gid: r.gid,
        dateStr: String(r.dateStr).slice(0, 10),
        isPast: String(r.dateStr).slice(0, 10) < TODAY,
      })),
      ...insertedLessons,
    ];
    const seenIds = new Set();
    const deduped = allLessonsToEnroll.filter(l => {
      if (seenIds.has(l.id)) return false;
      seenIds.add(l.id);
      return true;
    });

    for (const { id: lessonId, gid } of deduped) {
      const members = GROUP_MEMBERS[gid] || [];
      for (const sid of members) {
        await pool.query(
          `INSERT IGNORE INTO enrollments (student_id, lesson_id) VALUES (?,?)`,
          [sid, lessonId]
        );
      }
    }
    console.log('✓ Enrollments');

    const subCache = {};
    const getSubId = async (sid) => {
      if (subCache[sid] !== undefined) return subCache[sid];
      const [[row]] = await pool.query(
        `SELECT id FROM student_subscriptions WHERE student_id=? AND status IN ('active') LIMIT 1`,
        [sid]
      );
      subCache[sid] = row ? row.id : null;
      return subCache[sid];
    };

    const pastLessons = deduped.filter(l => l.isPast);
    for (const { id: lessonId, gid } of pastLessons) {
      const members = GROUP_MEMBERS[gid] || [];
      for (const sid of members) {
        const subId = await getSubId(sid);
        const status = RAND_STATUS();
        await pool.query(
          `INSERT IGNORE INTO attendance (lesson_id, student_id, status, subscription_id)
           VALUES (?,?,?,?)`,
          [lessonId, sid, status, subId]
        );
      }
    }
    console.log(`✓ Attendance: ${pastLessons.length} past lessons`);

    console.log('\n✅ SEED COMPLETE');
    process.exit(0);
  } catch (err) {
    console.error('❌', err.message, err.stack);
    process.exit(1);
  }
})();
