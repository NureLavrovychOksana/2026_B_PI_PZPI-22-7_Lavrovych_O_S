const pool = require('../config/db');

const findAll = async () => {
  const [rows] = await pool.query(
    `SELECT
       tp.id, tp.user_id, tp.bio, tp.experience_years, tp.education,
       tp.rate_type, tp.rate_amount,
       u.first_name, u.last_name, u.email, u.phone, u.avatar_url,
       (SELECT COUNT(DISTINCT en.student_id)
        FROM lessons l2
        JOIN dance_groups dg2 ON dg2.id = l2.group_id
        JOIN enrollments en ON en.lesson_id = l2.id
        WHERE COALESCE(l2.teacher_id, dg2.teacher_id) = u.id) AS students_count,
       (SELECT COUNT(*)
        FROM lessons l3
        JOIN dance_groups dg3 ON dg3.id = l3.group_id
        WHERE COALESCE(l3.teacher_id, dg3.teacher_id) = u.id AND l3.lesson_date <= CURDATE()) AS lessons_count
     FROM teacher_profiles tp
     JOIN users u ON u.id = tp.user_id
     ORDER BY u.last_name, u.first_name`
  );

  if (rows.length === 0) return [];

  const teacherIds = rows.map(r => r.id);
  const [styles] = await pool.query(
    `SELECT ts.teacher_id, ds.id AS style_id, ds.name AS style_name
     FROM teacher_styles ts
     JOIN dance_styles ds ON ds.id = ts.style_id
     WHERE ts.teacher_id IN (?)`,
    [teacherIds]
  );

  const stylesMap = {};
  styles.forEach(s => {
    if (!stylesMap[s.teacher_id]) stylesMap[s.teacher_id] = [];
    stylesMap[s.teacher_id].push({ id: s.style_id, name: s.style_name });
  });

  return rows.map(t => ({
    ...t,
    styles: stylesMap[t.id] || [],
  }));
};

const findById = async (id) => {
  const [rows] = await pool.query(
    `SELECT
       tp.id, tp.user_id, tp.bio, tp.experience_years, tp.education,
       tp.rate_type, tp.rate_amount,
       u.first_name, u.last_name, u.email, u.phone, u.avatar_url,
       (SELECT COUNT(DISTINCT en.student_id)
        FROM lessons l2
        JOIN dance_groups dg2 ON dg2.id = l2.group_id
        JOIN enrollments en ON en.lesson_id = l2.id
        WHERE COALESCE(l2.teacher_id, dg2.teacher_id) = u.id) AS students_count,
       (SELECT COUNT(*)
        FROM lessons l3
        JOIN dance_groups dg3 ON dg3.id = l3.group_id
        WHERE COALESCE(l3.teacher_id, dg3.teacher_id) = u.id AND l3.lesson_date <= CURDATE()) AS lessons_count
     FROM teacher_profiles tp
     JOIN users u ON u.id = tp.user_id
     WHERE tp.id = ?`,
    [id]
  );

  if (!rows[0]) return null;

  const teacher = rows[0];

  const [styles] = await pool.query(
    `SELECT ds.id, ds.name
     FROM teacher_styles ts
     JOIN dance_styles ds ON ds.id = ts.style_id
     WHERE ts.teacher_id = ?`,
    [id]
  );

  teacher.styles = styles;
  return teacher;
};

const findByUserId = async (userId) => {
  const [rows] = await pool.query(
    `SELECT tp.id, tp.user_id, tp.bio, tp.experience_years, tp.education
     FROM teacher_profiles tp
     WHERE tp.user_id = ?`,
    [userId]
  );
  return rows[0] || null;
};

const create = async ({ user_id, bio, experience_years, education }) => {
  const [result] = await pool.query(
    `INSERT INTO teacher_profiles (user_id, bio, experience_years, education)
     VALUES (?, ?, ?, ?)`,
    [user_id, bio || null, experience_years || 0, education || null]
  );
  return result.insertId;
};

const update = async (id, { bio, experience_years, education }) => {
  const [result] = await pool.query(
    `UPDATE teacher_profiles
     SET bio = ?, experience_years = ?, education = ?
     WHERE id = ?`,
    [bio || null, experience_years || 0, education || null, id]
  );
  return result.affectedRows > 0;
};

const syncStyles = async (teacherId, styleIds) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    await conn.query(
      'DELETE FROM teacher_styles WHERE teacher_id = ?',
      [teacherId]
    );

    if (styleIds && styleIds.length > 0) {
      const values = styleIds.map(sid => [teacherId, sid]);
      await conn.query(
        'INSERT INTO teacher_styles (teacher_id, style_id) VALUES ?',
        [values]
      );
    }

    await conn.commit();
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
};

const findSchedule = async (teacherId, weekStart) => {
  const [rows] = await pool.query(
    `SELECT
       l.id, l.group_id, l.hall_id, l.lesson_date, l.start_time, l.end_time,
       dg.name AS group_name,
       h.name  AS hall_name,
       ds.name AS style_name
     FROM lessons l
     JOIN dance_groups dg ON dg.id = l.group_id
     JOIN halls h         ON h.id  = l.hall_id
     JOIN dance_styles ds ON ds.id = dg.style_id
     WHERE COALESCE(l.teacher_id, dg.teacher_id) = ?
       AND l.lesson_date >= ?
       AND l.lesson_date < DATE_ADD(?, INTERVAL 7 DAY)
     ORDER BY l.lesson_date, l.start_time`,
    [teacherId, weekStart, weekStart]
  );
  return rows;
};

const findGroups = async (teacherUserId) => {
  const [rows] = await pool.query(
    `SELECT
       dg.id, dg.name, dg.status,
       ds.name AS style_name,
       h.name  AS hall_name,
       COUNT(DISTINCT e.student_id) AS students_count
     FROM dance_groups dg
     JOIN dance_styles ds ON ds.id = dg.style_id
     JOIN halls h         ON h.id  = dg.hall_id
     LEFT JOIN lessons l  ON l.group_id = dg.id AND COALESCE(l.teacher_id, dg.teacher_id) = dg.teacher_id
     LEFT JOIN enrollments e ON e.lesson_id = l.id
     WHERE dg.teacher_id = ?
     GROUP BY dg.id, dg.name, dg.status, ds.name, h.name
     ORDER BY dg.name`,
    [teacherUserId]
  );
  return rows;
};

const setRate = async (teacherProfileId, rate_type, rate_amount) => {
  await pool.query(
    'UPDATE teacher_profiles SET rate_type = ?, rate_amount = ? WHERE id = ?',
    [rate_type, rate_amount, teacherProfileId]
  );
};

const getFinance = async (teacherProfileId, dateFrom, dateTo) => {
  const [[profile]] = await pool.query(
    'SELECT user_id, rate_type, rate_amount FROM teacher_profiles WHERE id = ?',
    [teacherProfileId]
  );
  if (!profile) return null;

  const paidParams = [teacherProfileId];
  let paidWhere = '';
  if (dateFrom) { paidWhere += ' AND created_at >= ?'; paidParams.push(dateFrom); }
  if (dateTo)   { paidWhere += ' AND created_at <= ?'; paidParams.push(dateTo + ' 23:59:59'); }
  const [[{ total_paid }]] = await pool.query(
    `SELECT COALESCE(SUM(amount), 0) AS total_paid FROM teacher_payouts WHERE teacher_id = ?${paidWhere}`,
    paidParams
  );

  const dateWhere = [];
  const baseParams = [profile.user_id];
  if (dateFrom) { dateWhere.push('l.lesson_date >= ?'); baseParams.push(dateFrom); }
  if (dateTo)   { dateWhere.push('l.lesson_date <= ?'); baseParams.push(dateTo);   }
  const extraWhere = dateWhere.length ? ' AND ' + dateWhere.join(' AND ') : '';

  const [[{ total_hours, total_lessons, conducted_lessons, conducted_hours }]] = await pool.query(`
    SELECT
      COALESCE(SUM(TIMESTAMPDIFF(MINUTE,
        CONCAT(l.lesson_date, ' ', l.start_time),
        CONCAT(l.lesson_date, ' ', l.end_time)
      ) / 60.0), 0) AS total_hours,
      COUNT(DISTINCT l.id) AS total_lessons,
      COUNT(DISTINCT CASE WHEN a_agg.lesson_id IS NOT NULL THEN l.id END) AS conducted_lessons,
      COALESCE(SUM(CASE WHEN a_agg.lesson_id IS NOT NULL THEN
        TIMESTAMPDIFF(MINUTE,
          CONCAT(l.lesson_date, ' ', l.start_time),
          CONCAT(l.lesson_date, ' ', l.end_time)
        ) / 60.0 ELSE 0 END), 0) AS conducted_hours
    FROM lessons l
    JOIN dance_groups dg ON dg.id = l.group_id
    LEFT JOIN (
      SELECT DISTINCT lesson_id FROM attendance WHERE status = 'present'
    ) a_agg ON a_agg.lesson_id = l.id
    WHERE COALESCE(l.teacher_id, dg.teacher_id) = ? AND l.lesson_date <= CURDATE()
    ${extraWhere}
  `, baseParams);

  const rate_type   = profile.rate_type === 'per_student' ? 'per_student' : 'per_lesson';
  const rate_amount = Number(profile.rate_amount) || 0;
  const paid        = Number(total_paid);
  let total_earnings   = 0;
  let total_attendance = 0;

  if (rate_type === 'per_lesson') {
    total_earnings = rate_amount * Number(conducted_lessons);
  } else {
    const [[{ present_count }]] = await pool.query(`
      SELECT COUNT(a.id) AS present_count
      FROM attendance a
      JOIN lessons l ON l.id = a.lesson_id
      JOIN dance_groups dg ON dg.id = l.group_id
      WHERE COALESCE(l.teacher_id, dg.teacher_id) = ? AND a.status = 'present' AND l.lesson_date <= CURDATE()
      ${extraWhere}
    `, baseParams);
    total_attendance = Number(present_count);
    total_earnings   = rate_amount * total_attendance;
  }

  const balance = total_earnings - paid;

  return {
    rate_type,
    rate_amount,
    total_paid: paid,
    total_hours: Number(total_hours),
    total_lessons: Number(total_lessons),
    conducted_lessons: Number(conducted_lessons),
    conducted_hours: Number(conducted_hours),
    total_attendance,
    total_earnings,
    balance,
  };
};

const getPayrollSummary = async (month, year) => {
  const dateFrom = `${year}-${String(month).padStart(2, '0')}-01`;
  const lastDay  = new Date(year, month, 0).getDate();
  const dateTo   = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;

  const [rows] = await pool.query(`
    SELECT
      tp.id   AS teacher_profile_id,
      u.id    AS user_id,
      u.first_name, u.last_name, u.email,
      tp.rate_type, tp.rate_amount,
      COALESCE(COUNT(DISTINCT eff_l.id), 0) AS total_lessons,
      COALESCE(COUNT(DISTINCT CASE WHEN cond.lesson_id IS NOT NULL THEN eff_l.id END), 0) AS conducted_lessons,
      COALESCE(SUM(TIMESTAMPDIFF(MINUTE,
        CONCAT(eff_l.lesson_date,' ',eff_l.start_time),
        CONCAT(eff_l.lesson_date,' ',eff_l.end_time)
      )/60.0), 0) AS total_hours,
      COALESCE(SUM(CASE WHEN cond.lesson_id IS NOT NULL THEN
        TIMESTAMPDIFF(MINUTE,
          CONCAT(eff_l.lesson_date,' ',eff_l.start_time),
          CONCAT(eff_l.lesson_date,' ',eff_l.end_time)
        )/60.0 ELSE 0 END), 0) AS conducted_hours,
      COALESCE(SUM(att_agg.present_count), 0) AS total_present
    FROM teacher_profiles tp
    JOIN users u ON u.id = tp.user_id
    LEFT JOIN (
      SELECT l.id, l.lesson_date, l.start_time, l.end_time,
             COALESCE(l.teacher_id, dg.teacher_id) AS effective_teacher_id
      FROM lessons l
      JOIN dance_groups dg ON dg.id = l.group_id
      WHERE l.lesson_date BETWEEN ? AND ? AND l.lesson_date <= CURDATE()
    ) eff_l ON eff_l.effective_teacher_id = u.id
    LEFT JOIN (
      SELECT DISTINCT lesson_id FROM attendance WHERE status = 'present'
    ) cond ON cond.lesson_id = eff_l.id
    LEFT JOIN (
      SELECT lesson_id, SUM(status = 'present') AS present_count
      FROM attendance GROUP BY lesson_id
    ) att_agg ON att_agg.lesson_id = eff_l.id
    GROUP BY tp.id, u.id, u.first_name, u.last_name, u.email, tp.rate_type, tp.rate_amount
    ORDER BY u.last_name, u.first_name
  `, [dateFrom, dateTo]);

  const result = [];
  for (const row of rows) {
    const rate_amount       = Number(row.rate_amount);
    const rate_type         = row.rate_type === 'per_student' ? 'per_student' : 'per_lesson';
    const total_lessons     = Number(row.total_lessons);
    const conducted_lessons = Number(row.conducted_lessons);
    const total_present     = Number(row.total_present);

    const total_earnings = rate_type === 'per_lesson'
      ? rate_amount * conducted_lessons
      : rate_amount * total_present;

    result.push({
      teacher_profile_id: row.teacher_profile_id,
      first_name:         row.first_name,
      last_name:          row.last_name,
      email:              row.email,
      rate_type,
      rate_amount,
      total_lessons,
      conducted_lessons,
      total_hours:        Math.round(Number(row.total_hours) * 10) / 10,
      conducted_hours:    Math.round(Number(row.conducted_hours) * 10) / 10,
      total_enrollments:  total_present,
      total_earnings,
    });
  }

  return result;
};

const addPayout = async (teacherProfileId, amount, note, createdBy) => {
  const [result] = await pool.query(
    'INSERT INTO teacher_payouts (teacher_id, amount, note, created_by) VALUES (?, ?, ?, ?)',
    [teacherProfileId, amount, note || null, createdBy]
  );
  return result.insertId;
};

const getPayouts = async (teacherProfileId) => {
  const [rows] = await pool.query(
    `SELECT p.id, p.amount, p.note, p.created_at,
            u.first_name AS admin_first_name, u.last_name AS admin_last_name
     FROM teacher_payouts p
     JOIN users u ON u.id = p.created_by
     WHERE p.teacher_id = ?
     ORDER BY p.created_at DESC`,
    [teacherProfileId]
  );
  return rows;
};

module.exports = {
  findAll,
  findById,
  findByUserId,
  create,
  update,
  syncStyles,
  findSchedule,
  findGroups,
  setRate,
  getFinance,
  getPayrollSummary,
  addPayout,
  getPayouts,
};
