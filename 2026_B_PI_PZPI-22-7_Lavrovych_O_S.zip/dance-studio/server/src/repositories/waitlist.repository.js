const pool = require('../config/db');

const findByLesson = async (lessonId) => {
  const [rows] = await pool.query(
    `SELECT w.id, w.student_id, w.lesson_id, w.position, w.created_at,
       u.first_name, u.last_name, u.email
     FROM waitlist w
     JOIN users u ON u.id = w.student_id
     WHERE w.lesson_id = ?
     ORDER BY w.position ASC, w.created_at ASC`,
    [lessonId]
  );
  return rows;
};

const findByStudent = async (studentId) => {
  const [rows] = await pool.query(
    `SELECT w.id, w.student_id, w.lesson_id, w.position, w.created_at,
       l.lesson_date, l.start_time, l.end_time,
       dg.name AS group_name,
       ds.name AS style_name,
       h.name  AS hall_name
     FROM waitlist w
     JOIN lessons l      ON l.id  = w.lesson_id
     JOIN dance_groups dg ON dg.id = l.group_id
     JOIN dance_styles ds ON ds.id = dg.style_id
     JOIN halls h         ON h.id  = l.hall_id
     WHERE w.student_id = ?
     ORDER BY l.lesson_date, l.start_time`,
    [studentId]
  );
  return rows;
};

const findOne = async (studentId, lessonId) => {
  const [[row]] = await pool.query(
    'SELECT * FROM waitlist WHERE student_id = ? AND lesson_id = ?',
    [studentId, lessonId]
  );
  return row || null;
};

const findById = async (id) => {
  const [[row]] = await pool.query('SELECT * FROM waitlist WHERE id = ?', [id]);
  return row || null;
};

const add = async (studentId, lessonId) => {
  const [[{ maxPos }]] = await pool.query(
    'SELECT COALESCE(MAX(position), 0) AS maxPos FROM waitlist WHERE lesson_id = ?',
    [lessonId]
  );
  const [result] = await pool.query(
    'INSERT INTO waitlist (student_id, lesson_id, position) VALUES (?, ?, ?)',
    [studentId, lessonId, maxPos + 1]
  );
  return result.insertId;
};

const remove = async (id) => {
  const [result] = await pool.query('DELETE FROM waitlist WHERE id = ?', [id]);
  return result.affectedRows > 0;
};

const removeByStudentLesson = async (studentId, lessonId) => {
  const [result] = await pool.query(
    'DELETE FROM waitlist WHERE student_id = ? AND lesson_id = ?',
    [studentId, lessonId]
  );
  return result.affectedRows > 0;
};

const getFirst = async (lessonId) => {
  const [[row]] = await pool.query(
    'SELECT * FROM waitlist WHERE lesson_id = ? ORDER BY position ASC, created_at ASC LIMIT 1',
    [lessonId]
  );
  return row || null;
};

module.exports = { findByLesson, findByStudent, findOne, findById, add, remove, removeByStudentLesson, getFirst };
