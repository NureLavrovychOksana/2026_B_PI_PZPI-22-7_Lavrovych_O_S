const pool = require('../config/db');

const getDebtors = async () => {
  const [rows] = await pool.query(
    `SELECT u.id, u.first_name, u.last_name, u.email, u.phone,
            (SELECT MAX(ss2.expiry_date) FROM student_subscriptions ss2
             WHERE ss2.student_id = u.id AND ss2.expiry_date IS NOT NULL) AS last_expiry,
            (SELECT MAX(p2.payment_date) FROM payments p2
             WHERE p2.user_id = u.id AND p2.status = 'success') AS last_payment
     FROM users u
     WHERE u.role = 'student'
       AND NOT EXISTS (
         SELECT 1 FROM student_subscriptions ss
         WHERE ss.student_id = u.id AND ss.status = 'active'
           AND (ss.expiry_date IS NULL OR ss.expiry_date >= CURDATE())
       )
     ORDER BY last_payment ASC`
  );
  return rows;
};

const getExpiringSubscriptions = async (days = 14) => {
  const [rows] = await pool.query(
    `SELECT u.id, u.first_name, u.last_name, u.email, u.phone,
            ss.id AS subscription_id, ss.sessions_left, ss.expiry_date,
            sp.name AS plan_name, sp.type AS plan_type,
            DATEDIFF(ss.expiry_date, CURDATE()) AS days_left
     FROM student_subscriptions ss
     JOIN users              u  ON u.id  = ss.student_id
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.status = 'active' AND ss.expiry_date IS NOT NULL
       AND ss.expiry_date >= CURDATE() AND ss.expiry_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY)
     ORDER BY ss.expiry_date ASC`,
    [days]
  );
  return rows;
};

const getStudentPersonalStats = async (studentId) => {
  const [[attendance]] = await pool.query(
    `SELECT COUNT(*) AS total,
            SUM(status = 'present') AS present, SUM(status = 'absent') AS absent, SUM(status = 'excused') AS excused,
            ROUND(SUM(status = 'present') * 100.0 / NULLIF(COUNT(*), 0)) AS attendance_percent
     FROM attendance WHERE student_id = ?`,
    [studentId]
  );
  const [[currentMonth]] = await pool.query(
    `SELECT COUNT(*) AS total, SUM(a.status = 'present') AS present
     FROM attendance a JOIN lessons l ON l.id = a.lesson_id
     WHERE a.student_id = ? AND MONTH(l.lesson_date) = MONTH(CURDATE()) AND YEAR(l.lesson_date) = YEAR(CURDATE())`,
    [studentId]
  );
  const [groupStats] = await pool.query(
    `SELECT dg.name AS group_name, ds.name AS style_name,
            COUNT(DISTINCT a.lesson_id) AS attended_lessons,
            ROUND(SUM(a.status = 'present') * 100.0 / NULLIF(COUNT(a.id), 0)) AS attendance_percent
     FROM attendance a
     JOIN lessons l ON l.id = a.lesson_id JOIN dance_groups dg ON dg.id = l.group_id JOIN dance_styles ds ON ds.id = dg.style_id
     WHERE a.student_id = ?
     GROUP BY dg.id, dg.name, ds.name ORDER BY attended_lessons DESC`,
    [studentId]
  );
  return { attendance, current_month: currentMonth, by_group: groupStats };
};

const getStudentsAtRisk = async (maxSessions = 2) => {
  const [rows] = await pool.query(
    `SELECT u.id, u.first_name, u.last_name, u.email, u.phone,
            ss.id AS subscription_id, ss.sessions_left, ss.expiry_date,
            sp.name AS plan_name, sp.price AS plan_price,
            (SELECT MAX(l2.lesson_date) FROM enrollments e2 JOIN lessons l2 ON l2.id = e2.lesson_id
             WHERE e2.student_id = u.id AND l2.lesson_date <= CURDATE()) AS last_lesson_date
     FROM student_subscriptions ss
     JOIN users              u  ON u.id  = ss.student_id
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.status = 'active' AND ss.sessions_left IS NOT NULL AND ss.sessions_left <= ?
       AND (ss.expiry_date IS NULL OR ss.expiry_date >= CURDATE())
     ORDER BY ss.sessions_left ASC, u.last_name ASC`,
    [maxSessions]
  );
  return rows;
};

module.exports = { getDebtors, getExpiringSubscriptions, getStudentPersonalStats, getStudentsAtRisk };
