const pool = require('../config/db');

const getTeacherReport = async (teacherId, { dateFrom, dateTo } = {}) => {
  const [[teacher]] = await pool.query(
    `SELECT u.id, u.first_name, u.last_name, u.email, u.phone,
            tp.bio, tp.experience_years, tp.education,
            COUNT(DISTINCT dg.id) AS groups_count
     FROM users u
     LEFT JOIN teacher_profiles tp ON tp.user_id = u.id
     LEFT JOIN dance_groups     dg ON dg.teacher_id = u.id AND dg.status = 'active'
     WHERE u.id = ? AND u.role = 'teacher'
     GROUP BY u.id`,
    [teacherId]
  );
  if (!teacher) return null;

  const [styles] = await pool.query(
    `SELECT ds.name FROM teacher_styles ts
     JOIN teacher_profiles tp ON tp.id = ts.teacher_id
     JOIN dance_styles     ds ON ds.id = ts.style_id
     WHERE tp.user_id = ?`,
    [teacherId]
  );

  let lessonSql = `
    SELECT COUNT(DISTINCT l.id) AS total_lessons, COUNT(DISTINCT e.student_id) AS unique_students,
           COUNT(DISTINCT a.id) AS total_attendance,
           COUNT(DISTINCT CASE WHEN a.status = 'present' THEN a.id END) AS present_count,
           ROUND(COUNT(DISTINCT CASE WHEN a.status = 'present' THEN a.id END) * 100.0 / NULLIF(COUNT(DISTINCT a.id), 0)) AS attendance_percent
    FROM lessons l
    JOIN dance_groups dg ON dg.id = l.group_id
    LEFT JOIN enrollments e ON e.lesson_id = l.id
    LEFT JOIN attendance  a ON a.lesson_id = l.id
    WHERE COALESCE(l.teacher_id, dg.teacher_id) = ?`;
  const params = [teacherId];
  if (dateFrom) { lessonSql += ' AND l.lesson_date >= ?'; params.push(dateFrom); }
  if (dateTo)   { lessonSql += ' AND l.lesson_date <= ?'; params.push(dateTo);   }
  const [[stats]] = await pool.query(lessonSql, params);

  const [groupStats] = await pool.query(
    `SELECT dg.id, dg.name AS group_name, ds.name AS style_name,
            COUNT(DISTINCT e.student_id) AS students_count,
            COUNT(DISTINCT l.id) AS lessons_count
     FROM dance_groups dg
     JOIN dance_styles ds ON ds.id = dg.style_id
     LEFT JOIN lessons     l ON l.group_id  = dg.id
     LEFT JOIN enrollments e ON e.lesson_id = l.id
     WHERE dg.teacher_id = ? AND dg.status = 'active'
     GROUP BY dg.id, dg.name, ds.name`,
    [teacherId]
  );

  return { teacher: { ...teacher, styles: styles.map(s => s.name) }, stats, groups: groupStats };
};

const getTeacherTimesheet = async (teacherId, { dateFrom, dateTo } = {}) => {
  let sql = `
    SELECT l.id AS lesson_id, DATE_FORMAT(l.lesson_date, '%Y-%m-%d') AS lesson_date,
           l.start_time, l.end_time,
           ROUND(TIMESTAMPDIFF(MINUTE, l.start_time, l.end_time) / 60.0, 2) AS duration_hours,
           dg.name AS group_name, ds.name AS style_name, h.name AS hall_name,
           COUNT(DISTINCT e.id) AS enrolled_count,
           COUNT(DISTINCT CASE WHEN a.status = 'present' THEN a.id END) AS present_count,
           COUNT(DISTINCT CASE WHEN a.status = 'absent'  THEN a.id END) AS absent_count
    FROM lessons l
    JOIN dance_groups    dg ON dg.id = l.group_id
    JOIN dance_styles    ds ON ds.id = dg.style_id
    JOIN halls           h  ON h.id  = l.hall_id
    LEFT JOIN enrollments e ON e.lesson_id = l.id
    LEFT JOIN attendance  a ON a.lesson_id = l.id
    WHERE COALESCE(l.teacher_id, dg.teacher_id) = ?`;
  const params = [teacherId];
  if (dateFrom) { sql += ' AND l.lesson_date >= ?'; params.push(dateFrom); }
  if (dateTo)   { sql += ' AND l.lesson_date <= ?'; params.push(dateTo);   }
  sql += ` GROUP BY l.id, l.lesson_date, l.start_time, l.end_time, dg.name, ds.name, h.name
           ORDER BY l.lesson_date DESC, l.start_time DESC LIMIT 200`;
  const [rows] = await pool.query(sql, params);
  return rows.map(r => ({
    lesson_id:      Number(r.lesson_id),
    lesson_date:    r.lesson_date,
    start_time:     String(r.start_time).slice(0, 5),
    end_time:       String(r.end_time).slice(0, 5),
    duration_hours: Number(r.duration_hours) || 0,
    group_name:     r.group_name,
    style_name:     r.style_name,
    hall_name:      r.hall_name,
    enrolled_count: Number(r.enrolled_count),
    present_count:  Number(r.present_count),
    absent_count:   Number(r.absent_count),
  }));
};

const getTeacherDisciplineStats = async (teacherId) => {
  const [[month]] = await pool.query(
    `SELECT COUNT(DISTINCT l.id) AS total_lessons,
            COUNT(DISTINCT CASE WHEN a.status = 'present' THEN l.id END) AS conducted_lessons,
            COUNT(a.id) AS total_marks,
            COALESCE(SUM(a.status = 'absent'), 0) AS absent_count,
            COALESCE(SUM(a.status = 'excused'), 0) AS excused_count,
            ROUND(COALESCE(SUM(a.status = 'absent'), 0) * 100.0 / NULLIF(COUNT(a.id), 0)) AS absence_rate
     FROM lessons l
     JOIN dance_groups dg ON dg.id = l.group_id
     LEFT JOIN attendance a ON a.lesson_id = l.id
     WHERE COALESCE(l.teacher_id, dg.teacher_id) = ?
       AND MONTH(l.lesson_date) = MONTH(CURDATE()) AND YEAR(l.lesson_date) = YEAR(CURDATE())`,
    [teacherId]
  );
  const [[ret]] = await pool.query(
    `SELECT COUNT(DISTINCT CASE WHEN lc >= 2 THEN student_id END) AS retained,
            COUNT(DISTINCT student_id) AS total
     FROM (
       SELECT a.student_id, COUNT(a.id) AS lc FROM attendance a
       JOIN lessons l ON l.id = a.lesson_id
       JOIN dance_groups dg ON dg.id = l.group_id
       WHERE COALESCE(l.teacher_id, dg.teacher_id) = ?
         AND a.status = 'present'
         AND MONTH(l.lesson_date) = MONTH(CURDATE()) AND YEAR(l.lesson_date) = YEAR(CURDATE())
       GROUP BY a.student_id
     ) t`,
    [teacherId]
  );
  return {
    total_lessons:     Number(month.total_lessons)     || 0,
    conducted_lessons: Number(month.conducted_lessons) || 0,
    total_marks:       Number(month.total_marks)       || 0,
    absent_count:      Number(month.absent_count)      || 0,
    excused_count:     Number(month.excused_count)     || 0,
    absence_rate:      Number(month.absence_rate)      || 0,
    retained:          Number(ret.retained)            || 0,
    total_students:    Number(ret.total)               || 0,
    retention_rate:    Number(ret.total) > 0
      ? Math.round((Number(ret.retained) / Number(ret.total)) * 100)
      : 0,
  };
};

module.exports = { getTeacherReport, getTeacherTimesheet, getTeacherDisciplineStats };
