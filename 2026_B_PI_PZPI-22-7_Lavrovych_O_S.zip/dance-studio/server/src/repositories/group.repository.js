const pool = require('../config/db');

const findAll = async (teacherId = null, { styleId = null } = {}) => {
  const lessonJoin = teacherId
    ? `LEFT JOIN lessons l ON l.group_id = dg.id AND COALESCE(l.teacher_id, dg.teacher_id) = dg.teacher_id`
    : `LEFT JOIN lessons l ON l.group_id = dg.id`;

  const base = `
    SELECT
      dg.id, dg.name, dg.status, dg.level,
      dg.style_id, dg.teacher_id, dg.hall_id,
      dg.lessons_per_week,
      COALESCE(glr.lesson_duration, 60)   AS lesson_duration,
      COALESCE(glr.is_children,    false) AS is_children,
      ds.name        AS style_name,
      h.name         AS hall_name,
      h.capacity     AS hall_capacity,
      u.first_name   AS teacher_first_name,
      u.last_name    AS teacher_last_name,
      COUNT(DISTINCT e.student_id) AS students_count
    FROM dance_groups dg
    JOIN dance_styles ds ON ds.id = dg.style_id
    JOIN halls        h  ON h.id  = dg.hall_id
    JOIN users        u  ON u.id  = dg.teacher_id
    LEFT JOIN group_lesson_requirements glr ON glr.group_id = dg.id
    ${lessonJoin}
    LEFT JOIN enrollments e ON e.lesson_id = l.id
  `;

  const conditions = [];
  const params = [];

  if (teacherId) { conditions.push('dg.teacher_id = ?'); params.push(teacherId); }
  if (styleId)   { conditions.push('dg.style_id = ?');   params.push(styleId); }

  const where = conditions.length ? ' WHERE ' + conditions.join(' AND ') : '';
  const [rows] = await pool.query(base + where + ' GROUP BY dg.id ORDER BY dg.name', params);
  return rows;
};

const findById = async (id) => {
  const [rows] = await pool.query(
    `SELECT
       dg.id, dg.name, dg.status, dg.level,
       dg.style_id, dg.teacher_id, dg.hall_id,
       dg.lessons_per_week,
       COALESCE(glr.lesson_duration, 60)   AS lesson_duration,
       COALESCE(glr.is_children,    false) AS is_children,
       ds.name        AS style_name,
       h.name         AS hall_name,
       h.capacity     AS hall_capacity,
       u.first_name   AS teacher_first_name,
       u.last_name    AS teacher_last_name,
       COUNT(DISTINCT e.student_id) AS students_count
     FROM dance_groups dg
     JOIN dance_styles ds ON ds.id = dg.style_id
     JOIN halls        h  ON h.id  = dg.hall_id
     JOIN users        u  ON u.id  = dg.teacher_id
     LEFT JOIN group_lesson_requirements glr ON glr.group_id = dg.id
     LEFT JOIN lessons    l ON l.group_id   = dg.id
     LEFT JOIN enrollments e ON e.lesson_id = l.id
     WHERE dg.id = ?
     GROUP BY dg.id`,
    [id]
  );
  return rows[0] || null;
};

const create = async ({ name, style_id, level, teacher_id, hall_id, status, lessons_per_week }) => {
  const [result] = await pool.query(
    `INSERT INTO dance_groups (name, style_id, level, teacher_id, hall_id, status, lessons_per_week)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [name, style_id, level || 'starter', teacher_id, hall_id, status || 'active', lessons_per_week ?? 2]
  );
  return result.insertId;
};

const update = async (id, { name, style_id, level, teacher_id, hall_id, status, lessons_per_week }) => {
  const [result] = await pool.query(
    `UPDATE dance_groups
     SET name = ?, style_id = ?, level = ?, teacher_id = ?, hall_id = ?, status = ?, lessons_per_week = ?
     WHERE id = ?`,
    [name, style_id, level, teacher_id, hall_id, status, lessons_per_week ?? 2, id]
  );
  return result.affectedRows > 0;
};

const remove = async (id) => {
  const [result] = await pool.query(
    'DELETE FROM dance_groups WHERE id = ?',
    [id]
  );
  return result.affectedRows > 0;
};

const findAttendanceStats = async (groupId, dateFrom, dateTo) => {
  const [rows] = await pool.query(
    `SELECT
       u.id AS student_id,
       u.first_name, u.last_name,
       COUNT(a.id)                                              AS total,
       SUM(a.status = 'present')                               AS present,
       SUM(a.status = 'absent')                                AS absent,
       SUM(a.status = 'excused')                               AS excused,
       ROUND(SUM(a.status = 'present') / COUNT(a.id) * 100, 1) AS percent
     FROM enrollments e
     JOIN lessons l ON l.id = e.lesson_id
     JOIN users u   ON u.id = e.student_id
     LEFT JOIN attendance a
           ON a.lesson_id = l.id AND a.student_id = u.id
     WHERE l.group_id = ?
       AND (? IS NULL OR l.lesson_date >= ?)
       AND (? IS NULL OR l.lesson_date <= ?)
     GROUP BY u.id
     ORDER BY u.last_name`,
    [groupId, dateFrom || null, dateFrom || null, dateTo || null, dateTo || null]
  );
  return rows;
};

const countLessons = async (groupId) => {
  const [[row]] = await pool.query(
    'SELECT COUNT(*) AS total FROM lessons WHERE group_id = ?',
    [groupId]
  );
  return row.total;
};

const reassignFutureLessons = async (groupId, newTeacherId, oldTeacherId) => {
  if (oldTeacherId) {
    await pool.query(
      `UPDATE lessons SET teacher_id = ? WHERE group_id = ? AND lesson_date < CURDATE() AND (teacher_id IS NULL OR teacher_id = ?)`,
      [oldTeacherId, groupId, oldTeacherId]
    );
  }
  await pool.query(
    `UPDATE lessons SET teacher_id = ? WHERE group_id = ? AND lesson_date >= CURDATE()`,
    [newTeacherId, groupId]
  );
};

module.exports = {
  findAll,
  findById,
  create,
  update,
  remove,
  findAttendanceStats,
  countLessons,
  reassignFutureLessons,
};