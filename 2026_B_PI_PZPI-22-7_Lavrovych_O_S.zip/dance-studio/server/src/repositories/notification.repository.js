const pool = require('../config/db');

const create = async ({ userId, type, title, body }) => {
  const [result] = await pool.query(
    `INSERT INTO notifications (user_id, type, title, body)
     VALUES (?, ?, ?, ?)`,
    [userId, type, title, body || null]
  );
  return result.insertId;
};

const findByUser = async (userId) => {
  const [rows] = await pool.query(
    `SELECT id, type, title, body, is_read, created_at
     FROM notifications
     WHERE user_id = ?
     ORDER BY created_at DESC`,
    [userId]
  );
  return rows;
};

const markRead = async (id, userId) => {
  const [result] = await pool.query(
    `UPDATE notifications
     SET is_read = 1
     WHERE id = ? AND user_id = ?`,
    [id, userId]
  );
  return result.affectedRows > 0;
};

const markAllRead = async (userId) => {
  const [result] = await pool.query(
    `UPDATE notifications SET is_read = 1 WHERE user_id = ?`,
    [userId]
  );
  return result.affectedRows;
};

const countUnread = async (userId) => {
  const [[row]] = await pool.query(
    `SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND is_read = 0`,
    [userId]
  );
  return row.count;
};

const broadcast = async ({ userIds, type, title, body }) => {
  if (!userIds || userIds.length === 0) return 0;
  const values = userIds.map(uid => [uid, type, title, body || null]);
  const [result] = await pool.query(
    `INSERT INTO notifications (user_id, type, title, body) VALUES ?`,
    [values]
  );
  return result.affectedRows;
};

module.exports = { create, findByUser, markRead, markAllRead, countUnread, broadcast };