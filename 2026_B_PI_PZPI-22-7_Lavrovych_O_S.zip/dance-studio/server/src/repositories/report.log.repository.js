const pool = require('../config/db');

const getAttendanceLogs = async () => {
  const [rows] = await pool.query(
    `SELECT DATE_FORMAT(l.lesson_date, '%Y-%m-%d') AS date,
            TIME_FORMAT(l.start_time, '%H:%i') AS start_time,
            TIME_FORMAT(l.end_time,   '%H:%i') AS end_time,
            dg.name AS group_name, ds.name AS style_name,
            COALESCE(CONCAT(teacher.first_name, ' ', teacher.last_name), '') AS teacher_name,
            CONCAT(student.first_name, ' ', student.last_name) AS student_name,
            student.email AS student_email,
            CASE a.status
              WHEN 'present' THEN 'Присутній'
              WHEN 'absent'  THEN 'Відсутній'
              WHEN 'excused' THEN 'Поважна причина'
              ELSE a.status
            END AS status,
            ROUND(TIMESTAMPDIFF(MINUTE, l.start_time, l.end_time) / 60.0, 2) AS duration_hours
     FROM attendance a
     JOIN lessons      l       ON l.id       = a.lesson_id
     JOIN dance_groups dg      ON dg.id      = l.group_id
     JOIN dance_styles ds      ON ds.id      = dg.style_id
     LEFT JOIN users   teacher ON teacher.id = COALESCE(l.teacher_id, dg.teacher_id)
     JOIN users        student ON student.id = a.student_id
     ORDER BY l.lesson_date DESC, l.start_time DESC
     LIMIT 5000`
  );
  return rows;
};

const getTransactionLogs = async () => {
  const [rows] = await pool.query(
    `SELECT DATE_FORMAT(p.payment_date, '%Y-%m-%d') AS date,
            p.id AS payment_id,
            CONCAT(u.first_name, ' ', u.last_name) AS student_name,
            u.email AS student_email, COALESCE(u.phone, '') AS student_phone,
            p.amount,
            CASE p.payment_method
              WHEN 'cash'   THEN 'Готівка'
              WHEN 'card'   THEN 'Картка'
              WHEN 'liqpay' THEN 'LiqPay'
              ELSE p.payment_method
            END AS payment_method,
            CASE p.status
              WHEN 'success'  THEN 'Успішно'
              WHEN 'pending'  THEN 'Очікує'
              WHEN 'failed'   THEN 'Помилка'
              WHEN 'refunded' THEN 'Повернення'
              ELSE p.status
            END AS payment_status,
            COALESCE(sp.name, '') AS plan_name,
            CASE sp.type
              WHEN 'COUNT'     THEN 'Кількісний'
              WHEN 'UNLIMITED' THEN 'Безлімітний'
              ELSE COALESCE(sp.type, '')
            END AS plan_type,
            COALESCE(ss.sessions_left, '') AS sessions_after_purchase
     FROM payments p
     JOIN users                   u  ON u.id  = p.user_id AND u.role = 'student'
     LEFT JOIN student_subscriptions ss ON ss.id  = p.subscription_id
     LEFT JOIN subscription_plans    sp ON sp.id  = ss.plan_id
     ORDER BY p.payment_date DESC
     LIMIT 5000`
  );
  return rows;
};

module.exports = { getAttendanceLogs, getTransactionLogs };
