const pool = require('../config/db');
const crypto = require('crypto');

const create = async (user_id) => {
  await pool.query(
    'DELETE FROM password_reset_tokens WHERE user_id = ?',
    [user_id]
  );

  const token = crypto.randomBytes(32).toString('hex');
  const expires_at = new Date(Date.now() + 60 * 60 * 1000); // 1 година

  await pool.query(
    'INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)',
    [user_id, token, expires_at]
  );

  return token;
};

const findByToken = async (token) => {
  const [rows] = await pool.query(
    `SELECT * FROM password_reset_tokens
     WHERE token = ?
       AND used = 0
       AND expires_at > NOW()`,
    [token]
  );
  return rows[0] || null;
};

const markUsed = async (token) => {
  await pool.query(
    'UPDATE password_reset_tokens SET used = 1 WHERE token = ?',
    [token]
  );
};

module.exports = { create, findByToken, markUsed };