const pool = require('../config/db');

const findByEmail = async (email) => {
  const [rows] = await pool.query(
    'SELECT * FROM users WHERE email = ?',
    [email]
  );
  return rows[0] || null;
};

const DEFAULT_NOTIF_PREFS = { email: true, sms: true, news: false, schedule: true };

const findById = async (id) => {
  const [rows] = await pool.query(
    `SELECT id, email, role, first_name, last_name, phone, avatar_url, student_secure_token, created_at, notification_prefs
     FROM users WHERE id = ?`,
    [id]
  );
  if (!rows[0]) return null;
  const row = rows[0];
  row.notification_prefs = row.notification_prefs
    ? (typeof row.notification_prefs === 'string' ? JSON.parse(row.notification_prefs) : row.notification_prefs)
    : DEFAULT_NOTIF_PREFS;
  return row;
};

const setNotifPrefs = async (id, prefs) => {
  await pool.query(
    'UPDATE users SET notification_prefs = ? WHERE id = ?',
    [JSON.stringify(prefs), id]
  );
};

const findBySecureToken = async (token) => {
  const [rows] = await pool.query(
    `SELECT id, email, role, first_name, last_name, phone, avatar_url, student_secure_token, created_at
     FROM users WHERE student_secure_token = ?`,
    [token]
  );
  return rows[0] || null;
};

const setSecureToken = async (id, token) => {
  await pool.query('UPDATE users SET student_secure_token = ? WHERE id = ?', [token, id]);
};

const create = async ({ email, password_hash, role, first_name, last_name, phone }) => {
  const [result] = await pool.query(
    `INSERT INTO users (email, password_hash, role, first_name, last_name, phone)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [email, password_hash, role || 'student', first_name, last_name, phone || null]
  );
  return result.insertId;
};

const findAll = async (role = null) => {
  const base = `
    SELECT id, email, role, first_name, last_name, phone, avatar_url, created_at
    FROM users
  `;
  if (role) {
    const [rows] = await pool.query(
      base + ' WHERE role = ? ORDER BY last_name, first_name',
      [role]
    );
    return rows;
  }
  const [rows] = await pool.query(base + ' ORDER BY last_name, first_name');
  return rows;
};

const updateAvatarUrl = async (id, avatarUrl) => {
  await pool.query('UPDATE users SET avatar_url = ? WHERE id = ?', [avatarUrl, id]);
};

const update = async (id, fields) => {
  const allowed = ['email', 'first_name', 'last_name', 'phone', 'role', 'password_hash'];
  const keys = Object.keys(fields).filter(k => allowed.includes(k));
  if (keys.length === 0) return false;

  const setClause = keys.map(k => `${k} = ?`).join(', ');
  const values = [...keys.map(k => fields[k]), id];

  const [result] = await pool.query(
    `UPDATE users SET ${setClause} WHERE id = ?`,
    values
  );
  return result.affectedRows > 0;
};

const remove = async (id) => {
  const [[{ groupCount }]] = await pool.query(
    'SELECT COUNT(*) AS groupCount FROM dance_groups WHERE teacher_id = ?', [id]
  );
  if (groupCount > 0) {
    const err = new Error(`Спочатку перепризначте ${groupCount} групу(и) цього викладача іншому`);
    err.status = 409;
    throw err;
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    await conn.query('DELETE FROM attendance            WHERE student_id = ?', [id]);
    await conn.query('DELETE FROM student_subscriptions WHERE student_id = ?', [id]);
    await conn.query('DELETE FROM payments              WHERE user_id    = ?', [id]);

    const [result] = await conn.query('DELETE FROM users WHERE id = ?', [id]);
    await conn.commit();
    return result.affectedRows > 0;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
};

const findStudentStats = async (studentId) => {
  const [[attendance]] = await pool.query(
    `SELECT
       COUNT(*) AS total_lessons,
       SUM(status = 'present') AS present_count,
       SUM(status = 'absent')  AS absent_count,
       SUM(status = 'excused') AS excused_count
     FROM attendance
     WHERE student_id = ?`,
    [studentId]
  );

  const [subscriptions] = await pool.query(
    `SELECT ss.*, sp.name AS plan_name, sp.type AS plan_type
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.student_id = ?
       AND ss.status = 'active'
     ORDER BY ss.expiry_date ASC
     LIMIT 1`,
    [studentId]
  );

  const [groups] = await pool.query(
    `SELECT DISTINCT dg.id, dg.name, ds.name AS style_name
     FROM enrollments e
     JOIN lessons l ON l.id = e.lesson_id
     JOIN dance_groups dg ON dg.id = l.group_id
     JOIN dance_styles ds ON ds.id = dg.style_id
     WHERE e.student_id = ?`,
    [studentId]
  );

  return {
    attendance,
    active_subscription: subscriptions[0] || null,
    groups,
  };
};

const searchStudents = async (query) => {
  const like = `%${query || ''}%`;
  const [rows] = await pool.query(
    `SELECT id, first_name, last_name, email, phone
     FROM users
     WHERE role = 'student'
       AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR CONCAT(first_name,' ',last_name) LIKE ?)
     ORDER BY last_name, first_name
     LIMIT 20`,
    [like, like, like, like]
  );
  return rows;
};

module.exports = {
  findByEmail,
  findById,
  findBySecureToken,
  setSecureToken,
  create,
  findAll,
  update,
  updateAvatarUrl,
  setNotifPrefs,
  remove,
  findStudentStats,
  searchStudents,
};