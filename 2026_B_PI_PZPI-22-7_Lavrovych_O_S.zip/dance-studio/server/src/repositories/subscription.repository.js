const pool = require('../config/db');

const findAllPlans = async ({ excludeTrial = false } = {}) => {
  const conditions = ['is_active = 1'];
  if (excludeTrial) conditions.push('price > 0');
  const [rows] = await pool.query(
    `SELECT * FROM subscription_plans WHERE ${conditions.join(' AND ')} ORDER BY price ASC`
  );
  return rows;
};

const findAllPlansAdmin = async () => {
  const [rows] = await pool.query(
    `SELECT * FROM subscription_plans ORDER BY is_active DESC, price ASC`
  );
  return rows;
};

const findTrialPlan = async () => {
  const [rows] = await pool.query(
    `SELECT * FROM subscription_plans WHERE price = 0 LIMIT 1`
  );
  return rows[0] || null;
};

const hasPhoneUsedTrial = async (phone) => {
  const [rows] = await pool.query(
    `SELECT 1 FROM users u
     JOIN student_subscriptions ss ON ss.student_id = u.id
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE u.phone = ? AND sp.price = 0
     LIMIT 1`,
    [phone]
  );
  return rows.length > 0;
};

const findPlanById = async (id) => {
  const [rows] = await pool.query(
    `SELECT * FROM subscription_plans WHERE id = ?`,
    [id]
  );
  return rows[0] || null;
};

const createPlan = async ({ name, type, sessionsCount, validityDays, price }) => {
  const [result] = await pool.query(
    `INSERT INTO subscription_plans (name, type, sessions_count, validity_days, price)
     VALUES (?, ?, ?, ?, ?)`,
    [name, type || 'COUNT', sessionsCount || null, validityDays || null, price]
  );
  return result.insertId;
};

const updatePlan = async (id, { name, type, sessionsCount, validityDays, price, isActive }) => {
  const fields = {};
  if (name          !== undefined) fields.name           = name;
  if (type          !== undefined) fields.type           = type;
  if (sessionsCount !== undefined) fields.sessions_count = sessionsCount;
  if (validityDays  !== undefined) fields.validity_days  = validityDays;
  if (price         !== undefined) fields.price          = price;
  if (isActive      !== undefined) fields.is_active      = isActive;

  const keys = Object.keys(fields);
  if (keys.length === 0) return false;

  const setClause = keys.map(k => `${k} = ?`).join(', ');
  const values    = [...keys.map(k => fields[k]), id];

  const [result] = await pool.query(
    `UPDATE subscription_plans SET ${setClause} WHERE id = ?`,
    values
  );
  return result.affectedRows > 0;
};

const removePlan = async (id) => {
  const [[{ cnt }]] = await pool.query(
    `SELECT COUNT(*) AS cnt FROM student_subscriptions
     WHERE plan_id = ? AND status IN ('active', 'pending')`,
    [id]
  );
  if (cnt > 0) return false;

  const [[{ hist }]] = await pool.query(
    `SELECT COUNT(*) AS hist FROM student_subscriptions WHERE plan_id = ?`,
    [id]
  );
  if (hist > 0) {
    await pool.query(`UPDATE subscription_plans SET is_active = 0 WHERE id = ?`, [id]);
    return true;
  }

  const [result] = await pool.query(`DELETE FROM subscription_plans WHERE id = ?`, [id]);
  return result.affectedRows > 0;
};

const EFFECTIVE_STATUS_SQL = `
  CASE
    WHEN ss.status = 'cancelled' THEN 'cancelled'
    WHEN ss.status = 'pending'   THEN 'pending'
    WHEN ss.status = 'exhausted' THEN 'exhausted'
    WHEN ss.expiry_date IS NOT NULL AND ss.expiry_date < CURDATE() THEN 'expired'
    WHEN ss.status = 'active' AND sp.type = 'COUNT' AND ss.sessions_left = 0 THEN 'exhausted'
    ELSE 'active'
  END
`;

const findByStudent = async (studentId) => {
  const [rows] = await pool.query(
    `SELECT
       ss.*,
       ${EFFECTIVE_STATUS_SQL} AS effective_status,
       sp.name           AS plan_name,
       sp.type           AS plan_type,
       sp.sessions_count AS plan_sessions_count,
       sp.validity_days  AS plan_validity_days,
       sp.price          AS plan_price
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.student_id = ?
     ORDER BY FIELD((${EFFECTIVE_STATUS_SQL}), 'active', 'pending', 'exhausted', 'expired', 'cancelled') ASC,
              ss.expiry_date ASC, ss.purchase_date ASC`,
    [studentId]
  );
  return rows;
};

const findAllActiveByStudent = async (studentId) => {
  const [rows] = await pool.query(
    `SELECT
       ss.*,
       'active' AS effective_status,
       sp.name           AS plan_name,
       sp.type           AS plan_type,
       sp.sessions_count AS plan_sessions_count,
       sp.price          AS plan_price,
       (SELECT COUNT(*) FROM enrollments e
        JOIN lessons l ON l.id = e.lesson_id
        WHERE e.subscription_id = ss.id AND l.lesson_date >= CURDATE()) AS sessions_frozen
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.student_id = ?
       AND ss.status = 'active'
       AND (ss.expiry_date IS NULL OR ss.expiry_date >= CURDATE())
       AND (sp.type = 'UNLIMITED' OR ss.sessions_left > 0)
     ORDER BY ss.expiry_date ASC`,
    [studentId]
  );
  return rows;
};

const findSubscriptionById = async (id) => {
  const [rows] = await pool.query(
    `SELECT
       ss.*,
       sp.name  AS plan_name,
       sp.type  AS plan_type,
       sp.price AS plan_price
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.id = ?`,
    [id]
  );
  return rows[0] || null;
};

const createSubscription = async ({
  studentId, planId, purchaseDate, activationDate, expiryDate, sessionsLeft, status
}) => {
  const [result] = await pool.query(
    `INSERT INTO student_subscriptions
       (student_id, plan_id, purchase_date, activation_date, expiry_date, sessions_left, status)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [studentId, planId, purchaseDate, activationDate, expiryDate || null, sessionsLeft || null, status || 'active']
  );
  return result.insertId;
};

const tryActivateNextPending = async (studentId) => {
  const [[pending]] = await pool.query(
    `SELECT ss.id, sp.validity_days, sp.type
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.student_id = ? AND ss.status = 'pending'
     ORDER BY ss.purchase_date ASC
     LIMIT 1`,
    [studentId]
  );
  if (!pending) return null;

  const now        = new Date();
  const activation = now.toISOString().slice(0, 10);
  let   expiry     = null;
  // COUNT plans without validity_days default to 30 days; UNLIMITED plans stay open-ended
  const days = pending.validity_days ?? (pending.type === 'COUNT' ? 30 : null);
  if (days) {
    const e = new Date(now);
    e.setDate(e.getDate() + days);
    expiry = e.toISOString().slice(0, 10);
  }

  await pool.query(
    `UPDATE student_subscriptions
     SET status = 'active', activation_date = ?, expiry_date = ?
     WHERE id = ? AND status = 'pending'`,
    [activation, expiry, pending.id]
  );
  return pending.id;
};

const updateSubscription = async (id, fields) => {
  const allowed = ['sessions_left', 'status', 'expiry_date'];
  const keys    = Object.keys(fields).filter(k => allowed.includes(k));
  if (keys.length === 0) return false;

  const setClause = keys.map(k => `${k} = ?`).join(', ');
  const values    = [...keys.map(k => fields[k]), id];

  const [result] = await pool.query(
    `UPDATE student_subscriptions SET ${setClause} WHERE id = ?`,
    values
  );
  return result.affectedRows > 0;
};

const findAllWithStudents = async () => {
  const [rows] = await pool.query(
    `SELECT
       ss.*,
       ${EFFECTIVE_STATUS_SQL} AS effective_status,
       sp.name           AS plan_name,
       sp.type           AS plan_type,
       sp.sessions_count AS plan_sessions_count,
       sp.validity_days  AS plan_validity_days,
       sp.price          AS plan_price,
       u.first_name,
       u.last_name,
       u.email           AS student_email
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     JOIN users u ON u.id = ss.student_id
     ORDER BY ss.purchase_date DESC, ss.id DESC`
  );
  return rows;
};

module.exports = {
  findAllPlans,
  findAllPlansAdmin,
  findTrialPlan,
  hasPhoneUsedTrial,
  findPlanById,
  createPlan,
  updatePlan,
  removePlan,
  findByStudent,
  findAllActiveByStudent,
  findAllWithStudents,
  findSubscriptionById,
  createSubscription,
  updateSubscription,
  tryActivateNextPending,
};