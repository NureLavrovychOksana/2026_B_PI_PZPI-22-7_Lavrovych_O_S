const pool = require('../config/db');

const findAll = async ({ includeArchived = false } = {}) => {
  const where = includeArchived ? '' : 'WHERE h.is_active = 1';
  const [rows] = await pool.query(`
    SELECT h.*,
      (SELECT COUNT(*) FROM lessons WHERE hall_id = h.id AND lesson_date >= CURDATE()) AS future_lessons_count
    FROM halls h
    ${where}
    ORDER BY h.name
  `);
  return rows;
};

const findById = async (id) => {
  const [rows] = await pool.query('SELECT * FROM halls WHERE id = ?', [id]);
  return rows[0] || null;
};

const create = async ({ name, capacity }) => {
  const [result] = await pool.query(
    'INSERT INTO halls (name, capacity) VALUES (?, ?)',
    [name, capacity || 20]
  );
  return result.insertId;
};

const update = async (id, { name, capacity }) => {
  const [result] = await pool.query(
    'UPDATE halls SET name = ?, capacity = ? WHERE id = ?',
    [name, capacity, id]
  );
  return result.affectedRows > 0;
};

const archive = async (id) => {
  await pool.query('UPDATE halls SET is_active = 0 WHERE id = ?', [id]);
};

const restore = async (id) => {
  await pool.query('UPDATE halls SET is_active = 1 WHERE id = ?', [id]);
};

const relocateAndArchive = async (fromId, toId) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [result] = await conn.query(
      'UPDATE lessons SET hall_id = ? WHERE hall_id = ? AND lesson_date >= CURDATE()',
      [toId, fromId]
    );
    await conn.query('UPDATE halls SET is_active = 0 WHERE id = ?', [fromId]);
    await conn.commit();
    return result.affectedRows;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
};

const remove = async (id) => {
  const [result] = await pool.query('DELETE FROM halls WHERE id = ?', [id]);
  return result.affectedRows > 0;
};

module.exports = { findAll, findById, create, update, archive, restore, relocateAndArchive, remove };
