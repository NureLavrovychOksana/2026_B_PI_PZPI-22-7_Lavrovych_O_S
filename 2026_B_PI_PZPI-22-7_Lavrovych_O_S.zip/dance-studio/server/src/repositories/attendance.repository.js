const pool = require('../config/db');

const findByLesson = async (lessonId) => {
  const [rows] = await pool.query(
    `SELECT
       a.id, COALESCE(a.status, 'absent') AS status, a.marked_at,
       u.id         AS student_id,
       u.first_name, u.last_name, u.email, u.avatar_url,
       ss.sessions_left,
       sp.name AS plan_name,
       sp.type AS plan_type
     FROM enrollments e
     JOIN users u ON u.id = e.student_id
     LEFT JOIN attendance a ON a.student_id = e.student_id AND a.lesson_id = e.lesson_id
     LEFT JOIN student_subscriptions ss
       ON ss.id = (
         SELECT id FROM student_subscriptions
         WHERE student_id = u.id AND status = 'active'
           AND (expiry_date IS NULL OR expiry_date >= CURDATE())
         ORDER BY expiry_date ASC LIMIT 1
       )
     LEFT JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE e.lesson_id = ?
     ORDER BY u.last_name, u.first_name`,
    [lessonId]
  );
  return rows;
};

const findByStudent = async (studentId, { dateFrom, dateTo } = {}) => {
  let sql = `
    SELECT
      a.id, a.status, a.marked_at,
      l.lesson_date, l.start_time, l.end_time,
      dg.name AS group_name,
      ds.name AS style_name
    FROM attendance a
    JOIN lessons      l  ON l.id  = a.lesson_id
    JOIN dance_groups dg ON dg.id = l.group_id
    JOIN dance_styles ds ON ds.id = dg.style_id
    WHERE a.student_id = ?
  `;
  const params = [studentId];

  if (dateFrom) { sql += ' AND l.lesson_date >= ?'; params.push(dateFrom); }
  if (dateTo)   { sql += ' AND l.lesson_date <= ?'; params.push(dateTo);   }

  sql += ' ORDER BY l.lesson_date DESC, l.start_time DESC';
  const [rows] = await pool.query(sql, params);
  return rows;
};

const findOne = async (studentId, lessonId) => {
  const [rows] = await pool.query(
    'SELECT * FROM attendance WHERE student_id = ? AND lesson_id = ?',
    [studentId, lessonId]
  );
  return rows[0] || null;
};

const findActiveSubscriptionForUpdate = async (conn, studentId, markedAt) => {
  const [rows] = await conn.query(
    `SELECT ss.id, ss.sessions_left, sp.type
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.student_id = ?
       AND ss.status = 'active'
       AND ss.activation_date <= ?
       AND (ss.expiry_date IS NULL OR ss.expiry_date >= ?)
       AND (sp.type = 'UNLIMITED' OR ss.sessions_left > 0)
     ORDER BY sp.price ASC, ss.expiry_date ASC
     LIMIT 1
     FOR UPDATE`,
    [studentId, markedAt, markedAt]
  );
  return rows[0] || null;
};

const deductSession = async (conn, subscriptionId) => {
  await conn.query(
    `UPDATE student_subscriptions
     SET sessions_left = sessions_left - 1
     WHERE id = ?`,
    [subscriptionId]
  );
};

const exhaustSubscription = async (conn, subscriptionId) => {
  await conn.query(
    `UPDATE student_subscriptions
     SET status = 'exhausted'
     WHERE id = ? AND sessions_left = 0`,
    [subscriptionId]
  );
};

const insertAttendance = async (conn, { studentId, lessonId, subscriptionId, status, markedAt }) => {
  const [result] = await conn.query(
    `INSERT INTO attendance (student_id, lesson_id, subscription_id, status, marked_at)
     VALUES (?, ?, ?, ?, ?)`,
    [studentId, lessonId, subscriptionId || null, status, markedAt]
  );
  return result.insertId;
};

const updateAttendance = async (id, status) => {
  const [result] = await pool.query(
    'UPDATE attendance SET status = ? WHERE id = ?',
    [status, id]
  );
  return result.affectedRows > 0;
};

module.exports = {
  findByLesson,
  findByStudent,
  findOne,
  findActiveSubscriptionForUpdate,
  deductSession,
  exhaustSubscription,
  insertAttendance,
  updateAttendance,
};