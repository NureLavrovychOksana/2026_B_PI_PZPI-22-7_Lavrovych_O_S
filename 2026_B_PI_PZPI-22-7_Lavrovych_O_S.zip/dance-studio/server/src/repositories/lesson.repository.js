const pool = require("../config/db");

const findAll = async ({ week, groupId, teacherId } = {}) => {
  let sql = `
    SELECT
      l.id, l.group_id, l.hall_id, l.lesson_date, l.start_time, l.end_time,
      l.status,
      dg.name        AS group_name,
      dg.level       AS group_level,
      ds.name        AS style_name,
      h.name         AS hall_name,
      h.capacity     AS hall_capacity,
      u.id           AS teacher_id,
      u.first_name   AS teacher_first_name,
      u.last_name    AS teacher_last_name,
      h.capacity - COUNT(e.id) AS free_spots
    FROM lessons l
    JOIN dance_groups dg ON dg.id = l.group_id
    JOIN dance_styles ds ON ds.id = dg.style_id
    JOIN halls        h  ON h.id  = l.hall_id
    JOIN users        u  ON u.id  = COALESCE(l.teacher_id, dg.teacher_id)
    LEFT JOIN enrollments e ON e.lesson_id = l.id
    WHERE 1=1
  `;
  const params = [];

  if (week) {
    sql += " AND l.lesson_date >= ? AND l.lesson_date < DATE_ADD(?, INTERVAL 7 DAY)";
    params.push(week, week);
  }
  if (groupId) {
    sql += " AND l.group_id = ?";
    params.push(groupId);
  }
  if (teacherId) {
    sql += " AND COALESCE(l.teacher_id, dg.teacher_id) = ?";
    params.push(teacherId);
  }

  sql += " GROUP BY l.id, u.id, u.first_name, u.last_name ORDER BY l.lesson_date, l.start_time";
  const [rows] = await pool.query(sql, params);
  return rows;
};

const findById = async (id) => {
  const [rows] = await pool.query(
    `SELECT
       l.id, l.group_id, l.hall_id, l.lesson_date, l.start_time, l.end_time,
       l.notes, l.notes_author_id,
       l.status,
       l.teacher_id   AS lesson_teacher_id,
       dg.name        AS group_name,
       dg.level       AS group_level,
       dg.teacher_id  AS group_teacher_id,
       ds.name        AS style_name,
       h.name         AS hall_name,
       h.capacity     AS hall_capacity,
       u.id           AS teacher_id,
       u.first_name   AS teacher_first_name,
       u.last_name    AS teacher_last_name,
       h.capacity - COUNT(e.id) AS free_spots
     FROM lessons l
     JOIN dance_groups dg ON dg.id = l.group_id
     JOIN dance_styles ds ON ds.id = dg.style_id
     JOIN halls        h  ON h.id  = l.hall_id
     JOIN users        u  ON u.id  = COALESCE(l.teacher_id, dg.teacher_id)
     LEFT JOIN enrollments e ON e.lesson_id = l.id
     WHERE l.id = ?
     GROUP BY l.id, u.id, u.first_name, u.last_name`,
    [id],
  );
  return rows[0] || null;
};

const updateNotes = async (id, notes, authorId) => {
  await pool.query(
    "UPDATE lessons SET notes = ?, notes_author_id = ? WHERE id = ?",
    [notes || null, authorId, id],
  );
  return findById(id);
};

const findNotesByGroup = async (groupId) => {
  const [rows] = await pool.query(
    `SELECT
       l.id, l.lesson_date, l.start_time, l.end_time, l.notes,
       l.notes_author_id,
       ds.name AS style_name,
       u.first_name AS author_first_name,
       u.last_name  AS author_last_name
     FROM lessons l
     JOIN dance_groups dg ON dg.id = l.group_id
     JOIN dance_styles ds ON ds.id = dg.style_id
     LEFT JOIN users u ON u.id = l.notes_author_id
     WHERE l.group_id = ?
       AND l.notes IS NOT NULL
       AND l.notes != ''
     ORDER BY l.lesson_date DESC, l.start_time DESC`,
    [groupId],
  );
  return rows;
};

const findConflicts = async ({
  hallId,
  groupId,
  lessonDate,
  startTime,
  endTime,
  excludeId = null,
}) => {
  let sql = `
    SELECT
      l.id, l.lesson_date, l.start_time, l.end_time,
      dg.name      AS group_name,
      dg.teacher_id,
      u.first_name AS teacher_first_name,
      u.last_name  AS teacher_last_name,
      h.name       AS hall_name,
      CASE
        WHEN l.hall_id = ?                              THEN 'hall'
        WHEN dg.teacher_id = (
          SELECT teacher_id FROM dance_groups WHERE id = ?
        )                                               THEN 'teacher'
        WHEN l.group_id = ?                             THEN 'group'
      END AS conflict_type
    FROM lessons l
    JOIN dance_groups dg ON dg.id = l.group_id
    JOIN halls        h  ON h.id  = l.hall_id
    JOIN users        u  ON u.id  = dg.teacher_id
    WHERE l.lesson_date = ?
      AND l.start_time  < ?
      AND l.end_time    > ?
      AND l.status != 'cancelled'
      AND (
        l.hall_id = ?
        OR dg.teacher_id = (SELECT teacher_id FROM dance_groups WHERE id = ?)
        OR l.group_id = ?
      )
  `;
  const params = [
    hallId,
    groupId,
    groupId,
    lessonDate,
    endTime,
    startTime,
    hallId,
    groupId,
    groupId,
  ];

  if (excludeId) {
    sql += " AND l.id != ?";
    params.push(excludeId);
  }

  const [rows] = await pool.query(sql, params);
  return rows;
};

const create = async ({ groupId, hallId, lessonDate, startTime, endTime }) => {
  const [result] = await pool.query(
    `INSERT INTO lessons (group_id, hall_id, lesson_date, start_time, end_time, teacher_id)
     SELECT ?, ?, ?, ?, ?, teacher_id FROM dance_groups WHERE id = ?`,
    [groupId, hallId, lessonDate, startTime, endTime, groupId],
  );
  return result.insertId;
};

const update = async (
  id,
  { groupId, hallId, lessonDate, startTime, endTime, updateTeacher = false },
) => {
  let sql = `UPDATE lessons SET group_id = ?, hall_id = ?, lesson_date = ?, start_time = ?, end_time = ?`;
  const params = [groupId, hallId, lessonDate, startTime, endTime];
  if (updateTeacher) {
    sql += `, teacher_id = (SELECT teacher_id FROM dance_groups WHERE id = ?)`;
    params.push(groupId);
  }
  sql += ` WHERE id = ?`;
  params.push(id);
  const [result] = await pool.query(sql, params);
  return result.affectedRows > 0;
};

const remove = async (id) => {
  const [result] = await pool.query("DELETE FROM lessons WHERE id = ?", [id]);
  return result.affectedRows > 0;
};

module.exports = {
  findAll,
  findById,
  findConflicts,
  create,
  update,
  remove,
  updateNotes,
  findNotesByGroup,
};
