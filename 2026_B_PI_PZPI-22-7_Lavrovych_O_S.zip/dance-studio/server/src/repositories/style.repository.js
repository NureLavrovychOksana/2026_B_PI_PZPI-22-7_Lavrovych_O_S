const pool = require('../config/db');

const findAll = async () => {
  const [rows] = await pool.query(
    'SELECT * FROM dance_styles ORDER BY name'
  );
  return rows;
};

const findById = async (id) => {
  const [rows] = await pool.query(
    'SELECT * FROM dance_styles WHERE id = ?',
    [id]
  );
  return rows[0] || null;
};

const create = async ({ name, description }) => {
  const [result] = await pool.query(
    'INSERT INTO dance_styles (name, description) VALUES (?, ?)',
    [name, description || null]
  );
  return result.insertId;
};

const update = async (id, { name, description }) => {
  const [result] = await pool.query(
    'UPDATE dance_styles SET name = ?, description = ? WHERE id = ?',
    [name, description || null, id]
  );
  return result.affectedRows > 0;
};

const remove = async (id) => {
  const [result] = await pool.query(
    'DELETE FROM dance_styles WHERE id = ?',
    [id]
  );
  return result.affectedRows > 0;
};

module.exports = { findAll, findById, create, update, remove };