const pool = require('../config/db');

const findAll = async ({ dateFrom, dateTo, method, status } = {}) => {
  let sql = `
    SELECT
      p.id, p.amount, p.payment_date, p.payment_method, p.status,
      u.id         AS user_id,
      u.first_name, u.last_name, u.email,
      ss.id        AS subscription_id,
      sp.name      AS plan_name
    FROM payments p
    JOIN users u ON u.id = p.user_id
    LEFT JOIN student_subscriptions ss ON ss.id = p.subscription_id
    LEFT JOIN subscription_plans    sp ON sp.id = ss.plan_id
    WHERE 1=1
  `;
  const params = [];

  if (dateFrom) { sql += ' AND p.payment_date >= ?'; params.push(dateFrom); }
  if (dateTo)   { sql += ' AND p.payment_date <= ?'; params.push(dateTo + ' 23:59:59'); }
  if (method)   { sql += ' AND p.payment_method = ?'; params.push(method); }
  if (status)   { sql += ' AND p.status = ?'; params.push(status); }

  sql += ' ORDER BY p.payment_date DESC';
  const [rows] = await pool.query(sql, params);
  return rows;
};

const findByUser = async (userId) => {
  const [rows] = await pool.query(
    `SELECT
       p.id, p.amount, p.payment_date, p.payment_method, p.status,
       ss.id   AS subscription_id,
       sp.name AS plan_name
     FROM payments p
     LEFT JOIN student_subscriptions ss ON ss.id = p.subscription_id
     LEFT JOIN subscription_plans    sp ON sp.id = ss.plan_id
     WHERE p.user_id = ?
     ORDER BY p.payment_date DESC`,
    [userId]
  );
  return rows;
};

const findByOrderId = async (orderId) => {
  const [rows] = await pool.query(
    `SELECT * FROM payments WHERE liqpay_order_id = ?`,
    [orderId]
  );
  return rows[0] || null;
};

const create = async ({ userId, subscriptionId, amount, method, status, liqpayOrderId }) => {
  const [result] = await pool.query(
    `INSERT INTO payments
       (user_id, subscription_id, amount, payment_method, status, liqpay_order_id)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [userId, subscriptionId || null, amount, method || 'cash', status || 'success', liqpayOrderId || null]
  );
  return result.insertId;
};

const updateStatus = async (orderId, status) => {
  const [result] = await pool.query(
    `UPDATE payments SET status = ? WHERE liqpay_order_id = ?`,
    [status, orderId]
  );
  return result.affectedRows > 0;
};

// Atomic claim: only one concurrent caller wins (affectedRows = 1), others get 0
const claimPending = async (orderId) => {
  const [result] = await pool.query(
    `UPDATE payments SET status = 'success' WHERE liqpay_order_id = ? AND status = 'pending'`,
    [orderId]
  );
  return result.affectedRows > 0;
};

const confirmCashById = async (id) => {
  const [result] = await pool.query(
    `UPDATE payments SET status = 'success'
     WHERE id = ? AND payment_method = 'cash' AND status = 'pending'`,
    [id]
  );
  return result.affectedRows > 0;
};

module.exports = { findAll, findByUser, findByOrderId, create, updateStatus, claimPending, confirmCashById };