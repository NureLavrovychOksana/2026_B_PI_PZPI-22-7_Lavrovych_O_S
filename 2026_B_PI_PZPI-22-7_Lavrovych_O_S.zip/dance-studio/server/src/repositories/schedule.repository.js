const pool = require('../config/db');

const init = async () => {
  const fixColType = async (table, col, refTable, refCol) => {
    const [[refInfo]] = await pool.query(
      `SELECT COLUMN_TYPE, IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
      [refTable, refCol]
    );
    if (!refInfo) return;
    const [[srcInfo]] = await pool.query(
      `SELECT IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
      [table, col]
    );
    const nullable = srcInfo?.IS_NULLABLE === 'YES' ? 'DEFAULT NULL' : 'NOT NULL';
    await pool.query(
      `ALTER TABLE \`${table}\` MODIFY COLUMN \`${col}\` ${refInfo.COLUMN_TYPE} ${nullable}`
    );
  };

  const addFK = async (table, col, name, def, refTable, refCol) => {
    const [[{ cnt }]] = await pool.query(
      `SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?`,
      [table, name]
    );
    if (cnt === 0) {
      try {
        await pool.query(`ALTER TABLE \`${table}\` ADD CONSTRAINT \`${name}\` ${def}`);
      } catch (err) {
        if (err.code === 'ER_FK_INCOMPATIBLE_COLUMNS' && refTable && refCol) {
          try {
            await fixColType(table, col, refTable, refCol);
            await pool.query(`ALTER TABLE \`${table}\` ADD CONSTRAINT \`${name}\` ${def}`);
          } catch (e2) {
            console.warn(`[schedule.repository] addFK ${name} skipped:`, e2.message);
          }
        } else {
          console.warn(`[schedule.repository] addFK ${name} skipped:`, err.message);
        }
      }
    }
  };

  await pool.query(`
    CREATE TABLE IF NOT EXISTS teacher_availability_blocks (
      id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
      teacher_id  INT UNSIGNED NOT NULL,
      day_of_week TINYINT NOT NULL COMMENT '0=Пн, 6=Нд',
      start_time  TIME NOT NULL,
      end_time    TIME NOT NULL,
      reason      VARCHAR(200) DEFAULT NULL,
      created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_teacher_day (teacher_id, day_of_week),
      CONSTRAINT fk_tab_teacher_id FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS group_lesson_requirements (
      group_id         INT PRIMARY KEY,
      lessons_per_week TINYINT  NOT NULL DEFAULT 2,
      lesson_duration  SMALLINT NOT NULL DEFAULT 60 COMMENT 'хвилини',
      preferred_start  TIME     DEFAULT NULL COMMENT 'бажаний початок занять',
      preferred_end    TIME     DEFAULT NULL COMMENT 'бажаний кінець занять',
      is_children      BOOLEAN  NOT NULL DEFAULT FALSE,
      updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT fk_glr_group_id FOREIGN KEY (group_id) REFERENCES dance_groups(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);
  await addFK('teacher_availability_blocks', 'teacher_id', 'fk_tab_teacher_id',
    'FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE', 'users', 'id');
  await addFK('group_lesson_requirements', 'group_id', 'fk_glr_group_id',
    'FOREIGN KEY (group_id) REFERENCES dance_groups(id) ON DELETE CASCADE', 'dance_groups', 'id');
};

init().catch(err => console.error('[schedule.repository] init error:', err));

const getGroupRequirements = async () => {
  const [rows] = await pool.query(`
    SELECT
      dg.id                                           AS group_id,
      dg.name                                         AS group_name,
      ds.name                                         AS style_name,
      CONCAT(u.first_name, ' ', u.last_name)          AS teacher_name,
      u.id                                            AS teacher_id,
      COALESCE(glr.lessons_per_week, dg.lessons_per_week, 2) AS lessons_per_week,
      COALESCE(glr.lesson_duration, 60)               AS lesson_duration,
      glr.preferred_start,
      glr.preferred_end,
      COALESCE(glr.is_children, FALSE)                AS is_children,
      COALESCE(
        (SELECT COUNT(DISTINCT e.student_id)
         FROM enrollments e
         JOIN lessons l ON l.id = e.lesson_id
         WHERE l.group_id = dg.id
         ORDER BY l.lesson_date DESC
         LIMIT 1),
        0
      ) AS typical_students
    FROM dance_groups dg
    JOIN dance_styles ds ON ds.id = dg.style_id
    JOIN users u ON u.id = dg.teacher_id
    LEFT JOIN group_lesson_requirements glr ON glr.group_id = dg.id
    WHERE dg.status = 'active'
    ORDER BY ds.name, dg.name
  `);
  return rows.map(r => ({
    ...r,
    lessons_per_week: Number(r.lessons_per_week),
    lesson_duration:  Number(r.lesson_duration),
    is_children:      Boolean(r.is_children),
    typical_students: Number(r.typical_students),
  }));
};

const upsertGroupRequirement = async (groupId, data) => {
  const { lessons_per_week, lesson_duration, preferred_start, preferred_end, is_children } = data;
  await pool.query(`
    INSERT INTO group_lesson_requirements
      (group_id, lessons_per_week, lesson_duration, preferred_start, preferred_end, is_children)
    VALUES (?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      lessons_per_week = VALUES(lessons_per_week),
      lesson_duration  = VALUES(lesson_duration),
      preferred_start  = VALUES(preferred_start),
      preferred_end    = VALUES(preferred_end),
      is_children      = VALUES(is_children)
  `, [groupId, lessons_per_week ?? 2, lesson_duration ?? 60,
      preferred_start ?? null, preferred_end ?? null, is_children ?? false]);
};

const getTeacherAvailability = async (teacherId) => {
  const [rows] = await pool.query(
    `SELECT id, teacher_id, day_of_week, start_time, end_time, reason
     FROM teacher_availability_blocks WHERE teacher_id = ?`,
    [teacherId]
  );
  return rows;
};

const upsertTeacherAvailability = async (teacherId, blocks) => {
  await pool.query(`DELETE FROM teacher_availability_blocks WHERE teacher_id = ?`, [teacherId]);
  if (!blocks?.length) return;
  const values = blocks.map(b => [teacherId, b.day_of_week, b.start_time, b.end_time, b.reason ?? null]);
  await pool.query(
    `INSERT INTO teacher_availability_blocks (teacher_id, day_of_week, start_time, end_time, reason) VALUES ?`,
    [values]
  );
};

module.exports = {
  getGroupRequirements,
  upsertGroupRequirement,
  getTeacherAvailability,
  upsertTeacherAvailability,
};
