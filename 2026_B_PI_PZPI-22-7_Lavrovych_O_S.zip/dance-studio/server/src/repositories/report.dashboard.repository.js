const pool = require('../config/db');

const getDashboardStats = async () => {
  const [[students]]        = await pool.query(`SELECT COUNT(*) AS total FROM users WHERE role = 'student'`);
  const [[todayLessons]]    = await pool.query(`SELECT COUNT(*) AS total FROM lessons WHERE lesson_date = CURDATE()`);
  const [[monthRevenue]]    = await pool.query(
    `SELECT COALESCE(SUM(p.amount), 0) AS total FROM payments p
     JOIN users u ON u.id = p.user_id AND u.role = 'student'
     WHERE p.status = 'success' AND MONTH(p.payment_date) = MONTH(CURDATE()) AND YEAR(p.payment_date) = YEAR(CURDATE())`
  );
  const [[prevMonthRevenue]] = await pool.query(
    `SELECT COALESCE(SUM(p.amount), 0) AS total FROM payments p
     JOIN users u ON u.id = p.user_id AND u.role = 'student'
     WHERE p.status = 'success'
       AND MONTH(p.payment_date) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))
       AND YEAR(p.payment_date)  = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))`
  );
  const [[occupancy]] = await pool.query(
    `SELECT COALESCE(ROUND(COUNT(e.id) * 100.0 / NULLIF(COUNT(DISTINCT l.id) * AVG(h.capacity), 0)), 0) AS percent
     FROM lessons l
     JOIN halls h ON h.id = l.hall_id
     LEFT JOIN enrollments e ON e.lesson_id = l.id
     WHERE MONTH(l.lesson_date) = MONTH(CURDATE()) AND YEAR(l.lesson_date) = YEAR(CURDATE())`
  );
  const [[groups]]  = await pool.query(`SELECT COUNT(*) AS total FROM dance_groups WHERE status = 'active'`);
  const [[debtors]] = await pool.query(
    `SELECT COUNT(DISTINCT u.id) AS total FROM users u
     LEFT JOIN student_subscriptions ss
       ON ss.student_id = u.id AND ss.status = 'active'
       AND (ss.expiry_date IS NULL OR ss.expiry_date >= CURDATE())
     WHERE u.role = 'student' AND ss.id IS NULL`
  );
  return {
    students:           students.total,
    today_lessons:      todayLessons.total,
    active_groups:      groups.total,
    debtors:            debtors.total,
    month_revenue:      Number(monthRevenue.total),
    prev_month_revenue: Number(prevMonthRevenue.total),
    occupancy_percent:  Number(occupancy.percent),
  };
};

const getRevenueByMonth = async (months = 12) => {
  const [rows] = await pool.query(
    `SELECT DATE_FORMAT(p.payment_date, '%Y-%m') AS month, COALESCE(SUM(p.amount), 0) AS total
     FROM payments p
     JOIN users u ON u.id = p.user_id AND u.role = 'student'
     WHERE p.status = 'success' AND p.payment_date >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
     GROUP BY DATE_FORMAT(p.payment_date, '%Y-%m') ORDER BY month ASC`,
    [months]
  );
  return rows;
};

const getRevenueByWeek = async () => {
  const [rows] = await pool.query(
    `SELECT YEAR(p.payment_date) AS yr, WEEK(p.payment_date, 1) AS week_number,
            MIN(DATE(p.payment_date)) AS week_start, COALESCE(SUM(p.amount), 0) AS total
     FROM payments p
     JOIN users u ON u.id = p.user_id AND u.role = 'student'
     WHERE p.status = 'success' AND p.payment_date >= DATE_SUB(CURDATE(), INTERVAL 14 WEEK)
     GROUP BY yr, week_number ORDER BY yr ASC, week_number ASC`
  );
  return rows;
};

const getRecentActivity = async (limit = 10) => {
  const [rows] = await pool.query(
    `(SELECT 'payment' AS type, CONCAT(u.first_name, ' ', u.last_name) AS subject,
              CONCAT('Оплата ', p.amount, ' грн (', p.payment_method, ')') AS description,
              p.payment_date AS created_at
       FROM payments p JOIN users u ON u.id = p.user_id WHERE p.status = 'success')
     UNION ALL
     (SELECT 'registration' AS type, CONCAT(u.first_name, ' ', u.last_name) AS subject,
              'Новий учень зареєстрований' AS description, u.created_at
       FROM users u WHERE u.role = 'student')
     UNION ALL
     (SELECT 'lesson_added' AS type, dg.name AS subject,
              CONCAT('Додано заняття на ', DATE_FORMAT(l.lesson_date, '%d.%m.%Y')) AS description,
              COALESCE(l.created_at, TIMESTAMP(l.lesson_date)) AS created_at
       FROM lessons l JOIN dance_groups dg ON dg.id = l.group_id)
     ORDER BY created_at DESC LIMIT ?`,
    [limit]
  );
  return rows;
};

const getAttendanceByGroup = async ({ dateFrom, dateTo } = {}) => {
  const conds = [];
  const p = [];
  if (dateFrom) { conds.push('l.lesson_date >= ?'); p.push(dateFrom); }
  if (dateTo)   { conds.push('l.lesson_date <= ?'); p.push(dateTo);   }
  const dateWhere = conds.length ? `WHERE ${conds.join(' AND ')}` : '';

  const sql = `
    SELECT dg.id, dg.name AS group_name, ds.name AS style_name,
           CONCAT(u.first_name, ' ', u.last_name) AS teacher_name,
           COALESCE(ls.total_lessons, 0)        AS total_lessons,
           COALESCE(es.enrolled_students, 0)    AS enrolled_students,
           COALESCE(ls.total_marks, 0)          AS total_marks,
           COALESCE(ls.present_count, 0)        AS present_count,
           COALESCE(ls.absent_count, 0)         AS absent_count,
           COALESCE(ls.excused_count, 0)        AS excused_count,
           ROUND(COALESCE(ls.present_count, 0) * 100.0 /
                 NULLIF(COALESCE(ls.total_marks, 0), 0)) AS attendance_percent
    FROM dance_groups dg
    JOIN dance_styles ds ON ds.id = dg.style_id
    JOIN users u ON u.id = dg.teacher_id
    LEFT JOIN (
      SELECT l.group_id,
             COUNT(DISTINCT l.id)                    AS total_lessons,
             COALESCE(SUM(a_agg.total_marks), 0)     AS total_marks,
             COALESCE(SUM(a_agg.present_count), 0)   AS present_count,
             COALESCE(SUM(a_agg.absent_count), 0)    AS absent_count,
             COALESCE(SUM(a_agg.excused_count), 0)   AS excused_count
      FROM lessons l
      LEFT JOIN (
        SELECT lesson_id,
               COUNT(*)                    AS total_marks,
               SUM(status = 'present')     AS present_count,
               SUM(status = 'absent')      AS absent_count,
               SUM(status = 'excused')     AS excused_count
        FROM attendance GROUP BY lesson_id
      ) a_agg ON a_agg.lesson_id = l.id
      ${dateWhere}
      GROUP BY l.group_id
    ) ls ON ls.group_id = dg.id
    LEFT JOIN (
      SELECT l.group_id, COUNT(DISTINCT e.student_id) AS enrolled_students
      FROM enrollments e
      JOIN lessons l ON l.id = e.lesson_id
      ${dateWhere}
      GROUP BY l.group_id
    ) es ON es.group_id = dg.id
    WHERE dg.status = 'active'
    ORDER BY attendance_percent DESC`;

  const [rows] = await pool.query(sql, [...p, ...p]);
  return rows;
};

const getLTV = async () => {
  const [[row]] = await pool.query(
    `SELECT ROUND(AVG(total), 0) AS ltv FROM
     (SELECT p.user_id, SUM(p.amount) AS total
      FROM payments p
      JOIN users u ON u.id = p.user_id AND u.role = 'student'
      WHERE p.status = 'success'
      GROUP BY p.user_id) t`
  );
  return Number(row.ltv) || 0;
};

const getRevenueSplit = async () => {
  const [[newRev]] = await pool.query(
    `SELECT COALESCE(SUM(p.amount), 0) AS total FROM payments p
     JOIN users u ON u.id = p.user_id AND u.role = 'student'
     WHERE p.status = 'success' AND MONTH(p.payment_date) = MONTH(CURDATE()) AND YEAR(p.payment_date) = YEAR(CURDATE())
       AND NOT EXISTS (
         SELECT 1 FROM payments p2
         WHERE p2.user_id = p.user_id AND p2.status = 'success'
           AND p2.payment_date < DATE_FORMAT(CURDATE(), '%Y-%m-01'))`
  );
  const [[renewalRev]] = await pool.query(
    `SELECT COALESCE(SUM(p.amount), 0) AS total FROM payments p
     JOIN users u ON u.id = p.user_id AND u.role = 'student'
     WHERE p.status = 'success' AND MONTH(p.payment_date) = MONTH(CURDATE()) AND YEAR(p.payment_date) = YEAR(CURDATE())
       AND EXISTS (
         SELECT 1 FROM payments p2
         WHERE p2.user_id = p.user_id AND p2.status = 'success'
           AND p2.payment_date < DATE_FORMAT(CURDATE(), '%Y-%m-01'))`
  );
  return { new_revenue: Number(newRev.total) || 0, renewal_revenue: Number(renewalRev.total) || 0 };
};

const getFunnel = async () => {
  const [[registered]] = await pool.query(`SELECT COUNT(*) AS n FROM users WHERE role = 'student'`);
  const [[paidOnce]]   = await pool.query(
    `SELECT COUNT(DISTINCT p.user_id) AS n FROM payments p
     JOIN users u ON u.id = p.user_id AND u.role = 'student'
     WHERE p.status = 'success'`
  );
  const [[activeSub]]  = await pool.query(
    `SELECT COUNT(*) AS n FROM student_subscriptions
     WHERE status = 'active' AND (expiry_date IS NULL OR expiry_date >= CURDATE())
       AND (sessions_left IS NULL OR sessions_left > 0)`
  );
  return { registered: Number(registered.n), paid_once: Number(paidOnce.n), active_subscription: Number(activeSub.n) };
};

const getChurnRisk = async () => {
  const [[row]] = await pool.query(
    `SELECT COUNT(DISTINCT ss.student_id) AS n FROM student_subscriptions ss
     WHERE ss.status = 'active' AND (ss.expiry_date IS NULL OR ss.expiry_date >= CURDATE())
       AND NOT EXISTS (
         SELECT 1 FROM attendance a
         JOIN lessons l ON l.id = a.lesson_id
         WHERE a.student_id = ss.student_id
           AND a.status = 'present'
           AND MONTH(l.lesson_date) = MONTH(CURDATE())
           AND YEAR(l.lesson_date)  = YEAR(CURDATE()))`
  );
  return Number(row.n);
};

const getTeacherUtilization = async () => {
  const [rows] = await pool.query(
    /* Split into two subqueries so enrollments JOIN never inflates SUM(hours).
       Only past lessons (lesson_date <= CURDATE()) are counted — future
       scheduled lessons have no attendance yet and must not penalise utilization. */
    `SELECT
       u.id   AS teacher_id,
       CONCAT(u.first_name, ' ', u.last_name) AS teacher_name,
       COALESCE(ls.total_lessons,    0) AS total_lessons,
       COALESCE(ls.attended_lessons, 0) AS attended_lessons,
       COALESCE(ls.total_hours,      0) AS total_hours,
       COALESCE(es.students_count,   0) AS students_count,
       ROUND(COALESCE(ls.attended_lessons, 0) * 100.0
             / NULLIF(COALESCE(ls.total_lessons, 0), 0)) AS utilization_percent
     FROM users u
     LEFT JOIN (
       SELECT dg.teacher_id,
              COUNT(DISTINCT l.id)                                               AS total_lessons,
              COALESCE(SUM(a_agg.present_count > 0), 0) AS attended_lessons,
              ROUND(SUM(CASE WHEN COALESCE(a_agg.present_count, 0) > 0
                             THEN TIMESTAMPDIFF(MINUTE, l.start_time, l.end_time)
                             ELSE 0 END) / 60.0, 1)   AS total_hours
       FROM dance_groups dg
       JOIN lessons l ON l.group_id = dg.id
         AND MONTH(l.lesson_date) = MONTH(CURDATE()) AND YEAR(l.lesson_date) = YEAR(CURDATE())
         AND l.lesson_date <= CURDATE()
       LEFT JOIN (
         SELECT lesson_id, SUM(status = 'present') AS present_count
         FROM attendance GROUP BY lesson_id
       ) a_agg ON a_agg.lesson_id = l.id
       WHERE dg.status = 'active'
       GROUP BY dg.teacher_id
     ) ls ON ls.teacher_id = u.id
     LEFT JOIN (
       SELECT dg.teacher_id, COUNT(DISTINCT a.student_id) AS students_count
       FROM dance_groups dg
       JOIN lessons l ON l.group_id = dg.id
         AND MONTH(l.lesson_date) = MONTH(CURDATE()) AND YEAR(l.lesson_date) = YEAR(CURDATE())
         AND l.lesson_date <= CURDATE()
       JOIN attendance a ON a.lesson_id = l.id AND a.status = 'present'
       WHERE dg.status = 'active'
       GROUP BY dg.teacher_id
     ) es ON es.teacher_id = u.id
     WHERE u.role = 'teacher'
       AND (ls.total_lessons > 0 OR es.students_count > 0)
     ORDER BY utilization_percent ASC`
  );
  return rows.map(r => ({
    teacher_id:          Number(r.teacher_id),
    teacher_name:        r.teacher_name,
    total_lessons:       Number(r.total_lessons),
    attended_lessons:    Number(r.attended_lessons),
    total_hours:         Number(r.total_hours),
    students_count:      Number(r.students_count),
    utilization_percent: Number(r.utilization_percent) || 0,
  }));
};

const getStylesEnhanced = async () => {
  /* All metrics scoped to current calendar month so revenue, lessons,
     students, attendance and churn all share the same time window. */
  const [rows] = await pool.query(
    `SELECT ds.id AS style_id, ds.name AS style,
            COUNT(DISTINCT dg.id) AS groups_count,
            MAX(COALESCE(mo.lessons_count,  0)) AS lessons_count,
            MAX(COALESCE(mo.students_count, 0)) AS students_count,
            MAX(COALESCE(mo.present_count,  0)) AS present_count,
            MAX(COALESCE(mo.absent_count,   0)) AS absent_count,
            ROUND(
              MAX(COALESCE(mo.present_count, 0)) * 100.0 /
              NULLIF(MAX(COALESCE(mo.present_count, 0)) + MAX(COALESCE(mo.absent_count, 0)), 0)
            ) AS attendance_rate,
            (SELECT COUNT(DISTINCT e3.student_id) FROM enrollments e3
             JOIN lessons l3 ON l3.id = e3.lesson_id
             JOIN dance_groups dg3 ON dg3.id = l3.group_id
             WHERE dg3.style_id = ds.id
               AND MONTH(l3.lesson_date) = MONTH(CURDATE())
               AND YEAR(l3.lesson_date)  = YEAR(CURDATE())
               AND NOT EXISTS (
                 SELECT 1 FROM attendance a4
                 JOIN lessons l4 ON l4.id = a4.lesson_id
                 JOIN dance_groups dg4 ON dg4.id = l4.group_id
                 WHERE a4.student_id = e3.student_id
                   AND dg4.style_id = ds.id
                   AND a4.status = 'present'
                   AND MONTH(l4.lesson_date) = MONTH(CURDATE())
                   AND YEAR(l4.lesson_date)  = YEAR(CURDATE()))) AS churn_risk_count
     FROM dance_styles ds
     LEFT JOIN dance_groups dg ON dg.style_id = ds.id AND dg.status = 'active'
     LEFT JOIN (
       SELECT dg2.style_id,
              COUNT(DISTINCT l.id)                   AS lessons_count,
              COUNT(DISTINCT e.student_id)            AS students_count,
              COALESCE(SUM(a_agg.present_count), 0)  AS present_count,
              COALESCE(SUM(a_agg.absent_count),  0)  AS absent_count
       FROM dance_groups dg2
       JOIN lessons l ON l.group_id = dg2.id
         AND MONTH(l.lesson_date) = MONTH(CURDATE())
         AND YEAR(l.lesson_date)  = YEAR(CURDATE())
       LEFT JOIN enrollments e ON e.lesson_id = l.id
       LEFT JOIN (
         SELECT lesson_id,
                SUM(status = 'present') AS present_count,
                SUM(status = 'absent')  AS absent_count
         FROM attendance GROUP BY lesson_id
       ) a_agg ON a_agg.lesson_id = l.id
       WHERE dg2.status = 'active'
       GROUP BY dg2.style_id
     ) mo ON mo.style_id = ds.id
     GROUP BY ds.id, ds.name ORDER BY students_count DESC`
  );
  return rows.map(r => {
    const sc  = Number(r.students_count);
    const crc = Number(r.churn_risk_count) || 0;
    const lc  = Number(r.lessons_count);
    return {
      style_id:           Number(r.style_id),
      style:              r.style,
      groups_count:       Number(r.groups_count),
      students_count:     sc,
      lessons_count:      lc,
      present_count:      Number(r.present_count),
      absent_count:       Number(r.absent_count),
      attendance_rate:    Number(r.attendance_rate) || 0,
      churn_risk_count:   crc,
      churn_rate:         sc > 0 ? Math.round((crc / sc) * 100) : 0,
    };
  });
};

const getAnomalies = async () => {
  const [rows] = await pool.query(
    `SELECT dg.id AS group_id, dg.name AS group_name,
            CONCAT(u.first_name, ' ', u.last_name) AS teacher_name,
            u.id AS teacher_id, ds.name AS style_name,
            COUNT(a.id) AS total_marks,
            COALESCE(SUM(a.status = 'absent'), 0) AS absent_count,
            ROUND(COALESCE(SUM(a.status = 'absent'), 0) * 100.0 / NULLIF(COUNT(a.id), 0)) AS absence_rate
     FROM dance_groups dg
     JOIN users u ON u.id = dg.teacher_id
     JOIN dance_styles ds ON ds.id = dg.style_id
     JOIN lessons l ON l.group_id = dg.id
       AND MONTH(l.lesson_date) = MONTH(CURDATE()) AND YEAR(l.lesson_date) = YEAR(CURDATE())
     LEFT JOIN attendance a ON a.lesson_id = l.id
     WHERE dg.status = 'active'
     GROUP BY dg.id, dg.name, u.first_name, u.last_name, u.id, ds.name
     HAVING total_marks > 0 AND absence_rate >= 30
     ORDER BY absence_rate DESC LIMIT 5`
  );
  return rows.map(r => ({
    group_id:     Number(r.group_id),
    group_name:   r.group_name,
    teacher_name: r.teacher_name,
    teacher_id:   Number(r.teacher_id),
    style_name:   r.style_name,
    total_marks:  Number(r.total_marks),
    absent_count: Number(r.absent_count),
    absence_rate: Number(r.absence_rate) || 0,
  }));
};

module.exports = {
  getDashboardStats, getRevenueByMonth, getRevenueByWeek,
  getRecentActivity, getAttendanceByGroup,
  getLTV, getRevenueSplit, getFunnel, getChurnRisk,
  getTeacherUtilization, getStylesEnhanced, getAnomalies,
};
