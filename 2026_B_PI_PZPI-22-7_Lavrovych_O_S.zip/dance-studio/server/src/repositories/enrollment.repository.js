const pool = require('../config/db');

const findByLesson = async (lessonId) => {
  const [rows] = await pool.query(
    `SELECT
       e.id, e.enrolled_at,
       u.id         AS student_id,
       u.first_name, u.last_name, u.email, u.phone,
       ss.sessions_left, ss.expiry_date, ss.status AS subscription_status,
       sp.name AS plan_name, sp.type AS plan_type
     FROM enrollments e
     JOIN users u ON u.id = e.student_id
     LEFT JOIN student_subscriptions ss
       ON ss.id = (
         SELECT id FROM student_subscriptions
         WHERE student_id = u.id AND status = 'active'
           AND (expiry_date IS NULL OR expiry_date >= CURDATE())
         ORDER BY expiry_date ASC LIMIT 1
       )
     LEFT JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE e.lesson_id = ?
     ORDER BY u.last_name, u.first_name`,
    [lessonId]
  );
  return rows;
};

const findByStudent = async (studentId) => {
  const [rows] = await pool.query(
    `SELECT
       e.id, e.enrolled_at,
       l.id AS lesson_id, l.lesson_date, l.start_time, l.end_time,
       dg.name AS group_name,
       ds.name AS style_name,
       h.name  AS hall_name,
       u.first_name AS teacher_first_name,
       u.last_name  AS teacher_last_name
     FROM enrollments e
     JOIN lessons     l  ON l.id  = e.lesson_id
     JOIN dance_groups dg ON dg.id = l.group_id
     JOIN dance_styles ds ON ds.id = dg.style_id
     JOIN halls        h  ON h.id  = l.hall_id
     JOIN users        u  ON u.id  = dg.teacher_id
     WHERE e.student_id = ?
     ORDER BY l.lesson_date, l.start_time`,
    [studentId]
  );
  return rows;
};

const findOne = async (studentId, lessonId) => {
  const [rows] = await pool.query(
    'SELECT * FROM enrollments WHERE student_id = ? AND lesson_id = ?',
    [studentId, lessonId]
  );
  return rows[0] || null;
};

const create = async (studentId, lessonId) => {
  const [result] = await pool.query(
    'INSERT INTO enrollments (student_id, lesson_id) VALUES (?, ?)',
    [studentId, lessonId]
  );
  return result.insertId;
};

const createWithSub = async (studentId, lessonId, subscriptionId = null) => {
  const [result] = await pool.query(
    'INSERT INTO enrollments (student_id, lesson_id, subscription_id) VALUES (?, ?, ?)',
    [studentId, lessonId, subscriptionId || null]
  );
  return result.insertId;
};

const createWithConn = async (conn, studentId, lessonId, subscriptionId = null) => {
  const [result] = await conn.query(
    'INSERT INTO enrollments (student_id, lesson_id, subscription_id) VALUES (?, ?, ?)',
    [studentId, lessonId, subscriptionId || null]
  );
  return result.insertId;
};

const remove = async (id) => {
  const [result] = await pool.query(
    'DELETE FROM enrollments WHERE id = ?',
    [id]
  );
  return result.affectedRows > 0;
};

const findById = async (id) => {
  const [rows] = await pool.query(
    'SELECT * FROM enrollments WHERE id = ?',
    [id]
  );
  return rows[0] || null;
};

module.exports = { findByLesson, findByStudent, findOne, findById, create, createWithSub, createWithConn, remove };