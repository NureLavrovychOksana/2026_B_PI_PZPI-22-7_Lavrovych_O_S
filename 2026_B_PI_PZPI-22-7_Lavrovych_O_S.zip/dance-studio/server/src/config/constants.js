const BCRYPT_ROUNDS = 10;

module.exports = { BCRYPT_ROUNDS };
