const mysql = require('mysql2');
require('dotenv').config();

const callbackPool = mysql.createPool({
  host:     process.env.DB_HOST,
  port:     Number(process.env.DB_PORT) || 3306,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  timezone: '+00:00',
  dateStrings: true,
  charset:  'UTF8MB4_UNICODE_CI',
});

callbackPool.on('connection', (conn) => {
  conn.query("SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'", (err) => {
    if (err) console.error('[DB] SET NAMES error:', err.message);
  });
});

module.exports = callbackPool.promise();