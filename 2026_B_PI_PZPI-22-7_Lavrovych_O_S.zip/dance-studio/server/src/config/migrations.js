const pool = require('./db');

// Idempotent: extends an ENUM column only if the new value isn't already present.
const extendEnum = async (table, column, newValue, fullEnumDef) => {
  const [[col]] = await pool.query(
    `SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [table, column]
  );
  if (!col || col.COLUMN_TYPE.includes(`'${newValue}'`)) return;
  await pool.query(`ALTER TABLE \`${table}\` MODIFY COLUMN \`${column}\` ${fullEnumDef}`);
  console.log(`Migration: ${table}.${column} extended with '${newValue}'`);
};

const addCol = async (table, column, definition) => {
  const [[{ cnt }]] = await pool.query(
    `SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [table, column]
  );
  if (cnt === 0) {
    await pool.query(`ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`);
    console.log(`Migration: ${table}.${column} added`);
  }
};

const createWaitlistTable = async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS \`waitlist\` (
      \`id\`          INT NOT NULL AUTO_INCREMENT,
      \`student_id\`  INT NOT NULL,
      \`lesson_id\`   INT NOT NULL,
      \`position\`    INT NOT NULL DEFAULT 0,
      \`created_at\`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`),
      UNIQUE KEY \`uq_waitlist\` (\`student_id\`, \`lesson_id\`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);
};

const runMigrations = async () => {
  try {
    await addCol('users',   'avatar_url',           'VARCHAR(500) NULL');
    await addCol('lessons', 'notes',                'TEXT NULL');
    await addCol('lessons', 'notes_author_id',      'INT NULL');
    await addCol('lessons', 'created_at',           'TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
    await createWaitlistTable();
    await addCol('users',   'student_secure_token', 'VARCHAR(36) NULL');
    await extendEnum(
      'student_subscriptions', 'status', 'pending',
      "ENUM('active','pending','exhausted','expired','cancelled') NOT NULL DEFAULT 'active'"
    );
    await addCol('users', 'notification_prefs', 'JSON NULL');
    await addCol('dance_groups',     'lessons_per_week', 'INT NOT NULL DEFAULT 2');
    await addCol('teacher_profiles', 'hourly_rate', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
    await addCol('lessons', 'status', "ENUM('scheduled','cancelled') NOT NULL DEFAULT 'scheduled'");
    await addCol('halls', 'is_active', 'TINYINT(1) NOT NULL DEFAULT 1');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS password_reset_tokens (
        id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id    INT UNSIGNED NOT NULL,
        token      VARCHAR(128) NOT NULL UNIQUE,
        expires_at DATETIME NOT NULL,
        used       TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_prt_user (user_id),
        INDEX idx_prt_token (token)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS teacher_payouts (
        id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        teacher_id INT NOT NULL,
        amount     DECIMAL(10,2) NOT NULL,
        note       VARCHAR(300) DEFAULT NULL,
        created_by INT UNSIGNED NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_tp_teacher (teacher_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    `);
    const [[styleIdCol]] = await pool.query(
      `SELECT IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dance_groups' AND COLUMN_NAME = 'style_id'`
    );
    if (styleIdCol && styleIdCol.IS_NULLABLE === 'NO') {
      const [fkRows] = await pool.query(
        `SELECT CONSTRAINT_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dance_groups'
           AND COLUMN_NAME = 'style_id' AND REFERENCED_TABLE_NAME = 'dance_styles'`
      );
      for (const fk of fkRows) {
        await pool.query(`ALTER TABLE dance_groups DROP FOREIGN KEY \`${fk.CONSTRAINT_NAME}\``);
      }
      await pool.query(`ALTER TABLE dance_groups MODIFY COLUMN style_id INT NULL`);
      await pool.query(
        `ALTER TABLE dance_groups ADD CONSTRAINT fk_dg_style
         FOREIGN KEY (style_id) REFERENCES dance_styles(id) ON DELETE SET NULL`
      );
      console.log('Migration: dance_groups.style_id made nullable with ON DELETE SET NULL');
    }
    console.log('Migrations: OK');
  } catch (err) {
    console.error('Migrations error:', err.message);
  }
};

module.exports = { runMigrations };
