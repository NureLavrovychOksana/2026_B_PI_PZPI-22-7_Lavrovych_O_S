const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Dance Studio API',
      version: '1.0.0',
      description: 'API для веб-системи управління танцювальною студією',
    },
    servers: [
      { url: 'http://localhost:5000', description: 'Development' }
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        }
      },
      schemas: {

        // ─── AUTH ───────────────────────────────────────────
        RegisterRequest: {
          type: 'object',
          required: ['email', 'password', 'first_name', 'last_name'],
          properties: {
            email:      { type: 'string', example: 'user@test.com' },
            password:   { type: 'string', example: 'secret123' },
            first_name: { type: 'string', example: 'Оксана' },
            last_name:  { type: 'string', example: 'Коваль' },
            phone:      { type: 'string', example: '+380991234567' },
            role:       { type: 'string', enum: ['admin','teacher','student'], default: 'student' }
          }
        },
        LoginRequest: {
          type: 'object',
          required: ['email', 'password'],
          properties: {
            email:    { type: 'string', example: 'user@test.com' },
            password: { type: 'string', example: 'secret123' }
          }
        },
        AuthResponse: {
          type: 'object',
          properties: {
            token: { type: 'string' },
            user:  { $ref: '#/components/schemas/User' }
          }
        },
        ForgotPasswordRequest: {
          type: 'object',
          required: ['email'],
          properties: {
            email: { type: 'string', example: 'user@test.com' }
          }
        },
        ResetPasswordRequest: {
          type: 'object',
          required: ['token', 'password'],
          properties: {
            token:    { type: 'string' },
            password: { type: 'string', example: 'newSecret123' }
          }
        },

        // ─── USER ────────────────────────────────────────────
        User: {
          type: 'object',
          properties: {
            id:         { type: 'integer', example: 1 },
            email:      { type: 'string',  example: 'user@test.com' },
            role:       { type: 'string',  enum: ['admin','teacher','student'] },
            first_name: { type: 'string',  example: 'Оксана' },
            last_name:  { type: 'string',  example: 'Коваль' },
            phone:      { type: 'string',  example: '+380991234567' },
            created_at: { type: 'string',  format: 'date-time' }
          }
        },
        UpdateUserRequest: {
          type: 'object',
          properties: {
            email:      { type: 'string' },
            first_name: { type: 'string' },
            last_name:  { type: 'string' },
            phone:      { type: 'string' },
            role:       { type: 'string', enum: ['admin','teacher','student'] }
          }
        },

        // ─── TEACHER PROFILE ─────────────────────────────────
        TeacherProfile: {
          type: 'object',
          properties: {
            id:               { type: 'integer' },
            user_id:          { type: 'integer' },
            bio:              { type: 'string' },
            experience_years: { type: 'integer', example: 5 },
            education:        { type: 'string' },
            user:             { $ref: '#/components/schemas/User' },
            styles:           { type: 'array', items: { $ref: '#/components/schemas/DanceStyle' } }
          }
        },
        CreateTeacherProfileRequest: {
          type: 'object',
          properties: {
            bio:              { type: 'string' },
            experience_years: { type: 'integer' },
            education:        { type: 'string' },
            style_ids:        { type: 'array', items: { type: 'integer' } }
          }
        },

        // ─── DANCE STYLE ─────────────────────────────────────
        DanceStyle: {
          type: 'object',
          properties: {
            id:          { type: 'integer', example: 1 },
            name:        { type: 'string',  example: 'Хіп-хоп' },
            description: { type: 'string' }
          }
        },
        CreateDanceStyleRequest: {
          type: 'object',
          required: ['name'],
          properties: {
            name:        { type: 'string' },
            description: { type: 'string' }
          }
        },

        // ─── HALL ────────────────────────────────────────────
        Hall: {
          type: 'object',
          properties: {
            id:       { type: 'integer', example: 1 },
            name:     { type: 'string',  example: 'Зал 1' },
            capacity: { type: 'integer', example: 20 }
          }
        },
        CreateHallRequest: {
          type: 'object',
          required: ['name'],
          properties: {
            name:     { type: 'string' },
            capacity: { type: 'integer', default: 20 }
          }
        },

        // ─── DANCE GROUP ──────────────────────────────────────
        DanceGroup: {
          type: 'object',
          properties: {
            id:         { type: 'integer' },
            name:       { type: 'string',  example: 'Хіп-хоп початківці' },
            style_id:   { type: 'integer' },
            teacher_id: { type: 'integer' },
            hall_id:    { type: 'integer' },
            status:     { type: 'string', enum: ['active','paused','closed'] },
            style:      { $ref: '#/components/schemas/DanceStyle' },
            teacher:    { $ref: '#/components/schemas/User' },
            hall:       { $ref: '#/components/schemas/Hall' }
          }
        },
        CreateGroupRequest: {
          type: 'object',
          required: ['name', 'style_id', 'teacher_id', 'hall_id'],
          properties: {
            name:       { type: 'string' },
            style_id:   { type: 'integer' },
            teacher_id: { type: 'integer' },
            hall_id:    { type: 'integer' },
            status:     { type: 'string', enum: ['active','paused','closed'], default: 'active' }
          }
        },

        // ─── LESSON ──────────────────────────────────────────
        Lesson: {
          type: 'object',
          properties: {
            id:          { type: 'integer' },
            group_id:    { type: 'integer' },
            hall_id:     { type: 'integer' },
            lesson_date: { type: 'string', format: 'date',     example: '2026-05-30' },
            start_time:  { type: 'string', format: 'time',     example: '10:00' },
            end_time:    { type: 'string', format: 'time',     example: '11:00' },
            group:       { $ref: '#/components/schemas/DanceGroup' },
            hall:        { $ref: '#/components/schemas/Hall' }
          }
        },
        CreateLessonRequest: {
          type: 'object',
          required: ['group_id', 'hall_id', 'lesson_date', 'start_time', 'end_time'],
          properties: {
            group_id:    { type: 'integer' },
            hall_id:     { type: 'integer' },
            lesson_date: { type: 'string', format: 'date' },
            start_time:  { type: 'string', example: '10:00' },
            end_time:    { type: 'string', example: '11:00' }
          }
        },
        ConflictError: {
          type: 'object',
          properties: {
            message: { type: 'string', example: 'Конфлікт: зал вже зайнятий' },
            conflict_type: { type: 'string', enum: ['hall', 'teacher', 'group'] },
            conflicting_lesson: { $ref: '#/components/schemas/Lesson' }
          }
        },
        GenerateScheduleRequest: {
          type: 'object',
          required: ['week_start', 'duration_min'],
          properties: {
            week_start:   { type: 'string', format: 'date', example: '2026-06-01' },
            duration_min: { type: 'integer', enum: [60, 120] }
          }
        },

        // ─── ENROLLMENT ───────────────────────────────────────
        Enrollment: {
          type: 'object',
          properties: {
            id:          { type: 'integer' },
            student_id:  { type: 'integer' },
            lesson_id:   { type: 'integer' },
            enrolled_at: { type: 'string', format: 'date-time' }
          }
        },
        CreateEnrollmentRequest: {
          type: 'object',
          required: ['student_id', 'lesson_id'],
          properties: {
            student_id: { type: 'integer' },
            lesson_id:  { type: 'integer' }
          }
        },

        // ─── ATTENDANCE ───────────────────────────────────────
        Attendance: {
          type: 'object',
          properties: {
            id:              { type: 'integer' },
            student_id:      { type: 'integer' },
            lesson_id:       { type: 'integer' },
            subscription_id: { type: 'integer', nullable: true },
            status:          { type: 'string', enum: ['present','absent','excused'] },
            marked_at:       { type: 'string', format: 'date-time' },
            student:         { $ref: '#/components/schemas/User' },
            sessions_left:   { type: 'integer', nullable: true }
          }
        },
        MarkAttendanceRequest: {
          type: 'object',
          required: ['lesson_id', 'student_id'],
          properties: {
            lesson_id:  { type: 'integer' },
            student_id: { type: 'integer' },
            status:     { type: 'string', enum: ['present','absent','excused'], default: 'present' },
            marked_at:  { type: 'string', format: 'date-time' }
          }
        },
        BulkAttendanceRequest: {
          type: 'object',
          required: ['lesson_id', 'records'],
          properties: {
            lesson_id: { type: 'integer' },
            records: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  student_id: { type: 'integer' },
                  status:     { type: 'string', enum: ['present','absent','excused'] }
                }
              }
            }
          }
        },

        // ─── SUBSCRIPTION PLAN ────────────────────────────────
        SubscriptionPlan: {
          type: 'object',
          properties: {
            id:             { type: 'integer' },
            name:           { type: 'string',  example: 'Абонемент 8 занять' },
            type:           { type: 'string',  enum: ['COUNT','UNLIMITED'] },
            sessions_count: { type: 'integer', nullable: true },
            validity_days:  { type: 'integer', nullable: true },
            price:          { type: 'number',  example: 1600.00 }
          }
        },
        CreatePlanRequest: {
          type: 'object',
          required: ['name', 'type', 'price'],
          properties: {
            name:           { type: 'string' },
            type:           { type: 'string', enum: ['COUNT','UNLIMITED'] },
            sessions_count: { type: 'integer', nullable: true },
            validity_days:  { type: 'integer', nullable: true },
            price:          { type: 'number' }
          }
        },

        // ─── STUDENT SUBSCRIPTION ────────────────────────────
        StudentSubscription: {
          type: 'object',
          properties: {
            id:              { type: 'integer' },
            student_id:      { type: 'integer' },
            plan_id:         { type: 'integer' },
            purchase_date:   { type: 'string', format: 'date' },
            activation_date: { type: 'string', format: 'date' },
            expiry_date:     { type: 'string', format: 'date', nullable: true },
            sessions_left:   { type: 'integer', nullable: true },
            status:          { type: 'string', enum: ['active','exhausted','expired','cancelled'] },
            plan:            { $ref: '#/components/schemas/SubscriptionPlan' }
          }
        },
        CreateStudentSubscriptionRequest: {
          type: 'object',
          required: ['student_id', 'plan_id', 'activation_date'],
          properties: {
            student_id:      { type: 'integer' },
            plan_id:         { type: 'integer' },
            activation_date: { type: 'string', format: 'date' }
          }
        },

        // ─── PAYMENT ─────────────────────────────────────────
        Payment: {
          type: 'object',
          properties: {
            id:              { type: 'integer' },
            user_id:         { type: 'integer' },
            subscription_id: { type: 'integer', nullable: true },
            amount:          { type: 'number',  example: 1600.00 },
            payment_date:    { type: 'string',  format: 'date-time' },
            payment_method:  { type: 'string',  enum: ['cash','card','liqpay'] },
            status:          { type: 'string',  enum: ['pending','success','failed','refunded'] }
          }
        },
        ManualPaymentRequest: {
          type: 'object',
          required: ['student_id', 'plan_id', 'amount', 'payment_method'],
          properties: {
            student_id:      { type: 'integer' },
            plan_id:         { type: 'integer' },
            amount:          { type: 'number' },
            payment_method:  { type: 'string', enum: ['cash','card'] },
            activation_date: { type: 'string', format: 'date' }
          }
        },
        CheckoutRequest: {
          type: 'object',
          required: ['plan_id'],
          properties: {
            plan_id: { type: 'integer' }
          }
        },
        CheckoutResponse: {
          type: 'object',
          properties: {
            checkout_url: { type: 'string' },
            data:         { type: 'string' },
            signature:    { type: 'string' }
          }
        },

        // ─── NOTIFICATION ────────────────────────────────────
        Notification: {
          type: 'object',
          properties: {
            id:         { type: 'integer' },
            user_id:    { type: 'integer' },
            type:       { type: 'string', example: 'subscription_expired' },
            title:      { type: 'string' },
            body:       { type: 'string' },
            is_read:    { type: 'boolean' },
            created_at: { type: 'string', format: 'date-time' }
          }
        },
        SendNotificationRequest: {
          type: 'object',
          required: ['title', 'body', 'target'],
          properties: {
            title:    { type: 'string' },
            body:     { type: 'string' },
            target:   { type: 'string', enum: ['all','group','user'] },
            group_id: { type: 'integer', nullable: true },
            user_id:  { type: 'integer', nullable: true }
          }
        },

        // ─── MATERIAL ────────────────────────────────────────
        Material: {
          type: 'object',
          properties: {
            id:         { type: 'integer' },
            group_id:   { type: 'integer' },
            uploader_id:{ type: 'integer' },
            type:       { type: 'string', enum: ['file','link'] },
            title:      { type: 'string' },
            url:        { type: 'string' },
            created_at: { type: 'string', format: 'date-time' }
          }
        },

        // ─── REPORTS ─────────────────────────────────────────
        PaymentReport: {
          type: 'object',
          properties: {
            total:    { type: 'number' },
            count:    { type: 'integer' },
            payments: { type: 'array', items: { $ref: '#/components/schemas/Payment' } }
          }
        },
        AttendanceReport: {
          type: 'object',
          properties: {
            group_id:   { type: 'integer' },
            group_name: { type: 'string' },
            total:      { type: 'integer' },
            present:    { type: 'integer' },
            percent:    { type: 'number', example: 78.5 }
          }
        },
        TeacherReport: {
          type: 'object',
          properties: {
            teacher_id:      { type: 'integer' },
            full_name:       { type: 'string' },
            lessons_count:   { type: 'integer' },
            students_count:  { type: 'integer' }
          }
        },

        // ─── ЗАГАЛЬНІ ────────────────────────────────────────
        Error: {
          type: 'object',
          properties: {
            message: { type: 'string' }
          }
        },
        SuccessMessage: {
          type: 'object',
          properties: {
            message: { type: 'string' }
          }
        }
      }
    },
    security: [{ bearerAuth: [] }]
  },
  apis: ['./src/routes/*.js'],
};

module.exports = swaggerJsdoc(options);