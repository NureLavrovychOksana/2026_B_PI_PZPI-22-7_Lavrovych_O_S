const attendanceService = require('../services/attendance.service');
const asyncHandler      = require('../middleware/asyncHandler');

const mark = asyncHandler(async (req, res) => {
  const { lesson_id, student_id, status } = req.body;
  if (!lesson_id || !student_id)
    return res.status(400).json({ message: 'lesson_id та student_id є обовʼязковими' });
  const result = await attendanceService.mark(
    { lessonId: lesson_id, studentId: student_id, status },
    req.user
  );
  res.status(201).json(result);
});

const markBulk = asyncHandler(async (req, res) => {
  const { lesson_id, records } = req.body;
  if (!lesson_id || !Array.isArray(records) || records.length === 0)
    return res.status(400).json({ message: 'lesson_id та масив records є обовʼязковими' });
  res.json(await attendanceService.markBulk({ lessonId: lesson_id, records }, req.user));
});

const updateMark = asyncHandler(async (req, res) => {
  const { status } = req.body;
  if (!status) return res.status(400).json({ message: 'status є обовʼязковим' });
  res.json(await attendanceService.updateMark(req.params.id, status, req.user));
});

const getByLesson = asyncHandler(async (req, res) => {
  res.json(await attendanceService.getByLesson(req.params.lessonId, req.user));
});

const getByStudent = asyncHandler(async (req, res) => {
  const { date_from, date_to } = req.query;
  res.json(await attendanceService.getByStudent(
    req.params.studentId,
    { dateFrom: date_from, dateTo: date_to },
    req.user
  ));
});

module.exports = { mark, markBulk, updateMark, getByLesson, getByStudent };
