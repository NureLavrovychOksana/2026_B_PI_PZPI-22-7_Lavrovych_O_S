const teacherService = require('../services/teacher.service');
const asyncHandler   = require('../middleware/asyncHandler');

const getAll = asyncHandler(async (req, res) => {
  res.json(await teacherService.getAll());
});

const getById = asyncHandler(async (req, res) => {
  res.json(await teacherService.getById(req.params.id));
});

const getMe = asyncHandler(async (req, res) => {
  res.json(await teacherService.getByUserId(req.user.id));
});

const create = asyncHandler(async (req, res) => {
  const { email, first_name, last_name } = req.body;
  if (!email || !first_name || !last_name)
    return res.status(400).json({ message: 'Поля email, імʼя та прізвище є обовʼязковими' });
  const teacher = await teacherService.create(req.body);
  res.status(201).json(teacher);
});

const update = asyncHandler(async (req, res) => {
  res.json(await teacherService.update(req.params.id, req.body));
});

const getSchedule = asyncHandler(async (req, res) => {
  res.json(await teacherService.getSchedule(req.params.id, req.query.week));
});

const getMySchedule = asyncHandler(async (req, res) => {
  const teacherProfile = await teacherService.getByUserId(req.user.id);
  res.json(await teacherService.getSchedule(teacherProfile.id, req.query.week));
});

const getGroups = asyncHandler(async (req, res) => {
  res.json(await teacherService.getGroups(req.params.id));
});

const getMyGroups = asyncHandler(async (req, res) => {
  const teacherProfile = await teacherService.getByUserId(req.user.id);
  res.json(await teacherService.getGroups(teacherProfile.id));
});

const getMyFinance = asyncHandler(async (req, res) => {
  const profile = await teacherService.getByUserId(req.user.id);
  const { date_from, date_to } = req.query;
  res.json(await teacherService.getFinance(profile.id, date_from, date_to));
});

const getTeacherFinance = asyncHandler(async (req, res) => {
  const { date_from, date_to } = req.query;
  res.json(await teacherService.getFinance(req.params.id, date_from, date_to));
});

const setRate = asyncHandler(async (req, res) => {
  const { rate_type, rate_amount } = req.body;
  if (!['per_lesson', 'per_student'].includes(rate_type))
    return res.status(400).json({ message: 'Невірний тип ставки' });
  const amount = Number(rate_amount);
  if (isNaN(amount) || amount < 0)
    return res.status(400).json({ message: 'Невірний розмір ставки' });
  await teacherService.setRate(req.params.id, rate_type, amount);
  res.json({ ok: true });
});

const getPayrollSummary = asyncHandler(async (req, res) => {
  const now   = new Date();
  const month = parseInt(req.query.month, 10) || (now.getMonth() + 1);
  const year  = parseInt(req.query.year,  10) || now.getFullYear();
  res.json(await teacherService.getPayrollSummary(month, year));
});

const getPayouts = asyncHandler(async (req, res) => {
  res.json(await teacherService.getPayouts(req.params.id));
});

const addPayout = asyncHandler(async (req, res) => {
  const amount = Number(req.body.amount);
  if (isNaN(amount) || amount <= 0)
    return res.status(400).json({ message: 'Невірна сума' });
  const id = await teacherService.addPayout(req.params.id, amount, req.body.note, req.user.id);
  res.status(201).json({ id, ok: true });
});

module.exports = {
  getAll, getById, getMe, create, update,
  getSchedule, getMySchedule,
  getGroups, getMyGroups,
  getMyFinance, getTeacherFinance,
  setRate, getPayrollSummary, getPayouts, addPayout,
};
