const reportService = require('../services/report.service');
const { sendXlsx }  = require('../utils/excel');
const asyncHandler  = require('../middleware/asyncHandler');

const getDashboard = asyncHandler(async (req, res) => {
  res.json(await reportService.getDashboard());
});

const getRevenue = asyncHandler(async (req, res) => {
  const { months, group_by } = req.query;
  res.json(await reportService.getRevenue({ months: Number(months), groupBy: group_by }));
});

const getAttendance = asyncHandler(async (req, res) => {
  const { date_from, date_to } = req.query;
  res.json(await reportService.getAttendance({ dateFrom: date_from, dateTo: date_to }));
});

const getTeacherReport = asyncHandler(async (req, res) => {
  res.json(await reportService.getTeacherReport(req.params.teacherId));
});

const getDebtors = asyncHandler(async (req, res) => {
  res.json(await reportService.getDebtors());
});

const getExpiringSubscriptions = asyncHandler(async (req, res) => {
  res.json(await reportService.getExpiringSubscriptions(Number(req.query.days)));
});

const getStudentStats = asyncHandler(async (req, res) => {
  res.json(await reportService.getStudentStats(req.params.studentId, req.user));
});

const getStudentsAtRisk = asyncHandler(async (req, res) => {
  res.json(await reportService.getStudentsAtRisk(Number(req.query.max_sessions) || 2));
});

const getAttendanceLogs = asyncHandler(async (req, res) => {
  res.json(await reportService.getAttendanceLogs());
});

const getTransactionLogs = asyncHandler(async (req, res) => {
  res.json(await reportService.getTransactionLogs());
});

const getTeacherTimesheet = asyncHandler(async (req, res) => {
  const { date_from, date_to } = req.query;
  res.json(await reportService.getTeacherTimesheet(
    req.params.teacherId,
    { dateFrom: date_from, dateTo: date_to }
  ));
});

const getTeacherDisciplineStats = asyncHandler(async (req, res) => {
  res.json(await reportService.getTeacherDisciplineStats(req.params.teacherId));
});

const getAttendanceCsv = asyncHandler(async (req, res) => {
  const rows    = await reportService.getAttendanceLogs();
  const headers = ['date','start_time','end_time','group_name','style_name','teacher_name','student_name','student_email','status','duration_hours'];
  const labels  = ['Дата','Початок','Кінець','Група','Стиль','Викладач','Учень','Email','Статус','Тривалість (год)'];
  const today   = new Date().toISOString().slice(0, 10);
  await sendXlsx(res, 'Відвідуваність', headers, labels, rows, `log_vidviduvanosti_${today}.xlsx`);
});

const getTransactionCsv = asyncHandler(async (req, res) => {
  const rows    = await reportService.getTransactionLogs();
  const headers = ['date','payment_id','student_name','student_email','student_phone','amount','payment_method','payment_status','plan_name','plan_type','sessions_after_purchase'];
  const labels  = ['Дата','ID платежу','Учень','Email','Телефон','Сума','Метод','Статус','Тариф','Тип тарифу','Залишок занять'];
  const today   = new Date().toISOString().slice(0, 10);
  await sendXlsx(res, 'Транзакції', headers, labels, rows, `log_tranzaktsii_${today}.xlsx`);
});

const getDebtorsCsv = asyncHandler(async (req, res) => {
  const rows    = await reportService.getDebtors();
  const headers = ['first_name','last_name','email','phone','last_expiry','last_payment'];
  const labels  = ['Імʼя','Прізвище','Email','Телефон','Останній абонемент (до)','Остання оплата'];
  const today   = new Date().toISOString().slice(0, 10);
  await sendXlsx(res, 'Боржники', headers, labels, rows, `borgnyky_${today}.xlsx`);
});

module.exports = {
  getDashboard, getRevenue, getAttendance,
  getTeacherReport, getDebtors, getExpiringSubscriptions,
  getStudentStats, getStudentsAtRisk,
  getAttendanceLogs, getTransactionLogs,
  getTeacherTimesheet, getTeacherDisciplineStats,
  getAttendanceCsv, getTransactionCsv, getDebtorsCsv,
};
