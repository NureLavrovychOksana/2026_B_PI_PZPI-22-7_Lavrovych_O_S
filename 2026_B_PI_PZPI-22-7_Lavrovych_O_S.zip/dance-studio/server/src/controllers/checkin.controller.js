const checkinService = require('../services/checkin.service');

const processCheckIn = async (req, res, next) => {
  try {
    const { token } = req.body;
    const result = await checkinService.processCheckIn(token);
    res.json(result);
  } catch (err) {
    next(err);
  }
};

module.exports = { processCheckIn };
