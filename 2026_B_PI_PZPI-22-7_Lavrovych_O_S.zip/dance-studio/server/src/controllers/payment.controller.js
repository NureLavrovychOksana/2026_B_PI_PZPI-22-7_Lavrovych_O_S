const paymentService = require('../services/payment.service');
const asyncHandler   = require('../middleware/asyncHandler');

const getAll = asyncHandler(async (req, res) => {
  const { date_from, date_to, method, status } = req.query;
  res.json(await paymentService.getAll({ dateFrom: date_from, dateTo: date_to, method, status }));
});

const getByUser = asyncHandler(async (req, res) => {
  res.json(await paymentService.getByUser(req.params.userId, req.user));
});

const createManual = asyncHandler(async (req, res) => {
  const { user_id, subscription_id, amount, method } = req.body;
  res.status(201).json(await paymentService.createManual({
    userId: user_id, subscriptionId: subscription_id, amount, method,
  }));
});

const createCheckout = asyncHandler(async (req, res) => {
  res.json(await paymentService.createCheckout({ userId: req.user.id, planId: req.body.plan_id }));
});

// no auth middleware on this route — LiqPay signs requests itself
// must return 200 even on business errors so LiqPay stops retrying
const webhook = async (req, res) => {
  try {
    const result = await paymentService.handleWebhook(req.body);
    res.status(200).json(result);
  } catch (err) {
    console.error('[liqpay webhook]', err.message);
    res.status(400).json({ message: err.message });
  }
};

const createCashCheckout = asyncHandler(async (req, res) => {
  res.status(201).json(await paymentService.createCashCheckout({ userId: req.user.id, planId: req.body.plan_id }));
});

const confirmCheckout = asyncHandler(async (req, res) => {
  res.json(await paymentService.confirmCheckout({ orderId: req.body.order_id, userId: req.user.id }));
});

const confirmCashPayment = asyncHandler(async (req, res) => {
  res.json(await paymentService.confirmCashPayment(Number(req.params.id)));
});

module.exports = { getAll, getByUser, createManual, createCheckout, createCashCheckout, webhook, confirmCheckout, confirmCashPayment };
