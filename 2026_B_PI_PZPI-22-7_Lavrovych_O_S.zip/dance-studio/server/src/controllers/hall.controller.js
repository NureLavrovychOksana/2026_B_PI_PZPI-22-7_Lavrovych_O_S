const hallService  = require('../services/hall.service');
const asyncHandler = require('../middleware/asyncHandler');

const getAll = asyncHandler(async (req, res) => {
  const includeArchived = req.query.include_archived === '1';
  res.json(await hallService.getAll({ includeArchived }));
});

const getById = asyncHandler(async (req, res) => {
  res.json(await hallService.getById(req.params.id));
});

const create = asyncHandler(async (req, res) => {
  res.status(201).json(await hallService.create(req.body));
});

const update = asyncHandler(async (req, res) => {
  res.json(await hallService.update(req.params.id, req.body));
});

const remove = asyncHandler(async (req, res) => {
  const targetHallId = req.body?.targetHallId ? Number(req.body.targetHallId) : null;
  const result = await hallService.remove(req.params.id, targetHallId);
  res.json(result);
});

const restore = asyncHandler(async (req, res) => {
  res.json(await hallService.restore(req.params.id));
});

module.exports = { getAll, getById, create, update, remove, restore };
