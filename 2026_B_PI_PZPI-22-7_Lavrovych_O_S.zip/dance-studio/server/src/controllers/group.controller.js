const groupService = require('../services/group.service');
const asyncHandler = require('../middleware/asyncHandler');

const getAll = asyncHandler(async (req, res) => {
  const { styleId } = req.query;
  res.json(await groupService.getAll(req.user, { styleId: styleId ? Number(styleId) : null }));
});

const getById = asyncHandler(async (req, res) => {
  res.json(await groupService.getById(req.params.id, req.user));
});

const create = asyncHandler(async (req, res) => {
  res.status(201).json(await groupService.create(req.body));
});

const update = asyncHandler(async (req, res) => {
  res.json(await groupService.update(req.params.id, req.body));
});

const remove = asyncHandler(async (req, res) => {
  const result = await groupService.remove(req.params.id);
  res.json({ message: result.action === 'archived' ? 'Групу переведено в архів' : 'Групу видалено', action: result.action });
});

const getAttendanceStats = asyncHandler(async (req, res) => {
  const { date_from, date_to } = req.query;
  res.json(await groupService.getAttendanceStats(
    req.params.id, req.user, date_from || null, date_to || null
  ));
});

module.exports = { getAll, getById, create, update, remove, getAttendanceStats };
