const styleService = require('../services/style.service');
const asyncHandler = require('../middleware/asyncHandler');

const getAll = asyncHandler(async (req, res) => {
  res.json(await styleService.getAll());
});

const getById = asyncHandler(async (req, res) => {
  res.json(await styleService.getById(req.params.id));
});

const create = asyncHandler(async (req, res) => {
  res.status(201).json(await styleService.create(req.body));
});

const update = asyncHandler(async (req, res) => {
  res.json(await styleService.update(req.params.id, req.body));
});

const remove = asyncHandler(async (req, res) => {
  await styleService.remove(req.params.id);
  res.json({ message: 'Стиль успішно видалено' });
});

module.exports = { getAll, getById, create, update, remove };
