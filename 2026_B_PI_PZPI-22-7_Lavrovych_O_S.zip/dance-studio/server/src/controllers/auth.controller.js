const authService = require('../services/auth.service');

const register = async (req, res, next) => {
  try {
    const { email, password, first_name, last_name, phone, role } = req.body;
    const result = await authService.register({ email, password, first_name, last_name, phone, role });
    res.status(201).json(result);
  } catch (err) {
    next(err);
  }
};

const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const result = await authService.login({ email, password });
    res.json(result);
  } catch (err) {
    next(err);
  }
};

const me = async (req, res, next) => {
  try {
    const user = await authService.getMe(req.user.id);
    res.json(user);
  } catch (err) {
    next(err);
  }
};

const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'Введіть email' });
    }

    await authService.forgotPassword(email);

    res.json({
      message: 'Якщо акаунт з таким email існує, ви отримаєте лист з інструкціями'
    });
  } catch (err) {
    next(err);
  }
};

const resetPassword = async (req, res, next) => {
  try {
    const { token, password } = req.body;

    if (!token || !password) {
      return res.status(400).json({ message: 'Токен та новий пароль є обовʼязковими' });
    }

    await authService.resetPassword(token, password);

    res.json({ message: 'Пароль успішно змінено. Тепер ви можете увійти.' });
  } catch (err) {
    next(err);
  }
};

module.exports = { register, login, me, forgotPassword, resetPassword };