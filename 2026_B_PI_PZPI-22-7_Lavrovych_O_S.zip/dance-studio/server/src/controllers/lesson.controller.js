const lessonService = require('../services/lesson.service');
const asyncHandler  = require('../middleware/asyncHandler');

const getAll = asyncHandler(async (req, res) => {
  const { week, groupId, teacherId } = req.query;
  res.json(await lessonService.getAll({ week, groupId, teacherId }));
});

const getById = asyncHandler(async (req, res) => {
  res.json(await lessonService.getById(req.params.id));
});

const create = asyncHandler(async (req, res) => {
  const { group_id, hall_id, lesson_date, start_time, end_time } = req.body;
  const lesson = await lessonService.create({
    groupId: group_id, hallId: hall_id,
    lessonDate: lesson_date, startTime: start_time, endTime: end_time,
  });
  res.status(201).json(lesson);
});

const update = asyncHandler(async (req, res) => {
  const { group_id, hall_id, lesson_date, start_time, end_time } = req.body;
  res.json(await lessonService.update(req.params.id, {
    groupId: group_id, hallId: hall_id,
    lessonDate: lesson_date, startTime: start_time, endTime: end_time,
  }));
});

const remove = asyncHandler(async (req, res) => {
  await lessonService.remove(req.params.id);
  res.json({ message: 'Заняття успішно видалено' });
});

const updateNotes = asyncHandler(async (req, res) => {
  res.json(await lessonService.updateNotes(req.params.id, req.body.notes, req.user.id));
});

const getNotesByGroup = asyncHandler(async (req, res) => {
  res.json(await lessonService.getNotesByGroup(req.params.groupId));
});

module.exports = { getAll, getById, create, update, remove, updateNotes, getNotesByGroup };
