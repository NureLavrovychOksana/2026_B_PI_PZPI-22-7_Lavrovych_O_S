const enrollmentService = require('../services/enrollment.service');
const asyncHandler      = require('../middleware/asyncHandler');

const getByLesson = asyncHandler(async (req, res) => {
  res.json(await enrollmentService.getByLesson(req.params.lessonId));
});

const getByStudent = asyncHandler(async (req, res) => {
  res.json(await enrollmentService.getByStudent(req.params.studentId));
});

const enroll = asyncHandler(async (req, res) => {
  const { student_id, lesson_id } = req.body;
  if (!student_id || !lesson_id)
    return res.status(400).json({ message: 'student_id та lesson_id є обовʼязковими' });
  res.status(201).json(await enrollmentService.enroll(student_id, lesson_id));
});

const selfEnroll = async (req, res, next) => {
  try {
    const { lesson_id } = req.body;
    if (!lesson_id) return res.status(400).json({ message: 'lesson_id є обовʼязковим' });
    res.status(201).json(await enrollmentService.selfEnroll(req.user.id, lesson_id));
  } catch (err) {
    if (err.waitlist) return res.status(409).json({ message: err.message, waitlist: true });
    next(err);
  }
};

const unenroll = asyncHandler(async (req, res) => {
  await enrollmentService.unenroll(req.params.id, req.user);
  res.json({ message: 'Запис успішно видалено' });
});

const joinWaitlist = asyncHandler(async (req, res) => {
  const { lesson_id } = req.body;
  if (!lesson_id) return res.status(400).json({ message: 'lesson_id є обовʼязковим' });
  res.status(201).json(await enrollmentService.joinWaitlist(req.user.id, lesson_id));
});

const leaveWaitlist = asyncHandler(async (req, res) => {
  await enrollmentService.leaveWaitlist(req.params.id, req.user);
  res.json({ message: 'Видалено зі списку очікування' });
});

const getWaitlistByLesson = asyncHandler(async (req, res) => {
  res.json(await enrollmentService.getWaitlistByLesson(req.params.lessonId));
});

const getWaitlistByStudent = asyncHandler(async (req, res) => {
  const studentId = req.params.studentId || req.user.id;
  res.json(await enrollmentService.getWaitlistByStudent(studentId));
});

const teacherManualEnroll = asyncHandler(async (req, res) => {
  const { student_id, lesson_id } = req.body;
  if (!student_id || !lesson_id)
    return res.status(400).json({ message: 'student_id та lesson_id є обовʼязковими' });
  res.status(201).json(await enrollmentService.teacherEnroll(req.user.id, student_id, lesson_id));
});

const bulkEnroll = asyncHandler(async (req, res) => {
  const { student_id, group_id, date_from, date_to } = req.body;
  if (!student_id || !group_id || !date_from || !date_to)
    return res.status(400).json({ message: 'student_id, group_id, date_from, date_to є обовʼязковими' });
  res.status(201).json(await enrollmentService.bulkEnroll(student_id, group_id, date_from, date_to));
});

module.exports = {
  getByLesson, getByStudent, enroll, selfEnroll, unenroll,
  teacherManualEnroll, bulkEnroll,
  joinWaitlist, leaveWaitlist, getWaitlistByLesson, getWaitlistByStudent,
};
