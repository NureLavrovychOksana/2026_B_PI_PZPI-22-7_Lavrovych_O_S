const subscriptionService = require('../services/subscription.service');
const asyncHandler        = require('../middleware/asyncHandler');

const getAllPlans = asyncHandler(async (req, res) => {
  const isAdmin = req.user?.role === 'admin';
  res.json(await subscriptionService.getAllPlans({ excludeTrial: !isAdmin, adminView: isAdmin }));
});

const createPlan = asyncHandler(async (req, res) => {
  res.status(201).json(await subscriptionService.createPlan(req.body));
});

const updatePlan = asyncHandler(async (req, res) => {
  res.json(await subscriptionService.updatePlan(req.params.id, req.body));
});

const removePlan = asyncHandler(async (req, res) => {
  await subscriptionService.removePlan(req.params.id);
  res.json({ message: 'Тариф видалено' });
});

const getAllSubscriptions = asyncHandler(async (req, res) => {
  res.json(await subscriptionService.getAllSubscriptions());
});

const getStudentSubscriptions = asyncHandler(async (req, res) => {
  res.json(await subscriptionService.getStudentSubscriptions(req.params.studentId, req.user));
});

const getActiveSubscriptions = asyncHandler(async (req, res) => {
  res.json(await subscriptionService.getActiveSubscriptions(req.params.studentId, req.user));
});

const assignSubscription = asyncHandler(async (req, res) => {
  const { student_id, plan_id, activation_date, purchase_date } = req.body;
  if (!student_id || !plan_id)
    return res.status(400).json({ message: 'student_id та plan_id є обовʼязковими' });
  const sub = await subscriptionService.assignSubscription({
    studentId: student_id, planId: plan_id,
    activationDate: activation_date, purchaseDate: purchase_date,
    forceActive: true,
  });
  res.status(201).json(sub);
});

const cancelSubscription = asyncHandler(async (req, res) => {
  res.json(await subscriptionService.cancelSubscription(req.params.id, req.user));
});

module.exports = {
  getAllPlans, createPlan, updatePlan, removePlan,
  getAllSubscriptions,
  getStudentSubscriptions, getActiveSubscriptions,
  assignSubscription, cancelSubscription,
};
