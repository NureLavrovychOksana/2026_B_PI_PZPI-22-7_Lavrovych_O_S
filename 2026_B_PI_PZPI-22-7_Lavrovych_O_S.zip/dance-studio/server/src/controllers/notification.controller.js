const notificationService    = require('../services/notification.service');
const { sendReminderEmail }  = require('../utils/mailer');
const asyncHandler           = require('../middleware/asyncHandler');

const getMyNotifications = asyncHandler(async (req, res) => {
  res.json(await notificationService.getMyNotifications(req.user.id));
});

const getUnreadCount = asyncHandler(async (req, res) => {
  const count = await notificationService.getUnreadCount(req.user.id);
  res.json({ count });
});

const markRead = asyncHandler(async (req, res) => {
  res.json(await notificationService.markRead(req.params.id, req.user.id));
});

const markAllRead = asyncHandler(async (req, res) => {
  res.json(await notificationService.markAllRead(req.user.id));
});

const broadcast = asyncHandler(async (req, res) => {
  const { group_id, type, title, body } = req.body;
  if (!title) return res.status(400).json({ message: 'title є обовʼязковим' });
  res.json(await notificationService.broadcast({
    groupId: group_id || null,
    type:    type     || 'manual',
    title,
    body,
  }));
});

const sendEmail = asyncHandler(async (req, res) => {
  const { to, name, type } = req.body;
  if (!to || !name) return res.status(400).json({ message: 'to і name є обовʼязковими' });
  await sendReminderEmail({ to, name, type: type || 'debtor' });
  res.json({ ok: true });
});

module.exports = { getMyNotifications, getUnreadCount, markRead, markAllRead, broadcast, sendEmail };
