const userService   = require('../services/user.service');
const asyncHandler  = require('../middleware/asyncHandler');

const getAll = asyncHandler(async (req, res) => {
  const { role } = req.query;
  res.json(await userService.getAll(role || null));
});

const getById = asyncHandler(async (req, res) => {
  res.json(await userService.getById(req.params.id));
});

const create = asyncHandler(async (req, res) => {
  const user = await userService.create(req.body);
  res.status(201).json(user);
});

const update = asyncHandler(async (req, res) => {
  res.json(await userService.update(req.params.id, req.body));
});

const remove = asyncHandler(async (req, res) => {
  if (Number(req.params.id) === req.user.id)
    return res.status(400).json({ message: 'Не можна видалити власний акаунт' });
  await userService.remove(req.params.id);
  res.json({ message: 'Користувача успішно видалено' });
});

const getProfile = asyncHandler(async (req, res) => {
  res.json(await userService.getById(req.user.id));
});

const updateProfile = asyncHandler(async (req, res) => {
  res.json(await userService.updateProfile(req.user.id, req.body));
});

const getStudentStats = asyncHandler(async (req, res) => {
  res.json(await userService.getStudentStats(req.params.id));
});

const getQrToken = asyncHandler(async (req, res) => {
  const token = await userService.getOrCreateSecureToken(req.user.id);
  res.json({ token });
});

const deleteSelf = asyncHandler(async (req, res) => {
  await userService.removeSelf(req.user.id);
  res.json({ message: 'Акаунт успішно видалено' });
});

const uploadAvatarHandler = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'Файл не завантажено' });
  const avatarUrl = `/uploads/avatars/${req.file.filename}`;
  const user = await userService.updateAvatarUrl(req.user.id, avatarUrl);
  res.json({ avatar_url: user.avatar_url });
});

const updateNotifPrefs = asyncHandler(async (req, res) => {
  const prefs = await userService.updateNotifPrefs(req.user.id, req.body);
  res.json({ notification_prefs: prefs });
});

const searchStudents = asyncHandler(async (req, res) => {
  res.json(await userService.searchStudents(req.query.q || ''));
});

module.exports = {
  getAll, getById, update, remove, create,
  getProfile, updateProfile, uploadAvatarHandler,
  getStudentStats, deleteSelf, getQrToken,
  updateNotifPrefs, searchStudents,
};
