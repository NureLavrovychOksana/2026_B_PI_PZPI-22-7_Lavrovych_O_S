/**
 * Lightweight validation middleware.
 *
 * Usage:
 *   const { validate, required, email, phone, strongPassword, minLength, maxLength, positiveNumber } = require('./validate.middleware');
 *   router.post('/register', validate(registerSchema), controller.register);
 *
 * Schema: { fieldName: [validatorFn, ...] }
 * Each validatorFn: (value, body) => errorString | null
 */

const sanitizeStr = (v) =>
  typeof v === 'string' ? v.trim().replace(/</g, '&lt;').replace(/>/g, '&gt;') : v;

const validate = (schema) => (req, res, next) => {
  const errors = {};
  for (const [field, validators] of Object.entries(schema)) {
    const val = req.body[field];
    for (const fn of validators) {
      const err = fn(val, req.body);
      if (err) { errors[field] = err; break; }
    }
  }
  if (Object.keys(errors).length) {
    return res.status(400).json({ message: Object.values(errors)[0], errors });
  }
  for (const key of Object.keys(req.body)) {
    if (typeof req.body[key] === 'string') req.body[key] = sanitizeStr(req.body[key]);
  }
  next();
};

const required = (msg = "Обовʼязкове поле") => (v) =>
  (v == null || String(v).trim() === '') ? msg : null;

const email = () => (v) =>
  v && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v).trim())
    ? 'Невірний формат email'
    : null;

const phone = () => (v) =>
  v && !/^\+380\d{9}$/.test(String(v).trim())
    ? 'Телефон: формат +380XXXXXXXXX'
    : null;

const minLength = (min) => (v) =>
  v && String(v).trim().length < min ? `Мінімум ${min} символів` : null;

const maxLength = (max) => (v) =>
  v && String(v).trim().length > max ? `Максимум ${max} символів` : null;

const strongPassword = () => (v) =>
  v && !/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/.test(v)
    ? 'Пароль: мін. 8 символів, велика літера, цифра, спецсимвол (@$!%*?&)'
    : null;

const positiveNumber = (max) => (v) => {
  if (v == null || v === '') return null;
  const n = Number(v);
  if (isNaN(n) || n < 0) return 'Має бути позитивне число';
  if (max != null && n > max) return `Не може перевищувати ${max}`;
  return null;
};

const registerSchema = {
  first_name: [required("Введіть імʼя"), minLength(2), maxLength(50)],
  last_name:  [required('Введіть прізвище'), minLength(2), maxLength(50)],
  email:      [required('Введіть email'), email()],
  password:   [required('Введіть пароль'), strongPassword()],
  phone:      [phone()],
};

const loginSchema = {
  email:    [required('Введіть email'), email()],
  password: [required('Введіть пароль')],
};

const userCreateSchema = {
  first_name: [required("Введіть імʼя"), minLength(2), maxLength(50)],
  last_name:  [required('Введіть прізвище'), minLength(2), maxLength(50)],
  email:      [required('Введіть email'), email()],
  phone:      [phone()],
};

module.exports = {
  validate,
  required,
  email,
  phone,
  minLength,
  maxLength,
  strongPassword,
  positiveNumber,
  registerSchema,
  loginSchema,
  userCreateSchema,
};
