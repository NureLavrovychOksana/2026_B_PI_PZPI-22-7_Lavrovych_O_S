const errorHandler = (err, req, res, next) => {
  console.error(`[${new Date().toISOString()}] ${err.stack || err.message}`);

  const status  = err.status  || 500;
  const message = err.message || 'Внутрішня помилка сервера';

  const body = { message };
  if (err.conflicts) body.conflicts = err.conflicts;

  res.status(status).json(body);
};

module.exports = errorHandler;