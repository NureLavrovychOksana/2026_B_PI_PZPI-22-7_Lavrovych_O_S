const express = require('express');
const cors    = require('cors');
const path    = require('path');
require('dotenv').config();
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./config/swagger');
const errorHandler = require('./middleware/error.handler');
const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const teacherRoutes = require('./routes/teacher.routes');
const groupRoutes = require('./routes/group.routes');
const hallRoutes  = require('./routes/hall.routes');
const styleRoutes = require('./routes/style.routes');
const lessonRoutes = require('./routes/lesson.routes');
const enrollmentRoutes = require('./routes/enrollment.routes');
const attendanceRoutes = require('./routes/attendance.routes');
const notificationRoutes = require('./routes/notification.routes');
const subscriptionRoutes = require('./routes/subscription.routes');
const paymentRoutes = require('./routes/payment.routes');
const reportRoutes = require('./routes/report.routes');
const settingsRoutes = require('./routes/settings.routes');
const scheduleRoutes  = require('./routes/schedule.routes');
const checkinRoutes   = require('./routes/checkin.routes');
const { runMigrations }          = require('./config/migrations');
const { startLessonReminderJob } = require('./jobs/lessonReminders');

const app = express();
const PORT = process.env.PORT || 5000;

const ALLOWED_ORIGINS = [process.env.CLIENT_URL, 'http://localhost:4173'].filter(Boolean);
app.use(cors({ origin: ALLOWED_ORIGINS }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.use('/api/auth',     authRoutes);
app.use('/api/users',    userRoutes);
app.use('/api/teachers', teacherRoutes);
app.use('/api/groups',   groupRoutes);
app.use('/api/halls',  hallRoutes);
app.use('/api/styles', styleRoutes);
app.use('/api/lessons', lessonRoutes);
app.use('/api/enrollments', enrollmentRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/subscriptions', subscriptionRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/schedule', scheduleRoutes);
app.use('/api/checkin',  checkinRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.use(errorHandler);

app.listen(PORT, async () => {
  console.log(`Server:  http://localhost:${PORT}`);
  console.log(`Swagger: http://localhost:${PORT}/api/docs`);
  await runMigrations();
  startLessonReminderJob();
});