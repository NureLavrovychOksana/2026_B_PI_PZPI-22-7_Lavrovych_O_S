const router = require('express').Router();
const checkinController = require('../controllers/checkin.controller');
const authMiddleware    = require('../middleware/auth.middleware');
const roleMiddleware    = require('../middleware/role.middleware');

/**
 * POST /api/checkin
 * Body: { token: string }
 * Auth: admin or teacher (the one scanning the QR)
 *
 * Returns student info + matched lesson (within ±30 min window) + subscription status.
 */
router.post('/', authMiddleware, roleMiddleware('admin', 'teacher'), checkinController.processCheckIn);

module.exports = router;
