const router = require('express').Router();
const paymentController = require('../controllers/payment.controller');
const authMiddleware    = require('../middleware/auth.middleware');
const roleMiddleware    = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Payments
 *   description: Оплати та LiqPay
 */

/**
 * @swagger
 * /api/payments:
 *   get:
 *     tags: [Payments]
 *     summary: Всі платежі (admin)
 *     parameters:
 *       - in: query
 *         name: date_from
 *         schema: { type: string, format: date }
 *       - in: query
 *         name: date_to
 *         schema: { type: string, format: date }
 *       - in: query
 *         name: method
 *         schema: { type: string, enum: [cash, card, liqpay] }
 *       - in: query
 *         name: status
 *         schema: { type: string, enum: [pending, success, failed, refunded] }
 *     responses:
 *       200:
 *         description: Список платежів
 */
router.get('/', authMiddleware, roleMiddleware('admin'), paymentController.getAll);

/**
 * @swagger
 * /api/payments/user/{userId}:
 *   get:
 *     tags: [Payments]
 *     summary: Платежі користувача (admin або сам користувач)
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Список платежів
 */
router.get('/user/:userId', authMiddleware, paymentController.getByUser);

/**
 * @swagger
 * /api/payments/manual:
 *   post:
 *     tags: [Payments]
 *     summary: Ручна фіксація оплати (admin)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [user_id, amount]
 *             properties:
 *               user_id:         { type: integer }
 *               subscription_id: { type: integer }
 *               amount:          { type: number }
 *               method:          { type: string, enum: [cash, card] }
 *     responses:
 *       201:
 *         description: Платіж зафіксовано
 */
router.post('/manual', authMiddleware, roleMiddleware('admin'), paymentController.createManual);

/**
 * @swagger
 * /api/payments/checkout:
 *   post:
 *     tags: [Payments]
 *     summary: Ініціалізувати оплату через LiqPay (student)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [plan_id]
 *             properties:
 *               plan_id: { type: integer }
 *     responses:
 *       200:
 *         description: data, signature та checkout_url для форми LiqPay
 */
router.post('/checkout', authMiddleware, roleMiddleware('student'), paymentController.createCheckout);
router.post('/checkout/cash', authMiddleware, roleMiddleware('student'), paymentController.createCashCheckout);

/**
 * @swagger
 * /api/payments/webhook:
 *   post:
 *     tags: [Payments]
 *     summary: Webhook від LiqPay (без авторизації)
 *     responses:
 *       200:
 *         description: OK
 */
router.post('/webhook', paymentController.webhook);

/**
 * @swagger
 * /api/payments/confirm:
 *   post:
 *     tags: [Payments]
 *     summary: Підтвердити оплату після liqpay.callback (student)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [order_id]
 *             properties:
 *               order_id: { type: string }
 *     responses:
 *       200:
 *         description: Абонемент активовано
 */
router.post('/confirm', authMiddleware, roleMiddleware('student'), paymentController.confirmCheckout);
router.put('/:id/confirm-cash', authMiddleware, roleMiddleware('admin'), paymentController.confirmCashPayment);

module.exports = router;