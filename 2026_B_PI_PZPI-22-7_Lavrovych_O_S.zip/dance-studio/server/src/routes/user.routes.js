const router = require('express').Router();
const userController = require('../controllers/user.controller');
const authMiddleware = require('../middleware/auth.middleware');
const roleMiddleware = require('../middleware/role.middleware');
const { uploadAvatar } = require('../config/multer');
const { validate, userCreateSchema } = require('../middleware/validate.middleware');

/**
 * @swagger
 * tags:
 *   name: Users
 *   description: Управління користувачами
 */

/**
 * @swagger
 * /api/users/profile:
 *   get:
 *     tags: [Users]
 *     summary: Отримати власний профіль
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 */
router.get('/students', authMiddleware, roleMiddleware('admin', 'teacher'), userController.searchStudents);

router.get('/profile',                      authMiddleware, userController.getProfile);
router.get('/profile/qr-token',             authMiddleware, userController.getQrToken);
router.post('/profile/avatar',              authMiddleware, uploadAvatar.single('avatar'), userController.uploadAvatarHandler);
router.put('/profile/notification-prefs',   authMiddleware, userController.updateNotifPrefs);
router.delete('/profile',                   authMiddleware, userController.deleteSelf);

/**
 * @swagger
 * /api/users/profile:
 *   put:
 *     tags: [Users]
 *     summary: Оновити власний профіль (імʼя, телефон, пароль)
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               first_name: { type: string }
 *               last_name:  { type: string }
 *               phone:      { type: string }
 *               password:   { type: string, description: Новий пароль (мін. 6 символів) }
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 */
router.put('/profile', authMiddleware, userController.updateProfile);

/**
 * @swagger
 * /api/users:
 *   get:
 *     tags: [Users]
 *     summary: Список всіх користувачів (тільки адмін)
 *     parameters:
 *       - in: query
 *         name: role
 *         schema:
 *           type: string
 *           enum: [admin, teacher, student]
 *         description: Фільтр за роллю
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/User'
 */
router.get('/', authMiddleware, roleMiddleware('admin'), userController.getAll);
/**
 * @swagger
 * /api/users:
 *   post:
 *     tags: [Users]
 *     summary: Створити користувача (тільки адмін)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email, password, role, first_name, last_name]
 *             properties:
 *               email:      { type: string }
 *               password:   { type: string }
 *               role:       { type: string, enum: [admin, teacher, student] }
 *               first_name: { type: string }
 *               last_name:  { type: string }
 *               phone:      { type: string }
 *     responses:
 *       201:
 *         description: Користувача створено
 *       409:
 *         description: Email вже зайнятий
 */
router.post('/', authMiddleware, roleMiddleware('admin'), validate(userCreateSchema), userController.create);
/**
 * @swagger
 * /api/users/{id}:
 *   get:
 *     tags: [Users]
 *     summary: Користувач за ID (тільки адмін)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       404:
 *         description: Не знайдено
 */
router.get('/:id', authMiddleware, roleMiddleware('admin'), userController.getById);

/**
 * @swagger
 * /api/users/{id}/stats:
 *   get:
 *     tags: [Users]
 *     summary: Статистика учня (відвідуваність, абонемент, групи)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 attendance:
 *                   type: object
 *                   properties:
 *                     total_lessons:  { type: integer }
 *                     present_count:  { type: integer }
 *                     absent_count:   { type: integer }
 *                     excused_count:  { type: integer }
 *                 active_subscription:
 *                   $ref: '#/components/schemas/StudentSubscription'
 *                 groups:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:         { type: integer }
 *                       name:       { type: string }
 *                       style_name: { type: string }
 */
router.get(
  '/:id/stats',
  authMiddleware,
  roleMiddleware('admin', 'teacher'),
  userController.getStudentStats
);

/**
 * @swagger
 * /api/users/{id}:
 *   put:
 *     tags: [Users]
 *     summary: Оновити дані будь-якого користувача (тільки адмін)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateUserRequest'
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       409:
 *         description: Email вже зайнятий
 */
router.put('/:id', authMiddleware, roleMiddleware('admin'), userController.update);

/**
 * @swagger
 * /api/users/{id}:
 *   delete:
 *     tags: [Users]
 *     summary: Видалити користувача (тільки адмін)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessMessage'
 *       400:
 *         description: Не можна видалити себе
 */
router.delete('/:id', authMiddleware, roleMiddleware('admin'), userController.remove);

module.exports = router;