const router = require('express').Router();
const sc             = require('../controllers/subscription.controller');
const authMiddleware = require('../middleware/auth.middleware');
const roleMiddleware = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Subscriptions
 *   description: Тарифи та абонементи
 */

/**
 * @swagger
 * /api/subscription-plans:
 *   get:
 *     tags: [Subscriptions]
 *     summary: Список тарифів (публічний)
 *     responses:
 *       200:
 *         description: Масив тарифів
 */
router.get('/plans', authMiddleware, sc.getAllPlans);

router.get('/all', authMiddleware, roleMiddleware('admin'), sc.getAllSubscriptions);

/**
 * @swagger
 * /api/subscription-plans:
 *   post:
 *     tags: [Subscriptions]
 *     summary: Створити тариф (admin)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [name, price]
 *             properties:
 *               name:           { type: string }
 *               type:           { type: string, enum: [COUNT, UNLIMITED] }
 *               sessions_count: { type: integer }
 *               validity_days:  { type: integer }
 *               price:          { type: number }
 *     responses:
 *       201:
 *         description: Тариф створено
 */
router.post('/plans', authMiddleware, roleMiddleware('admin'), sc.createPlan);

/**
 * @swagger
 * /api/subscription-plans/{id}:
 *   put:
 *     tags: [Subscriptions]
 *     summary: Оновити тариф (admin)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Оновлено
 */
router.put('/plans/:id', authMiddleware, roleMiddleware('admin'), sc.updatePlan);

/**
 * @swagger
 * /api/subscription-plans/{id}:
 *   delete:
 *     tags: [Subscriptions]
 *     summary: Видалити тариф (admin)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Видалено
 *       409:
 *         description: Тариф використовується
 */
router.delete('/plans/:id', authMiddleware, roleMiddleware('admin'), sc.removePlan);

/**
 * @swagger
 * /api/subscriptions/student/{studentId}:
 *   get:
 *     tags: [Subscriptions]
 *     summary: Всі абонементи учня
 *     parameters:
 *       - in: path
 *         name: studentId
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Список абонементів
 */
router.get('/student/:studentId', authMiddleware, sc.getStudentSubscriptions);

/**
 * @swagger
 * /api/subscriptions/student/{studentId}/active:
 *   get:
 *     tags: [Subscriptions]
 *     summary: Усі активні абонементи учня (з яких ще можна списувати), у порядку списання FIFO
 *     parameters:
 *       - in: path
 *         name: studentId
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Масив активних абонементів (може бути порожнім)
 */
router.get('/student/:studentId/active', authMiddleware, sc.getActiveSubscriptions);

/**
 * @swagger
 * /api/subscriptions:
 *   post:
 *     tags: [Subscriptions]
 *     summary: Призначити абонемент учню вручну (admin)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [student_id, plan_id]
 *             properties:
 *               student_id:      { type: integer }
 *               plan_id:         { type: integer }
 *               activation_date: { type: string, format: date }
 *               purchase_date:   { type: string, format: date }
 *     responses:
 *       201:
 *         description: Абонемент призначено
 */
router.post('/', authMiddleware, roleMiddleware('admin'), sc.assignSubscription);

/**
 * @swagger
 * /api/subscriptions/{id}/cancel:
 *   put:
 *     tags: [Subscriptions]
 *     summary: Скасувати абонемент (admin)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Скасовано
 */
router.put('/:id/cancel', authMiddleware, roleMiddleware('admin'), sc.cancelSubscription);

module.exports = router;