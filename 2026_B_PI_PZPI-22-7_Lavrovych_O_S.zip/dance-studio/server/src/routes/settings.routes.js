const router = require('express').Router();
const pool   = require('../config/db');
const authMiddleware = require('../middleware/auth.middleware');
const roleMiddleware = require('../middleware/role.middleware');

router.get('/public', async (req, res) => {
  try {
    const [[counts]] = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM users WHERE role = 'student') AS students_count,
        (SELECT COUNT(*) FROM dance_styles)                 AS styles_count,
        (SELECT COUNT(*) FROM halls)                        AS halls_count,
        (SELECT COUNT(*) FROM lessons
          WHERE lesson_date >= DATE(NOW() - INTERVAL WEEKDAY(NOW()) DAY)
            AND lesson_date <  DATE(NOW() - INTERVAL WEEKDAY(NOW()) DAY) + INTERVAL 7 DAY
        ) AS weekly_lessons
    `);

    const [settingRows] = await pool.query(
      "SELECT `key`, `value` FROM studio_settings WHERE `key` IN ('studio_name','studio_address','studio_phone','studio_email','studio_founded')"
    );
    const s = {};
    settingRows.forEach(r => { s[r.key] = r.value; });

    const foundedYear  = parseInt(s.studio_founded || '2022', 10);
    const yearsActive  = new Date().getFullYear() - foundedYear;

    res.json({
      students_count: counts.students_count,
      styles_count:   counts.styles_count,
      halls_count:    counts.halls_count,
      weekly_lessons: counts.weekly_lessons,
      years_active:   Math.max(yearsActive, 1),
      studio_name:    s.studio_name    || 'Move Studio',
      studio_address: s.studio_address || '',
      studio_phone:   s.studio_phone   || '',
      studio_email:   s.studio_email   || '',
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

/**
 * @swagger
 * /api/settings:
 *   get:
 *     tags: [Settings]
 *     summary: Отримати всі налаштування (admin)
 */
router.get('/', authMiddleware, roleMiddleware('admin'), async (req, res) => {
  const [rows] = await pool.query('SELECT `key`, `value` FROM studio_settings');
  const settings = {};
  rows.forEach(r => { settings[r.key] = r.value; });
  res.json(settings);
});

/**
 * @swagger
 * /api/settings:
 *   put:
 *     tags: [Settings]
 *     summary: Оновити налаштування (admin)
 */
router.put('/', authMiddleware, roleMiddleware('admin'), async (req, res) => {
  const entries = Object.entries(req.body);
  if (!entries.length) return res.status(400).json({ message: 'Немає даних' });

  await Promise.all(
    entries.map(([key, value]) =>
      pool.query(
        'INSERT INTO studio_settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = ?',
        [key, value, value]
      )
    )
  );
  res.json({ message: 'Збережено' });
});

module.exports = router;