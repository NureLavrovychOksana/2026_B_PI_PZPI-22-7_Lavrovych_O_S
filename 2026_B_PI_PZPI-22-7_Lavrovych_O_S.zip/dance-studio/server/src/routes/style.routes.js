const router = require('express').Router();
const styleController = require('../controllers/style.controller');
const authMiddleware = require('../middleware/auth.middleware');
const roleMiddleware = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Styles
 *   description: Стилі танцю
 */

/**
 * @swagger
 * /api/styles:
 *   get:
 *     tags: [Styles]
 *     summary: Список всіх стилів
 *     security: []
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/DanceStyle'
 */
router.get('/', styleController.getAll);

/**
 * @swagger
 * /api/styles/{id}:
 *   get:
 *     tags: [Styles]
 *     summary: Стиль за ID
 *     security: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DanceStyle'
 */
router.get('/:id', styleController.getById);

/**
 * @swagger
 * /api/styles:
 *   post:
 *     tags: [Styles]
 *     summary: Створити стиль
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateDanceStyleRequest'
 *     responses:
 *       201:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DanceStyle'
 */
router.post('/', authMiddleware, roleMiddleware('admin'), styleController.create);

/**
 * @swagger
 * /api/styles/{id}:
 *   put:
 *     tags: [Styles]
 *     summary: Оновити стиль
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateDanceStyleRequest'
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DanceStyle'
 */
router.put('/:id', authMiddleware, roleMiddleware('admin'), styleController.update);

/**
 * @swagger
 * /api/styles/{id}:
 *   delete:
 *     tags: [Styles]
 *     summary: Видалити стиль
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessMessage'
 */
router.delete('/:id', authMiddleware, roleMiddleware('admin'), styleController.remove);

module.exports = router;