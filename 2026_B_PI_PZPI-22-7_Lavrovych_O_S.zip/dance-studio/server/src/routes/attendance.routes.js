const router = require('express').Router();
const attendanceController = require('../controllers/attendance.controller');
const authMiddleware       = require('../middleware/auth.middleware');
const roleMiddleware       = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Attendance
 *   description: Журнал відвідуваності
 */

/**
 * @swagger
 * /api/attendance:
 *   post:
 *     tags: [Attendance]
 *     summary: Відмітити одного учня (teacher, admin)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [lesson_id, student_id]
 *             properties:
 *               lesson_id:  { type: integer }
 *               student_id: { type: integer }
 *               status:
 *                 type: string
 *                 enum: [present, absent, excused]
 *                 default: present
 *     responses:
 *       201:
 *         description: Відмітку зроблено, повертає sessions_left та no_subscription
 *       403:
 *         description: Учень не записаний або немає доступу
 *       409:
 *         description: Вже відмічено
 */
router.post(
  '/',
  authMiddleware,
  roleMiddleware('admin', 'teacher'),
  attendanceController.mark
);

/**
 * @swagger
 * /api/attendance/bulk:
 *   post:
 *     tags: [Attendance]
 *     summary: Масова відмітка по групі (teacher, admin)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [lesson_id, records]
 *             properties:
 *               lesson_id: { type: integer }
 *               records:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     student_id: { type: integer }
 *                     status:     { type: string, enum: [present, absent, excused] }
 *     responses:
 *       200:
 *         description: Масив results і errors
 */
router.post(
  '/bulk',
  authMiddleware,
  roleMiddleware('admin', 'teacher'),
  attendanceController.markBulk
);

/**
 * @swagger
 * /api/attendance/{id}:
 *   put:
 *     tags: [Attendance]
 *     summary: Скоригувати статус відмітки (admin, teacher)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               status: { type: string, enum: [present, absent, excused] }
 *     responses:
 *       200:
 *         description: Оновлено
 */
router.put(
  '/:id',
  authMiddleware,
  roleMiddleware('admin', 'teacher'),
  attendanceController.updateMark
);

/**
 * @swagger
 * /api/attendance/lesson/{lessonId}:
 *   get:
 *     tags: [Attendance]
 *     summary: Журнал відвідуваності заняття (admin, teacher)
 *     parameters:
 *       - in: path
 *         name: lessonId
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Список відміток
 */
router.get(
  '/lesson/:lessonId',
  authMiddleware,
  roleMiddleware('admin', 'teacher'),
  attendanceController.getByLesson
);

/**
 * @swagger
 * /api/attendance/student/{studentId}:
 *   get:
 *     tags: [Attendance]
 *     summary: Журнал відвідуваності учня (admin, teacher або сам учень)
 *     parameters:
 *       - in: path
 *         name: studentId
 *         required: true
 *         schema: { type: integer }
 *       - in: query
 *         name: date_from
 *         schema: { type: string, format: date }
 *       - in: query
 *         name: date_to
 *         schema: { type: string, format: date }
 *     responses:
 *       200:
 *         description: Список відміток
 */
router.get(
  '/student/:studentId',
  authMiddleware,
  attendanceController.getByStudent
);

module.exports = router;