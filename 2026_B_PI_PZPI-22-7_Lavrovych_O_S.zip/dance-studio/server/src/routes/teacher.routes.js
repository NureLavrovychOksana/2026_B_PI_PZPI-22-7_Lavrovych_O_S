const router = require('express').Router();
const teacherController = require('../controllers/teacher.controller');
const authMiddleware = require('../middleware/auth.middleware');
const roleMiddleware = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Teachers
 *   description: Профілі викладачів
 */

/**
 * @swagger
 * /api/teachers:
 *   get:
 *     tags: [Teachers]
 *     summary: Список всіх викладачів з профілями та стилями
 *     security: []
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/TeacherProfile'
 */
router.get('/', teacherController.getAll);

/**
 * @swagger
 * /api/teachers/me:
 *   get:
 *     tags: [Teachers]
 *     summary: Профіль поточного викладача
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TeacherProfile'
 */
router.get('/me', authMiddleware, roleMiddleware('teacher'), teacherController.getMe);

/**
 * @swagger
 * /api/teachers/me/schedule:
 *   get:
 *     tags: [Teachers]
 *     summary: Розклад поточного викладача
 *     parameters:
 *       - in: query
 *         name: week
 *         schema:
 *           type: string
 *           format: date
 *         description: Початок тижня YYYY-MM-DD (якщо не передано — поточний тиждень)
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Lesson'
 */
router.get('/me/schedule', authMiddleware, roleMiddleware('teacher'), teacherController.getMySchedule);

/**
 * @swagger
 * /api/teachers/me/groups:
 *   get:
 *     tags: [Teachers]
 *     summary: Групи поточного викладача
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/DanceGroup'
 */
router.get('/me/groups',   authMiddleware, roleMiddleware('teacher'), teacherController.getMyGroups);
router.get('/me/finance',  authMiddleware, roleMiddleware('teacher'), teacherController.getMyFinance);

/**
 * @swagger
 * /api/teachers/{id}:
 *   get:
 *     tags: [Teachers]
 *     summary: Профіль викладача за ID
 *     security: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TeacherProfile'
 *       404:
 *         description: Не знайдено
 */
router.get('/payroll-summary', authMiddleware, roleMiddleware('admin'), teacherController.getPayrollSummary);
router.get('/:id', teacherController.getById);

/**
 * @swagger
 * /api/teachers/{id}/schedule:
 *   get:
 *     tags: [Teachers]
 *     summary: Розклад викладача за тиждень
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *       - in: query
 *         name: week
 *         schema:
 *           type: string
 *           format: date
 *         description: Початок тижня YYYY-MM-DD
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Lesson'
 */
router.get('/:id/schedule', teacherController.getSchedule);

/**
 * @swagger
 * /api/teachers/{id}/groups:
 *   get:
 *     tags: [Teachers]
 *     summary: Групи викладача
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/DanceGroup'
 */
router.get('/:id/groups', authMiddleware, roleMiddleware('admin'), teacherController.getGroups);

/**
 * @swagger
 * /api/teachers:
 *   post:
 *     tags: [Teachers]
 *     summary: Створити викладача (user + profile + styles)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email, first_name, last_name]
 *             properties:
 *               email:            { type: string }
 *               password:         { type: string, description: "Якщо не передано — teacher123" }
 *               first_name:       { type: string }
 *               last_name:        { type: string }
 *               phone:            { type: string }
 *               bio:              { type: string }
 *               experience_years: { type: integer }
 *               education:        { type: string }
 *               style_ids:
 *                 type: array
 *                 items:
 *                   type: integer
 *     responses:
 *       201:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TeacherProfile'
 *       409:
 *         description: Email вже зайнятий
 */
router.post('/', authMiddleware, roleMiddleware('admin'), teacherController.create);

/**
 * @swagger
 * /api/teachers/{id}:
 *   put:
 *     tags: [Teachers]
 *     summary: Оновити профіль викладача
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               first_name:       { type: string }
 *               last_name:        { type: string }
 *               phone:            { type: string }
 *               email:            { type: string }
 *               bio:              { type: string }
 *               experience_years: { type: integer }
 *               education:        { type: string }
 *               style_ids:
 *                 type: array
 *                 items:
 *                   type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/TeacherProfile'
 */
router.put('/:id', authMiddleware, roleMiddleware('admin', 'teacher'), teacherController.update);

router.get('/:id/finance',    authMiddleware, roleMiddleware('admin'), teacherController.getTeacherFinance);
router.put('/:id/rate',       authMiddleware, roleMiddleware('admin'), teacherController.setRate);
router.get('/:id/payouts',    authMiddleware, roleMiddleware('admin'), teacherController.getPayouts);
router.post('/:id/payouts',   authMiddleware, roleMiddleware('admin'), teacherController.addPayout);

module.exports = router;