const router = require('express').Router();
const notificationController = require('../controllers/notification.controller');
const authMiddleware         = require('../middleware/auth.middleware');
const roleMiddleware         = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Notifications
 *   description: Сповіщення
 */

/**
 * @swagger
 * /api/notifications:
 *   get:
 *     tags: [Notifications]
 *     summary: Мої сповіщення
 *     responses:
 *       200:
 *         description: Список сповіщень
 */
router.get('/', authMiddleware, notificationController.getMyNotifications);

/**
 * @swagger
 * /api/notifications/unread-count:
 *   get:
 *     tags: [Notifications]
 *     summary: Кількість непрочитаних
 *     responses:
 *       200:
 *         description: '{ count: N }'
 */
router.get('/unread-count', authMiddleware, notificationController.getUnreadCount);

/**
 * @swagger
 * /api/notifications/{id}/read:
 *   put:
 *     tags: [Notifications]
 *     summary: Позначити одне прочитаним
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Оновлено
 *       404:
 *         description: Не знайдено
 */
router.put('/:id/read', authMiddleware, notificationController.markRead);

/**
 * @swagger
 * /api/notifications/read-all:
 *   put:
 *     tags: [Notifications]
 *     summary: Позначити всі прочитаними
 *     responses:
 *       200:
 *         description: '{ updated: N }'
 */
router.put('/read-all', authMiddleware, notificationController.markAllRead);

/**
 * @swagger
 * /api/notifications/broadcast:
 *   post:
 *     tags: [Notifications]
 *     summary: Розіслати сповіщення (admin)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [title]
 *             properties:
 *               title:    { type: string }
 *               body:     { type: string }
 *               type:     { type: string, example: manual }
 *               group_id: { type: integer, description: "NULL = всім студентам" }
 *     responses:
 *       200:
 *         description: '{ sent: N }'
 */
router.post(
  '/broadcast',
  authMiddleware,
  roleMiddleware('admin'),
  notificationController.broadcast
);

router.post(
  '/send-email',
  authMiddleware,
  roleMiddleware('admin'),
  notificationController.sendEmail
);

module.exports = router;