const router         = require('express').Router();
const scheduleService = require('../services/schedule.service');
const scheduleRepo    = require('../repositories/schedule.repository');
const authMiddleware  = require('../middleware/auth.middleware');
const roleMiddleware  = require('../middleware/role.middleware');
const asyncHandler    = require('../middleware/asyncHandler');

const auth = [authMiddleware, roleMiddleware('admin')];

router.get('/group-requirements', ...auth, asyncHandler(async (req, res) => {
  res.json(await scheduleRepo.getGroupRequirements());
}));

router.put('/group-requirements/:groupId', ...auth, asyncHandler(async (req, res) => {
  await scheduleRepo.upsertGroupRequirement(Number(req.params.groupId), req.body);
  res.json({ ok: true });
}));

router.get('/teacher-availability/:teacherId', ...auth, asyncHandler(async (req, res) => {
  res.json(await scheduleRepo.getTeacherAvailability(Number(req.params.teacherId)));
}));

router.put('/teacher-availability/:teacherId', ...auth, asyncHandler(async (req, res) => {
  await scheduleRepo.upsertTeacherAvailability(Number(req.params.teacherId), req.body.blocks);
  res.json({ ok: true });
}));

// generate returns JSON, nothing is saved to DB at this stage
router.post('/generate-draft', ...auth, asyncHandler(async (req, res) => {
  const { week_start, group_requirements, hall_ids, allowed_days, time_from, time_to, slot_step } = req.body;
  res.json(await scheduleService.generateDraft({
    weekStart:         week_start,
    groupRequirements: group_requirements,
    hallIds:           hall_ids,
    allowedDays:       allowed_days,
    timeFrom:          time_from,
    timeTo:            time_to,
    slotStep:          slot_step ?? 30,
  }));
}));

router.get('/week-status', ...auth, asyncHandler(async (req, res) => {
  const { week_start } = req.query;
  if (!week_start) return res.status(400).json({ message: 'week_start required' });
  res.json(await scheduleService.getWeekStatus(week_start));
}));

router.post('/publish', ...auth, asyncHandler(async (req, res) => {
  const { lessons, mode, week_start } = req.body;
  res.json(await scheduleService.publishSchedule(lessons, mode, week_start));
}));

module.exports = router;
