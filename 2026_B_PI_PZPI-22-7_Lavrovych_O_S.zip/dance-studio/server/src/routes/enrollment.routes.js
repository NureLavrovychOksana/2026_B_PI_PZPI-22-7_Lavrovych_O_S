const router = require('express').Router();
const c = require('../controllers/enrollment.controller');
const auth = require('../middleware/auth.middleware');
const role = require('../middleware/role.middleware');

router.post('/', auth, role('admin'), c.enroll);

router.post('/bulk', auth, role('admin'), c.bulkEnroll);

router.post('/by-teacher', auth, role('admin', 'teacher'), c.teacherManualEnroll);

router.post('/self', auth, role('student'), c.selfEnroll);

router.post('/waitlist',           auth, role('student'),          c.joinWaitlist);
router.delete('/waitlist/:id',     auth,                           c.leaveWaitlist);
router.get('/waitlist/my',         auth, role('student'),          c.getWaitlistByStudent);
router.get('/waitlist/lesson/:lessonId', auth, role('admin', 'teacher'), c.getWaitlistByLesson);

router.delete('/:id', auth, c.unenroll);

router.get('/lesson/:lessonId',   auth, role('admin', 'teacher'), c.getByLesson);
router.get('/student/:studentId', auth,                            c.getByStudent);

module.exports = router;
