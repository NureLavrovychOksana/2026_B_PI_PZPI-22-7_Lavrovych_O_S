const router = require('express').Router();
const rc             = require('../controllers/report.controller');
const authMiddleware = require('../middleware/auth.middleware');
const roleMiddleware = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Reports
 *   description: Аналітика та звіти
 */

/**
 * @swagger
 * /api/reports/dashboard:
 *   get:
 *     tags: [Reports]
 *     summary: Дашборд адміна — KPI, графік доходів, стилі, активність
 *     responses:
 *       200:
 *         description: Агреговані дані для дашборду
 */
router.get('/dashboard', authMiddleware, roleMiddleware('admin'), rc.getDashboard);

/**
 * @swagger
 * /api/reports/revenue:
 *   get:
 *     tags: [Reports]
 *     summary: Графік доходів
 *     parameters:
 *       - in: query
 *         name: months
 *         schema: { type: integer, default: 12 }
 *         description: Кількість місяців назад
 *       - in: query
 *         name: group_by
 *         schema: { type: string, enum: [month, week] }
 *     responses:
 *       200:
 *         description: Масив { month/week_start, total }
 */
router.get('/revenue', authMiddleware, roleMiddleware('admin'), rc.getRevenue);

/**
 * @swagger
 * /api/reports/attendance:
 *   get:
 *     tags: [Reports]
 *     summary: Відвідуваність по групах за період
 *     parameters:
 *       - in: query
 *         name: date_from
 *         schema: { type: string, format: date }
 *       - in: query
 *         name: date_to
 *         schema: { type: string, format: date }
 *     responses:
 *       200:
 *         description: Масив груп зі статистикою відвідуваності
 */
router.get('/attendance', authMiddleware, roleMiddleware('admin', 'teacher'), rc.getAttendance);

/**
 * @swagger
 * /api/reports/teachers/{teacherId}:
 *   get:
 *     tags: [Reports]
 *     summary: Детальний звіт по викладачу
 *     parameters:
 *       - in: path
 *         name: teacherId
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Профіль, стилі, статистика занять, деталі по групах
 */
router.get('/teachers/:teacherId', authMiddleware, roleMiddleware('admin'), rc.getTeacherReport);

/**
 * @swagger
 * /api/reports/debtors:
 *   get:
 *     tags: [Reports]
 *     summary: Учні без активного абонементу
 *     responses:
 *       200:
 *         description: Список боржників з датою останнього платежу
 */
router.get('/debtors', authMiddleware, roleMiddleware('admin'), rc.getDebtors);

/**
 * @swagger
 * /api/reports/expiring-subscriptions:
 *   get:
 *     tags: [Reports]
 *     summary: Абонементи що закінчуються найближчим часом
 *     parameters:
 *       - in: query
 *         name: days
 *         schema: { type: integer, default: 14 }
 *     responses:
 *       200:
 *         description: Список учнів з інформацією про абонемент і кількістю днів що залишились
 */
router.get('/expiring-subscriptions', authMiddleware, roleMiddleware('admin'), rc.getExpiringSubscriptions);

/**
 * @swagger
 * /api/reports/students/{studentId}:
 *   get:
 *     tags: [Reports]
 *     summary: Особиста статистика учня (сам учень або адмін/викладач)
 *     parameters:
 *       - in: path
 *         name: studentId
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Загальна відвідуваність, поточний місяць, статистика по групах
 */
router.get('/students/:studentId', authMiddleware, rc.getStudentStats);

router.get('/students-at-risk',  authMiddleware, roleMiddleware('admin'), rc.getStudentsAtRisk);
router.get('/attendance-logs',   authMiddleware, roleMiddleware('admin'), rc.getAttendanceLogs);
router.get('/transaction-logs',  authMiddleware, roleMiddleware('admin'), rc.getTransactionLogs);
router.get('/attendance-csv',    authMiddleware, roleMiddleware('admin'), rc.getAttendanceCsv);
router.get('/transaction-csv',   authMiddleware, roleMiddleware('admin'), rc.getTransactionCsv);
router.get('/debtors-csv',       authMiddleware, roleMiddleware('admin'), rc.getDebtorsCsv);
router.get('/teachers/:teacherId/timesheet',  authMiddleware, roleMiddleware('admin', 'teacher'), rc.getTeacherTimesheet);
router.get('/teachers/:teacherId/discipline', authMiddleware, roleMiddleware('admin', 'teacher'), rc.getTeacherDisciplineStats);

module.exports = router;