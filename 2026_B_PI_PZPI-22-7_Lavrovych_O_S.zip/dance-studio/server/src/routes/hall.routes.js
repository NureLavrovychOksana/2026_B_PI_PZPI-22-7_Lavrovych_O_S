const router = require('express').Router();
const hallController = require('../controllers/hall.controller');
const authMiddleware = require('../middleware/auth.middleware');
const roleMiddleware = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Halls
 *   description: Управління залами студії
 */

/**
 * @swagger
 * /api/halls:
 *   get:
 *     tags: [Halls]
 *     summary: Список всіх залів
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Hall'
 */
router.get('/', authMiddleware, hallController.getAll);

/**
 * @swagger
 * /api/halls/{id}:
 *   get:
 *     tags: [Halls]
 *     summary: Зал за ID
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Hall'
 *       404:
 *         description: Зал не знайдено
 */
router.get('/:id', authMiddleware, hallController.getById);

/**
 * @swagger
 * /api/halls:
 *   post:
 *     tags: [Halls]
 *     summary: Створити зал
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateHallRequest'
 *     responses:
 *       201:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Hall'
 */
router.post('/', authMiddleware, roleMiddleware('admin'), hallController.create);

/**
 * @swagger
 * /api/halls/{id}:
 *   put:
 *     tags: [Halls]
 *     summary: Оновити зал
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateHallRequest'
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Hall'
 */
router.put('/:id', authMiddleware, roleMiddleware('admin'), hallController.update);

/**
 * @swagger
 * /api/halls/{id}:
 *   delete:
 *     tags: [Halls]
 *     summary: Видалити зал
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SuccessMessage'
 */
router.delete('/:id', authMiddleware, roleMiddleware('admin'), hallController.remove);

router.post('/:id/restore', authMiddleware, roleMiddleware('admin'), hallController.restore);

module.exports = router;