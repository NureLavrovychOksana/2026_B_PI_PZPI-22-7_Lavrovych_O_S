const router = require('express').Router();
const lessonController = require('../controllers/lesson.controller');
const authMiddleware   = require('../middleware/auth.middleware');
const roleMiddleware   = require('../middleware/role.middleware');

/**
 * @swagger
 * tags:
 *   name: Lessons
 *   description: Заняття та розклад
 */

/**
 * @swagger
 * /api/lessons:
 *   get:
 *     tags: [Lessons]
 *     summary: Розклад занять
 *     parameters:
 *       - in: query
 *         name: week
 *         schema: { type: string, format: date }
 *         description: Понеділок тижня (YYYY-MM-DD)
 *       - in: query
 *         name: groupId
 *         schema: { type: integer }
 *       - in: query
 *         name: teacherId
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Список занять
 */
router.get('/', lessonController.getAll);

/**
 * @swagger
 * /api/lessons/{id}:
 *   get:
 *     tags: [Lessons]
 *     summary: Деталі заняття
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Заняття
 *       404:
 *         description: Не знайдено
 */
router.get('/:id', lessonController.getById);

/**
 * @swagger
 * /api/lessons:
 *   post:
 *     tags: [Lessons]
 *     summary: Створити заняття (admin)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [group_id, hall_id, lesson_date, start_time, end_time]
 *             properties:
 *               group_id:    { type: integer }
 *               hall_id:     { type: integer }
 *               lesson_date: { type: string, format: date }
 *               start_time:  { type: string, example: "10:00" }
 *               end_time:    { type: string, example: "11:30" }
 *     responses:
 *       201:
 *         description: Заняття створено
 *       409:
 *         description: Конфлікт розкладу
 */
router.post('/', authMiddleware, roleMiddleware('admin'), lessonController.create);

/**
 * @swagger
 * /api/lessons/{id}:
 *   put:
 *     tags: [Lessons]
 *     summary: Оновити заняття (admin)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               group_id:    { type: integer }
 *               hall_id:     { type: integer }
 *               lesson_date: { type: string, format: date }
 *               start_time:  { type: string }
 *               end_time:    { type: string }
 *     responses:
 *       200:
 *         description: Оновлено
 *       409:
 *         description: Конфлікт розкладу
 */
router.put('/:id', authMiddleware, roleMiddleware('admin'), lessonController.update);

/**
 * @swagger
 * /api/lessons/{id}:
 *   delete:
 *     tags: [Lessons]
 *     summary: Видалити заняття (admin)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema: { type: integer }
 *     responses:
 *       200:
 *         description: Видалено
 */
router.delete('/:id', authMiddleware, roleMiddleware('admin'), lessonController.remove);

router.put('/:id/notes', authMiddleware, roleMiddleware('admin', 'teacher'), lessonController.updateNotes);
router.get('/group/:groupId/notes', authMiddleware, roleMiddleware('admin', 'teacher'), lessonController.getNotesByGroup);

module.exports = router;