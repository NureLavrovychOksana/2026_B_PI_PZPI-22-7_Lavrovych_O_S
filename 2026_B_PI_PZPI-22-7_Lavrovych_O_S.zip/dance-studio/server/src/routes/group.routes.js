const router = require('express').Router();
const groupController = require('../controllers/group.controller');
const authMiddleware  = require('../middleware/auth.middleware');
const roleMiddleware  = require('../middleware/role.middleware');
const optionalAuth    = require('../middleware/optionalAuth.middleware');

/**
 * @swagger
 * tags:
 *   name: Groups
 *   description: Танцювальні групи
 */

/**
 * @swagger
 * /api/groups:
 *   get:
 *     tags: [Groups]
 *     summary: Список груп (admin — всі, teacher — тільки свої)
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/DanceGroup'
 */
router.get('/', optionalAuth, groupController.getAll);

/**
 * @swagger
 * /api/groups/{id}:
 *   get:
 *     tags: [Groups]
 *     summary: Деталі групи
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DanceGroup'
 *       404:
 *         description: Групу не знайдено
 */
router.get('/:id', optionalAuth, groupController.getById);

/**
 * @swagger
 * /api/groups/{id}/attendance-stats:
 *   get:
 *     tags: [Groups]
 *     summary: Статистика відвідуваності групи по учнях
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *       - in: query
 *         name: date_from
 *         schema:
 *           type: string
 *           format: date
 *         description: Початок діапазону (необов'язково)
 *       - in: query
 *         name: date_to
 *         schema:
 *           type: string
 *           format: date
 *         description: Кінець діапазону (необов'язково)
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/AttendanceReport'
 */
router.get(
  '/:id/attendance-stats',
  authMiddleware,
  roleMiddleware('admin', 'teacher'),
  groupController.getAttendanceStats
);

/**
 * @swagger
 * /api/groups:
 *   post:
 *     tags: [Groups]
 *     summary: Створити групу
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateGroupRequest'
 *     responses:
 *       201:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DanceGroup'
 *       400:
 *         description: Невалідні дані або не знайдено звʼязані сутності
 */
router.post(
  '/',
  authMiddleware,
  roleMiddleware('admin'),
  groupController.create
);

/**
 * @swagger
 * /api/groups/{id}:
 *   put:
 *     tags: [Groups]
 *     summary: Оновити групу
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateGroupRequest'
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/DanceGroup'
 */
router.put(
  '/:id',
  authMiddleware,
  roleMiddleware('admin'),
  groupController.update
);

/**
 * @swagger
 * /api/groups/{id}:
 *   delete:
 *     tags: [Groups]
 *     summary: Видалити групу (каскадно видаляє всі заняття групи)
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:         { type: string }
 *                 deleted_lessons: { type: integer }
 */
router.delete(
  '/:id',
  authMiddleware,
  roleMiddleware('admin'),
  groupController.remove
);

module.exports = router;