const pool                = require('../config/db');
const notificationRepo    = require('../repositories/notification.repository');
const { sendLessonReminderEmail } = require('../utils/mailer');
const { notifyAdmins }    = require('../utils/adminNotify');

const getSetting = async (key) => {
  try {
    const [[row]] = await pool.query("SELECT `value` FROM studio_settings WHERE `key` = ?", [key]);
    return row?.value ?? null;
  } catch { return null; }
};

const checkAndCancelUnderpopulatedLessons = async () => {
  try {
    const minStr   = await getSetting('min_students_cancel');
    const minStudents = Number(minStr) || 0;
    if (minStudents === 0) return;

    const hoursStr = await getSetting('cancel_hours_before');
    const windowH  = Math.max(Number(hoursStr) || 2, 1);

    const [lessons] = await pool.query(`
      SELECT l.id, l.lesson_date, l.start_time,
             dg.name AS group_name,
             COALESCE(l.teacher_id, dg.teacher_id) AS teacher_id,
             COUNT(e.id) AS enrolled_count
      FROM lessons l
      JOIN dance_groups dg ON dg.id = l.group_id
      LEFT JOIN enrollments e ON e.lesson_id = l.id
      WHERE l.status = 'scheduled'
        AND TIMESTAMP(l.lesson_date, l.start_time)
              BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL ? HOUR)
      GROUP BY l.id, l.lesson_date, l.start_time, dg.name, l.teacher_id, dg.teacher_id
      HAVING enrolled_count < ?
    `, [windowH, minStudents]);

    for (const lesson of lessons) {
      await pool.query("UPDATE lessons SET status = 'cancelled' WHERE id = ?", [lesson.id]);

      const label = `${lesson.group_name} ${String(lesson.start_time).slice(0, 5)} (${lesson.lesson_date})`;

      const [enrolled] = await pool.query(
        'SELECT student_id FROM enrollments WHERE lesson_id = ?', [lesson.id]
      );
      for (const r of enrolled) {
        notificationRepo.create({
          userId: r.student_id,
          type:   'lesson_cancelled',
          title:  'Заняття скасовано',
          body:   `Заняття ${label} скасовано: недостатня кількість учнів (${lesson.enrolled_count}/${minStudents}).`,
        }).catch(() => {});
      }

      if (lesson.teacher_id) {
        notificationRepo.create({
          userId: lesson.teacher_id,
          type:   'lesson_cancelled',
          title:  'Заняття скасовано',
          body:   `Заняття ${label} скасовано автоматично — недостатня кількість учнів (${lesson.enrolled_count}/${minStudents}).`,
        }).catch(() => {});
      }

      notifyAdmins(
        'lesson_cancelled',
        'Заняття скасовано',
        `${label} скасовано автоматично — недостатня кількість учнів (${lesson.enrolled_count}/${minStudents}).`,
        'notify_lesson_cancel'
      ).catch(() => {});

      console.log(`[autoCancel] lesson ${lesson.id} cancelled: ${lesson.enrolled_count}/${minStudents} students`);
    }
  } catch (err) {
    console.error('[checkAndCancelUnderpopulatedLessons]', err.message);
  }
};

const sendLessonReminders = async () => {
  try {
    const [lessons] = await pool.query(`
      SELECT
        l.id        AS lesson_id,
        l.lesson_date,
        l.start_time,
        dg.name     AS group_name,
        ds.name     AS style_name,
        h.name      AS hall_name
      FROM lessons l
      JOIN dance_groups  dg ON dg.id = l.group_id
      JOIN dance_styles  ds ON ds.id = dg.style_id
      JOIN halls         h  ON h.id  = l.hall_id
      WHERE l.status = 'scheduled'
        AND TIMESTAMP(l.lesson_date, l.start_time)
              BETWEEN DATE_ADD(NOW(), INTERVAL 50 MINUTE)
                  AND DATE_ADD(NOW(), INTERVAL 70 MINUTE)
    `);

    if (lessons.length === 0) return;

    for (const lesson of lessons) {
      const [enrolled] = await pool.query(`
        SELECT u.id, u.first_name, u.last_name, u.email, u.notification_prefs
        FROM enrollments e
        JOIN users u ON u.id = e.student_id
        WHERE e.lesson_id = ?
      `, [lesson.lesson_id]);

      for (const student of enrolled) {
        const prefs = student.notification_prefs
          ? (typeof student.notification_prefs === 'string'
              ? JSON.parse(student.notification_prefs)
              : student.notification_prefs)
          : { sms: true, email: true };

        const marker = `lesson_id:${lesson.lesson_id}`;

        const [[existing]] = await pool.query(`
          SELECT id FROM notifications
          WHERE user_id = ? AND type = 'lesson_reminder' AND body LIKE ?
            AND created_at >= CURDATE()
        `, [student.id, `%${marker}%`]);

        if (existing) continue;

        const timeStr  = String(lesson.start_time).slice(0, 5);
        const title    = `Заняття через 1 годину: ${lesson.group_name}`;
        const body     = `${lesson.style_name} · ${timeStr} · ${lesson.hall_name} [${marker}]`;

        if (prefs.sms !== false) {
          await notificationRepo.create({
            userId: student.id,
            type:   'lesson_reminder',
            title,
            body,
          });
        }

        if (prefs.email !== false) {
          sendLessonReminderEmail({
            to:        student.email,
            name:      student.first_name,
            groupName: lesson.group_name,
            styleName: lesson.style_name,
            hallName:  lesson.hall_name,
            date:      lesson.lesson_date,
            time:      timeStr,
          }).catch(err => console.error('[reminder email]', err.message));
        }
      }
    }
  } catch (err) {
    console.error('[lessonReminders]', err.message);
  }
};

const checkExpiringSubscriptions = async () => {
  try {
    const enabledStr = await getSetting('notify_subscription_exp');
    if (enabledStr !== '1') return;

    const [expiring] = await pool.query(`
      SELECT ss.id, ss.expiry_date,
             u.first_name, u.last_name,
             sp.name AS plan_name
      FROM student_subscriptions ss
      JOIN users u  ON u.id = ss.student_id
      JOIN subscription_plans sp ON sp.id = ss.plan_id
      WHERE ss.status = 'active'
        AND ss.expiry_date IS NOT NULL
        AND ss.expiry_date = CURDATE() + INTERVAL 3 DAY
    `);

    for (const sub of expiring) {
      const [[dup]] = await pool.query(
        `SELECT id FROM notifications
         WHERE type = 'subscription_expiring'
           AND body LIKE ?
           AND created_at >= CURDATE()
         LIMIT 1`,
        [`%[sub:${sub.id}]%`]
      );
      if (dup) continue;

      const expDate = new Date(sub.expiry_date).toLocaleDateString('uk-UA');
      await notifyAdmins(
        'subscription_expiring',
        'Закінчення абонементу',
        `${sub.first_name} ${sub.last_name} — «${sub.plan_name}» закінчується ${expDate}. [sub:${sub.id}]`
      );
    }
  } catch (err) {
    console.error('[checkExpiringSubscriptions]', err.message);
  }
};

const startLessonReminderJob = () => {
  const tick = () => {
    checkAndCancelUnderpopulatedLessons();
    sendLessonReminders();
    checkExpiringSubscriptions();
  };
  tick(); // run once on start
  setInterval(tick, 15 * 60 * 1000); // then every 15 min
  console.log('Lesson reminder + auto-cancel job started (every 15 min)');
};

module.exports = { startLessonReminderJob };
