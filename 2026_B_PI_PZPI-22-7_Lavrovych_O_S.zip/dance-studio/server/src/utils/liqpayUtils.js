'use strict';
const crypto = require('crypto');

/**
 * @param {string} privateKey
 * @param {string} data 
 * @returns {string}
 */
const computeSignature = (privateKey, data) =>
  crypto.createHash('sha1').update(privateKey + data + privateKey).digest('base64');

/**
 * @param {object} params
 * @returns {string}
 */
const encodeParams = (params) =>
  Buffer.from(JSON.stringify(params)).toString('base64');

/**
 * @param {string} privateKey
 * @param {string} data
 * @param {string} signature
 * @returns {boolean}
 */
const verifySignature = (privateKey, data, signature) =>
  computeSignature(privateKey, data) === signature;

module.exports = { computeSignature, encodeParams, verifySignature };
