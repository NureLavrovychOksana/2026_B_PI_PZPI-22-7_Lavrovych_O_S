const toMin    = t => { const [h, m] = String(t).split(':').map(Number); return h * 60 + m; };
const overlaps = (aS, aE, bS, bE) => aS < bE && aE > bS;

// same group must have at least 22h between lessons to avoid fatigue
const MIN_GROUP_GAP_MIN = 22 * 60;
// prime time starts at 17:00 for adult groups on weekdays
const PRIME_MIN = 17 * 60;

// hard constraints
const validateHardConstraints = (assignment, existing) => {
  const { group_id, teacher_id, hall_id, dayIdx, startMin, endMin } = assignment;
  const violations = [];
  const candAbsStart = dayIdx * 1440 + startMin;
  const candAbsEnd   = dayIdx * 1440 + endMin;

  for (const ex of existing) {
    if (ex.group_id === group_id) {
      const exAbsStart = ex.dayIdx * 1440 + ex.startMin;
      const exAbsEnd   = ex.dayIdx * 1440 + ex.endMin;
      const gap = candAbsStart >= exAbsEnd
        ? candAbsStart - exAbsEnd
        : exAbsStart - candAbsEnd;
      if (gap < MIN_GROUP_GAP_MIN)
        violations.push({ type: 'group_gap', msg: `Менш ніж 22 год між заняттями групи (інтервал: ${Math.round(gap / 60)} год)` });
    }
    if (ex.dayIdx !== dayIdx) continue;
    if (!overlaps(startMin, endMin, ex.startMin, ex.endMin)) continue;
    if (ex.hall_id    === hall_id)    violations.push({ type: 'hall_conflict',    msg: `Зал зайнятий: ${ex.group_name || `група #${ex.group_id}`}` });
    if (ex.teacher_id === teacher_id) violations.push({ type: 'teacher_conflict', msg: `Викладач веде: ${ex.group_name || `група #${ex.group_id}`}` });
  }

  return { valid: violations.length === 0, violations };
};

// soft constraints — score starts at 100, range 0-125
const calculateScheduleScore = (assignment, allAssigned, req, hall, context = {}) => {
  const { group_id, teacher_id, dayIdx, startMin, endMin } = assignment;
  let score = 100;
  const warnings = [];

  const isWeekday = dayIdx <= 4;
  const inPrime   = startMin >= PRIME_MIN;

  // S1: prime time
  if (req) {
    if (req.is_children) {
      if (inPrime && isWeekday)     { score -= 25; warnings.push({ type: 'timing', msg: 'Дитяча група в прайм-тайм (рекомендовано до 17:00 у будні)' }); }
      else if (startMin >= 18 * 60) { score -= 20; warnings.push({ type: 'timing', msg: 'Дитяча група після 18:00' }); }
    } else if (isWeekday) {
      if (inPrime) { score += 25; }
      else         { score -= 50; warnings.push({ type: 'timing', msg: 'Доросла група вдень у будні (рекомендується 17:00–21:00)' }); }
    }
    if (req.preferred_start && req.preferred_end) {
      if (!(startMin >= toMin(req.preferred_start) && endMin <= toMin(req.preferred_end))) {
        score -= 10;
        warnings.push({ type: 'timing', msg: `Поза бажаним вікном ${req.preferred_start}–${req.preferred_end}` });
      }
    }
  }

  // S2: teacher idle gaps
  for (const other of allAssigned.filter(a => a.teacher_id === teacher_id && a.dayIdx === dayIdx)) {
    const gap = Math.max(0, startMin > other.endMin ? startMin - other.endMin : other.startMin - endMin);
    if (gap > 60 && gap < 480) {
      score -= Math.min(25, Math.floor(gap / 60) * 8);
      warnings.push({ type: 'teacher_gap', msg: `Простій викладача ${(gap / 60).toFixed(1)} год між заняттями` });
    }
  }

  // S3: even day spread
  const groupDays = allAssigned.filter(a => a.group_id === group_id).map(a => a.dayIdx);
  if (req && req.lessons_per_week > 1 && groupDays.length > 0) {
    if (groupDays.every(d => d === dayIdx)) { score -= 30; warnings.push({ type: 'day_spread', msg: 'Усі заняття групи в один день' }); }
    const ideal = Math.round(7 / req.lessons_per_week);
    const minGapDays = Math.min(...groupDays.map(d => Math.abs(d - dayIdx)));
    if (minGapDays === 1) {
      score -= 40;
      warnings.push({ type: 'day_spread', msg: 'Заняття в суміжні дні' });
    } else if (minGapDays < Math.max(1, ideal - 1)) {
      score -= 15;
      warnings.push({ type: 'day_spread', msg: `Заняття надто близько (рекомендується ~${ideal} дні між заняттями)` });
    }
  }

  // S4: hall capacity
  if (hall && req?.typical_students) {
    const ratio = req.typical_students / hall.capacity;
    if      (ratio > 1.0)  { score -= 30; warnings.push({ type: 'hall_capacity', msg: `Зал замалий: ${req.typical_students}/${hall.capacity} — переповнення` }); }
    else if (ratio < 0.25) { score -= 15; warnings.push({ type: 'hall_capacity', msg: `Зал завеликий: ${Math.round(ratio * 100)}% заповнення` }); }
    else if (ratio < 0.5)  { score -= 5; }
  }

  // S5: day popularity
  if (req && !req.is_children) {
    if (dayIdx === 4 && inPrime) score -= 5;
    if (!isWeekday && (req.typical_students || 0) >= 8) { score -= 10; warnings.push({ type: 'day_popularity', msg: 'Масова доросла група на вихідному — рекомендуються будні' }); }
  }

  // S6: back-to-back in hall
  if (hall) {
    const tFrom   = context.timeFromMin ?? 9 * 60;
    const tTo     = context.timeToMin   ?? 21 * 60;
    const hallDay = allAssigned.filter(a => a.hall_id === hall.id && a.dayIdx === dayIdx);
    if (hallDay.length === 0) {
      const penalty = Math.round((Math.abs(startMin - (tFrom + tTo) / 2) / Math.max(1, (tTo - tFrom) / 2)) * 28);
      if (penalty > 4) {
        score -= penalty;
        if (penalty > 14) warnings.push({ type: 'day_center', msg: 'Одиночне заняття біля краю дня' });
      }
    } else {
      let minGap = Infinity;
      for (const a of hallDay) {
        if (startMin - a.endMin >= 0) minGap = Math.min(minGap, startMin - a.endMin);
        if (a.startMin - endMin >= 0) minGap = Math.min(minGap, a.startMin - endMin);
      }
      if (minGap === Infinity) minGap = 0;
      if (minGap > 0) {
        score -= Math.min(60, Math.round(minGap / 30) * 16);
        if (minGap >= 60) warnings.push({ type: 'hall_gap', msg: `Вікно в залі ${minGap} хв — рекомендується Back-to-Back розміщення` });
      }
    }
  }

  return { score: Math.max(0, score), warnings };
};

// domain builder
const buildSlotsForGroup = (durationMin, allowedDays, timeFromMin, timeToMin, stepMin) => {
  const slots = [];
  for (const dayIdx of allowedDays)
    for (let start = timeFromMin; start + durationMin <= timeToMin; start += stepMin)
      slots.push({ dayIdx, startMin: start, endMin: start + durationMin });
  return slots;
};

const isTeacherBlocked = (assignment, availability) =>
  (availability[assignment.teacher_id] || []).some(
    b => b.dayIdx === assignment.dayIdx && overlaps(assignment.startMin, assignment.endMin, b.startMin, b.endMin)
  );

// candidate builder — LCV
const buildCandidates = (variable, allAssigned, halls, availability, remaining, allowedDays, timeFromMin, timeToMin, stepMin) => {
  const slots      = buildSlotsForGroup(variable.duration_min, allowedDays, timeFromMin, timeToMin, stepMin);
  const sampleSize = Math.min(remaining.length, 8);
  const candidates = [];

  for (const slot of slots) {
    for (const hall of halls) {
      const cand = { group_id: variable.group_id, teacher_id: variable.req.teacher_id, hall_id: hall.id, group_name: variable.req.group_name, ...slot };
      if (!validateHardConstraints(cand, allAssigned).valid || isTeacherBlocked(cand, availability)) continue;

      const tentative = [...allAssigned, cand];
      const remaining_options = remaining.slice(0, sampleSize).reduce((sum, other) => {
        const oSlots = buildSlotsForGroup(other.duration_min, allowedDays, timeFromMin, timeToMin, stepMin);
        for (const os of oSlots)
          for (const h of halls)
            if (validateHardConstraints({ group_id: other.group_id, teacher_id: other.req.teacher_id, hall_id: h.id, ...os }, tentative).valid) sum++;
        return sum;
      }, 0);

      const { score } = calculateScheduleScore(cand, allAssigned, variable.req, hall, { timeFromMin, timeToMin });
      candidates.push({ cand, remaining_options, score });
    }
  }

  const dayLoad = allAssigned.reduce((acc, a) => ({ ...acc, [a.dayIdx]: (acc[a.dayIdx] || 0) + 1 }), {});
  candidates.sort((a, b) => {
    const mA = a.score - (dayLoad[a.cand.dayIdx] || 0) * 15;
    const mB = b.score - (dayLoad[b.cand.dayIdx] || 0) * 15;
    return mA !== mB ? mB - mA : b.remaining_options - a.remaining_options;
  });

  return candidates;
};

// greedy CSP with MRV + LCV — picks the most constrained variable first
const backtrackDraft = (variables, allAssigned, halls, availability, allowedDays, timeFromMin, timeToMin, stepMin) => {
  if (variables.length === 0) return { placed: allAssigned, unplaced: [] };

  let minCount = Infinity, chosenIdx = 0;
  for (let i = 0; i < variables.length; i++) {
    const v = variables[i];
    let count = 0;
    for (const slot of buildSlotsForGroup(v.duration_min, allowedDays, timeFromMin, timeToMin, stepMin))
      for (const hall of halls) {
        const cand = { group_id: v.group_id, teacher_id: v.req.teacher_id, hall_id: hall.id, ...slot };
        if (validateHardConstraints(cand, allAssigned).valid && !isTeacherBlocked(cand, availability)) count++;
      }
    if (count < minCount) { minCount = count; chosenIdx = i; }
  }

  const variable  = variables[chosenIdx];
  const remaining = [...variables.slice(0, chosenIdx), ...variables.slice(chosenIdx + 1)];
  const candidates = buildCandidates(variable, allAssigned, halls, availability, remaining, allowedDays, timeFromMin, timeToMin, stepMin);

  if (candidates.length === 0) {
    const { placed, unplaced } = backtrackDraft(remaining, allAssigned, halls, availability, allowedDays, timeFromMin, timeToMin, stepMin);
    return { placed, unplaced: [{ ...variable, reason: 'Немає доступних слотів без конфліктів' }, ...unplaced] };
  }

  const best = candidates[0].cand;
  const { score, warnings } = calculateScheduleScore(best, allAssigned, variable.req, halls.find(h => h.id === best.hall_id), { timeFromMin, timeToMin });
  return backtrackDraft(remaining, [...allAssigned, { ...best, duration_min: variable.duration_min, varKey: variable.varKey, score, warnings }], halls, availability, allowedDays, timeFromMin, timeToMin, stepMin);
};

module.exports = { toMin, validateHardConstraints, buildSlotsForGroup, backtrackDraft };
