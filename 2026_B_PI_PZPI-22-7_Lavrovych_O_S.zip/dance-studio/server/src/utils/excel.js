const ExcelJS = require('exceljs');

const sendXlsx = async (res, sheetName, headers, labelRow, rows, filename) => {
  const wb    = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet(sheetName);

  const headerRow = sheet.addRow(labelRow);
  headerRow.font  = { bold: true };
  headerRow.fill  = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8F5E9' } };

  rows.forEach(r => sheet.addRow(headers.map(h => r[h] ?? '')));

  sheet.columns.forEach((col, i) => {
    let max = String(labelRow[i] ?? '').length;
    col.eachCell(cell => { const l = String(cell.value ?? '').length; if (l > max) max = l; });
    col.width = Math.min(max + 2, 45);
  });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  await wb.xlsx.write(res);
  res.end();
};

module.exports = { sendXlsx };
