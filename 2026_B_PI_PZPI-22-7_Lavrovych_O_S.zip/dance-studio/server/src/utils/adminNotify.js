const pool = require('../config/db');
const { sendAdminNotifyEmail } = require('./mailer');

const notifyAdmins = async (type, title, body, settingKey = null) => {
  try {
    if (settingKey) {
      const [[setting]] = await pool.query(
        "SELECT `value` FROM studio_settings WHERE `key` = ?",
        [settingKey]
      );
      if (!setting || setting.value !== '1') return;
    }

    const [admins] = await pool.query("SELECT id FROM users WHERE role = 'admin'");
    if (!admins.length) return;

    const values = admins.map(a => [a.id, type, title, body || null]);
    await pool.query(
      "INSERT INTO notifications (user_id, type, title, body) VALUES ?",
      [values]
    );

    const [[emailRow]] = await pool.query(
      "SELECT `value` FROM studio_settings WHERE `key` = 'admin_notify_email'"
    );
    if (emailRow?.value) {
      sendAdminNotifyEmail({ to: emailRow.value, title, body: body || '' }).catch(() => {});
    }
  } catch {

  }
};

module.exports = { notifyAdmins };
