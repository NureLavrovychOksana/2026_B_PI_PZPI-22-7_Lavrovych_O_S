const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const sendPasswordResetEmail = async (to, token) => {
  const resetUrl = `${process.env.CLIENT_URL}/reset-password?token=${token}`;

  await transporter.sendMail({
    from: `"Dance Studio" <${process.env.SMTP_USER}>`,
    to,
    subject: 'Відновлення пароля — Dance Studio',
    html: `
      <div style="font-family: sans-serif; max-width: 480px; margin: 0 auto;">
        <h2>Відновлення пароля</h2>
        <p>Ви отримали цей лист тому, що надійшов запит на скидання пароля для вашого акаунту.</p>
        <p>
          <a href="${resetUrl}"
             style="display:inline-block; padding:12px 24px; background:#C8FA3A;
                    color:#000; text-decoration:none; border-radius:6px; font-weight:bold;">
            Скинути пароль
          </a>
        </p>
        <p>Посилання дійсне протягом <strong>1 години</strong>.</p>
        <p>Якщо ви не надсилали цей запит — просто проігноруйте цей лист.</p>
        <hr/>
        <small style="color:#999;">
          Або скопіюйте посилання: ${resetUrl}
        </small>
      </div>
    `,
  });
};

const sendReminderEmail = async ({ to, name, type }) => {
  const templates = {
    debtor: {
      subject: 'Нагадування про поновлення абонементу — Move Studio',
      html: `
        <div style="font-family:sans-serif;max-width:480px;margin:0 auto;color:#1a1a18;">
          <h2 style="color:#0a0a0a;">Вітаємо, ${name}!</h2>
          <p>Нагадуємо, що ваш абонемент у <strong>Move Studio</strong> закінчився.</p>
          <p>Щоб продовжити заняття, будь ласка, поновіть абонемент зручним для вас способом.</p>
          <p style="margin-top:24px;">З повагою,<br/>Команда Move Studio</p>
        </div>
      `,
    },
    risk: {
      subject: 'Ваш абонемент скоро закінчиться — Move Studio',
      html: `
        <div style="font-family:sans-serif;max-width:480px;margin:0 auto;color:#1a1a18;">
          <h2 style="color:#0a0a0a;">Вітаємо, ${name}!</h2>
          <p>Нагадуємо, що ваш абонемент у <strong>Move Studio</strong> скоро закінчиться.</p>
          <p>Поновіть вчасно, щоб не переривати заняття 🎵</p>
          <p style="margin-top:24px;">З повагою,<br/>Команда Move Studio</p>
        </div>
      `,
    },
  };

  const tpl = templates[type] ?? templates.debtor;

  await transporter.sendMail({
    from: `"Move Studio" <${process.env.SMTP_USER}>`,
    to,
    subject: tpl.subject,
    html: tpl.html,
  });
};

const sendLessonReminderEmail = async ({ to, name, groupName, styleName, hallName, date, time }) => {
  const dateStr = new Date(date).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', weekday: 'long' });
  await transporter.sendMail({
    from: `"Move Studio" <${process.env.SMTP_USER}>`,
    to,
    subject: `Нагадування: заняття сьогодні о ${time} — Move Studio`,
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;color:#1a1a18;">
        <h2 style="color:#0a0a0a;">Привіт, ${name}!</h2>
        <p>Нагадуємо, що <strong>через 1 годину</strong> у вас заняття:</p>
        <table style="border-collapse:collapse;margin:16px 0;">
          <tr><td style="color:#666;padding:4px 12px 4px 0;">Група</td><td><strong>${groupName}</strong></td></tr>
          <tr><td style="color:#666;padding:4px 12px 4px 0;">Стиль</td><td>${styleName}</td></tr>
          <tr><td style="color:#666;padding:4px 12px 4px 0;">Зал</td><td>${hallName}</td></tr>
          <tr><td style="color:#666;padding:4px 12px 4px 0;">Час</td><td><strong>${dateStr}, ${time}</strong></td></tr>
        </table>
        <p style="margin-top:24px;">Чекаємо вас!</p>
        <p>З повагою,<br/>Команда Move Studio</p>
      </div>
    `,
  });
};

const sendAdminNotifyEmail = async ({ to, title, body }) => {
  await transporter.sendMail({
    from: `"Move Studio" <${process.env.SMTP_USER}>`,
    to,
    subject: `[Move Studio] ${title}`,
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;color:#1a1a18;">
        <h2 style="color:#0a0a0a;font-size:16px;">${title}</h2>
        <p style="line-height:1.6;">${body}</p>
        <hr style="border:none;border-top:1px solid #eee;margin:20px 0;"/>
        <small style="color:#999;">Автоматичне сповіщення Move Studio</small>
      </div>
    `,
  });
};

module.exports = { sendPasswordResetEmail, sendReminderEmail, sendLessonReminderEmail, sendAdminNotifyEmail };