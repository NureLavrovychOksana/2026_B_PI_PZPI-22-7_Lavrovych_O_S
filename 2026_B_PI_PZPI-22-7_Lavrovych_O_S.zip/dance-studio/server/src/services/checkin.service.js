const pool = require('../config/db');
const userRepository = require('../repositories/user.repository');

const WINDOW_BEFORE_MIN = 15; // allow check-in 15 min before lesson
const WINDOW_AFTER_MIN  = 30; // allow check-in up to 30 min after start

const processCheckIn = async (scanToken) => {
  if (!scanToken) {
    const e = new Error('Токен не передано'); e.status = 400; throw e;
  }

  const student = await userRepository.findBySecureToken(scanToken);
  if (!student) {
    const e = new Error('Студента не знайдено або токен невірний'); e.status = 404; throw e;
  }
  if (student.role !== 'student') {
    const e = new Error('QR-код не належить студенту'); e.status = 400; throw e;
  }

  const [[{ now }]] = await pool.query("SELECT NOW() AS now");
  const nowDate = new Date(now);
  const todayStr = nowDate.toISOString().slice(0, 10);

  const windowStart = new Date(nowDate.getTime() - WINDOW_BEFORE_MIN * 60000);
  const windowEnd   = new Date(nowDate.getTime() + WINDOW_AFTER_MIN  * 60000);
  const toHM = (d) => `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:00`;

  const [lessons] = await pool.query(
    `SELECT
       l.id, l.lesson_date, l.start_time, l.end_time,
       dg.name  AS group_name,
       ds.name  AS style_name,
       h.name   AS hall_name,
       h.id     AS hall_id
     FROM enrollments e
     JOIN lessons      l   ON l.id  = e.lesson_id
     JOIN dance_groups dg  ON dg.id = l.group_id
     JOIN dance_styles ds  ON ds.id = dg.style_id
     JOIN halls        h   ON h.id  = l.hall_id
     WHERE e.student_id  = ?
       AND l.lesson_date = ?
       AND l.start_time  BETWEEN ? AND ?
     ORDER BY l.start_time ASC
     LIMIT 1`,
    [student.id, todayStr, toHM(windowStart), toHM(windowEnd)]
  );

  const matchedLesson = lessons[0] || null;

  let alreadyMarked = false;
  if (matchedLesson) {
    const [[{ cnt }]] = await pool.query(
      `SELECT COUNT(*) AS cnt FROM attendance
       WHERE student_id = ? AND lesson_id = ? AND status = 'present'`,
      [student.id, matchedLesson.id]
    );
    alreadyMarked = cnt > 0;
  }

  const [subs] = await pool.query(
    `SELECT ss.sessions_left, ss.expiry_date, ss.status, sp.name AS plan_name, sp.type AS plan_type
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.student_id = ? AND ss.status = 'active'
     ORDER BY ss.expiry_date ASC LIMIT 1`,
    [student.id]
  );

  return {
    student: {
      id:         student.id,
      first_name: student.first_name,
      last_name:  student.last_name,
      avatar_url: student.avatar_url,
    },
    subscription: subs[0] || null,
    matched_lesson: matchedLesson,
    already_marked: alreadyMarked,
    server_time: toHM(nowDate).slice(0, 5),
    window: { from: toHM(windowStart).slice(0, 5), to: toHM(windowEnd).slice(0, 5) },
  };
};

module.exports = { processCheckIn };
