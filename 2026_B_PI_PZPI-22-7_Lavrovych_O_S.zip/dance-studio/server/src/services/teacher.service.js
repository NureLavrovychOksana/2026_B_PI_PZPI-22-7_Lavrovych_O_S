const teacherRepository      = require('../repositories/teacher.repository');
const userRepository         = require('../repositories/user.repository');
const styleRepository        = require('../repositories/style.repository');
const notificationRepository = require('../repositories/notification.repository');

const getProfileOrThrow = async (id) => {
  const teacher = await teacherRepository.findById(id);
  if (!teacher) {
    const err = new Error('Профіль викладача не знайдено');
    err.status = 404;
    throw err;
  }
  return teacher;
};

const getAll = async () => {
  return teacherRepository.findAll();
};

const getById = async (id) => {
  return getProfileOrThrow(id);
};

const getByUserId = async (userId) => {
  const profile = await teacherRepository.findByUserId(userId);
  if (!profile) {
    const err = new Error('Профіль викладача не знайдено');
    err.status = 404;
    throw err;
  }
  return teacherRepository.findById(profile.id);
};

const create = async ({ email, password, first_name, last_name, phone, bio, experience_years, education, style_ids }) => {
  const existing = await userRepository.findByEmail(email);
  if (existing) {
    const err = new Error('Користувач з таким email вже існує');
    err.status = 409;
    throw err;
  }

  if (style_ids && style_ids.length > 0) {
    for (const sid of style_ids) {
      const style = await styleRepository.findById(sid);
      if (!style) {
        const err = new Error(`Стиль з ID ${sid} не знайдено`);
        err.status = 400;
        throw err;
      }
    }
  }

  const bcrypt = require('bcrypt');
  const password_hash = await bcrypt.hash(password || 'teacher123', 10);

  const userId = await userRepository.create({
    email,
    password_hash,
    role: 'teacher',
    first_name,
    last_name,
    phone,
  });

  const profileId = await teacherRepository.create({
    user_id: userId,
    bio,
    experience_years,
    education,
  });

  if (style_ids && style_ids.length > 0) {
    await teacherRepository.syncStyles(profileId, style_ids);
  }

  return teacherRepository.findById(profileId);
};

const update = async (id, { bio, experience_years, education, style_ids, first_name, last_name, phone, email }) => {
  await getProfileOrThrow(id);

  await teacherRepository.update(id, { bio, experience_years, education });

  const teacher = await teacherRepository.findById(id);
  const userFields = {};
  if (first_name) userFields.first_name = first_name;
  if (last_name)  userFields.last_name  = last_name;
  if (phone)      userFields.phone      = phone;
  if (email)      userFields.email      = email;

  if (Object.keys(userFields).length > 0) {
    await userRepository.update(teacher.user_id, userFields);
  }

  if (style_ids !== undefined) {
    if (style_ids.length > 0) {
      for (const sid of style_ids) {
        const style = await styleRepository.findById(sid);
        if (!style) {
          const err = new Error(`Стиль з ID ${sid} не знайдено`);
          err.status = 400;
          throw err;
        }
      }
    }
    await teacherRepository.syncStyles(id, style_ids);
  }

  return teacherRepository.findById(id);
};

const getSchedule = async (teacherId, weekStart) => {
  const profile = await getProfileOrThrow(teacherId);


  let week = weekStart;
  if (!week) {
    const today = new Date();
    const day = today.getDay();
    const diff = today.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(today.setDate(diff));
    week = monday.toISOString().split('T')[0];
  }

  return teacherRepository.findSchedule(profile.user_id, week);
};

const getGroups = async (teacherId) => {
  const profile = await getProfileOrThrow(teacherId);
  return teacherRepository.findGroups(profile.user_id);
};

const getFinance = async (teacherProfileId, dateFrom, dateTo) => {
  const data = await teacherRepository.getFinance(teacherProfileId, dateFrom, dateTo);
  if (!data) { const e = new Error('Не знайдено'); e.status = 404; throw e; }
  return data;
};

const RATE_TYPE_LABELS = {
  per_lesson:  'за урок',
  per_student: 'за учня',
  percent:     '% від виручки',
};

const setRate = async (teacherProfileId, rate_type, rate_amount) => {
  const profile = await getProfileOrThrow(teacherProfileId);
  await teacherRepository.setRate(teacherProfileId, rate_type, rate_amount);
  const label = RATE_TYPE_LABELS[rate_type] || rate_type;
  notificationRepository.create({
    userId: profile.user_id,
    type:   'rate_changed',
    title:  'Змінено ставку',
    body:   `Адміністратор встановив нову ставку: ${rate_amount}${rate_type === 'percent' ? '%' : ' ₴'} ${label}.`,
  }).catch(() => {});
};

const getPayrollSummary = async (month, year) => {
  return teacherRepository.getPayrollSummary(month, year);
};

const addPayout = async (teacherProfileId, amount, note, adminUserId) => {
  const profile = await getProfileOrThrow(teacherProfileId);
  const id = await teacherRepository.addPayout(teacherProfileId, amount, note, adminUserId);
  notificationRepository.create({
    userId: profile.user_id,
    type:   'payout_received',
    title:  'Нарахування виплати',
    body:   `Вам нараховано ${Number(amount).toLocaleString('uk-UA')} ₴.${note ? ` ${note}` : ''}`,
  }).catch(() => {});
  return id;
};

const getPayouts = async (teacherProfileId) => {
  await getProfileOrThrow(teacherProfileId);
  return teacherRepository.getPayouts(teacherProfileId);
};

module.exports = {
  getAll,
  getById,
  getByUserId,
  create,
  update,
  getSchedule,
  getGroups,
  getFinance,
  setRate,
  getPayrollSummary,
  addPayout,
  getPayouts,
};