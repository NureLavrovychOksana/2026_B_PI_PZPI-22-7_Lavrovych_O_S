const groupRepository  = require('../repositories/group.repository');
const styleRepository  = require('../repositories/style.repository');
const hallRepository   = require('../repositories/hall.repository');
const userRepository   = require('../repositories/user.repository');
const scheduleRepo     = require('../repositories/schedule.repository');
const pool             = require('../config/db');

const getGroupOrThrow = async (id) => {
  const group = await groupRepository.findById(id);
  if (!group) {
    const err = new Error('Групу не знайдено');
    err.status = 404;
    throw err;
  }
  return group;
};

const validateRelations = async ({ style_id, teacher_id, hall_id }) => {
  if (style_id) {
    const style = await styleRepository.findById(style_id);
    if (!style) {
      const err = new Error(`Стиль з ID ${style_id} не знайдено`);
      err.status = 400;
      throw err;
    }
  }

  if (hall_id) {
    const hall = await hallRepository.findById(hall_id);
    if (!hall) {
      const err = new Error(`Зал з ID ${hall_id} не знайдено`);
      err.status = 400;
      throw err;
    }
  }

  if (teacher_id) {
    const teacher = await userRepository.findById(teacher_id);
    if (!teacher || teacher.role !== 'teacher') {
      const err = new Error(`Викладача з ID ${teacher_id} не знайдено`);
      err.status = 400;
      throw err;
    }
  }
};

const getAll = async (user, filters = {}) => {
  const teacherId = user?.role === 'teacher' ? user.id : null;
  return groupRepository.findAll(teacherId, filters);
};

const getById = async (id, user) => {
  const group = await getGroupOrThrow(id);

  if (user?.role === 'teacher' && group.teacher_id !== user.id) {
    const err = new Error('Доступ заборонено');
    err.status = 403;
    throw err;
  }

  return group;
};

const create = async ({ name, style_id, level, teacher_id, hall_id, status, lessons_per_week, lesson_duration, is_children }) => {
  if (!name || !style_id || !teacher_id || !hall_id) {
    const err = new Error('Поля name, style_id, teacher_id, hall_id є обовʼязковими');
    err.status = 400;
    throw err;
  }

  await validateRelations({ style_id, teacher_id, hall_id });

  const id = await groupRepository.create({ name, style_id, level, teacher_id, hall_id, status, lessons_per_week });
  await scheduleRepo.upsertGroupRequirement(id, {
    lessons_per_week: lessons_per_week ?? 2,
    lesson_duration:  lesson_duration  ?? 60,
    is_children:      is_children      ?? false,
    preferred_start:  null,
    preferred_end:    null,
  });
  return groupRepository.findById(id);
};

const update = async (id, { name, style_id, level, teacher_id, hall_id, status, lessons_per_week, lesson_duration, is_children }) => {
  const group = await getGroupOrThrow(id);

  const newTeacherId = teacher_id || group.teacher_id;
  const teacherChanged = teacher_id && Number(teacher_id) !== Number(group.teacher_id);

  await validateRelations({
    style_id:   style_id   || group.style_id,
    teacher_id: newTeacherId,
    hall_id:    hall_id    || group.hall_id,
  });

  await groupRepository.update(id, {
    name:             name             || group.name,
    style_id:         style_id         || group.style_id,
    level:            level            || group.level,
    teacher_id:       newTeacherId,
    hall_id:          hall_id          || group.hall_id,
    status:           status           || group.status,
    lessons_per_week: lessons_per_week ?? group.lessons_per_week,
  });

  if (teacherChanged) {
    await groupRepository.reassignFutureLessons(id, newTeacherId, group.teacher_id);
  }

  if (lesson_duration !== undefined || is_children !== undefined) {
    await scheduleRepo.upsertGroupRequirement(id, {
      lessons_per_week: lessons_per_week ?? group.lessons_per_week,
      lesson_duration:  lesson_duration  ?? 60,
      is_children:      is_children      ?? false,
      preferred_start:  null,
      preferred_end:    null,
    });
  }

  return groupRepository.findById(id);
};

const remove = async (id) => {
  await getGroupOrThrow(id);

  const [[{ past_count }]] = await pool.query(
    `SELECT COUNT(*) AS past_count FROM lessons WHERE group_id = ? AND lesson_date < CURDATE()`,
    [id]
  );

  if (Number(past_count) === 0) {
    await pool.query(`
      UPDATE student_subscriptions ss
      JOIN attendance a ON a.subscription_id = ss.id
      JOIN lessons l ON l.id = a.lesson_id
      SET ss.sessions_left = ss.sessions_left + 1
      WHERE l.group_id = ? AND a.status = 'present' AND ss.sessions_left IS NOT NULL
    `, [id]);
    await pool.query(`DELETE a FROM attendance a JOIN lessons l ON l.id = a.lesson_id WHERE l.group_id = ?`, [id]);
    await pool.query(`DELETE w FROM waitlist w JOIN lessons l ON l.id = w.lesson_id WHERE l.group_id = ?`, [id]);
    await pool.query(`DELETE e FROM enrollments e JOIN lessons l ON l.id = e.lesson_id WHERE l.group_id = ?`, [id]);
    await pool.query(`DELETE FROM lessons WHERE group_id = ?`, [id]);
    await pool.query(`DELETE FROM group_lesson_requirements WHERE group_id = ?`, [id]);
    await groupRepository.remove(id);
    return { action: 'deleted' };
  }

  await pool.query(`
    UPDATE student_subscriptions ss
    JOIN attendance a ON a.subscription_id = ss.id
    JOIN lessons l ON l.id = a.lesson_id
    SET ss.sessions_left = ss.sessions_left + 1
    WHERE l.group_id = ? AND l.lesson_date >= CURDATE() AND a.status = 'present' AND ss.sessions_left IS NOT NULL
  `, [id]);
  await pool.query(`
    UPDATE student_subscriptions ss
    JOIN attendance a ON a.subscription_id = ss.id
    JOIN lessons l ON l.id = a.lesson_id
    SET ss.status = 'active'
    WHERE l.group_id = ? AND l.lesson_date >= CURDATE() AND a.status = 'present' AND ss.status = 'exhausted'
  `, [id]);
  await pool.query(`DELETE a FROM attendance a JOIN lessons l ON l.id = a.lesson_id WHERE l.group_id = ? AND l.lesson_date >= CURDATE()`, [id]);
  await pool.query(`DELETE w FROM waitlist w JOIN lessons l ON l.id = w.lesson_id WHERE l.group_id = ? AND l.lesson_date >= CURDATE()`, [id]);
  await pool.query(`DELETE e FROM enrollments e JOIN lessons l ON l.id = e.lesson_id WHERE l.group_id = ? AND l.lesson_date >= CURDATE()`, [id]);
  await pool.query(`DELETE FROM lessons WHERE group_id = ? AND lesson_date >= CURDATE()`, [id]);
  await pool.query(`UPDATE dance_groups SET status = 'closed' WHERE id = ?`, [id]);
  return { action: 'archived' };
};

const getAttendanceStats = async (id, user, dateFrom, dateTo) => {
  await getById(id, user);
  return groupRepository.findAttendanceStats(id, dateFrom, dateTo);
};

module.exports = {
  getAll,
  getById,
  create,
  update,
  remove,
  getAttendanceStats,
};