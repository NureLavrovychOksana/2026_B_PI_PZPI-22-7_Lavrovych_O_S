const paymentRepository      = require('../repositories/payment.repository');
const subscriptionRepository = require('../repositories/subscription.repository');
const userRepository         = require('../repositories/user.repository');
const liqpayService          = require('./liqpay.service');
const { assignSubscription } = require('./subscription.service');
const { notifyAdmins }       = require('../utils/adminNotify');

const createManual = async ({ userId, subscriptionId, amount, method }) => {
  if (!userId || !amount) {
    const err = new Error('user_id та amount є обовʼязковими');
    err.status = 400;
    throw err;
  }

  const user = await userRepository.findById(userId);
  if (!user) {
    const err = new Error('Користувача не знайдено');
    err.status = 404;
    throw err;
  }

  const id = await paymentRepository.create({
    userId,
    subscriptionId: subscriptionId || null,
    amount,
    method:  method || 'cash',
    status: 'success',
  });

  notifyAdmins(
    'payment_received',
    'Надходження оплати',
    `${user.first_name} ${user.last_name} — ${Number(amount).toLocaleString('uk-UA')} ₴ (${method || 'готівка'}).`,
    'notify_payment'
  );

  const [payment] = await paymentRepository.findByUser(userId);
  return payment;
};

const createCheckout = async ({ userId, planId }) => {
  if (!userId || !planId) {
    const err = new Error('user_id та plan_id є обовʼязковими');
    err.status = 400;
    throw err;
  }

  const plan = await subscriptionRepository.findPlanById(planId);
  if (!plan) {
    const err = new Error('Тариф не знайдено');
    err.status = 404;
    throw err;
  }

  const orderId = `subscription_${userId}_${Date.now()}`;

  const { data, signature } = liqpayService.createCheckout({
    orderId,
    amount:      plan.price,
    description: `Абонемент "${plan.name}"`,
    callbackUrl: process.env.SERVER_URL
      ? `${process.env.SERVER_URL}/api/payments/webhook`
      : undefined,
    resultUrl: process.env.CLIENT_URL
      ? `${process.env.CLIENT_URL}/payment/result?order_id=${orderId}`
      : undefined,
  });

  await paymentRepository.create({
    userId,
    subscriptionId: null,
    amount:  plan.price,
    method:  'liqpay',
    status:  'pending',
    liqpayOrderId: orderId,
  });

  return {
    order_id:  orderId,
    data,
    signature,
    plan,
  };
};

const _activateForOrder = async (orderId, amount) => {
  // Atomic: only the first caller (webhook OR confirmCheckout) wins the claim
  const claimed = await paymentRepository.claimPending(orderId);
  if (!claimed) return null;

  const userId = Number(orderId.split('_')[1]);

  const plans = await subscriptionRepository.findAllPlans();
  const plan  = plans.find(p => Number(p.price) === Number(amount));
  if (!plan) return null;

  const sub = await assignSubscription({ studentId: userId, planId: plan.id, skipPayment: true });

  const pool = require('../config/db');
  await pool.query(
    `UPDATE payments SET subscription_id = ? WHERE liqpay_order_id = ?`,
    [sub.id, orderId]
  );

  return sub;
};

const handleWebhook = async ({ data, signature }) => {
  const valid = liqpayService.verifySignature(data, signature);
  if (!valid) {
    const err = new Error('Невірний підпис LiqPay');
    err.status = 400;
    throw err;
  }

  const payload = liqpayService.decode(data);
  const { order_id, status, amount } = payload;

  console.log(`[LiqPay webhook] order_id=${order_id} status=${status}`);

  const payment = await paymentRepository.findByOrderId(order_id);
  if (!payment) {
    return { ignored: true };
  }

  if (status === 'success' || status === 'sandbox') {
    if (payment.status === 'success') return { ignored: true }; 
    const sub = await _activateForOrder(order_id, amount);
    if (sub) {
      const userId = Number(order_id.split('_')[1]);
      const user = await userRepository.findById(userId).catch(() => null);
      notifyAdmins(
        'payment_received',
        'Надходження оплати (LiqPay)',
        `${user ? `${user.first_name} ${user.last_name}` : `ID ${userId}`} — ${Number(amount).toLocaleString('uk-UA')} ₴.`,
        'notify_payment'
      );
      return { success: true, subscription_id: sub.id };
    }
  } else if (['failure', 'error', 'reversed'].includes(status)) {
    await paymentRepository.updateStatus(order_id, 'failed');
    return { success: false, status };
  }

  return { ignored: true, status };
};

const confirmCheckout = async ({ orderId, userId }) => {
  const payment = await paymentRepository.findByOrderId(orderId);
  if (!payment) {
    const err = new Error('Платіж не знайдено');
    err.status = 404;
    throw err;
  }
  if (Number(payment.user_id) !== Number(userId)) {
    const err = new Error('Доступ заборонено');
    err.status = 403;
    throw err;
  }

  let subscriptionId = payment.subscription_id;
  if (payment.status !== 'success') {
    const sub = await _activateForOrder(orderId, payment.amount);
    subscriptionId = sub ? sub.id : null;
  }

  const sub = subscriptionId
    ? await subscriptionRepository.findSubscriptionById(subscriptionId)
    : null;
  return { success: true, subscription: sub };
};

const getAll = async (filters) => {
  return paymentRepository.findAll(filters);
};

const getByUser = async (userId, requestUser) => {
  if (requestUser.role === 'student' && requestUser.id !== Number(userId)) {
    const err = new Error('Доступ заборонено');
    err.status = 403;
    throw err;
  }
  return paymentRepository.findByUser(userId);
};

const createCashCheckout = async ({ userId, planId }) => {
  if (!userId || !planId) {
    const err = new Error('user_id та plan_id є обовʼязковими');
    err.status = 400;
    throw err;
  }

  const plan = await subscriptionRepository.findPlanById(planId);
  if (!plan) {
    const err = new Error('Тариф не знайдено');
    err.status = 404;
    throw err;
  }

  const sub = await assignSubscription({ studentId: userId, planId, skipPayment: true });

  await paymentRepository.create({
    userId,
    subscriptionId: sub.id,
    amount:  plan.price,
    method:  'cash',
    status:  'pending',
  });

  const user = await userRepository.findById(userId);
  notifyAdmins(
    'payment_received',
    'Запит на оплату готівкою',
    `${user.first_name} ${user.last_name} — "${plan.name}" (₴${Number(plan.price).toLocaleString('uk-UA')}). Очікує оплати готівкою.`,
    'notify_payment'
  );

  return { subscription: sub, plan };
};

const confirmCashPayment = async (paymentId) => {
  const confirmed = await paymentRepository.confirmCashById(paymentId);
  if (!confirmed) {
    const err = new Error('Платіж не знайдено або вже підтверджено');
    err.status = 404;
    throw err;
  }
  return { success: true };
};

module.exports = { createManual, createCheckout, createCashCheckout, handleWebhook, confirmCheckout, confirmCashPayment, getAll, getByUser };