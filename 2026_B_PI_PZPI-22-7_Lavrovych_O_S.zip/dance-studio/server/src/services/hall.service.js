const hallRepository = require('../repositories/hall.repository');

const getAll = async ({ includeArchived = false } = {}) => {
  return hallRepository.findAll({ includeArchived });
};

const getById = async (id) => {
  const hall = await hallRepository.findById(id);
  if (!hall) {
    const err = new Error('Зал не знайдено');
    err.status = 404;
    throw err;
  }
  return hall;
};

const create = async ({ name, capacity }) => {
  if (!name) {
    const err = new Error('Назва залу обовʼязкова');
    err.status = 400;
    throw err;
  }
  const id = await hallRepository.create({ name, capacity });
  return hallRepository.findById(id);
};

const update = async (id, { name, capacity }) => {
  await getById(id);
  if (!name) {
    const err = new Error('Назва залу обовʼязкова');
    err.status = 400;
    throw err;
  }
  await hallRepository.update(id, { name, capacity });
  return hallRepository.findById(id);
};

const remove = async (id, targetHallId) => {
  await getById(id);

  if (targetHallId) {
    await getById(targetHallId);
    const relocated = await hallRepository.relocateAndArchive(id, targetHallId);
    return { action: 'archived', relocated };
  }

  await hallRepository.archive(id);
  return { action: 'archived', relocated: 0 };
};

const restore = async (id) => {
  await getById(id);
  await hallRepository.restore(id);
  return hallRepository.findById(id);
};

module.exports = { getAll, getById, create, update, remove, restore };
