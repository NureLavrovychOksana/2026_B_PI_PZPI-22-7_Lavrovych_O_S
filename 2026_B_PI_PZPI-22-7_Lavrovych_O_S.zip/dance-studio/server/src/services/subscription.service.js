const subscriptionRepository  = require('../repositories/subscription.repository');
const userRepository          = require('../repositories/user.repository');
const notificationRepository  = require('../repositories/notification.repository');
const paymentRepository       = require('../repositories/payment.repository');

const getAllPlans = async ({ excludeTrial = false, adminView = false } = {}) => {
  if (adminView) return subscriptionRepository.findAllPlansAdmin();
  return subscriptionRepository.findAllPlans({ excludeTrial });
};

const createPlan = async ({ name, type, sessions_count, validity_days, price }) => {
  if (!name || !price) {
    const err = new Error('name та price є обовʼязковими');
    err.status = 400;
    throw err;
  }
  if (type === 'COUNT' && !sessions_count) {
    const err = new Error('Для тарифу COUNT необхідно вказати sessions_count');
    err.status = 400;
    throw err;
  }
  const id = await subscriptionRepository.createPlan({
    name,
    type:          type          || 'COUNT',
    sessionsCount: sessions_count || null,
    validityDays:  validity_days  || null,
    price,
  });
  return subscriptionRepository.findPlanById(id);
};

const updatePlan = async (id, body) => {
  const plan = await subscriptionRepository.findPlanById(id);
  if (!plan) {
    const err = new Error('Тариф не знайдено');
    err.status = 404;
    throw err;
  }
  await subscriptionRepository.updatePlan(id, {
    name:          body.name,
    type:          body.type,
    sessionsCount: body.sessions_count,
    validityDays:  body.validity_days,
    price:         body.price,
    isActive:      body.is_active,
  });
  return subscriptionRepository.findPlanById(id);
};

const removePlan = async (id) => {
  const plan = await subscriptionRepository.findPlanById(id);
  if (!plan) {
    const err = new Error('Тариф не знайдено');
    err.status = 404;
    throw err;
  }
  const removed = await subscriptionRepository.removePlan(id);
  if (!removed) {
    const err = new Error('Неможливо видалити тариф — він використовується в абонементах');
    err.status = 409;
    throw err;
  }
  return true;
};

const activatePendingIfNeeded = async (studentId) => {
  const active = await subscriptionRepository.findAllActiveByStudent(studentId);
  if (active.length > 0) return null; // ще є активний — нічого не робимо

  const activatedId = await subscriptionRepository.tryActivateNextPending(studentId);
  if (!activatedId) return null;

  notificationRepository.create({
    userId: studentId,
    type:   'subscription_activated',
    title:  'Новий абонемент активовано',
    body:   'Ваш наступний абонемент автоматично активовано.',
  }).catch(() => {});

  return activatedId;
};

const getStudentSubscriptions = async (studentId, requestUser) => {
  if (requestUser.role === 'student' && requestUser.id !== Number(studentId)) {
    const err = new Error('Доступ заборонено');
    err.status = 403;
    throw err;
  }
  await activatePendingIfNeeded(studentId).catch(() => {});
  return subscriptionRepository.findByStudent(studentId);
};

const getActiveSubscriptions = async (studentId, requestUser) => {
  if (requestUser.role === 'student' && requestUser.id !== Number(studentId)) {
    const err = new Error('Доступ заборонено');
    err.status = 403;
    throw err;
  }
  await activatePendingIfNeeded(studentId).catch(() => {});
  return subscriptionRepository.findAllActiveByStudent(studentId);
};

const assignSubscription = async ({ studentId, planId, activationDate, purchaseDate, skipPayment = false, forceActive = false }) => {
  const student = await userRepository.findById(studentId);
  if (!student || student.role !== 'student') {
    const err = new Error('Учня не знайдено');
    err.status = 404;
    throw err;
  }

  const plan = await subscriptionRepository.findPlanById(planId);
  if (!plan) {
    const err = new Error('Тариф не знайдено');
    err.status = 404;
    throw err;
  }

  const today     = new Date().toISOString().slice(0, 10);
  const purchDate = purchaseDate || today;
  const sessionsLeft = plan.type === 'COUNT' ? plan.sessions_count : null;

  const activeSubs = await subscriptionRepository.findAllActiveByStudent(studentId);
  const hasCurrent = activeSubs.length > 0;

  let actDate    = null;
  let expiryDate = null;
  let status     = 'pending';

  if (!hasCurrent || forceActive) {
    actDate = activationDate || today;
    if (plan.validity_days) {
      const exp = new Date(actDate);
      exp.setDate(exp.getDate() + plan.validity_days);
      expiryDate = exp.toISOString().slice(0, 10);
    }
    status = 'active';
  }

  const id = await subscriptionRepository.createSubscription({
    studentId,
    planId,
    purchaseDate:   purchDate,
    activationDate: actDate,
    expiryDate,
    sessionsLeft,
    status,
  });

  if (!skipPayment) {
    await paymentRepository.create({
      userId:         studentId,
      subscriptionId: id,
      amount:         plan.price,
      method:         'cash',
      status:         'success',
    });
  }

  return subscriptionRepository.findSubscriptionById(id);
};

const cancelSubscription = async (id, requestUser) => {
  const sub = await subscriptionRepository.findSubscriptionById(id);
  if (!sub) {
    const err = new Error('Абонемент не знайдено');
    err.status = 404;
    throw err;
  }
  await subscriptionRepository.updateSubscription(id, { status: 'cancelled' });
  return subscriptionRepository.findSubscriptionById(id);
};

const getAllSubscriptions = async () => {
  const pool = require('../config/db');
  const [needsActivation] = await pool.query(
    `SELECT DISTINCT ss.student_id
     FROM student_subscriptions ss
     WHERE ss.status = 'pending'
       AND NOT EXISTS (
         SELECT 1 FROM student_subscriptions ss2
         JOIN subscription_plans sp2 ON sp2.id = ss2.plan_id
         WHERE ss2.student_id = ss.student_id
           AND ss2.status = 'active'
           AND (ss2.expiry_date IS NULL OR ss2.expiry_date >= CURDATE())
           AND (sp2.type = 'UNLIMITED' OR ss2.sessions_left > 0)
       )`
  );
  for (const { student_id } of needsActivation) {
    await subscriptionRepository.tryActivateNextPending(student_id).catch(() => {});
  }
  return subscriptionRepository.findAllWithStudents();
};

module.exports = {
  getAllPlans,
  createPlan,
  updatePlan,
  removePlan,
  getAllSubscriptions,
  getStudentSubscriptions,
  getActiveSubscriptions,
  activatePendingIfNeeded,
  assignSubscription,
  cancelSubscription,
};