const userRepository = require('../repositories/user.repository');
const teacherRepository = require('../repositories/teacher.repository');
const bcrypt = require('bcrypt');
const pool = require('../config/db');
const { BCRYPT_ROUNDS } = require('../config/constants');

const getAll = async (role = null) => {
  return userRepository.findAll(role);
};

const getById = async (id) => {
  const user = await userRepository.findById(id);
  if (!user) {
    const err = new Error('Користувача не знайдено');
    err.status = 404;
    throw err;
  }
  return user;
};
const create = async ({ email, password, role, first_name, last_name, phone }) => {
  if (!email || !password || !role || !first_name || !last_name) {
    const err = new Error('email, password, role, first_name, last_name є обовʼязковими');
    err.status = 400;
    throw err;
  }
  if (password.length < 6) {
    const err = new Error('Пароль має містити щонайменше 6 символів');
    err.status = 400;
    throw err;
  }

  const existing = await userRepository.findByEmail(email);
  if (existing) {
    const err = new Error('Користувач з таким email вже існує');
    err.status = 409;
    throw err;
  }

  const password_hash = await bcrypt.hash(password, BCRYPT_ROUNDS);
  const id = await userRepository.create({ email, password_hash, role, first_name, last_name, phone });

  if (role === 'teacher') {
    await teacherRepository.create({ user_id: id });
  }

  return userRepository.findById(id);
};

const update = async (id, fields) => {
  await getById(id); 

  if (fields.password) {
    if (fields.password.length < 6) {
      const err = new Error('Пароль має містити щонайменше 6 символів');
      err.status = 400;
      throw err;
    }
    fields.password_hash = await bcrypt.hash(fields.password, BCRYPT_ROUNDS);
    delete fields.password;
  }

  if (fields.email) {
    const existing = await userRepository.findByEmail(fields.email);
    if (existing && existing.id !== Number(id)) {
      const err = new Error('Користувач з таким email вже існує');
      err.status = 409;
      throw err;
    }
  }

  await userRepository.update(id, fields);
  return userRepository.findById(id);
};

const remove = async (id) => {
  await getById(id);
  const deleted = await userRepository.remove(id);
  if (!deleted) {
    const err = new Error('Не вдалося видалити користувача');
    err.status = 500;
    throw err;
  }
};

const updateProfile = async (id, fields) => {
  const allowed = ['first_name', 'last_name', 'phone', 'password'];
  const filtered = Object.fromEntries(
    Object.entries(fields).filter(([k]) => allowed.includes(k))
  );
  return update(id, filtered);
};

const getStudentStats = async (studentId) => {
  await getById(studentId);
  return userRepository.findStudentStats(studentId);
};

const removeSelf = async (id) => {
  const [rows] = await pool.query(
    `SELECT id FROM student_subscriptions
     WHERE student_id = ? AND status = 'active'
       AND (expiry_date IS NULL OR expiry_date >= CURDATE())
     LIMIT 1`,
    [id]
  );
  if (rows.length > 0) {
    const e = new Error('Неможливо видалити акаунт з активним абонементом.');
    e.status = 400;
    throw e;
  }
  return remove(id);
};

const getOrCreateSecureToken = async (userId) => {
  const user = await userRepository.findById(userId);
  if (!user) { const e = new Error('Не знайдено'); e.status = 404; throw e; }
  if (user.student_secure_token) return user.student_secure_token;
  const token = require('crypto').randomUUID();
  await userRepository.setSecureToken(userId, token);
  return token;
};

const updateAvatarUrl = async (id, avatarUrl) => {
  await userRepository.updateAvatarUrl(id, avatarUrl);
  return userRepository.findById(id);
};

const searchStudents = async (query) => {
  return userRepository.searchStudents(query);
};

const updateNotifPrefs = async (userId, body) => {
  const allowed = ['email', 'sms', 'news', 'schedule'];
  const prefs = {};
  for (const key of allowed) {
    if (key in body) prefs[key] = Boolean(body[key]);
  }
  await userRepository.setNotifPrefs(userId, prefs);
  return prefs;
};

module.exports = { getAll, getById, create, update, remove, removeSelf, updateProfile, updateAvatarUrl, getStudentStats, getOrCreateSecureToken, searchStudents, updateNotifPrefs };