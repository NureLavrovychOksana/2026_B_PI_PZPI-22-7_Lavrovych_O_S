const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const userRepository = require('../repositories/user.repository');
const resetTokenRepository = require('../repositories/reset-token.repository');
const subscriptionRepository = require('../repositories/subscription.repository');
const mailer = require('../utils/mailer');
const { notifyAdmins } = require('../utils/adminNotify');
const { BCRYPT_ROUNDS } = require('../config/constants');

const generateToken = (user) => {
  return jwt.sign(
    { id: user.id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
  );
};

const safeUser = (user) => {
  const { password_hash, ...rest } = user;
  return rest;
};

const register = async ({ email, password, first_name, last_name, phone, role }) => {
  const isStudent = (role || 'student') === 'student';

  if (isStudent && !phone) {
    const err = new Error('Номер телефону є обов\'язковим');
    err.status = 400;
    throw err;
  }

  const existing = await userRepository.findByEmail(email);
  if (existing) {
    const err = new Error('Користувач з таким email вже існує');
    err.status = 409;
    throw err;
  }

  const password_hash = await bcrypt.hash(password, BCRYPT_ROUNDS);

  const id = await userRepository.create({
    email,
    password_hash,
    role: role || 'student',
    first_name,
    last_name,
    phone,
  });

  const user = await userRepository.findById(id);
  const token = generateToken(user);

  if (isStudent) {
    const trialAlreadyUsed = phone ? await subscriptionRepository.hasPhoneUsedTrial(phone) : false;
    if (!trialAlreadyUsed) {
      const trialPlan = await subscriptionRepository.findTrialPlan();
      if (trialPlan) {
        const today = new Date().toISOString().slice(0, 10);
        await subscriptionRepository.createSubscription({
          studentId: id,
          planId: trialPlan.id,
          purchaseDate: today,
          activationDate: today,
          expiryDate: null,
          sessionsLeft: trialPlan.sessions_count || 1,
          status: 'active',
        });
      }
    }

    notifyAdmins(
      'new_student',
      'Новий учень зареєстрований',
      `${first_name} ${last_name} (${email}) зареєструвався в системі.`,
      'notify_new_student'
    );
  }

  return { token, user: safeUser(user) };
};

const login = async ({ email, password }) => {
  const user = await userRepository.findByEmail(email);

  if (!user) {
    const err = new Error('Невірний email або пароль');
    err.status = 401;
    throw err;
  }

  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) {
    const err = new Error('Невірний email або пароль');
    err.status = 401;
    throw err;
  }

  const token = generateToken(user);
  return { token, user: safeUser(user) };
};

const forgotPassword = async (email) => {
  const user = await userRepository.findByEmail(email);
  if (!user) return;

  const token = await resetTokenRepository.create(user.id);

  try {
    await mailer.sendPasswordResetEmail(email, token);
  } catch (err) {
    console.error('Помилка відправки email:', err.message);
  }
};

const resetPassword = async (token, newPassword) => {
  const record = await resetTokenRepository.findByToken(token);

  if (!record) {
    const err = new Error('Посилання для скидання пароля недійсне або прострочене');
    err.status = 400;
    throw err;
  }

  if (newPassword.length < 6) {
    const err = new Error('Пароль має містити щонайменше 6 символів');
    err.status = 400;
    throw err;
  }

  const password_hash = await bcrypt.hash(newPassword, BCRYPT_ROUNDS);

  await userRepository.update(record.user_id, { password_hash });
  await resetTokenRepository.markUsed(token);
};

const getMe = async (userId) => {
  const user = await userRepository.findById(userId);
  if (!user) {
    const err = new Error('Користувача не знайдено');
    err.status = 404;
    throw err;
  }
  return safeUser(user);
};

module.exports = { register, login, forgotPassword, resetPassword, getMe };