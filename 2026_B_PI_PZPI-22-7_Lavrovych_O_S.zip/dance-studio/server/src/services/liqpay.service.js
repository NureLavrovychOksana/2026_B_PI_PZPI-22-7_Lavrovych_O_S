const { computeSignature, encodeParams, verifySignature: _verify } = require('../utils/liqpayUtils');

const PUBLIC_KEY  = process.env.LIQPAY_PUBLIC_KEY;
const PRIVATE_KEY = process.env.LIQPAY_PRIVATE_KEY;

const sign = (data) => computeSignature(PRIVATE_KEY, data);

const encode = (params) => {
  const data      = encodeParams(params);
  const signature = sign(data);
  return { data, signature };
};

const decode = (data) => {
  const json = Buffer.from(data, 'base64').toString('utf8');
  return JSON.parse(json);
};

const verifySignature = (data, signature) => _verify(PRIVATE_KEY, data, signature);

const createCheckout = ({ orderId, amount, description, callbackUrl, resultUrl }) => {
  const params = {
    version:    3,
    public_key: PUBLIC_KEY,
    action:     'pay',
    amount:     String(amount),
    currency:   'UAH',
    description,
    order_id:   orderId,
    language:   'uk',
  };
  if (callbackUrl) params.server_url = callbackUrl;
  if (resultUrl)   params.result_url = resultUrl;
  return encode(params);
};

module.exports = { sign, encode, decode, verifySignature, createCheckout };