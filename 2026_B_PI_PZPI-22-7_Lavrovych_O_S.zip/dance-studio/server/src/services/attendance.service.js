const pool = require("../config/db");
const attendanceRepository   = require("../repositories/attendance.repository");
const enrollmentRepository   = require("../repositories/enrollment.repository");
const lessonRepository       = require("../repositories/lesson.repository");
const notificationRepository = require("../repositories/notification.repository");
const subscriptionRepository = require("../repositories/subscription.repository");

const mark = async (
  { lessonId, studentId, status = "present" },
  requestUser,
) => {
  const lesson = await lessonRepository.findById(lessonId);
  if (!lesson) {
    const err = new Error("Заняття не знайдено");
    err.status = 404;
    throw err;
  }

  if (requestUser.role === "teacher" && lesson.teacher_id !== requestUser.id) {
    const err = new Error("Доступ заборонено");
    err.status = 403;
    throw err;
  }

  const enrollment = await enrollmentRepository.findOne(studentId, lessonId);
  if (!enrollment) {
    const err = new Error("Учень не записаний на це заняття");
    err.status = 403;
    throw err;
  }

  const existing = await attendanceRepository.findOne(studentId, lessonId);
  if (existing) {
    const err = new Error("Відвідуваність вже відмічена");
    err.status = 409;
    throw err;
  }

  const markedAt = new Date().toISOString().slice(0, 19).replace("T", " ");

  const conn = await pool.getConnection();
  await conn.query("SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED");
  await conn.beginTransaction();

  let attendanceId;
  let subscription = null;
  let sessionsLeft = null;
  const isNewFlow = !!enrollment.subscription_id;

  try {
    if (isNewFlow) {
      const [[linkedSub]] = await conn.query(
        `SELECT ss.id, ss.sessions_left, sp.type
         FROM student_subscriptions ss
         JOIN subscription_plans sp ON sp.id = ss.plan_id
         WHERE ss.id = ?`,
        [enrollment.subscription_id]
      );
      subscription = linkedSub;

      if ((status === "present" || status === "absent") && linkedSub?.type === "COUNT") {
        await conn.query(
          `UPDATE student_subscriptions SET sessions_left = sessions_left - 1 WHERE id = ?`,
          [linkedSub.id]
        );
        await conn.query(
          `UPDATE student_subscriptions SET status = 'exhausted' WHERE id = ? AND sessions_left = 0`,
          [linkedSub.id]
        );
        const [[updated]] = await conn.query(
          "SELECT sessions_left FROM student_subscriptions WHERE id = ?",
          [linkedSub.id]
        );
        sessionsLeft = updated.sessions_left;
      }
    } else if (status === "present") {
      subscription = await attendanceRepository.findActiveSubscriptionForUpdate(
        conn,
        studentId,
        markedAt,
      );

      if (subscription && subscription.type === "COUNT") {
        await attendanceRepository.deductSession(conn, subscription.id);
        await attendanceRepository.exhaustSubscription(conn, subscription.id);

        const [[updated]] = await conn.query(
          "SELECT sessions_left FROM student_subscriptions WHERE id = ?",
          [subscription.id],
        );
        sessionsLeft = updated.sessions_left;
      }
    }

    attendanceId = await attendanceRepository.insertAttendance(conn, {
      studentId,
      lessonId,
      subscriptionId: subscription?.id || null,
      status,
      markedAt,
    });

    await conn.commit();
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }

  if (subscription && subscription.type === "COUNT" && sessionsLeft === 0) {
    try {
      const activatedId = await subscriptionRepository.tryActivateNextPending(studentId);
      if (activatedId) {
        await notificationRepository.create({
          userId: studentId,
          type:   "subscription_activated",
          title:  "Новий абонемент активовано",
          body:   "Попередній абонемент вичерпано. Ваш наступний абонемент автоматично активовано.",
        });
      } else {
        await notificationRepository.create({
          userId: studentId,
          type: "subscription_exhausted",
          title: "Абонемент вичерпано",
          body: "Ваш абонемент закінчився. Придбайте новий, щоб продовжити відвідування.",
        });
      }
    } catch (notifErr) {
      console.error("Помилка post-exhaust:", notifErr.message);
    }
  } else if (
    subscription &&
    subscription.type === "COUNT" &&
    sessionsLeft !== null &&
    sessionsLeft > 0 &&
    sessionsLeft <= 3
  ) {
    try {
      await notificationRepository.create({
        userId: studentId,
        type: "subscription_low",
        title: "Залишилось мало занять",
        body: `У вашому абонементі залишилось ${sessionsLeft} ${sessionsLeft === 1 ? "заняття" : "заняття/занять"}. Подбайте про поповнення.`,
      });
    } catch (notifErr) {
      console.error("Помилка створення сповіщення:", notifErr.message);
    }
  }

  return {
    attendance_id: attendanceId,
    student_id: studentId,
    lesson_id: lessonId,
    status,
    marked_at: markedAt,
    subscription_id: subscription?.id || null,
    sessions_left: sessionsLeft,
    no_subscription: status === "present" && !subscription,
  };
};

const markBulk = async ({ lessonId, records }, requestUser) => {
  const results = [];
  const errors = [];

  for (const record of records) {
    try {
      const result = await mark(
        {
          lessonId,
          studentId: record.student_id,
          status: record.status || "present",
        },
        requestUser,
      );
      results.push(result);
    } catch (err) {
      errors.push({ student_id: record.student_id, error: err.message });
    }
  }

  return { results, errors };
};

const updateMark = async (attendanceId, status, requestUser) => {
  const allowed = ["present", "absent", "excused"];
  if (!allowed.includes(status)) {
    const err = new Error(
      "Невірний статус. Допустимі: present, absent, excused",
    );
    err.status = 400;
    throw err;
  }

  const [[existing]] = await pool.query(
    `SELECT a.id, a.status AS old_status, e.subscription_id AS enr_sub_id
     FROM attendance a
     JOIN enrollments e ON e.student_id = a.student_id AND e.lesson_id = a.lesson_id
     WHERE a.id = ?`,
    [attendanceId]
  );
  if (!existing) {
    const err = new Error("Запис відвідуваності не знайдено");
    err.status = 404;
    throw err;
  }

  if (existing.enr_sub_id) {
    const [[sub]] = await pool.query(
      `SELECT ss.id, sp.type AS plan_type
       FROM student_subscriptions ss
       JOIN subscription_plans sp ON sp.id = ss.plan_id
       WHERE ss.id = ?`,
      [existing.enr_sub_id]
    );
    if (sub?.plan_type === "COUNT") {
      const wasExcused = existing.old_status === "excused";
      const nowExcused = status === "excused";
      if (!wasExcused && nowExcused) {
        await pool.query(
          `UPDATE student_subscriptions
           SET sessions_left = sessions_left + 1,
               status = CASE WHEN status = 'exhausted' THEN 'active' ELSE status END
           WHERE id = ?`,
          [sub.id]
        );
      } else if (wasExcused && !nowExcused) {
        await pool.query(
          `UPDATE student_subscriptions
           SET sessions_left = GREATEST(0, sessions_left - 1),
               status = CASE WHEN sessions_left - 1 <= 0 THEN 'exhausted' ELSE status END
           WHERE id = ?`,
          [sub.id]
        );
      }
    }
  }

  const updated = await attendanceRepository.updateAttendance(attendanceId, status);
  if (!updated) {
    const err = new Error("Запис відвідуваності не знайдено");
    err.status = 404;
    throw err;
  }
  return { id: attendanceId, status };
};

const getByLesson = async (lessonId, requestUser) => {
  const lesson = await lessonRepository.findById(lessonId);
  if (!lesson) {
    const err = new Error("Заняття не знайдено");
    err.status = 404;
    throw err;
  }
  if (requestUser.role === "teacher" && lesson.teacher_id !== requestUser.id) {
    const err = new Error("Доступ заборонено");
    err.status = 403;
    throw err;
  }
  return attendanceRepository.findByLesson(lessonId);
};

const getByStudent = async (studentId, filters, requestUser) => {
  if (requestUser.role === "student" && requestUser.id !== Number(studentId)) {
    const err = new Error("Доступ заборонено");
    err.status = 403;
    throw err;
  }
  return attendanceRepository.findByStudent(studentId, filters);
};

module.exports = { mark, markBulk, updateMark, getByLesson, getByStudent };
