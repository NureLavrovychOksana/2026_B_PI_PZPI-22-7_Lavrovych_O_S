const lessonRepository       = require('../repositories/lesson.repository');
const groupRepository        = require('../repositories/group.repository');
const notificationRepository = require('../repositories/notification.repository');
const pool                   = require('../config/db');

const notifyEnrolledStudents = async (lessonId, title, body) => {
  const [students] = await pool.query(`
    SELECT u.id, u.notification_prefs
    FROM enrollments e
    JOIN users u ON u.id = e.student_id
    WHERE e.lesson_id = ?
  `, [lessonId]);

  for (const s of students) {
    const prefs = s.notification_prefs
      ? (typeof s.notification_prefs === 'string' ? JSON.parse(s.notification_prefs) : s.notification_prefs)
      : {};
    if (prefs.schedule === false) continue;
    notificationRepository.create({ userId: s.id, type: 'schedule_change', title, body }).catch(() => {});
  }
};

const fmtLesson = (l) =>
  `${l.style_name || l.group_name}, ${l.lesson_date} о ${String(l.start_time).slice(0,5)}`;

const getAll = async (filters) => {
  return lessonRepository.findAll(filters || {});
};

const getById = async (id) => {
  const lesson = await lessonRepository.findById(id);
  if (!lesson) {
    const err = new Error('Заняття не знайдено');
    err.status = 404;
    throw err;
  }
  return lesson;
};

const checkAndThrowConflicts = async ({ groupId, hallId, lessonDate, startTime, endTime, excludeId }) => {
  const conflicts = await lessonRepository.findConflicts({
    groupId, hallId, lessonDate, startTime, endTime, excludeId,
  });

  if (conflicts.length > 0) {
    const err = new Error('Конфлікт розкладу');
    err.status = 409;
    err.conflicts = conflicts;
    throw err;
  }
};

const create = async ({ groupId, hallId, lessonDate, startTime, endTime }) => {
  if (!groupId || !hallId || !lessonDate || !startTime || !endTime) {
    const err = new Error('Поля group_id, hall_id, lesson_date, start_time, end_time є обовʼязковими');
    err.status = 400;
    throw err;
  }

  const group = await groupRepository.findById(groupId);
  if (!group) {
    const err = new Error('Групу не знайдено');
    err.status = 404;
    throw err;
  }

  await checkAndThrowConflicts({ groupId, hallId, lessonDate, startTime, endTime });

  const id = await lessonRepository.create({ groupId, hallId, lessonDate, startTime, endTime });
  const lesson = await lessonRepository.findById(id);

  if (lesson?.group_teacher_id) {
    notificationRepository.create({
      userId: lesson.group_teacher_id,
      type:   'lesson_added',
      title:  'Нове заняття у розкладі',
      body:   `Додано заняття: ${fmtLesson(lesson)}, зал ${lesson.hall_name}.`,
    }).catch(() => {});
  }

  return lesson;
};

const update = async (id, { groupId, hallId, lessonDate, startTime, endTime }) => {
  const existing = await lessonRepository.findById(id);
  if (!existing) {
    const err = new Error('Заняття не знайдено');
    err.status = 404;
    throw err;
  }

  const merged = {
    groupId:    groupId    ?? existing.group_id,
    hallId:     hallId     ?? existing.hall_id,
    lessonDate: lessonDate ?? existing.lesson_date,
    startTime:  startTime  ?? existing.start_time,
    endTime:    endTime    ?? existing.end_time,
  };

  await checkAndThrowConflicts({ ...merged, excludeId: id });

  const updateTeacher = !!groupId && Number(groupId) !== existing.group_id;
  await lessonRepository.update(id, { ...merged, updateTeacher });
  const updated = await lessonRepository.findById(id);

  const changes = [];
  if (lessonDate && lessonDate !== existing.lesson_date) changes.push(`дата: ${lessonDate}`);
  if (startTime  && startTime  !== existing.start_time.slice(0,5))  changes.push(`час: ${String(startTime).slice(0,5)}–${String(endTime ?? existing.end_time).slice(0,5)}`);
  if (hallId     && hallId     !== existing.hall_id)    changes.push(`зал: ${updated.hall_name}`);

  if (changes.length > 0) {
    const changeBody = `${fmtLesson(updated)}: ${changes.join(', ')}.`;

    if (updated?.group_teacher_id) {
      notificationRepository.create({
        userId: updated.group_teacher_id,
        type:   'lesson_changed',
        title:  'Зміна у занятті',
        body:   changeBody,
      }).catch(() => {});
    }

    notifyEnrolledStudents(id, 'Зміна у розкладі', changeBody);
  }

  return updated;
};

const remove = async (id) => {
  const existing = await lessonRepository.findById(id);
  if (!existing) {
    const err = new Error('Заняття не знайдено');
    err.status = 404;
    throw err;
  }

  const cancelBody = `Скасовано заняття: ${fmtLesson(existing)}.`;

  if (existing.group_teacher_id) {
    notificationRepository.create({
      userId: existing.group_teacher_id,
      type:   'lesson_cancelled',
      title:  'Заняття скасовано',
      body:   cancelBody,
    }).catch(() => {});
  }

  notifyEnrolledStudents(id, 'Заняття скасовано', cancelBody);

  return lessonRepository.remove(id);
};

const updateNotes = async (id, notes, authorId) => {
  const lesson = await getById(id);
  return lessonRepository.updateNotes(lesson.id, notes, authorId);
};

const getNotesByGroup = async (groupId) => {
  return lessonRepository.findNotesByGroup(groupId);
};

module.exports = { getAll, getById, create, update, remove, updateNotes, getNotesByGroup };
