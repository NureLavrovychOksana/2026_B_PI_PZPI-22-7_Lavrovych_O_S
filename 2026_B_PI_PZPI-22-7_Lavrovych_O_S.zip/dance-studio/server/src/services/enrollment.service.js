const enrollmentRepository     = require('../repositories/enrollment.repository');
const waitlistRepository       = require('../repositories/waitlist.repository');
const lessonRepository         = require('../repositories/lesson.repository');
const userRepository           = require('../repositories/user.repository');
const notificationRepository   = require('../repositories/notification.repository');
const subscriptionRepository   = require('../repositories/subscription.repository');
const { notifyAdmins }         = require('../utils/adminNotify');
const pool                     = require('../config/db');

const getSetting = async (key) => {
  try {
    const [[row]] = await pool.query("SELECT `value` FROM studio_settings WHERE `key` = ?", [key]);
    return row?.value ?? null;
  } catch { return null; }
};

const getByLesson = async (lessonId) => {
  const lesson = await lessonRepository.findById(lessonId);
  if (!lesson) { const e = new Error('Заняття не знайдено'); e.status = 404; throw e; }
  return enrollmentRepository.findByLesson(lessonId);
};

const getByStudent = async (studentId) => {
  const student = await userRepository.findById(studentId);
  if (!student) { const e = new Error('Учня не знайдено'); e.status = 404; throw e; }
  return enrollmentRepository.findByStudent(studentId);
};

const enroll = async (studentId, lessonId) => {
  const student = await userRepository.findById(studentId);
  if (!student || student.role !== 'student') { const e = new Error('Учня не знайдено'); e.status = 404; throw e; }

  const lesson = await lessonRepository.findById(lessonId);
  if (!lesson) { const e = new Error('Заняття не знайдено'); e.status = 404; throw e; }
  if (lesson.status === 'cancelled') { const e = new Error('Заняття скасовано'); e.status = 409; throw e; }

  const existing = await enrollmentRepository.findOne(studentId, lessonId);
  if (existing) { const e = new Error('Учень вже записаний на це заняття'); e.status = 409; throw e; }

  const id = await enrollmentRepository.create(studentId, lessonId);
  return { id, student_id: studentId, lesson_id: lessonId };
};

const selfEnroll = async (studentId, lessonId) => {
  const lesson = await lessonRepository.findById(lessonId);
  if (!lesson) { const e = new Error('Заняття не знайдено'); e.status = 404; throw e; }
  if (lesson.status === 'cancelled') { const e = new Error('Заняття скасовано'); e.status = 409; throw e; }

  const now     = new Date();
  const nowDate = now.toISOString().slice(0, 10);
  const nowTime = now.toTimeString().slice(0, 5);
  const lessonDate = String(lesson.lesson_date).slice(0, 10);
  const lessonEnd  = String(lesson.end_time).slice(0, 5);
  if (lessonDate < nowDate || (lessonDate === nowDate && lessonEnd <= nowTime)) {
    const e = new Error('Заняття вже відбулось'); e.status = 409; throw e;
  }

  const existing = await enrollmentRepository.findOne(studentId, lessonId);
  if (existing) { const e = new Error('Ви вже записані на це заняття'); e.status = 409; throw e; }

  if (lesson.free_spots <= 0) {
    const e = new Error('Місць немає. Ви можете стати до листа очікування.');
    e.status = 409;
    e.waitlist = true;
    throw e;
  }

  const [[activeSub]] = await pool.query(
    `SELECT ss.id, ss.sessions_left, sp.type AS plan_type,
       (SELECT COUNT(*) FROM enrollments e
        JOIN lessons l2 ON l2.id = e.lesson_id
        WHERE e.subscription_id = ss.id AND l2.lesson_date >= CURDATE()) AS sessions_frozen
     FROM student_subscriptions ss
     JOIN subscription_plans sp ON sp.id = ss.plan_id
     WHERE ss.student_id = ?
       AND ss.status = 'active'
       AND (ss.expiry_date IS NULL OR ss.expiry_date >= CURDATE())
       AND (sp.type = 'UNLIMITED' OR ss.sessions_left > 0)
     ORDER BY ss.expiry_date ASC
     LIMIT 1`,
    [studentId]
  );

  if (!activeSub) {
    const e = new Error('Немає доступних занять. Придбайте або поповніть абонемент.');
    e.status = 403;
    e.noSubscription = true;
    throw e;
  }

  if (activeSub.plan_type === 'COUNT') {
    const available = activeSub.sessions_left - (activeSub.sessions_frozen || 0);
    if (available <= 0) {
      const e = new Error('Усі доступні заняття вже зарезервовано. Скасуйте один запис або придбайте новий абонемент.');
      e.status = 403;
      e.noSubscription = true;
      throw e;
    }
  }

  await waitlistRepository.removeByStudentLesson(studentId, lessonId);

  const id = await enrollmentRepository.createWithSub(studentId, lessonId, activeSub.id);

  if (lesson.group_teacher_id) {
    const student = await userRepository.findById(studentId);
    notificationRepository.create({
      userId: lesson.group_teacher_id,
      type:   'new_enrollment',
      title:  'Новий запис у групу',
      body:   `${student?.first_name ?? ''} ${student?.last_name ?? ''} записався на заняття ${lesson.start_time?.slice(0,5) ?? ''} (${lesson.lesson_date}).`,
    }).catch(() => {});
  }

  return { id, student_id: studentId, lesson_id: lessonId };
};

const joinWaitlist = async (studentId, lessonId) => {
  const lesson = await lessonRepository.findById(lessonId);
  if (!lesson) { const e = new Error('Заняття не знайдено'); e.status = 404; throw e; }

  const enrolled = await enrollmentRepository.findOne(studentId, lessonId);
  if (enrolled) { const e = new Error('Ви вже записані на це заняття'); e.status = 409; throw e; }

  const onWaitlist = await waitlistRepository.findOne(studentId, lessonId);
  if (onWaitlist) { const e = new Error('Ви вже у списку очікування'); e.status = 409; throw e; }

  const id = await waitlistRepository.add(studentId, lessonId);
  return { id, student_id: studentId, lesson_id: lessonId };
};

const leaveWaitlist = async (waitlistId, requestUser) => {
  const entry = await waitlistRepository.findById(waitlistId);
  if (!entry) { const e = new Error('Запис не знайдено'); e.status = 404; throw e; }

  if (requestUser.role === 'student' && entry.student_id !== requestUser.id) {
    const e = new Error('Доступ заборонено'); e.status = 403; throw e;
  }

  return waitlistRepository.remove(waitlistId);
};

const getWaitlistByLesson  = async (lessonId)  => waitlistRepository.findByLesson(lessonId);
const getWaitlistByStudent = async (studentId) => waitlistRepository.findByStudent(studentId);

const unenroll = async (enrollmentId, requestUser) => {
  const enrollment = await enrollmentRepository.findById(enrollmentId);
  if (!enrollment) { const e = new Error('Запис не знайдено'); e.status = 404; throw e; }

  if (requestUser.role === 'student' && enrollment.student_id !== requestUser.id) {
    const e = new Error('Доступ заборонено'); e.status = 403; throw e;
  }

  const lesson = await lessonRepository.findById(enrollment.lesson_id);

  if (requestUser.role === 'student' && lesson) {
    const hoursStr = await getSetting('cancel_hours_before');
    const hours = Number(hoursStr) || 0;
    if (hours > 0) {
      const lessonDt = new Date(`${lesson.lesson_date}T${lesson.start_time}`);
      const diffHours = (lessonDt - new Date()) / 3_600_000;
      if (diffHours < hours) {
        const e = new Error(`Скасування запису можливе не пізніше, ніж за ${hours} год. до початку заняття`);
        e.status = 403;
        throw e;
      }
    }
  }

  await enrollmentRepository.remove(enrollmentId);

  if (lesson?.group_teacher_id && requestUser.role === 'student') {
    const student = await userRepository.findById(enrollment.student_id);
    notificationRepository.create({
      userId: lesson.group_teacher_id,
      type:   'enrollment_cancelled',
      title:  'Скасування запису',
      body:   `${student?.first_name ?? ''} ${student?.last_name ?? ''} скасував запис на заняття ${lesson.start_time?.slice(0,5) ?? ''} (${lesson.lesson_date}).`,
    }).catch(() => {});
  }

  const minStr = await getSetting('min_students_cancel');
  const minStudents = Number(minStr) || 0;
  if (minStudents > 0 && lesson) {
    const [[{ cnt }]] = await pool.query(
      'SELECT COUNT(*) AS cnt FROM enrollments WHERE lesson_id = ?',
      [enrollment.lesson_id]
    );
    if (Number(cnt) < minStudents) {
      await pool.query("UPDATE lessons SET status = 'cancelled' WHERE id = ?", [enrollment.lesson_id]);

      const [remaining] = await pool.query(
        'SELECT student_id, subscription_id FROM enrollments WHERE lesson_id = ?',
        [enrollment.lesson_id]
      );
      const lessonLabel = `${lesson.group_name || ''} ${lesson.start_time?.slice(0,5) || ''} (${lesson.lesson_date})`;
      for (const r of remaining) {
        notificationRepository.create({
          userId: r.student_id,
          type:   'lesson_cancelled',
          title:  'Заняття скасовано',
          body:   `Заняття ${lessonLabel} скасовано: недостатня кількість учнів.`,
        }).catch(() => {});
      }

      if (lesson.group_teacher_id) {
        notificationRepository.create({
          userId: lesson.group_teacher_id,
          type:   'lesson_cancelled',
          title:  'Заняття скасовано',
          body:   `Заняття ${lessonLabel} скасовано автоматично — недостатня кількість записаних учнів.`,
        }).catch(() => {});
      }

      notifyAdmins(
        'lesson_cancelled',
        'Заняття скасовано',
        `Заняття ${lessonLabel} скасовано через недостатню кількість учнів.`,
        'notify_lesson_cancel'
      ).catch(() => {});

      return; 
    }
  }

  const next = await waitlistRepository.getFirst(enrollment.lesson_id);
  if (next) {
    let nextSubId = null;
    try {
      const [[nextSub]] = await pool.query(
        `SELECT ss.id, ss.sessions_left, sp.type AS plan_type,
           (SELECT COUNT(*) FROM enrollments e2
            JOIN lessons l2 ON l2.id = e2.lesson_id
            WHERE e2.subscription_id = ss.id AND l2.lesson_date >= CURDATE()) AS sessions_frozen
         FROM student_subscriptions ss
         JOIN subscription_plans sp ON sp.id = ss.plan_id
         WHERE ss.student_id = ?
           AND ss.status = 'active'
           AND (ss.expiry_date IS NULL OR ss.expiry_date >= CURDATE())
           AND (sp.type = 'UNLIMITED' OR ss.sessions_left > 0)
         ORDER BY ss.expiry_date ASC LIMIT 1`,
        [next.student_id]
      );
      if (nextSub) {
        const available = nextSub.plan_type === 'COUNT'
          ? nextSub.sessions_left - (nextSub.sessions_frozen || 0)
          : Infinity;
        if (available > 0) nextSubId = nextSub.id;
      }
    } catch {}

    await enrollmentRepository.createWithSub(next.student_id, enrollment.lesson_id, nextSubId);
    await waitlistRepository.remove(next.id);

    if (lesson) {
      await notificationRepository.create({
        userId: next.student_id,
        type: 'waitlist_promoted',
        title: 'Місце звільнилося!',
        body: `Вас переведено зі списку очікування на заняття ${lesson.start_time} (${lesson.lesson_date}).`,
      });
    }
  }
};

const teacherEnroll = async (teacherId, studentId, lessonId) => {
  const lesson = await lessonRepository.findById(lessonId);
  if (!lesson) { const e = new Error('Заняття не знайдено'); e.status = 404; throw e; }

  if (lesson.group_teacher_id !== teacherId) {
    const e = new Error('Ви не є викладачем цієї групи'); e.status = 403; throw e;
  }

  const student = await userRepository.findById(studentId);
  if (!student || student.role !== 'student') {
    const e = new Error('Учня не знайдено'); e.status = 404; throw e;
  }

  const existing = await enrollmentRepository.findOne(studentId, lessonId);
  if (existing) { const e = new Error('Учень вже записаний на це заняття'); e.status = 409; throw e; }

  const id = await enrollmentRepository.create(studentId, lessonId);
  return { id, student_id: studentId, lesson_id: lessonId };
};

const bulkEnroll = async (studentId, groupId, dateFrom, dateTo) => {
  const student = await userRepository.findById(studentId);
  if (!student || student.role !== 'student') {
    const e = new Error('Учня не знайдено'); e.status = 404; throw e;
  }

  const pool = require('../config/db');
  const [lessons] = await pool.query(
    `SELECT l.id FROM lessons l
     WHERE l.group_id = ?
       AND l.lesson_date >= ?
       AND l.lesson_date <= ?
     ORDER BY l.lesson_date`,
    [groupId, dateFrom, dateTo]
  );

  const enrolled = [];
  const skipped  = [];

  for (const lesson of lessons) {
    const existing = await enrollmentRepository.findOne(studentId, lesson.id);
    if (existing) { skipped.push(lesson.id); continue; }
    await enrollmentRepository.create(studentId, lesson.id);
    enrolled.push(lesson.id);
  }

  return { enrolled: enrolled.length, skipped: skipped.length, lesson_ids: enrolled };
};

module.exports = {
  getByLesson, getByStudent, enroll, selfEnroll, teacherEnroll, bulkEnroll,
  unenroll, joinWaitlist, leaveWaitlist, getWaitlistByLesson, getWaitlistByStudent,
};
