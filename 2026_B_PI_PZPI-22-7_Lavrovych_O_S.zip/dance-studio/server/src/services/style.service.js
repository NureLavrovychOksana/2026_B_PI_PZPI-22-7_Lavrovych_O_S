const styleRepository = require('../repositories/style.repository');
const pool            = require('../config/db');

const getAll = async () => styleRepository.findAll();

const getById = async (id) => {
  const style = await styleRepository.findById(id);
  if (!style) {
    const err = new Error('Стиль не знайдено');
    err.status = 404;
    throw err;
  }
  return style;
};

const create = async ({ name, description }) => {
  if (!name) {
    const err = new Error('Назва стилю обовʼязкова');
    err.status = 400;
    throw err;
  }
  const id = await styleRepository.create({ name, description });
  return styleRepository.findById(id);
};

const update = async (id, { name, description }) => {
  await getById(id);
  if (!name) {
    const err = new Error('Назва стилю обовʼязкова');
    err.status = 400;
    throw err;
  }
  await styleRepository.update(id, { name, description });
  return styleRepository.findById(id);
};

const remove = async (id) => {
  await getById(id);

  const [[{ active_cnt }]] = await pool.query(
    `SELECT COUNT(*) AS active_cnt FROM dance_groups WHERE style_id = ? AND status = 'active'`,
    [id]
  );
  if (Number(active_cnt) > 0) {
    const err = new Error(`Стиль використовується в ${active_cnt} активних групах. Змініть стиль у них перед видаленням.`);
    err.status = 400;
    throw err;
  }

  await pool.query(`UPDATE dance_groups SET style_id = NULL WHERE style_id = ?`, [id]);
  await pool.query(`DELETE FROM teacher_styles WHERE style_id = ?`, [id]);

  const deleted = await styleRepository.remove(id);
  if (!deleted) {
    const err = new Error('Не вдалося видалити стиль');
    err.status = 500;
    throw err;
  }
};

module.exports = { getAll, getById, create, update, remove };