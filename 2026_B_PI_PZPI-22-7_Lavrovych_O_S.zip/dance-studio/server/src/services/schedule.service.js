const scheduleRepo = require('../repositories/schedule.repository');
const pool         = require('../config/db');
const { toMin, backtrackDraft } = require('../utils/csp');

const toTime = m => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;

const generateDraft = async ({ weekStart, groupRequirements, hallIds, allowedDays, timeFrom, timeTo, slotStep = 30 }) => {
  if (!groupRequirements?.length) throw Object.assign(new Error('Список груп порожній'), { status: 400 });

  const timeFromMin = toMin(timeFrom);
  const timeToMin   = toMin(timeTo);

  const [hallRows] = hallIds?.length
    ? await pool.query(`SELECT id, name, capacity FROM halls WHERE id IN (?)`, [hallIds])
    : await pool.query(`SELECT id, name, capacity FROM halls`);
  if (!hallRows.length) throw Object.assign(new Error('Залів не знайдено'), { status: 400 });

  const allTeacherIds = [...new Set(groupRequirements.map(r => r.teacher_id))];
  const availability  = {};
  for (const tid of allTeacherIds) {
    const blocks = await scheduleRepo.getTeacherAvailability(tid);
    availability[tid] = blocks.map(b => ({
      dayIdx:   b.day_of_week,
      startMin: toMin(String(b.start_time).slice(0, 5)),
      endMin:   toMin(String(b.end_time).slice(0, 5)),
    }));
  }

  const variables = groupRequirements.flatMap(req =>
    Array.from({ length: req.lessons_per_week }, (_, occ) => ({
      varKey: `g${req.group_id}_occ${occ}`, group_id: req.group_id,
      occurrence: occ, duration_min: req.lesson_duration, req,
    }))
  );

  const { placed: newPlaced, unplaced } = backtrackDraft(variables, [], hallRows, availability, allowedDays, timeFromMin, timeToMin, slotStep);

  const [wsY, wsM, wsD] = weekStart.split('-').map(Number);
  const hallMap = Object.fromEntries(hallRows.map(h => [h.id, h]));
  const reqMap  = Object.fromEntries(groupRequirements.map(r => [r.group_id, r]));

  const placedLessons = newPlaced.map((p, i) => {
    const d = new Date(wsY, wsM - 1, wsD + p.dayIdx);
    const lesson_date = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const req  = reqMap[p.group_id] || {};
    const hall = hallMap[p.hall_id] || {};
    return {
      id: i + 1,
      group_id: p.group_id, group_name: req.group_name || '', style_name: req.style_name || '',
      teacher_id: req.teacher_id || null, teacher_name: req.teacher_name || '',
      hall_id: p.hall_id, hall_name: hall.name || null,
      lesson_date, start_time: toTime(p.startMin), end_time: toTime(p.endMin),
      duration_min: p.duration_min, is_unplaced: false, unplaced_reason: null,
      warnings: p.warnings || [], score: p.score ?? 100,
    };
  });

  const unplacedLessons = unplaced.map((u, i) => {
    const req = reqMap[u.group_id] || {};
    return {
      id: newPlaced.length + i + 1,
      group_id: u.group_id, group_name: req.group_name || '', style_name: req.style_name || '',
      teacher_id: req.teacher_id || null, teacher_name: req.teacher_name || '',
      hall_id: null, hall_name: null,
      lesson_date: null, start_time: null, end_time: null,
      duration_min: u.duration_min, is_unplaced: true,
      unplaced_reason: u.reason || 'Не вдалося знайти вільний слот',
      warnings: [], score: 0,
    };
  });

  const lessons = [...placedLessons, ...unplacedLessons];
  return {
    lessons,
    stats: {
      total:    lessons.length,
      placed:   placedLessons.length,
      unplaced: unplacedLessons.length,
      warnings: placedLessons.filter(l => l.warnings.length > 0).length,
    },
  };
};

const getWeekStatus = async (weekStart) => {
  const [[row]] = await pool.query(`
    SELECT
      COUNT(l.id) AS lesson_count,
      COALESCE(SUM(CASE WHEN e.cnt > 0 THEN 1 ELSE 0 END), 0) AS enrolled_lessons
    FROM lessons l
    LEFT JOIN (SELECT lesson_id, COUNT(*) AS cnt FROM enrollments GROUP BY lesson_id) e
      ON e.lesson_id = l.id
    WHERE l.lesson_date >= ? AND l.lesson_date < DATE_ADD(?, INTERVAL 7 DAY)
  `, [weekStart, weekStart]);
  const lesson_count     = Number(row.lesson_count);
  const enrolled_lessons = Number(row.enrolled_lessons);
  return {
    has_lessons:   lesson_count > 0,
    lesson_count,
    enrolled_lessons,
    can_overwrite: true,
  };
};

const publishSchedule = async (lessons, mode = 'append', weekStart) => {
  let placed = lessons.filter(l => !l.is_unplaced && l.lesson_date && l.start_time);
  if (!placed.length) return { published: 0 };

  if (mode === 'overwrite' && weekStart) {
    await pool.query(
      `DELETE FROM lessons
       WHERE lesson_date >= ? AND lesson_date < DATE_ADD(?, INTERVAL 7 DAY)
         AND id NOT IN (SELECT lesson_id FROM enrollments)`,
      [weekStart, weekStart]
    );
    const [kept] = await pool.query(
      `SELECT hall_id, lesson_date, start_time, end_time FROM lessons
       WHERE lesson_date >= ? AND lesson_date < DATE_ADD(?, INTERVAL 7 DAY)`,
      [weekStart, weekStart]
    );
    if (kept.length) {
      placed = placed.filter(l => !kept.some(e =>
        e.hall_id === l.hall_id &&
        String(e.lesson_date).slice(0, 10) === l.lesson_date &&
        toMin(String(e.start_time).slice(0, 5)) < toMin(String(l.end_time).slice(0, 5)) &&
        toMin(String(l.start_time).slice(0, 5)) < toMin(String(e.end_time).slice(0, 5))
      ));
    }
  } else if (mode === 'append' && weekStart) {
    const [existing] = await pool.query(
      `SELECT hall_id, lesson_date, start_time, end_time FROM lessons
       WHERE lesson_date >= ? AND lesson_date < DATE_ADD(?, INTERVAL 7 DAY)`,
      [weekStart, weekStart]
    );
    if (existing.length) {
      placed = placed.filter(l => !existing.some(e =>
        e.hall_id === l.hall_id &&
        String(e.lesson_date).slice(0, 10) === l.lesson_date &&
        toMin(String(e.start_time).slice(0, 5)) < toMin(String(l.end_time).slice(0, 5)) &&
        toMin(String(l.start_time).slice(0, 5)) < toMin(String(e.end_time).slice(0, 5))
      ));
    }
  }

  if (!placed.length) return { published: 0 };
  const values = placed.map(l => [l.group_id, l.hall_id, l.lesson_date, l.start_time, l.end_time, l.teacher_id ?? null]);
  await pool.query(`INSERT INTO lessons (group_id, hall_id, lesson_date, start_time, end_time, teacher_id) VALUES ?`, [values]);
  return { published: placed.length };
};

module.exports = { generateDraft, getWeekStatus, publishSchedule };
