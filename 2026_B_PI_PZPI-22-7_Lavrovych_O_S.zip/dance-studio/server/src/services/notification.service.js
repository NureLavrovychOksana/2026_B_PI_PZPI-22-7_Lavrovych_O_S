const notificationRepository = require('../repositories/notification.repository');
const pool = require('../config/db');

const getMyNotifications = async (userId) => {
  return notificationRepository.findByUser(userId);
};

const getUnreadCount = async (userId) => {
  return notificationRepository.countUnread(userId);
};

const markRead = async (id, userId) => {
  const updated = await notificationRepository.markRead(id, userId);
  if (!updated) {
    const err = new Error('Сповіщення не знайдено');
    err.status = 404;
    throw err;
  }
  return { id, is_read: true };
};

const markAllRead = async (userId) => {
  const count = await notificationRepository.markAllRead(userId);
  return { updated: count };
};

const broadcast = async ({ groupId, type, title, body }) => {
  let userIds = [];

  if (groupId) {
    const [rows] = await pool.query(
      `SELECT DISTINCT e.student_id
       FROM enrollments e
       JOIN lessons l ON l.id = e.lesson_id
       WHERE l.group_id = ?`,
      [groupId]
    );
    userIds = rows.map(r => r.student_id);
  } else {
    const [rows] = await pool.query(
      `SELECT id FROM users WHERE role = 'student'`
    );
    userIds = rows.map(r => r.id);
  }

  if (userIds.length === 0) {
    return { sent: 0 };
  }

  const sent = await notificationRepository.broadcast({ userIds, type, title, body });
  return { sent };
};

module.exports = { getMyNotifications, getUnreadCount, markRead, markAllRead, broadcast };