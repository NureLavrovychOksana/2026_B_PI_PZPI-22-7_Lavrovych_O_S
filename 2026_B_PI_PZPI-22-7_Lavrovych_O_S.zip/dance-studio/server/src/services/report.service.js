const dashRepo    = require('../repositories/report.dashboard.repository');
const studentRepo = require('../repositories/report.student.repository');
const teacherRepo = require('../repositories/report.teacher.repository');
const logRepo     = require('../repositories/report.log.repository');

const _currentMonthRange = () => {
  const n = new Date();
  const pad = v => String(v).padStart(2, '0');
  return {
    dateFrom: `${n.getFullYear()}-${pad(n.getMonth() + 1)}-01`,
    dateTo:   `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`,
  };
};

const getDashboard = async () => {
  const [
    stats, revenueSplit, ltv, funnel, churnRisk,
    revenueByMonth, stylesEnhanced, teacherUtilization,
    anomalies, expiringSoon, recentActivity, attendanceByGroup,
  ] = await Promise.all([
    dashRepo.getDashboardStats(),
    dashRepo.getRevenueSplit(),
    dashRepo.getLTV(),
    dashRepo.getFunnel(),
    dashRepo.getChurnRisk(),
    dashRepo.getRevenueByMonth(6),
    dashRepo.getStylesEnhanced(),
    dashRepo.getTeacherUtilization(),
    dashRepo.getAnomalies(),
    studentRepo.getExpiringSubscriptions(3),
    dashRepo.getRecentActivity(10),
    dashRepo.getAttendanceByGroup(_currentMonthRange()),
  ]);

  return {
    stats:               { ...stats, ltv, churn_risk_count: churnRisk },
    revenue_split:       revenueSplit,
    revenue_by_month:    revenueByMonth,
    styles_popularity:   stylesEnhanced,
    teacher_utilization: teacherUtilization,
    anomalies,
    expiring_soon:       expiringSoon,
    funnel,
    recent_activity:     recentActivity,
    attendance_by_group: attendanceByGroup,
  };
};

const getRevenue = async ({ months, groupBy } = {}) => {
  if (groupBy === 'week') return dashRepo.getRevenueByWeek();
  return dashRepo.getRevenueByMonth(months || 12);
};

const getAttendance = async ({ dateFrom, dateTo }) =>
  dashRepo.getAttendanceByGroup({ dateFrom, dateTo });

const getTeacherReport = async (teacherId) => {
  const report = await teacherRepo.getTeacherReport(teacherId);
  if (!report) {
    const err = new Error('Викладача не знайдено');
    err.status = 404;
    throw err;
  }
  return report;
};

const getDebtors = async () => studentRepo.getDebtors();

const getExpiringSubscriptions = async (days) =>
  studentRepo.getExpiringSubscriptions(days || 14);

const getStudentStats = async (studentId, requestUser) => {
  if (requestUser.role === 'student' && requestUser.id !== Number(studentId)) {
    const err = new Error('Доступ заборонено');
    err.status = 403;
    throw err;
  }
  return studentRepo.getStudentPersonalStats(studentId);
};

const getStudentsAtRisk = async (maxSessions) =>
  studentRepo.getStudentsAtRisk(maxSessions || 2);

const getAttendanceLogs  = async () => logRepo.getAttendanceLogs();
const getTransactionLogs = async () => logRepo.getTransactionLogs();

const getTeacherTimesheet = async (teacherId, { dateFrom, dateTo } = {}) =>
  teacherRepo.getTeacherTimesheet(teacherId, { dateFrom, dateTo });

const getTeacherDisciplineStats = async (teacherId) =>
  teacherRepo.getTeacherDisciplineStats(teacherId);

module.exports = {
  getDashboard, getRevenue, getAttendance,
  getTeacherReport, getDebtors, getExpiringSubscriptions,
  getStudentStats, getStudentsAtRisk,
  getAttendanceLogs, getTransactionLogs,
  getTeacherTimesheet, getTeacherDisciplineStats,
};
