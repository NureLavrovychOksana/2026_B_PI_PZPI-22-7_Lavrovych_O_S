'use strict';
require('dotenv').config();
const pool = require('./src/config/db');

const STUDENTS = [9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26,27,28,29];

const PLANS = [
  { amount: 2200, weight: 38 },  // 12 занять
  { amount: 1600, weight: 28 },  // 8 занять
  { amount: 2800, weight: 22 },  // Безлімітний
  { amount: 900,  weight: 10 },  // 4 заняття
  { amount: 250,  weight:  2 },  // Разове
];

const METHODS = [
  { m: 'cash',   w: 52 },
  { m: 'card',   w: 36 },
  { m: 'liqpay', w: 12 },
];

function weighted(arr) {
  const total = arr.reduce((s, x) => s + (x.weight ?? x.w), 0);
  let r = Math.random() * total;
  for (const x of arr) { r -= (x.weight ?? x.w); if (r <= 0) return x; }
  return arr[0];
}

function addDays(base, n) {
  const [y, m, d] = base.split('-').map(Number);
  const dt = new Date(y, m - 1, d + n);
  return `${dt.getFullYear()}-${String(dt.getMonth()+1).padStart(2,'0')}-${String(dt.getDate()).padStart(2,'0')}`;
}

const WEEK_TARGETS = [
  ['2026-03-09', 17400],
  ['2026-03-16', 23800],
  ['2026-03-23', 19200],
  ['2026-03-30', 21600],
  ['2026-04-06', 16800],
  ['2026-04-13', 26400],
  ['2026-04-20', 20100],
  ['2026-04-27', 22500],
  ['2026-05-04', 15600],
  ['2026-05-11', 24100],
  ['2026-05-18', 20800],
  ['2026-05-25', 27900],
  ['2026-06-01', 18600],
];

(async () => {
  try {
    let total = 0;
    for (const [monday, target] of WEEK_TARGETS) {
      let filled = 0;
      const shuffled = [...STUDENTS].sort(() => Math.random() - 0.5);
      let si = 0;

      while (filled < target - 300) {
        const studentId = shuffled[si % shuffled.length];
        si++;
        const plan   = weighted(PLANS);
        const method = weighted(METHODS).m;
        const dayOff = Math.floor(Math.random() * 6);
        const payDate = addDays(monday, dayOff);

        await pool.query(
          `INSERT INTO payments (user_id, subscription_id, amount, payment_date, payment_method, status)
           VALUES (?, NULL, ?, ?, ?, 'success')`,
          [studentId, plan.amount, payDate, method]
        );
        filled += plan.amount;
        total++;
      }
    }

    console.log(`✅ ${total} payment records inserted`);
    process.exit(0);
  } catch (err) {
    console.error('❌', err.message);
    process.exit(1);
  }
})();
