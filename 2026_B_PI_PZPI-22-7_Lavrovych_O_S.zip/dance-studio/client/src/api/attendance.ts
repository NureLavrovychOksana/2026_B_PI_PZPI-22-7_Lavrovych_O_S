import api from './axios';
import type { AttendanceRecord } from '../types';

export const getAttendanceByLesson = async (lessonId: number) => {
  const { data } = await api.get(`/attendance/lesson/${lessonId}`);
  return data as AttendanceRecord[];
};

export const getAttendanceByStudent = async (studentId: number, params?: { date_from?: string; date_to?: string }) => {
  const { data } = await api.get(`/attendance/student/${studentId}`, { params });
  return data;
};

export const markAttendance = async (payload: {
  lesson_id: number;
  student_id: number;
  status?: 'present' | 'absent' | 'excused';
}) => {
  const { data } = await api.post('/attendance', payload);
  return data;
};

export const markBulk = async (payload: {
  lesson_id: number;
  records: { student_id: number; status: string }[];
}) => {
  const { data } = await api.post('/attendance/bulk', payload);
  return data;
};

export const updateAttendance = async (id: number, status: string) => {
  const { data } = await api.put(`/attendance/${id}`, { status });
  return data;
};