import api from './axios';
import type { DanceGroup } from '../types';

export const getGroups = async (params?: { styleId?: number; teacherId?: number }) => {
  const { data } = await api.get('/groups', { params });
  return data as DanceGroup[];
};

export const getGroupById = async (id: number) => {
  const { data } = await api.get(`/groups/${id}`);
  return data as DanceGroup;
};
export const createGroup = async (payload: {
  name: string; style_id: number; level: string;
  teacher_id: number; hall_id: number; status: string;
}) => {
  const { data } = await api.post('/groups', payload);
  return data;
};

export const updateGroup = async (id: number, payload: any) => {
  const { data } = await api.put(`/groups/${id}`, payload);
  return data;
};

export const deleteGroup = async (id: number) => {
  const { data } = await api.delete(`/groups/${id}`);
  return data;
};


