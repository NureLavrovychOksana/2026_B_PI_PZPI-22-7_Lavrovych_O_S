import api from './axios';
import type { SubscriptionPlan, StudentSubscription } from '../types';

export const getPlans = async () => {
  const { data } = await api.get('/subscriptions/plans');
  return data as SubscriptionPlan[];
};

export const getStudentSubscriptions = async (studentId: number) => {
  const { data } = await api.get(`/subscriptions/student/${studentId}`);
  return data as StudentSubscription[];
};

export const getActiveSubscriptions = async (studentId: number) => {
  const { data } = await api.get(`/subscriptions/student/${studentId}/active`);
  return data as StudentSubscription[];
};

export const assignSubscription = async (payload: {
  student_id: number;
  plan_id: number;
  activation_date?: string;
  purchase_date?: string;
}) => {
  const { data } = await api.post('/subscriptions', payload);
  return data;
};

export const cancelSubscription = async (id: number) => {
  const { data } = await api.put(`/subscriptions/${id}/cancel`);
  return data;
};

export const getAllSubscriptions = async () => {
  const { data } = await api.get('/subscriptions/all');
  return data as StudentSubscription[];
};
export const createPlan = async (payload: {
  name: string;
  type: string;
  sessions_count?: number;
  validity_days?: number;
  price: number;
}) => {
  const { data } = await api.post('/subscriptions/plans', payload);
  return data;
};

export const updatePlan = async (id: number, payload: any) => {
  const { data } = await api.put(`/subscriptions/plans/${id}`, payload);
  return data;
};

export const removePlan = async (id: number) => {
  const { data } = await api.delete(`/subscriptions/plans/${id}`);
  return data;
};

