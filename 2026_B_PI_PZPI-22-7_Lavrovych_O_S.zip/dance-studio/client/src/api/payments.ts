import api from './axios';
import type { Payment } from '../types';

export const getPayments = async (params?: {
  date_from?: string;
  date_to?: string;
  method?: string;
  status?: string;
}) => {
  const { data } = await api.get('/payments', { params });
  return data as Payment[];
};

export const getPaymentsByUser = async (userId: number) => {
  const { data } = await api.get(`/payments/user/${userId}`);
  return data as Payment[];
};

export const createManualPayment = async (payload: {
  user_id: number;
  subscription_id?: number;
  amount: number;
  method: 'cash' | 'card';
}) => {
  const { data } = await api.post('/payments/manual', payload);
  return data;
};

export const createCheckout = async (planId: number) => {
  const { data } = await api.post('/payments/checkout', { plan_id: planId });
  return data;
};

export const createCashCheckout = async (planId: number) => {
  const { data } = await api.post('/payments/checkout/cash', { plan_id: planId });
  return data as { subscription: import('../types').StudentSubscription; plan: { id: number; name: string; price: number } };
};

export const confirmCheckout = async (orderId: string) => {
  const { data } = await api.post('/payments/confirm', { order_id: orderId });
  return data as { success: boolean; subscription: import('../types').StudentSubscription | null };
};

export const confirmCashPayment = async (id: number) => {
  const { data } = await api.put(`/payments/${id}/confirm-cash`);
  return data as { success: boolean };
};