import api from './axios';
import type { DashboardData, RevenuePoint, AttendanceGroupReport, TeacherReport, Debtor, ExpiringSubscription, StudentAtRisk, TeacherTimesheetLesson, TeacherDisciplineStats } from '../types';

export const getDashboard = async (): Promise<DashboardData> => {
  const { data } = await api.get('/reports/dashboard');
  return data;
};

export const getRevenue = async (params?: { months?: number; group_by?: 'month' | 'week' }) => {
  const { data } = await api.get('/reports/revenue', { params });
  return data as RevenuePoint[];
};

export const getAttendanceReport = async (params?: { date_from?: string; date_to?: string }) => {
  const { data } = await api.get('/reports/attendance', { params });
  return data as AttendanceGroupReport[];
};

export const getTeacherReport = async (teacherId: number) => {
  const { data } = await api.get(`/reports/teachers/${teacherId}`);
  return data as TeacherReport;
};

export const getDebtors = async () => {
  const { data } = await api.get('/reports/debtors');
  return data as Debtor[];
};

export const getExpiringSubscriptions = async (days?: number) => {
  const { data } = await api.get('/reports/expiring-subscriptions', { params: { days } });
  return data as ExpiringSubscription[];
};

export const getStudentStats = async (studentId: number) => {
  const { data } = await api.get(`/reports/students/${studentId}`);
  return data;
};

export const getStudentsAtRisk = async (maxSessions = 2) => {
  const { data } = await api.get('/reports/students-at-risk', { params: { max_sessions: maxSessions } });
  return data as StudentAtRisk[];
};

export const getAttendanceLogs = async () => {
  const { data } = await api.get('/reports/attendance-logs');
  return data as Record<string, any>[];
};

export const getTransactionLogs = async () => {
  const { data } = await api.get('/reports/transaction-logs');
  return data as Record<string, any>[];
};

export const getTeacherTimesheet = async (
  teacherId: number,
  params?: { date_from?: string; date_to?: string }
) => {
  const { data } = await api.get(`/reports/teachers/${teacherId}/timesheet`, { params });
  return data as TeacherTimesheetLesson[];
};

export const getTeacherDisciplineStats = async (teacherId: number) => {
  const { data } = await api.get(`/reports/teachers/${teacherId}/discipline`);
  return data as TeacherDisciplineStats;
};

