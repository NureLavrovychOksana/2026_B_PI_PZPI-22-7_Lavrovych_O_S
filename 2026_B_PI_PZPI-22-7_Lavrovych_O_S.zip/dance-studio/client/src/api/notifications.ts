import api from './axios';
import type { Notification } from '../types';

export const getMyNotifications = async () => {
  const { data } = await api.get('/notifications');
  return data as Notification[];
};

export const getUnreadCount = async () => {
  const { data } = await api.get('/notifications/unread-count');
  return data.count as number;
};

export const markRead = async (id: number) => {
  const { data } = await api.put(`/notifications/${id}/read`);
  return data;
};

export const markAllRead = async () => {
  const { data } = await api.put('/notifications/read-all');
  return data;
};

export const broadcast = async (payload: {
  title: string;
  body?: string;
  type?: string;
  group_id?: number;
}) => {
  const { data } = await api.post('/notifications/broadcast', payload);
  return data;
};