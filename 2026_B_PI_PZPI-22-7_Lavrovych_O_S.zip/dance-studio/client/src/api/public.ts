import api from './axios';

export interface PublicStats {
  students_count: number;
  styles_count:   number;
  halls_count:    number;
  weekly_lessons: number;
  years_active:   number;
  studio_name:    string;
  studio_address: string;
  studio_phone:   string;
  studio_email:   string;
}

export const getPublicStats = async (): Promise<PublicStats> => {
  const { data } = await api.get('/settings/public');
  return data;
};
