import api from './axios';

export const getSettings = async (): Promise<Record<string, string>> => {
  const { data } = await api.get('/settings');
  return data;
};

export const updateSettings = async (payload: Record<string, string>) => {
  const { data } = await api.put('/settings', payload);
  return data;
};