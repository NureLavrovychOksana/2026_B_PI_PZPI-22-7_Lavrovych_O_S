import api from './axios';

export const getTeachers = async () => {
  const { data } = await api.get('/teachers');
  return data;
};

export const getTeacherById = async (id: number) => {
  const { data } = await api.get(`/teachers/${id}`);
  return data;
};

export const getMyTeacherProfile = async () => {
  const { data } = await api.get('/teachers/me');
  return data;
};

export const createTeacher = async (payload: {
  email:             string;
  password?:         string;
  first_name:        string;
  last_name:         string;
  phone?:            string;
  bio?:              string;
  experience_years?: number;
  education?:        string;
  style_ids?:        number[];
}) => {
  const { data } = await api.post('/teachers', payload);
  return data;
};

export interface MyTeacherFinance {
  rate_type:        RateType;
  rate_amount:      number;
  total_paid:       number;
  total_hours:      number;
  total_lessons:    number;
  total_attendance: number;
  total_earnings:   number;
  balance:          number;
}

export const getMyTeacherFinance = async (params?: { date_from?: string; date_to?: string }) => {
  const { data } = await api.get('/teachers/me/finance', { params });
  return data as MyTeacherFinance;
};

export type RateType = 'per_lesson' | 'per_student' | 'percent';

export interface TeacherFinance {
  rate_type: RateType;
  rate_amount: number;
  total_paid: number;
  total_hours: number;
  total_lessons: number;
  conducted_lessons: number;
  conducted_hours: number;
  total_attendance: number;
  total_earnings: number;
  balance: number;
}

export interface TeacherPayrollRow {
  teacher_profile_id: number;
  first_name: string;
  last_name: string;
  email: string;
  rate_type: RateType;
  rate_amount: number;
  total_lessons: number;
  conducted_lessons: number;
  total_hours: number;
  conducted_hours: number;
  total_enrollments: number;
  total_earnings: number;
}

export const getTeacherFinance = async (id: number, params?: { date_from?: string; date_to?: string }) => {
  const { data } = await api.get(`/teachers/${id}/finance`, { params });
  return data as TeacherFinance;
};

export const setTeacherRate = async (id: number, rate_type: RateType, rate_amount: number) => {
  const { data } = await api.put(`/teachers/${id}/rate`, { rate_type, rate_amount });
  return data;
};

export const getTeacherPayrollSummary = async (month?: number, year?: number) => {
  const { data } = await api.get('/teachers/payroll-summary', { params: { month, year } });
  return data as TeacherPayrollRow[];
};

export const getTeacherPayouts = async (id: number) => {
  const { data } = await api.get(`/teachers/${id}/payouts`);
  return data as { id: number; amount: number; note: string | null; created_at: string; admin_first_name: string; admin_last_name: string }[];
};

export const addTeacherPayout = async (id: number, amount: number, note?: string) => {
  const { data } = await api.post(`/teachers/${id}/payouts`, { amount, note });
  return data;
};

export const updateTeacherProfile = async (id: number, payload: {
  first_name?:       string;
  last_name?:        string;
  email?:            string;
  phone?:            string;
  bio?:              string;
  experience_years?: number;
  education?:        string;
  style_ids?:        number[];
}) => {
  const { data } = await api.put(`/teachers/${id}`, payload);
  return data;
};