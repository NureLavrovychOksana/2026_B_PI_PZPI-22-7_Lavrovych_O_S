import api from './axios';
import type { Hall } from '../types';

export const getHalls = async ({ includeArchived = false } = {}) => {
  const { data } = await api.get('/halls', {
    params: includeArchived ? { include_archived: '1' } : undefined,
  });
  return data as Hall[];
};

export const createHall = async (payload: { name: string; capacity: number }) => {
  const { data } = await api.post('/halls', payload);
  return data as Hall;
};

export const updateHall = async (id: number, payload: { name: string; capacity: number }) => {
  const { data } = await api.put(`/halls/${id}`, payload);
  return data as Hall;
};

export const deleteHall = async (id: number, targetHallId?: number) => {
  const { data } = await api.delete(`/halls/${id}`, {
    data: targetHallId ? { targetHallId } : undefined,
  });
  return data as { action: string; relocated: number };
};

export const restoreHall = async (id: number) => {
  const { data } = await api.post(`/halls/${id}/restore`);
  return data as Hall;
};
