import api from './axios';
import type { DanceStyle } from '../types';

export const getStyles = async () => {
  const { data } = await api.get('/styles');
  return data as DanceStyle[];
};

export const createStyle = async (payload: { name: string; description?: string }) => {
  const { data } = await api.post('/styles', payload);
  return data as DanceStyle;
};

export const updateStyle = async (id: number, payload: { name: string; description?: string }) => {
  const { data } = await api.put(`/styles/${id}`, payload);
  return data as DanceStyle;
};

export const deleteStyle = async (id: number) => {
  await api.delete(`/styles/${id}`);
};