import api from './axios';
import type { Enrollment } from '../types';

export const getEnrollmentsByLesson = async (lessonId: number) => {
  const { data } = await api.get(`/enrollments/lesson/${lessonId}`);
  return data;
};

export const getEnrollmentsByStudent = async (studentId: number) => {
  const { data } = await api.get(`/enrollments/student/${studentId}`);
  return data as Enrollment[];
};

export const enroll = async (studentId: number, lessonId: number) => {
  const { data } = await api.post('/enrollments', { student_id: studentId, lesson_id: lessonId });
  return data;
};

export const selfEnroll = async (lessonId: number) => {
  const { data } = await api.post('/enrollments/self', { lesson_id: lessonId });
  return data;
};

export const unenroll = async (enrollmentId: number) => {
  const { data } = await api.delete(`/enrollments/${enrollmentId}`);
  return data;
};

export const joinWaitlist = async (lessonId: number) => {
  const { data } = await api.post('/enrollments/waitlist', { lesson_id: lessonId });
  return data as { id: number; student_id: number; lesson_id: number };
};

export const leaveWaitlist = async (waitlistId: number) => {
  const { data } = await api.delete(`/enrollments/waitlist/${waitlistId}`);
  return data;
};

export const teacherManualEnroll = async (lessonId: number, studentId: number) => {
  const { data } = await api.post('/enrollments/by-teacher', { lesson_id: lessonId, student_id: studentId });
  return data;
};

export const bulkEnroll = async (payload: {
  student_id: number;
  group_id: number;
  date_from: string;
  date_to: string;
}) => {
  const { data } = await api.post('/enrollments/bulk', payload);
  return data as { enrolled: number; skipped: number; lesson_ids: number[] };
};

export const getMyWaitlist = async () => {
  const { data } = await api.get('/enrollments/waitlist/my');
  return data as {
    id: number;
    lesson_id: number;
    position: number;
    lesson_date: string;
    start_time: string;
    end_time: string;
    group_name: string;
    style_name: string;
    hall_name: string;
  }[];
};
