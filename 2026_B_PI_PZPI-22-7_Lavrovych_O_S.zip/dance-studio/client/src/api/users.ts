import api from './axios';
import type { User } from '../types';

export const getUsers = async (params?: { role?: string }) => {
  const { data } = await api.get('/users', { params });
  return data as User[];
};

export const getUserById = async (id: number) => {
  const { data } = await api.get(`/users/${id}`);
  return data as User;
};

export const createUser = async (payload: {
  email: string;
  password: string;
  role: string;
  first_name: string;
  last_name: string;
  phone?: string;
}) => {
  const { data } = await api.post('/users', payload);
  return data;
};

export const updateUser = async (id: number, payload: Partial<User>) => {
  const { data } = await api.put(`/users/${id}`, payload);
  return data;
};

export const deleteUser = async (id: number) => {
  const { data } = await api.delete(`/users/${id}`);
  return data;
};

export const deleteOwnAccount = async () => {
  const { data } = await api.delete('/users/profile');
  return data;
};

export const getOwnProfile = async () => {
  const { data } = await api.get('/users/profile');
  return data;
};

export const updateOwnProfile = async (payload: {
  first_name?: string;
  last_name?: string;
  phone?: string;
  password?: string;
}) => {
  const { data } = await api.put('/users/profile', payload);
  return data;
};

export const getMyQrToken = async (): Promise<{ token: string }> => {
  const { data } = await api.get('/users/profile/qr-token');
  return data;
};

export const updateNotifPrefs = async (prefs: {
  email?: boolean; sms?: boolean; news?: boolean; schedule?: boolean;
}) => {
  const { data } = await api.put('/users/profile/notification-prefs', prefs);
  return data as { notification_prefs: typeof prefs };
};

export const searchStudents = async (q: string) => {
  const { data } = await api.get('/users/students', { params: { q } });
  return data as { id: number; first_name: string; last_name: string; email: string; phone?: string }[];
};