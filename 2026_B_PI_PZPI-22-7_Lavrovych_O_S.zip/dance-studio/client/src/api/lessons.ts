import api from './axios';
import type { Lesson } from '../types';

export const getLessons = async (params?: {
  week?: string;
  groupId?: number;
  teacherId?: number;
}) => {
  const { data } = await api.get('/lessons', { params });
  return data as Lesson[];
};

export const getLessonById = async (id: number) => {
  const { data } = await api.get(`/lessons/${id}`);
  return data as Lesson;
};

export const createLesson = async (payload: {
  group_id: number;
  hall_id: number;
  lesson_date: string;
  start_time: string;
  end_time: string;
}) => {
  const { data } = await api.post('/lessons', payload);
  return data as Lesson;
};

export const updateLesson = async (id: number, payload: Partial<{
  group_id: number;
  hall_id: number;
  lesson_date: string;
  start_time: string;
  end_time: string;
}>) => {
  const { data } = await api.put(`/lessons/${id}`, payload);
  return data as Lesson;
};

export const deleteLesson = async (id: number) => {
  const { data } = await api.delete(`/lessons/${id}`);
  return data;
};

export const updateLessonNotes = async (id: number, notes: string) => {
  const { data } = await api.put(`/lessons/${id}/notes`, { notes });
  return data as Lesson;
};

export const uploadUserAvatar = async (file: File) => {
  const form = new FormData();
  form.append('avatar', file);
  const { data } = await api.post('/users/profile/avatar', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data as { avatar_url: string };
};

export const getLessonNotesByGroup = async (groupId: number) => {
  const { data } = await api.get(`/lessons/group/${groupId}/notes`);
  return data as {
    id: number;
    lesson_date: string;
    start_time: string;
    end_time: string;
    notes: string;
    notes_author_id: number | null;
    style_name: string;
    author_first_name: string | null;
    author_last_name: string | null;
  }[];
};