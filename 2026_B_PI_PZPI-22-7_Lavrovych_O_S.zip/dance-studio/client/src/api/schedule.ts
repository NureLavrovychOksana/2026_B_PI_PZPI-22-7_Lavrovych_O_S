import api from './axios';
import type { DraftLesson, GroupRequirement, WizardConfig, WeekStatus } from '../types/schedule';

export const getGroupRequirements = async (): Promise<GroupRequirement[]> => {
  const { data } = await api.get('/schedule/group-requirements');
  return data;
};

export const updateGroupRequirement = async (groupId: number, payload: Partial<GroupRequirement>) => {
  await api.put(`/schedule/group-requirements/${groupId}`, payload);
};

export const getTeacherAvailability = async (teacherId: number) => {
  const { data } = await api.get(`/schedule/teacher-availability/${teacherId}`);
  return data as { id: number; day_of_week: number; start_time: string; end_time: string }[];
};

export const generateDraft = async (config: WizardConfig): Promise<{
  lessons: DraftLesson[];
  stats: { total: number; placed: number; unplaced: number; warnings: number };
}> => {
  const { data } = await api.post('/schedule/generate-draft', {
    week_start:         config.week_start,
    group_requirements: config.group_requirements,
    hall_ids:           config.hall_ids,
    allowed_days:       config.allowed_days,
    time_from:          config.time_from,
    time_to:            config.time_to,
    slot_step:          config.slot_step,
  });
  return data;
};

export const getWeekStatus = async (weekStart: string): Promise<WeekStatus> => {
  const { data } = await api.get('/schedule/week-status', { params: { week_start: weekStart } });
  return data;
};

export const publishSchedule = async (
  lessons: DraftLesson[],
  mode: 'append' | 'overwrite' = 'append',
  weekStart?: string,
): Promise<{ published: number }> => {
  const { data } = await api.post('/schedule/publish', { lessons, mode, week_start: weekStart });
  return data;
};
