export interface DanceStyleData {
  name: string;
  desc: string;
  levels: string[];
}

export interface TeacherData {
  name: string;
  initials: string;
  exp: string;
  styles: string[];
  bio: string;
  students: number;
  lessons: number;
  rating: string;
}

export interface ReviewData {
  stars: number;
  text: string;
  author: string;
  style: string;
}

export interface LineupLevel {
  label: string;
  dotClass: string;
  desc: string;
  imgSrc: string;
  imgAlt: string;
}

export interface PhotoGridItem {
  src: string;
  label: string;
  tall: boolean;
}

export const STYLES: DanceStyleData[] = [
  { name: 'Хіп-хоп',   desc: 'Вулична культура та техніка фрістайлу',             levels: ['Початковий', 'Середній'] },
  { name: 'Бачата',     desc: 'Чуттєвий латиноамериканський парний танець',         levels: ['All levels'] },
  { name: 'Контемп',    desc: 'Сучасна хореографія та пластика тіла',               levels: ['Середній', 'Продвинутий'] },
  { name: 'Брейк',      desc: 'Акробатика, фліксі та б-бой культура',               levels: ['Початковий'] },
  { name: 'K-Pop',      desc: 'Корейська поп-хореографія та cover dance',           levels: ['Всі рівні'] },
  { name: 'Джаз-фанк',  desc: 'Енергійне поєднання джазу і стріт-стайлу',          levels: ['Початковий', 'Середній'] },
  { name: 'Афро',       desc: 'Африканські ритми та рухи тіла',                     levels: ['Початковий'] },
  { name: 'Vogue',      desc: 'Ballroom culture та runway техніка',                 levels: ['Середній'] },
];

export const TEACHERS: TeacherData[] = [
  {
    name: 'Анна Коваль', initials: 'АК', exp: '7 років',
    styles: ['Хіп-хоп', 'K-Pop'],
    bio: 'Переможниця українських чемпіонатів зі стріт-данс. Авторська методика для початківців.',
    students: 84, lessons: 1240, rating: '4.9',
  },
  {
    name: 'Михайло Руденко', initials: 'МР', exp: '9 років',
    styles: ['Бачата', 'Сальса'],
    bio: 'Сертифікований інструктор латини. Провів майстер-класи у Варшаві та Відні.',
    students: 96, lessons: 1890, rating: '5.0',
  },
  {
    name: 'Оксана Лисенко', initials: 'ОЛ', exp: '5 років',
    styles: ['Контемп', 'Джаз-фанк'],
    bio: 'Хореограф театру сучасного танцю. Навчалась у Гнесинській академії.',
    students: 61, lessons: 730, rating: '4.8',
  },
];

export const REVIEWS: ReviewData[] = [
  {
    stars: 5,
    text: 'Move Studio — найкраще місце для тих, хто хоче танцювати без страху. Анна — чудовий педагог!',
    author: 'Марія С.', style: 'Хіп-хоп',
  },
  {
    stars: 5,
    text: 'Ходжу на бачату 6 місяців — не можу зупинитись. Михайло зробив з мене танцюриста з нуля!',
    author: 'Ігор В.', style: 'Бачата',
  },
  {
    stars: 5,
    text: 'Контемп з Оксаною — це мистецтво. Кожне заняття відкриває щось нове в собі.',
    author: 'Тетяна К.', style: 'Контемп',
  },
];

export const LINEUP: LineupLevel[] = [
  {
    label: 'FIRST STEP', dotClass: 'dot-1',
    desc: 'Перші кроки в танці. Базова координація та прості рухи для тих, хто ніколи не танцював.',
    imgSrc: 'https://images.unsplash.com/photo-1541904845547-0eaf866de232?w=800&q=80&auto=format&fit=crop',
    imgAlt: 'First Step',
  },
  {
    label: 'STARTER', dotClass: 'dot-2',
    desc: 'Перша хореографія, чіткий рахунок і робота в групі.',
    imgSrc: 'https://images.unsplash.com/photo-1690267717892-b88473bc771c?q=80&w=800&auto=format&fit=crop',
    imgAlt: 'Starter',
  },
  {
    label: 'LEARNER', dotClass: 'dot-3',
    desc: 'Кілька стилів, власний почерк і перші виступи перед студією.',
    imgSrc: 'https://images.unsplash.com/photo-1502519144081-acca18599776?q=80&w=800&auto=format&fit=crop',
    imgAlt: 'Learner',
  },
  {
    label: 'MASTER', dotClass: 'dot-4',
    desc: 'Складна хореографія, конкурсна практика і робота на сцені.',
    imgSrc: 'https://images.unsplash.com/photo-1547153760-18fc86324498?q=80&w=800&auto=format&fit=crop',
    imgAlt: 'Master',
  },
  {
    label: 'PRO CLASS', dotClass: 'dot-5',
    desc: 'Індивідуальна траєкторія з провідними хореографами студії.',
    imgSrc: 'https://images.unsplash.com/photo-1524330685423-3e1966445abe?q=80&w=800&auto=format&fit=crop',
    imgAlt: 'Pro Class',
  },
];

export const PHOTO_GRID: PhotoGridItem[] = [
  { src: 'https://images.unsplash.com/photo-1590050630581-f1c3753d7e33?w=800&q=80&auto=format&fit=crop', label: 'Хіп-хоп', tall: true },
  { src: 'https://images.unsplash.com/photo-1504609813442-a8924e83f76e?w=800&q=80&auto=format&fit=crop', label: 'Бачата',   tall: false },
  { src: 'https://images.unsplash.com/photo-1511715282680-fbf93a50e721?w=800&q=80&auto=format&fit=crop', label: 'Контемп',  tall: false },
  { src: 'https://images.unsplash.com/photo-1508700929628-666bc8bd84ea?w=800&q=80&auto=format&fit=crop', label: 'Брейк',    tall: false },
  { src: 'https://images.unsplash.com/photo-1621976360623-004223992275?w=800&q=80&auto=format&fit=crop', label: 'K-Pop',    tall: false },
];

export const DOT_COLORS: Record<string, string> = {
  'dot-1': '#444441',
  'dot-2': '#8aad1e',
  'dot-3': '#c8fa3a',
  'dot-4': '#c8fa3a',
  'dot-5': '#444441',
};

export const PHOTO_HEIGHTS: Record<string, number> = {
  'dot-1': 130,
  'dot-2': 190,
  'dot-3': 255,
  'dot-4': 315,
  'dot-5': 375,
};
