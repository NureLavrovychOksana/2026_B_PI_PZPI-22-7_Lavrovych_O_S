export const localDateStr = (d: Date = new Date()): string => {
  const y  = d.getFullYear();
  const m  = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${dd}`;
};

export const localToday = (): string => localDateStr(new Date());

export const getMondayOfWeek = (d: Date = new Date()): string => {
  const day = d.getDay();
  const mon = new Date(d);
  mon.setDate(d.getDate() - (day === 0 ? 6 : day - 1));
  return localDateStr(mon);
};
