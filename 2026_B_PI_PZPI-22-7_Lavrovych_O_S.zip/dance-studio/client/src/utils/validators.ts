/** Returns null on valid, error string on failure. */

export const validateRequired = (v: string, label = 'Поле'): string | null =>
  v.trim() === '' ? `${label} обовʼязкове` : null;

export const validateName = (v: string): string | null => {
  const t = v.trim();
  if (!t)        return "Обовʼязкове поле";
  if (t.length < 2)  return 'Мінімум 2 символи';
  if (t.length > 50) return 'Максимум 50 символів';
  return null;
};

export const validateEmail = (v: string): string | null => {
  if (!v.trim()) return 'Введіть email';
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) ? null : 'Невірний формат email';
};

export const validatePhone = (v: string): string | null => {
  if (!v.trim()) return null;
  return /^\+380\d{9}$/.test(v.trim()) ? null : 'Формат: +380XXXXXXXXX (13 символів)';
};

export const validatePassword = (v: string): string | null => {
  if (!v) return 'Введіть пароль';
  if (!/^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/.test(v))
    return 'Мін. 8 символів, велика літера, цифра, спецсимвол (@$!%*?&)';
  return null;
};

export const validatePositiveNumber = (v: string, max?: number): string | null => {
  if (!v) return null;
  const n = Number(v);
  if (isNaN(n) || n < 0) return 'Має бути позитивне число';
  if (max != null && n > max) return `Не може перевищувати ${max}`;
  return null;
};

export const validateDateRange = (from: string, to: string): string | null => {
  if (!from || !to) return null;
  return to >= from ? null : 'Дата завершення має бути не раніше дати початку';
};

export const validateTimeRange = (start: string, end: string, minMinutes?: number): string | null => {
  if (!start || !end) return null;
  if (end <= start) return 'Кінець має бути після початку';
  if (minMinutes != null) {
    const [sh, sm] = start.split(':').map(Number);
    const [eh, em] = end.split(':').map(Number);
    const diff = (eh * 60 + em) - (sh * 60 + sm);
    if (diff < minMinutes) return `Мінімальна тривалість — ${minMinutes} хвилин`;
  }
  return null;
};

export const validateBusinessHours = (time: string): string | null => {
  if (!time) return null;
  return time >= '08:00' && time <= '22:00' ? null : 'Час має бути в межах 08:00–22:00';
};
