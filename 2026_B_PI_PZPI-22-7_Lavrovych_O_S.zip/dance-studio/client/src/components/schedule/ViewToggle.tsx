import { IconGrid, IconList } from '../ui/Icon';
import s from './ViewToggle.module.css';

const DAYS_SHORT = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];

export type ViewMode = 'grid' | 'agenda';

interface ViewToggleProps {
  mode:     ViewMode;
  onChange: (mode: ViewMode) => void;
}

export const ViewToggleBtn = ({ mode, onChange }: ViewToggleProps) => (
  <div className={s.toggle}>
    <button
      className={`${s.btn} ${mode === 'grid' ? s.active : ''}`}
      onClick={() => onChange('grid')}
      title="Сітка"
    >
      <IconGrid size={14} strokeWidth={1.8} />
      <span className={s.label}>Сітка</span>
    </button>
    <button
      className={`${s.btn} ${mode === 'agenda' ? s.active : ''}`}
      onClick={() => onChange('agenda')}
      title="Список"
    >
      <IconList size={14} strokeWidth={1.8} />
      <span className={s.label}>Список</span>
    </button>
  </div>
);

interface DayPickerProps {
  weekDates: string[];
  today:     string;
  activeDay: number | null;
  onChange:  (day: number | null) => void;
}

export const DayPicker = ({ weekDates, today, activeDay, onChange }: DayPickerProps) => (
  <div className={s.dayPicker}>
    <button
      className={`${s.dayPill} ${activeDay === null ? s.dayPillActive : ''}`}
      onClick={() => onChange(null)}
    >
      Всі
    </button>
    {weekDates.map((date, i) => (
      <button
        key={date}
        className={`${s.dayPill} ${activeDay === i ? s.dayPillActive : ''} ${date === today ? s.dayPillToday : ''}`}
        onClick={() => onChange(i)}
      >
        {DAYS_SHORT[i]} <span className={s.dayNum}>{Number(date.slice(8))}</span>
      </button>
    ))}
  </div>
);
