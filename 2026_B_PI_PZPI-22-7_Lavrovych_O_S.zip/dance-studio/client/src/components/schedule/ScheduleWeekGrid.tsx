import { useMemo, Fragment } from 'react';
import type { Lesson } from '../../types';
import s from './ScheduleWeekGrid.module.css';

export { getMondayOfWeek } from '../../utils/dateUtils';

const DAYS_SHORT = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];

export const getDayIndex = (dateStr: string) => {
  const [y, m, d] = dateStr.slice(0, 10).split('-').map(Number);
  const day = new Date(y, m - 1, d).getDay();
  return day === 0 ? 6 : day - 1;
};

export const getWeekDates = (monday: string) =>
  Array.from({ length: 7 }, (_, i) => {
    const [y, m, d] = monday.split('-').map(Number);
    const date = new Date(y, m - 1, d + i);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  });

export const formatWeekLabel = (monday: string) => {
  const [y, m, d] = monday.split('-').map(Number);
  const start = new Date(y, m - 1, d);
  const end   = new Date(y, m - 1, d + 6);
  const f = (dt: Date) =>
    `${String(dt.getDate()).padStart(2, '0')}.${String(dt.getMonth() + 1).padStart(2, '0')}`;
  return `${f(start)} — ${f(end)}`;
};

interface Props {
  lessons:       Lesson[];
  weekDates:     string[];
  today:         string;
  renderCard:    (lesson: Lesson) => React.ReactNode;
  onEmptyClick?: (date: string) => void;
  loading?:      boolean;
  emptyMessage?: string;
}

const ScheduleWeekGrid = ({
  lessons, weekDates, today,
  renderCard, onEmptyClick,
  loading, emptyMessage = 'Занять на цьому тижні не знайдено',
}: Props) => {
  const lessonMap = useMemo(() => {
    const map: Record<number, Record<string, Lesson[]>> = {};
    lessons.forEach(l => {
      const day  = getDayIndex(l.lesson_date);
      const time = l.start_time.slice(0, 5);
      if (!map[day]) map[day] = {};
      if (!map[day][time]) map[day][time] = [];
      map[day][time].push(l);
    });
    return map;
  }, [lessons]);

  const timeSlots = useMemo(
    () => [...new Set(lessons.map(l => l.start_time.slice(0, 5)))].sort(),
    [lessons],
  );

  if (loading) return <div className={s.msg}>Завантаження...</div>;

  return (
    <div className={s.gridWrap}>
      <div className={s.grid}>

        {/* Header */}
        <div className={s.headerCell} />
        {weekDates.map((date, i) => (
          <div key={date} className={`${s.headerCell} ${date === today ? s.headerCellToday : ''}`}>
            {DAYS_SHORT[i]}<br />
            <span className={s.dateNum}>{Number(date.slice(8))}</span>
          </div>
        ))}

        {/* Rows */}
        {timeSlots.length === 0 ? (
          <>
            <div className={s.timeCell} />
            {Array.from({ length: 7 }, (_, dayIdx) => (
              <div
                key={dayIdx}
                className={s.emptyCell}
                onClick={onEmptyClick ? () => onEmptyClick(weekDates[dayIdx]) : undefined}
                style={onEmptyClick ? { cursor: 'pointer' } : undefined}
              />
            ))}
            <div className={s.emptyMsg} style={{ gridColumn: '1 / -1' }}>
              {emptyMessage}
            </div>
          </>
        ) : (
          timeSlots.map(time => (
            <Fragment key={time}>
              <div className={s.timeCell}>{time}</div>
              {Array.from({ length: 7 }, (_, dayIdx) => {
                const dayLessons = lessonMap[dayIdx]?.[time] ?? [];
                if (!dayLessons.length) {
                  return (
                    <div
                      key={dayIdx}
                      className={s.emptyCell}
                      onClick={onEmptyClick ? () => onEmptyClick(weekDates[dayIdx]) : undefined}
                      style={onEmptyClick ? { cursor: 'pointer' } : undefined}
                    />
                  );
                }
                return (
                  <div key={dayIdx} className={s.parallelCell}>
                    {dayLessons.map(lesson => (
                      <div key={lesson.id} className={s.lessonSlot}>
                        {renderCard(lesson)}
                      </div>
                    ))}
                  </div>
                );
              })}
            </Fragment>
          ))
        )}
      </div>
    </div>
  );
};

export default ScheduleWeekGrid;
