import { useMemo } from 'react';
import type { Lesson } from '../../types';
import { getDayIndex } from './ScheduleWeekGrid';
import s from './AgendaView.module.css';

const DAYS_FULL = ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пятниця', 'Субота', 'Неділя'];

const fmtDate = (iso: string) => {
  const [, m, d] = iso.split('-');
  return `${d}.${m}`;
};

interface Props {
  lessons:    Lesson[];
  weekDates:  string[];
  today:      string;
  activeDay:  number | null;
  renderCard: (lesson: Lesson, mode: 'agenda') => React.ReactNode;
}

const AgendaView = ({ lessons, weekDates, today, activeDay, renderCard }: Props) => {
  const byDay = useMemo(() => {
    const map: Record<number, Lesson[]> = {};
    lessons.forEach(l => {
      const idx = getDayIndex(l.lesson_date);
      if (!map[idx]) map[idx] = [];
      map[idx].push(l);
    });
    Object.values(map).forEach(arr =>
      arr.sort((a, b) => a.start_time.localeCompare(b.start_time))
    );
    return map;
  }, [lessons]);

  const days = activeDay !== null ? [activeDay] : Array.from({ length: 7 }, (_, i) => i);
  const hasAny = days.some(i => (byDay[i]?.length ?? 0) > 0);

  if (!hasAny) {
    return <div className={s.empty}>Занять не знайдено</div>;
  }

  return (
    <div className={s.wrap}>
      {days.map(dayIdx => {
        const date    = weekDates[dayIdx];
        const dayLessons = byDay[dayIdx] ?? [];
        const isToday = date === today;

        return (
          <div key={dayIdx} className={s.dayGroup}>
            <div className={`${s.dayHeader} ${isToday ? s.dayHeaderToday : ''}`}>
              <span className={s.dayName}>{DAYS_FULL[dayIdx]}</span>
              <span className={s.dayDate}>{fmtDate(date)}</span>
              {isToday && <span className={s.todayTag}>Сьогодні</span>}
            </div>

            {dayLessons.length === 0 ? (
              <div className={s.noLessons}>Занять немає</div>
            ) : (
              <div className={s.lessonList}>
                {dayLessons.map(lesson => (
                  <div key={lesson.id} className={s.lessonRow}>
                    {renderCard(lesson, 'agenda')}
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default AgendaView;
