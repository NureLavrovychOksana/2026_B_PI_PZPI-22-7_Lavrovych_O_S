import styles from './Skeleton.module.css';

interface SkeletonProps {
  width?:  string;
  height?: string;
  className?: string;
}

export const SkeletonLine = ({ width = '100%', height = '12px', className = '' }: SkeletonProps) => (
  <div
    className={`${styles.skeleton} ${className}`}
    style={{ width, height }}
  />
);

export const SkeletonCard = ({ children }: { children: React.ReactNode }) => (
  <div className={styles.card}>{children}</div>
);