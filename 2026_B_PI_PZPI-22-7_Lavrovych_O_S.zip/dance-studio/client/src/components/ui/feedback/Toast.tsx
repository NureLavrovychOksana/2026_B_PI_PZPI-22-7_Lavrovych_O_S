import { useEffect, useState } from 'react';
import styles from './Toast.module.css';

export type ToastType = 'success' | 'error' | 'info' | 'warn';

export interface ToastItem {
  id: string;
  message: string;
  type: ToastType;
}

interface ToastProps {
  items: ToastItem[];
  onRemove: (id: string) => void;
}

const ICONS: Record<ToastType, string> = {
  success: '✓',
  error:   '✕',
  info:    'i',
  warn:    '!',
};

const ToastMessage = ({ item, onRemove }: { item: ToastItem; onRemove: (id: string) => void }) => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setShow(true), 10);
    const t2 = setTimeout(() => {
      setShow(false);
      setTimeout(() => onRemove(item.id), 300);
    }, 4000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [item.id, onRemove]);

  return (
    <div className={`${styles.toast} ${styles[item.type]} ${show ? styles.show : ''}`}>
      <div className={styles.icon}>{ICONS[item.type]}</div>
      <div className={styles.text}>{item.message}</div>
    </div>
  );
};

const Toast = ({ items, onRemove }: ToastProps) => (
  <div className={styles.container}>
    {items.map(item => (
      <ToastMessage key={item.id} item={item} onRemove={onRemove} />
    ))}
  </div>
);

export default Toast;