import styles from './Badge.module.css';

type BadgeVariant =
  | 'lime' | 'success' | 'warn' | 'error' | 'info' | 'neutral'
  | 'admin' | 'teacher' | 'student'
  | 'cash' | 'card' | 'liqpay'
  | 'active' | 'expiring' | 'expired' | 'paused' | 'closed';

interface BadgeProps {
  variant?:   BadgeVariant;
  dot?:       boolean;
  children:   React.ReactNode;
  className?: string;
}

const Badge = ({ variant = 'neutral', dot = false, children, className = '' }: BadgeProps) => (
  <span className={`${styles.badge} ${styles[variant]} ${className}`.trim()}>
    {dot && <span className={styles.dot} />}
    {children}
  </span>
);

export default Badge;