import { IconInfo } from '../Icon';
import styles from './EmptyState.module.css';

interface EmptyStateProps {
  icon?:     React.ReactNode;
  title:     string;
  text?:     string;
  action?:   React.ReactNode;
}

const DefaultIcon = () => <IconInfo size={24} strokeWidth={1.5} />;

const EmptyState = ({ icon, title, text, action }: EmptyStateProps) => (
  <div className={styles.wrap}>
    <div className={styles.icon}>{icon ?? <DefaultIcon />}</div>
    <div className={styles.title}>{title}</div>
    {text   && <div className={styles.text}>{text}</div>}
    {action && action}
  </div>
);

export default EmptyState;