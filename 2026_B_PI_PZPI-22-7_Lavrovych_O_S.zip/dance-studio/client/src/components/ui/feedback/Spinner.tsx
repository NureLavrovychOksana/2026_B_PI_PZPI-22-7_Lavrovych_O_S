import styles from './Spinner.module.css';

interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  centered?: boolean;
}

const Spinner = ({ size = 'md', centered = false }: SpinnerProps) => {
  const el = <div className={`${styles.spinner} ${styles[size]}`} />;
  if (centered) return <div className={styles.wrap}>{el}</div>;
  return el;
};

export default Spinner;