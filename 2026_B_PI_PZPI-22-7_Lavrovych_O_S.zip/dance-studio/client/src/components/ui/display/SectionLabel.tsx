interface Props {
  children: React.ReactNode;
  mb?: number;
}

const SectionLabel = ({ children, mb = 16 }: Props) => (
  <div style={{
    fontSize: 10,
    color: 'var(--graphite)',
    fontFamily: 'var(--font-mono)',
    letterSpacing: '0.08em',
    marginBottom: mb,
  }}>
    {children}
  </div>
);

export default SectionLabel;
