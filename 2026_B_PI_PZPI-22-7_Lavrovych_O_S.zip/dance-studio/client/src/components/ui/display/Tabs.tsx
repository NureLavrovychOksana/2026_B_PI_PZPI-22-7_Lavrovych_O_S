import s from './Tabs.module.css';

export interface TabItem<T extends string = string> {
  value: T;
  label: string;
}

interface TabsProps<T extends string = string> {
  tabs: readonly TabItem<T>[];
  active: T;
  onChange: (v: T) => void;
  className?: string;
}

function Tabs<T extends string = string>({ tabs, active, onChange, className = '' }: TabsProps<T>) {
  return (
    <div className={`${s.tabs} ${className}`}>
      {tabs.map(t => (
        <button
          key={t.value}
          type="button"
          className={`${s.tab} ${active === t.value ? s.active : ''}`}
          onClick={() => onChange(t.value)}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

export default Tabs;
