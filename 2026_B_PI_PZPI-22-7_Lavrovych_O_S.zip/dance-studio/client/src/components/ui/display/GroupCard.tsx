import type { DanceGroup } from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import { IconHome } from '../Icon';
import styles from './GroupCard.module.css';

const STATUS_DOT: Record<string, string> = {
  active: styles.active,
  paused: styles.paused,
  closed: styles.closed,
};

interface GroupCardProps {
  group:    DanceGroup;
  onClick?: () => void;
  actions?: React.ReactNode;
  footer?:  React.ReactNode;
}

const GroupCard = ({ group, onClick, actions, footer }: GroupCardProps) => {
  const initials = `${group.teacher_first_name?.[0] ?? ''}${group.teacher_last_name?.[0] ?? ''}`.toUpperCase();

  return (
    <div className={`${styles.card} ${onClick ? styles.clickable : ''}`} onClick={onClick}>
      <div className={styles.top}>
        <div>
          <div className={styles.name}>{group.name}</div>
          <div className={styles.style}>{group.style_name}</div>
        </div>
        <div className={`${styles.statusDot} ${STATUS_DOT[group.status]}`} />
      </div>

      <div className={styles.meta}>
        <div className={styles.metaRow}>
          <IconHome size={13} strokeWidth={1.8} />
          {group.hall_name} · до {group.hall_capacity} осіб
        </div>

      </div>

      <div className={styles.footer}>
        {footer ?? (
          <>
            <div className={styles.teacher}>
              <div className={styles.teacherAvatar}>{initials}</div>
              <div className={styles.teacherName}>
                {group.teacher_first_name} {group.teacher_last_name}
              </div>
            </div>
            <span className={styles.levelBadge}>
              {LEVEL_LABELS[group.level]}
            </span>
          </>
        )}
      </div>

      {actions && (
        <div className={styles.actions}>
          {actions}
        </div>
      )}
    </div>
  );
};

export default GroupCard;
