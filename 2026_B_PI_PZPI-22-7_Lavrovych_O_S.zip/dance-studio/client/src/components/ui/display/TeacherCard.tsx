import { IconArrowRight } from '../Icon';
import s from './TeacherCard.module.css';

interface TeacherCardProps {
  showEnroll?: boolean;
  teacher: {
    id: number;
    user_id?: number;
    first_name: string;
    last_name: string;
    bio?: string;
    experience_years?: number;
    styles?: Array<string | { id: number; name: string }>;
    students_count?: number;
    lessons_count?: number;
    groups_count?: number;
  };
  visible?: boolean;
  delay?: number;
  onClick?: () => void;
}

const TeacherCard = ({ teacher, visible = true, delay = 0, showEnroll = true, onClick }: TeacherCardProps) => {
  const initials  = `${teacher.first_name[0]}${teacher.last_name[0]}`.toUpperCase();
  const styleList = (teacher.styles ?? []).slice(0, 3).map((st: any) =>
    typeof st === 'string' ? { id: st, name: st } : st
  );

  return (
    <div
      className={`${s.card} ${visible ? s.visible : ''}`}
      style={{ transitionDelay: `${delay}s`, cursor: onClick ? 'pointer' : 'default' }}
      onClick={onClick}
    >
      <div className={s.top}>
        <div className={s.avatar}>{initials}</div>
        <div>
          <div className={s.name}>{teacher.first_name} {teacher.last_name}</div>
          <div className={s.exp}>
            {teacher.experience_years ? `${teacher.experience_years} років досвіду` : 'Викладач студії'}
          </div>
          <div className={s.tags}>
            {styleList.map((st, i) => (
              <span key={st.id ?? i} className={s.tag}>{st.name}</span>
            ))}
          </div>
        </div>
      </div>

      {teacher.bio && (
        <div className={s.body}>
          <p className={s.bio}>{teacher.bio}</p>
          <div className={s.stats}>
            <div className={s.stat}>
              <div className={s.statVal}>{teacher.students_count ?? '—'}</div>
              <div className={s.statLbl}>Учнів</div>
            </div>
            <div className={s.stat}>
              <div className={s.statVal}>{teacher.lessons_count ?? '—'}</div>
              <div className={s.statLbl}>Занять</div>
            </div>
            <div className={s.stat}>
              <div className={s.statVal}>{teacher.experience_years ?? '—'}</div>
              <div className={s.statLbl}>Досвід</div>
            </div>
          </div>
        </div>
      )}

      {showEnroll && (
        <div className={s.enroll}>
          Записатись до {teacher.first_name}
          <IconArrowRight size={12} />
        </div>
      )}
    </div>
  );
};

export default TeacherCard;
