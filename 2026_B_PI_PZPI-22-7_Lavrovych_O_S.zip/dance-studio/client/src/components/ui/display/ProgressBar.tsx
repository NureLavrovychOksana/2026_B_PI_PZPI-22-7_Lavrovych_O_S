import s from './ProgressBar.module.css';

interface Props {
  value:   number;
  color?:  'lime' | 'warn' | 'error';
  height?: number;
  glow?:   boolean;
}

const ProgressBar = ({ value, color = 'lime', height = 5, glow = false }: Props) => (
  <div className={s.track} style={{ '--pb-h': `${height}px` } as React.CSSProperties}>
    <div
      className={[
        s.fill,
        color === 'warn'  ? s.fillWarn  : '',
        color === 'error' ? s.fillError : '',
        glow              ? s.glow      : '',
      ].filter(Boolean).join(' ')}
      style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
    />
  </div>
);

export default ProgressBar;
