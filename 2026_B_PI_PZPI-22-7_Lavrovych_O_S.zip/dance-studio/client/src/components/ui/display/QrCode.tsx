import { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';

interface Props {
  value: string;
  size?: number;
}

const QrCode = ({ value, size = 120 }: Props) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!canvasRef.current || !value) return;
    QRCode.toCanvas(canvasRef.current, value, {
      width: size,
      margin: 1,
      color: {
        dark:  '#c8fa3a', 
        light: '#1a1a18',
      },
    }).catch(() => setError(true));
  }, [value, size]);

  if (error) return (
    <div style={{ width: size, height: size, background: '#1a1a18', borderRadius: 6,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: 10, color: '#555', fontFamily: 'monospace' }}>
      QR error
    </div>
  );

  return (
    <canvas
      ref={canvasRef}
      style={{ borderRadius: 6, display: 'block' }}
    />
  );
};

export default QrCode;
