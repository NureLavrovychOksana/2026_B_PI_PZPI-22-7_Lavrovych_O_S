import styles from './StatCard.module.css';

interface StatCardProps {
  label:       string;
  value:       string | number;
  change?:     string;
  changeNeg?:  boolean;
  accentBorder?: boolean;
  icon?:       React.ReactNode;
  valueColor?: 'default' | 'accent' | 'warn' | 'error';
}

const StatCard = ({
  label, value, change, changeNeg,
  accentBorder, icon, valueColor = 'default',
}: StatCardProps) => (
  <div className={`${styles.card} ${accentBorder ? styles.accent_border : ''}`}>
    <div className={styles.label}>
      {icon && icon}
      {label}
    </div>
    <div className={`${styles.value} ${valueColor !== 'default' ? styles[valueColor] : ''}`}>
      {value}
    </div>
    {change && (
      <div className={`${styles.change} ${changeNeg ? styles.changeNeg : ''}`}>
        {change}
      </div>
    )}
  </div>
);

export default StatCard;