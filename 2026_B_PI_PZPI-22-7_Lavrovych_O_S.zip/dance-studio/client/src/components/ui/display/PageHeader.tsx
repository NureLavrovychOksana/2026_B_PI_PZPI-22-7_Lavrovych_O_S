import styles from './PageHeader.module.css';

interface PageHeaderProps {
  title:    string;
  sub?:     string;
  actions?: React.ReactNode;
}

const PageHeader = ({ title, sub, actions }: PageHeaderProps) => (
  <div className={styles.header}>
    <div className={styles.titles}>
      <h1 className={styles.title}>{title}</h1>
      {sub && <div className={styles.sub}>{sub}</div>}
    </div>
    {actions && (
      <>
        <div className={styles.spacer} />
        <div className={styles.actions}>{actions}</div>
      </>
    )}
  </div>
);

export default PageHeader;