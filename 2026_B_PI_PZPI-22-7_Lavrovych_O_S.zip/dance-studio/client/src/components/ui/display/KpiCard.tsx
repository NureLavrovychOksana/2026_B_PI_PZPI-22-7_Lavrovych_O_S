import { useCountUp }        from '../../../hooks/useCountUp';
import { useRevealOnScroll } from '../../../hooks/useRevealOnScroll';

interface Props {
  label:   string;
  value:   number | string;
  accent?: boolean;
  suffix?: string;
}

const KpiCard = ({ label, value, accent, suffix = '' }: Props) => {
  const { ref, visible } = useRevealOnScroll(0.1);
  const counted = useCountUp(typeof value === 'number' ? value : 0, 1000, visible);

  return (
    <div
      ref={ref}
      style={{
        background: 'var(--coal-2)',
        border: '1px solid #1e1e1c',
        borderRadius: 'var(--r-lg)',
        padding: '14px 16px',
        borderLeft: accent ? '3px solid var(--lime-hot)' : undefined,
      }}
    >
      <div style={{
        fontSize: 10, color: 'var(--graphite)',
        fontFamily: 'var(--font-mono)', letterSpacing: '0.08em', marginBottom: 8,
      }}>
        {label}
      </div>
      <div style={{
        fontFamily: 'var(--font-head)', fontSize: 28, fontWeight: 700,
        color: accent ? 'var(--lime)' : 'var(--paper)',
        letterSpacing: -1, lineHeight: 1,
      }}>
        {typeof value === 'number' ? `${counted}${suffix}` : value}
      </div>
    </div>
  );
};

export default KpiCard;
