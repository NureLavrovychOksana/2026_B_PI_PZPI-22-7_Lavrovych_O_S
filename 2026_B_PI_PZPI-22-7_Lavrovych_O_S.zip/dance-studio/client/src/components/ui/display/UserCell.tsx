import AvatarInitials from './AvatarInitials';
import css from './UserCell.module.css';

interface Props {
  firstName: string;
  lastName:  string;
  sub?:      string;
  src?:      string | null;
  size?:     number;
}

const UserCell = ({ firstName, lastName, sub, src, size = 32 }: Props) => (
  <div className={css.cell}>
    <AvatarInitials firstName={firstName} lastName={lastName} src={src} size={size} fontSize={11} />
    <div>
      <div className={css.name}>{firstName} {lastName}</div>
      {sub && <div className={css.sub}>{sub}</div>}
    </div>
  </div>
);

export default UserCell;
