import css from './AvatarInitials.module.css';

interface Props {
  firstName: string;
  lastName:  string;
  src?:      string | null;
  size?:     number;
  fontSize?: number;
}

const AvatarInitials = ({ firstName, lastName, src, size = 34, fontSize = 12 }: Props) => (
  <div className={css.avatar} style={{ width: size, height: size, fontSize }}>
    {src
      ? <img src={src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '50%' }} />
      : <>{(firstName[0] ?? '').toUpperCase()}{(lastName[0] ?? '').toUpperCase()}</>
    }
  </div>
);

export default AvatarInitials;
