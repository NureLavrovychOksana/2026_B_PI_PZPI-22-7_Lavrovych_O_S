const MONTHS_UK  = ['Січень','Лютий','Березень','Квітень','Травень','Червень','Липень','Серпень','Вересень','Жовтень','Листопад','Грудень'];
const DAYS_SHORT = ['Пн','Вт','Ср','Чт','Пт','Сб','Нд'];

interface MiniCalendarProps {
  year:     number;
  month:    number;
  dotDates: Set<string>;
  selected: string | null;
  today:    string;
  onSelect: (d: string) => void;
  onPrev:   () => void;
  onNext:   () => void;
  s:        Record<string, string>;
}

const MiniCalendar = ({ year, month, dotDates, selected, today, onSelect, onPrev, onNext, s }: MiniCalendarProps) => {
  const firstDay    = new Date(year, month, 1).getDay();
  const offset      = firstDay === 0 ? 6 : firstDay - 1;
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const cells: (string | null)[] = [];
  for (let i = 0; i < offset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    cells.push(`${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`);
  }

  return (
    <div className={s.cal}>
      <div className={s.calHead}>
        <button className={s.calNav} onClick={onPrev}>←</button>
        <span className={s.calTitle}>{MONTHS_UK[month]} {year}</span>
        <button className={s.calNav} onClick={onNext}>→</button>
      </div>
      <div className={s.calGrid}>
        {DAYS_SHORT.map(d => <div key={d} className={s.calDayLabel}>{d}</div>)}
        {cells.map((d, i) =>
          d === null ? <div key={`e${i}`} /> : (
            <button
              key={d}
              disabled={d < today}
              className={[
                s.calDay,
                d === today    ? s.calDayToday   : '',
                d === selected ? s.calDaySelected : '',
                d < today      ? s.calDayPast     : '',
                dotDates.has(d) ? s.calDayDot    : s.calDayNoDot,
              ].join(' ')}
              onClick={() => onSelect(d)}
            >
              {d.slice(8)}
              {dotDates.has(d) && <span className={s.dot} />}
            </button>
          )
        )}
      </div>
    </div>
  );
};

export default MiniCalendar;
