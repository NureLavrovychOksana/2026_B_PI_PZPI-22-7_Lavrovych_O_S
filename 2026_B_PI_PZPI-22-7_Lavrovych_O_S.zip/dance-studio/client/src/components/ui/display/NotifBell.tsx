import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { getUnreadCount } from '../../../api/notifications';
import { IconBell } from '../Icon';
import styles from './NotifBell.module.css';

interface Props {
  to: string;
}

const NotifBell = ({ to }: Props) => {
  const [unread, setUnread] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetch = async () => {
    try { setUnread(await getUnreadCount()); } catch { /* ignore */ }
  };

  useEffect(() => {
    fetch();
    timerRef.current = setInterval(fetch, 60_000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  return (
    <Link to={to} className={styles.btn} aria-label="Сповіщення">
      <IconBell size={18} strokeWidth={1.8} />
      {unread > 0 && <span className={styles.dot} />}
    </Link>
  );
};

export default NotifBell;
