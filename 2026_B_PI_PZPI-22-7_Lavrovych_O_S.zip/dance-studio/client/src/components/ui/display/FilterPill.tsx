import s from './FilterPill.module.css';

interface FilterPillProps {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

const FilterPill = ({ active, onClick, children }: FilterPillProps) => (
  <button
    type="button"
    className={`${s.pill} ${active ? s.active : ''}`}
    onClick={onClick}
  >
    {children}
  </button>
);

export default FilterPill;
