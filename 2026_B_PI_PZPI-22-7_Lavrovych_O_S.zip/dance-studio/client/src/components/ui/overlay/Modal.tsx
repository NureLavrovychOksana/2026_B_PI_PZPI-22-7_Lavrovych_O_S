import css from './Modal.module.css';

interface ModalProps {
  title:    string;
  onClose:  () => void;
  children: React.ReactNode;
  footer?:  React.ReactNode;
  wide?:    boolean;
}

const Modal = ({ title, onClose, children, footer, wide }: ModalProps) => (
  <div className={css.overlay} onClick={onClose}>
    <div className={`${css.box} ${wide ? css.wide : ''}`} onClick={e => e.stopPropagation()}>
      <div className={css.header}>
        <span className={css.title}>{title}</span>
        <button type="button" className={css.close} onClick={onClose} aria-label="Закрити">×</button>
      </div>
      <div className={css.body}>{children}</div>
      {footer && <div className={css.footer}>{footer}</div>}
    </div>
  </div>
);

export default Modal;
