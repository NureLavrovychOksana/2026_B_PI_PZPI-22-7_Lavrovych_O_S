import Button from '../form/Button';
import { IconTrash, IconAlertTriangle } from '../Icon';
import styles from './ConfirmModal.module.css';

interface ConfirmModalProps {
  title:     string;
  message:   string;
  confirmLabel?: string;
  cancelLabel?:  string;
  variant?:  'danger' | 'warning';
  loading?:  boolean;
  onConfirm: () => void;
  onCancel:  () => void;
}

const DangerIcon = () => <IconTrash size={18} />;
const WarnIcon   = () => <IconAlertTriangle size={18} />;

const ConfirmModal = ({
  title, message,
  confirmLabel = 'Підтвердити',
  cancelLabel  = 'Скасувати',
  variant  = 'danger',
  loading  = false,
  onConfirm, onCancel,
}: ConfirmModalProps) => (
  <div className={styles.overlay} onClick={onCancel}>
    <div className={styles.modal} onClick={e => e.stopPropagation()}>
      <div className={styles.header}>
        <div className={`${styles.iconWrap} ${variant === 'danger' ? styles.iconDanger : styles.iconWarning}`}>
          {variant === 'danger' ? <DangerIcon /> : <WarnIcon />}
        </div>
        <div className={styles.title}>{title}</div>
      </div>
      <div className={styles.body}>{message}</div>
      <div className={styles.actions}>
        <Button variant="secondary" onClick={onCancel} disabled={loading}>
          {cancelLabel}
        </Button>
        <Button variant="danger" onClick={onConfirm} loading={loading}>
          {confirmLabel}
        </Button>
      </div>
    </div>
  </div>
);

export default ConfirmModal;