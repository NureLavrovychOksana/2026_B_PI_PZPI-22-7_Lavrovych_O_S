import css from './FormField.module.css';

interface FormFieldProps {
  label:      string;
  error?:     string;
  hint?:      string;
  className?: string;
  children:   React.ReactNode;
}

const FormField = ({ label, error, hint, className, children }: FormFieldProps) => (
  <div className={`${css.group} ${className ?? ''}`}>
    <label className={css.labelWrap}>
      <span className={css.label}>
        {label}
        {hint && (
          <span className={css.tipWrap}>
            <span className={css.tipIcon}>?</span>
            <span className={css.tipBox}>{hint}</span>
          </span>
        )}
      </span>
      {children}
    </label>
    {error && <div className={css.error}>{error}</div>}
  </div>
);

export default FormField;
