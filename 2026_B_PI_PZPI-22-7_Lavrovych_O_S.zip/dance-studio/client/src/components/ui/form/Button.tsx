import { forwardRef } from 'react';
import { Link } from 'react-router-dom';
import styles from './Button.module.css';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size    = 'sm' | 'md' | 'lg';

interface ButtonProps {
  variant?:  Variant;
  size?:     Size;
  block?:    boolean;
  loading?:  boolean;
  disabled?: boolean;
  href?:     string;
  onClick?:  (e: React.MouseEvent) => void;
  type?:     'button' | 'submit' | 'reset';
  children:  React.ReactNode;
  className?: string;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(({
  variant = 'primary',
  size    = 'md',
  block   = false,
  loading = false,
  disabled,
  href,
  onClick,
  type = 'button',
  children,
  className = '',
}, ref) => {
  const cls = [
    styles.btn,
    styles[variant],
    size !== 'md' ? styles[size] : '',
    block ? styles.block : '',
    className,
  ].filter(Boolean).join(' ');

  if (href) {
    return (
      <Link to={href} className={cls} onClick={onClick}>
        {children}
      </Link>
    );
  }

  return (
    <button
      ref={ref}
      className={cls}
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
    >
      {loading && <span className={styles.spinner} />}
      {children}
    </button>
  );
});

Button.displayName = 'Button';
export default Button;