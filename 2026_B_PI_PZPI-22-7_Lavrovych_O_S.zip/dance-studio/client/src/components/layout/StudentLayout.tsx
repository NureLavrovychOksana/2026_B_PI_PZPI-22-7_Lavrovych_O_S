import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import styles from './AppLayout.module.css';
import {
  IconGrid, IconUser, IconCalendar, IconCirclePlus,
  IconShopping, IconClipboard, IconBell,
} from '../ui/Icon';

const NAV_ITEMS = [
  { label: 'Панель',        path: '/student', end: true, group: 'КАБІНЕТ УЧНЯ', icon: <IconGrid size={16} strokeWidth={1.8} /> },
  { label: 'Профіль',       path: '/student/profile',      icon: <IconUser size={16} strokeWidth={1.8} /> },
  { label: 'Мій розклад',   path: '/student/schedule',     icon: <IconCalendar size={16} strokeWidth={1.8} /> },
  { label: 'Записатись',    path: '/student/enroll',       icon: <IconCirclePlus size={16} strokeWidth={1.8} /> },
  { label: 'Магазин',       path: '/student/subscription', icon: <IconShopping size={16} strokeWidth={1.8} />, group: 'ФІНАНСИ' },
  { label: 'Відвідуваність',path: '/student/attendance',   icon: <IconClipboard size={16} strokeWidth={1.8} /> },
  { label: 'Сповіщення',    path: '/student/notifications',icon: <IconBell size={16} strokeWidth={1.8} />,     group: 'СИСТЕМА' },
];

const StudentLayout = () => (
  <div className={styles.app}>
    <Sidebar role="student" items={NAV_ITEMS} />
    <main className={styles.main}>
      <div className={styles.pageWrap}>
        <Outlet />
      </div>
    </main>
  </div>
);

export default StudentLayout;
