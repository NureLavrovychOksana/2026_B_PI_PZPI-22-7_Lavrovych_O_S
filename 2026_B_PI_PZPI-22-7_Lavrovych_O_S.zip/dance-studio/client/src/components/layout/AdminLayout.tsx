import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import styles from './AppLayout.module.css';
import {
  IconGrid, IconUsers, IconCalendar, IconZap, IconHome,
  IconCreditCard, IconDollar, IconBarChart, IconBell, IconSettings,
} from '../ui/Icon';

const NAV_ITEMS = [
  { label: 'Дашборд',      path: '/admin',  end: true,   icon: <IconGrid size={16} strokeWidth={1.8} />,        group: 'НАВІГАЦІЯ' },
  { label: 'Користувачі',  path: '/admin/users',        icon: <IconUsers size={16} strokeWidth={1.8} /> },
  { label: 'Розклад',      path: '/admin/schedule',     icon: <IconCalendar size={16} strokeWidth={1.8} /> },
  { label: 'Авто-розклад', path: '/admin/schedule/generator', icon: <IconZap size={16} strokeWidth={1.8} /> },
  { label: 'Групи',        path: '/admin/groups',       icon: <IconHome size={16} strokeWidth={1.8} /> },
  { label: 'Абонементи',   path: '/admin/subscriptions',icon: <IconCreditCard size={16} strokeWidth={1.8} />,   group: 'ФІНАНСИ' },
  { label: 'Оплати',       path: '/admin/payments',     icon: <IconDollar size={16} strokeWidth={1.8} /> },
  { label: 'Звіти',        path: '/admin/reports',      icon: <IconBarChart size={16} strokeWidth={1.8} /> },
  { label: 'Сповіщення',   path: '/admin/notifications',icon: <IconBell size={16} strokeWidth={1.8} />,         group: 'СИСТЕМА' },
  { label: 'Налаштування', path: '/admin/settings',     icon: <IconSettings size={16} strokeWidth={1.8} /> },
];

const AdminLayout = () => (
  <div className={styles.app}>
    <Sidebar role="admin" items={NAV_ITEMS} />
    <main className={styles.main}>
      <div className={styles.pageWrap}>
        <Outlet />
      </div>
    </main>
  </div>
);

export default AdminLayout;
