import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import styles from './AppLayout.module.css';
import { IconGrid, IconCalendar, IconUsers, IconBarChart, IconBell, IconUser } from '../ui/Icon';

const NAV_ITEMS = [
  { label: 'Дашборд',    path: '/teacher', group: 'НАВІГАЦІЯ', end: true, icon: <IconGrid size={16} strokeWidth={1.8} /> },
  { label: 'Мій розклад',path: '/teacher/schedule',     icon: <IconCalendar size={16} strokeWidth={1.8} /> },
  { label: 'Мої групи',  path: '/teacher/groups',       icon: <IconUsers size={16} strokeWidth={1.8} /> },
  { label: 'Статистика', path: '/teacher/stats',        icon: <IconBarChart size={16} strokeWidth={1.8} />, group: 'АНАЛІТИКА' },
  { label: 'Сповіщення', path: '/teacher/notifications',icon: <IconBell size={16} strokeWidth={1.8} />,    group: 'СИСТЕМА' },
  { label: 'Профіль',    path: '/teacher/profile',      icon: <IconUser size={16} strokeWidth={1.8} /> },
];

const TeacherLayout = () => (
  <div className={styles.app}>
    <Sidebar role="teacher" items={NAV_ITEMS} />
    <main className={styles.main}>
      <div className={styles.pageWrap}>
        <Outlet />
      </div>
    </main>
  </div>
);

export default TeacherLayout;
