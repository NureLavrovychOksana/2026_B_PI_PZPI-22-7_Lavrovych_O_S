import { NavLink, Link, useNavigate, useLocation } from 'react-router-dom';
import { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { getUnreadCount } from '../../api/notifications';
import styles from './Sidebar.module.css';
import type { Role } from '../../types';
import { IconLogOut, IconMenu, IconLayers } from '../ui/Icon';

interface NavItem {
  label: string;
  path: string;
  icon: React.ReactNode;
  badge?: number;
  group?: string;
  end?: boolean;
}

interface SidebarProps {
  role: Role;
  items: NavItem[];
}

const ROLE_LABELS: Record<Role, string> = {
  admin:   'Адміністратор',
  teacher: 'Викладач',
  student: 'Учень',
};

const Sidebar = ({ role, items }: SidebarProps) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);
  const [avatarError, setAvatarError] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchUnread = async () => {
    try {
      const count = await getUnreadCount();
      setUnread(count);
    } catch {}
  };

  useEffect(() => {
    fetchUnread();
    intervalRef.current = setInterval(fetchUnread, 60_000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  useEffect(() => {
    if (!location.pathname.includes('/notifications')) {
      fetchUnread();
    }
  }, [location.pathname]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const initials = user
    ? `${user.first_name[0]}${user.last_name[0]}`.toUpperCase()
    : '??';

  useEffect(() => { setAvatarError(false); }, [user?.avatar_url]);

  const serverOrigin = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/api$/, '');
  const avatarSrc = user?.avatar_url ? `${serverOrigin}${user.avatar_url}` : null;

  const groups: Record<string, NavItem[]> = {};
  items.forEach(item => {
    const key = item.group || '';
    if (!groups[key]) groups[key] = [];
    groups[key].push(item);
  });

  return (
    <>
      <button className={styles.mobileToggle} onClick={() => setOpen(true)} aria-label="Відкрити меню">
        <IconMenu size={18} strokeWidth={1.8} />
      </button>

      <div
        className={`${styles.overlay} ${open ? styles.overlayActive : ''}`}
        onClick={() => setOpen(false)}
      />

      <aside className={`${styles.sidebar} ${open ? styles.sidebarOpen : ''}`}>
        {/* Logo */}
        <div className={styles.logo}>
          <Link to="/home" className={styles.logoMark} onClick={() => setOpen(false)}>
            <div className={styles.logoDot}>
              <IconLayers size={14} strokeWidth={2.5} />
            </div>
            <div className={styles.logoText}>
              MOVE STUDIO
              <small>DANCE MANAGEMENT</small>
            </div>
          </Link>

          {/* User block — click to go to profile */}
          <Link to={`/${role}/profile`} className={styles.userBlock} onClick={() => setOpen(false)}>
            {avatarSrc && !avatarError
              ? <img src={avatarSrc} alt={initials} className={styles.avatarImg} onError={() => setAvatarError(true)} />
              : <div className={styles.avatar}>{initials}</div>
            }
            <div>
              <div className={styles.userName}>
                {user?.first_name} {user?.last_name}
              </div>
              <div className={styles.userRole}>{ROLE_LABELS[role]}</div>
            </div>
          </Link>
        </div>

        {/* Nav */}
        <nav className={styles.nav}>
          {Object.entries(groups).map(([group, groupItems]) => (
            <div key={group}>
              {group && <div className={styles.navGroup}>{group}</div>}
              {groupItems.map(item => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.end}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    `${styles.navItem} ${isActive ? styles.navItemActive : ''}`
                  }
                >
                  <span className={styles.navIconWrap}>
                    <span className={styles.navIcon}>{item.icon}</span>
                    {unread > 0 && item.path.includes('/notifications') && (
                      <span className={styles.notifDot} />
                    )}
                  </span>
                  {item.label}
                  {item.badge ? (
                    <span className={styles.badge}>{item.badge}</span>
                  ) : null}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        {/* Footer */}
        <div className={styles.footer}>
          <button className={styles.logoutBtn} onClick={handleLogout}>
            <IconLogOut size={14} strokeWidth={1.8} />
            Вийти
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;