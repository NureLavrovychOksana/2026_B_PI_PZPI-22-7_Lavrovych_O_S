import { useState } from 'react';
import { Outlet, NavLink, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import styles from './PublicLayout.module.css';
import { IconLayers, IconX, IconMenu } from '../ui/Icon';

const ROLE_HOME: Record<string, string> = {
  admin:   '/admin',
  teacher: '/teacher',
  student: '/student',
};

const NAV_LINKS = [
  { to: '/',         label: 'Головна',   end: true  },
  { to: '/classes',  label: 'Класи',     end: false },
  { to: '/teachers', label: 'Викладачі', end: false },
  { to: '/schedule', label: 'Розклад',   end: false },
];

const PublicLayout = () => {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);

  const close = () => setOpen(false);

  return (
    <div className={styles.layout}>
      <header className={styles.header}>
        {/* Top bar: logo + desktop nav + actions + hamburger */}
        <div className={styles.headerRow}>
          <Link to="/" className={styles.logo} onClick={close}>
            <div className={styles.logoDot}>
              <IconLayers size={14} strokeWidth={2.5} />
            </div>
            <span className={styles.logoText}>MOVE STUDIO</span>
          </Link>

          <nav className={styles.nav}>
            {NAV_LINKS.map(link => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.end}
                className={({ isActive }) =>
                  `${styles.navLink} ${isActive ? styles.navLinkActive : ''}`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </nav>

          <div className={styles.actions}>
            {user ? (
              <Link to={ROLE_HOME[user.role] || '/'} className={styles.btnPrimary}>
                Мій кабінет
              </Link>
            ) : (
              <>
                <Link to="/login"    className={`${styles.btnGhost}   ${styles.desktopOnly}`}>Увійти</Link>
                <Link to="/register" className={styles.btnPrimary}>Реєстрація</Link>
              </>
            )}
          </div>

          <button
            className={styles.hamburger}
            onClick={() => setOpen(v => !v)}
            aria-label={open ? 'Закрити меню' : 'Відкрити меню'}
            aria-expanded={open}
          >
            {open ? <IconX size={18} strokeWidth={2.5} /> : <IconMenu size={18} strokeWidth={2.5} />}
          </button>
        </div>

        {/* Mobile nav — accordion inside header (inherits sticky + blur) */}
        <div className={`${styles.mobileNav} ${open ? styles.mobileNavOpen : ''}`}>
          {NAV_LINKS.map(link => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              onClick={close}
              className={({ isActive }) =>
                `${styles.mobileNavLink} ${isActive ? styles.mobileNavLinkActive : ''}`
              }
            >
              {link.label}
            </NavLink>
          ))}

          {!user && (
            <div className={styles.mobileActions}>
              <Link to="/login"    className={styles.btnGhost}   onClick={close}>Увійти</Link>
              <Link to="/register" className={styles.btnPrimary} onClick={close}>Реєстрація</Link>
            </div>
          )}
        </div>
      </header>

      <Outlet />
    </div>
  );
};

export default PublicLayout;
