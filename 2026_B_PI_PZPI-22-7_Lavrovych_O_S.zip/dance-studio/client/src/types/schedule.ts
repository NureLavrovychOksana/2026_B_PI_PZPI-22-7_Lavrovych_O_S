export interface GroupRequirement {
  group_id:        number;
  group_name:      string;
  style_name:      string;
  teacher_name:    string;
  teacher_id:      number;
  lessons_per_week: number;
  lesson_duration: number;
  preferred_start?: string | null;
  preferred_end?:   string | null;
  is_children:     boolean;
  typical_students: number;
}

export interface ConstraintWarning {
  type: 'hall_conflict' | 'teacher_conflict' | 'group_gap'
      | 'timing' | 'teacher_gap' | 'day_spread' | 'hall_utilization'
      | 'day_center' | 'day_pattern' | 'day_popularity' | 'hall_capacity' | 'hall_gap';
  msg: string;
}

export interface DraftLesson {
  id:              number;
  group_id:        number;
  group_name:      string;
  style_name:      string;
  teacher_name:    string;
  teacher_id:      number;
  hall_id:         number | null;
  hall_name:       string | null;
  lesson_date:     string | null;
  start_time:      string | null;
  end_time:        string | null;
  duration_min:    number;
  is_unplaced:     boolean;
  unplaced_reason?: string | null;
  warnings:        ConstraintWarning[];
  score:           number;
}

export interface WizardConfig {
  week_start:         string;
  group_requirements: GroupRequirement[];
  hall_ids:           number[];
  allowed_days:       number[];
  time_from:          string;
  time_to:            string;
  slot_step:          number;
  publish_mode?:      'append' | 'overwrite';
}

export interface WeekStatus {
  has_lessons:      boolean;
  lesson_count:     number;
  enrolled_lessons: number;
  can_overwrite:    boolean;
}

export interface SlotValidation {
  valid:           boolean;
  violations:      ConstraintWarning[];
  warnings:        ConstraintWarning[];
  score:           number;
  level:           'ok' | 'warn' | 'error';
}
