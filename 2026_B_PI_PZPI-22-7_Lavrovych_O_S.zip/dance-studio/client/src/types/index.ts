export type Role = 'admin' | 'teacher' | 'student';

export interface User {
  id: number;
  email: string;
  role: Role;
  first_name: string;
  last_name: string;
  phone?: string;
  created_at: string;
  avatar_url?: string | null;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface DanceStyle {
  id: number;
  name: string;
  description?: string;
}

export interface Hall {
  id: number;
  name: string;
  capacity: number;
  is_active: number;
  future_lessons_count?: number;
}
export type GroupLevel = 'first_step' | 'starter' | 'learner' | 'master' | 'pro';

export const LEVEL_LABELS: Record<GroupLevel, string> = {
  first_step: 'База',
  starter:    'Початківці',
  learner:    'Продовжуючі',
  master:     'Просунуті',
  pro:        'Профі',
};

export interface DanceGroup {
  id: number;
  name: string;
  style_id: number;
  style_name: string;
  level: GroupLevel;
  teacher_id: number;
  teacher_first_name: string;
  teacher_last_name: string;
  hall_id: number;
  hall_name: string;
  hall_capacity: number;
  students_count: number;
  status: 'active' | 'paused' | 'closed';
  lessons_per_week: number;
  lesson_duration: number;
  is_children: boolean;
}

export interface Lesson {
  id: number;
  group_id: number;
  group_name: string;
  group_level: GroupLevel;
  group_teacher_id?: number;
  style_name: string;
  hall_id: number;
  hall_name: string;
  hall_capacity: number;
  free_spots: number;
  teacher_id: number;
  teacher_first_name: string;
  teacher_last_name: string;
  lesson_date: string;
  start_time: string;
  end_time: string;
  status?: 'scheduled' | 'cancelled' | 'completed';
}

export interface SubscriptionPlan {
  id: number;
  name: string;
  type: 'COUNT' | 'UNLIMITED';
  sessions_count?: number;
  validity_days?: number;
  price: number;
  is_active?: number;
}

export interface StudentSubscription {
  id: number;
  student_id: number;
  plan_id: number;
  plan_name: string;
  plan_type: 'COUNT' | 'UNLIMITED';
  plan_price: number;
  plan_validity_days?: number;
  purchase_date: string;
  activation_date: string;
  expiry_date?: string;
  sessions_left?: number;
  sessions_frozen?: number;
  plan_sessions_count?: number;
  status: 'active' | 'pending' | 'exhausted' | 'expired' | 'cancelled';
  effective_status?: 'active' | 'pending' | 'exhausted' | 'expired' | 'cancelled';
  first_name?: string;
  last_name?: string;
  student_email?: string;
}

export interface Payment {
  id: number;
  user_id: number;
  first_name: string;
  last_name: string;
  subscription_id?: number;
  plan_name?: string;
  amount: number;
  payment_date: string;
  payment_method: 'cash' | 'card' | 'liqpay';
  status: 'pending' | 'success' | 'failed' | 'refunded';
}

export interface Notification {
  id: number;
  type: string;
  title: string;
  body?: string;
  is_read: boolean;
  created_at: string;
}

export interface AttendanceRecord {
  id: number | null;
  student_id: number;
  first_name: string;
  last_name: string;
  avatar_url?: string | null;
  status: 'present' | 'absent' | 'excused';
  marked_at: string | null;
  sessions_left?: number;
  plan_name?: string;
}

export interface TeacherProfile {
  id: number;
  user_id: number;
  bio?: string;
  experience_years: number;
  education?: string;
}

export interface ConflictInfo {
  id: number;
  lesson_date: string;
  start_time: string;
  end_time: string;
  group_name: string;
  hall_name: string;
  teacher_first_name: string;
  teacher_last_name: string;
  conflict_type: 'hall' | 'teacher' | 'group';
}

export interface DashboardStats {
  students: number;
  today_lessons: number;
  active_groups: number;
  debtors: number;
  month_revenue: number;
  prev_month_revenue: number;
  occupancy_percent: number;
  ltv: number;
  churn_risk_count: number;
}

export interface Enrollment {
  id: number;
  student_id: number;
  lesson_id: number;
  enrolled_at: string;
  first_name?: string;
  last_name?: string;
}

export interface TeacherFull extends User {
  profile?: TeacherProfile;
  styles?: string[];
  groups_count?: number;
}

export interface RevenuePoint {
  month?: string;
  week_start?: string;
  total: number;
}

export interface AttendanceGroupReport {
  id: number;
  group_name: string;
  style_name: string;
  teacher_name: string;
  total_lessons: number;
  enrolled_students: number;
  present_count: number;
  absent_count: number;
  excused_count: number;
  attendance_percent: number;
}

export interface TeacherReport {
  teacher: TeacherFull & { styles: string[] };
  stats: {
    total_lessons: number;
    unique_students: number;
    total_attendance: number;
    present_count: number;
    attendance_percent: number;
  };
  groups: {
    id: number;
    group_name: string;
    style_name: string;
    students_count: number;
    lessons_count: number;
  }[];
}

export interface StudentPersonalStats {
  attendance: {
    total: number;
    present: number;
    absent: number;
    excused: number;
    attendance_percent: number;
  };
  current_month: {
    total: number;
    present: number;
  };
  by_group: {
    group_name: string;
    style_name: string;
    attended_lessons: number;
    attendance_percent: number;
  }[];
}

export interface Debtor {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  last_expiry?: string;
  last_payment?: string;
}

export interface ExpiringSubscription {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  subscription_id: number;
  sessions_left?: number;
  expiry_date: string;
  plan_name: string;
  plan_type: 'COUNT' | 'UNLIMITED';
  days_left: number;
}

export interface ActivityItem {
  type: 'payment' | 'registration' | 'lesson_added';
  subject: string;
  description: string;
  created_at: string;
}

export interface StyleEnhanced {
  style_id: number;
  style: string;
  groups_count: number;
  students_count: number;
  lessons_count: number;
  present_count: number;
  absent_count: number;
  attendance_rate: number;
  churn_risk_count: number;
  churn_rate: number;
}

export interface TeacherUtilization {
  teacher_id: number;
  teacher_name: string;
  total_lessons: number;
  attended_lessons: number;
  total_hours: number;
  students_count: number;
  utilization_percent: number;
}

export interface Anomaly {
  group_id: number;
  group_name: string;
  teacher_name: string;
  teacher_id: number;
  style_name: string;
  total_marks: number;
  absent_count: number;
  absence_rate: number;
}

export interface FunnelData {
  registered: number;
  paid_once: number;
  active_subscription: number;
}

export interface RevenueSplit {
  new_revenue: number;
  renewal_revenue: number;
}

export interface StudentAtRisk {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  phone?: string;
  subscription_id: number;
  sessions_left: number;
  expiry_date?: string;
  plan_name: string;
  plan_price: number;
  last_lesson_date?: string;
}

export interface TeacherTimesheetLesson {
  lesson_id: number;
  lesson_date: string;
  start_time: string;
  end_time: string;
  duration_hours: number;
  group_name: string;
  style_name: string;
  hall_name: string;
  enrolled_count: number;
  present_count: number;
  absent_count: number;
}

export interface TeacherDisciplineStats {
  total_lessons: number;
  conducted_lessons: number;
  total_marks: number;
  absent_count: number;
  excused_count: number;
  absence_rate: number;
  retained: number;
  total_students: number;
  retention_rate: number;
}

export interface DashboardData {
  stats: DashboardStats;
  revenue_split: RevenueSplit;
  revenue_by_month: RevenuePoint[];
  styles_popularity: StyleEnhanced[];
  teacher_utilization: TeacherUtilization[];
  anomalies: Anomaly[];
  expiring_soon: ExpiringSubscription[];
  funnel: FunnelData;
  recent_activity: ActivityItem[];
  attendance_by_group: AttendanceGroupReport[];
}