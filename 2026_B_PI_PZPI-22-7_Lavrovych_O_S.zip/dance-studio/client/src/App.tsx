import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Spinner from './components/ui/feedback/Spinner';

import PublicLayout  from './components/layout/PublicLayout';
import AdminLayout   from './components/layout/AdminLayout';
import TeacherLayout from './components/layout/TeacherLayout';
import StudentLayout from './components/layout/StudentLayout';

const HomePage           = lazy(() => import('./pages/public/Home/HomePage'));
const SchedulePage       = lazy(() => import('./pages/public/Schedule/SchedulePage'));
const ClassesPage        = lazy(() => import('./pages/public/Classes/ClassesPage'));
const ClassDetailPage    = lazy(() => import('./pages/public/Classes/ClassDetailPage'));
const TeachersPage       = lazy(() => import('./pages/public/Teachers/TeachersPage'));
const LoginPage          = lazy(() => import('./pages/public/Auth/LoginPage'));
const RegisterPage       = lazy(() => import('./pages/public/Auth/RegisterPage'));
const ForgotPasswordPage = lazy(() => import('./pages/public/Auth/ForgotPasswordPage'));
const ResetPasswordPage  = lazy(() => import('./pages/public/Auth/ResetPasswordPage'));

const AdminDashboard          = lazy(() => import('./pages/admin/Dashboard/AdminDashboard'));
const AdminUsers              = lazy(() => import('./pages/admin/Users/AdminUsers'));
const AdminSchedule           = lazy(() => import('./pages/admin/Schedule/AdminSchedule'));
const ScheduleGeneratorPage   = lazy(() => import('./pages/admin/ScheduleGenerator/ScheduleGeneratorPage'));
const AdminGroups             = lazy(() => import('./pages/admin/Groups/AdminGroups'));
const AdminSubscriptions      = lazy(() => import('./pages/admin/Subscriptions/AdminSubscriptions'));
const AdminPayments           = lazy(() => import('./pages/admin/Payments/AdminPayments'));
const AdminReports            = lazy(() => import('./pages/admin/Reports/AdminReports'));
const AdminNotifications      = lazy(() => import('./pages/admin/Notifications/AdminNotifications'));
const AdminSettings           = lazy(() => import('./pages/admin/Settings/AdminSettings'));
const AdminTeachers           = lazy(() => import('./pages/admin/Teachers/AdminTeachers'));

const TeacherDashboard     = lazy(() => import('./pages/teacher/Dashboard/TeacherDashboard'));
const TeacherSchedule      = lazy(() => import('./pages/teacher/Schedule/TeacherSchedule'));
const TeacherGroups        = lazy(() => import('./pages/teacher/Groups/TeacherGroups'));
const TeacherStats         = lazy(() => import('./pages/teacher/Stats/TeacherStats'));
const TeacherProfile       = lazy(() => import('./pages/teacher/Profile/TeacherProfile'));
const TeacherNotifications = lazy(() => import('./pages/teacher/Notifications/TeacherNotifications'));
const LessonPage           = lazy(() => import('./pages/teacher/Lessons/LessonPage'));

const StudentDashboard     = lazy(() => import('./pages/student/Dashboard/StudentDashboard'));
const StudentSchedule      = lazy(() => import('./pages/student/Schedule/StudentSchedule'));
const StudentEnroll        = lazy(() => import('./pages/student/Enroll/StudentEnroll'));
const StudentSubscription  = lazy(() => import('./pages/student/Subscription/StudentSubscription'));
const StudentPayments      = lazy(() => import('./pages/student/Payments/StudentPayments'));
const StudentAttendance    = lazy(() => import('./pages/student/Attendance/StudentAttendance'));
const StudentProfile       = lazy(() => import('./pages/student/Profile/StudentProfile'));
const StudentNotifications = lazy(() => import('./pages/student/Notifications/StudentNotifications'));
const StudentCheckout      = lazy(() => import('./pages/student/Checkout/StudentCheckout'));
const StudentPaymentSuccess = lazy(() => import('./pages/student/PaymentSuccess/StudentPaymentSuccess'));
const PaymentResult        = lazy(() => import('./pages/student/Payments/PaymentResult'));

import type { Role } from './types';

interface ProtectedRouteProps {
  children: React.ReactNode;
  role: Role;
}

const ProtectedRoute = ({ children, role }: ProtectedRouteProps) => {
  const { user, isLoading } = useAuth();
  if (isLoading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to={`/${user.role}`} replace />;
  return <>{children}</>;
};

const RoleRedirect = () => {
  const { user, isLoading } = useAuth();
  if (isLoading) return null;
  if (!user) return <HomePage />;
  return <Navigate to={`/${user.role}`} replace />;
};

const AppRoutes = () => (
  <Suspense fallback={<Spinner centered />}>
    <Routes>
      {/* Public */}
      <Route element={<PublicLayout />}>
        <Route path="/"            element={<RoleRedirect />} />
        <Route path="/home"        element={<HomePage />} />
        <Route path="/schedule"    element={<SchedulePage />} />
        <Route path="/classes"     element={<ClassesPage />} />
        <Route path="/classes/:id" element={<ClassDetailPage />} />
        <Route path="/teachers"    element={<TeachersPage />} />
      </Route>
      <Route path="/login"           element={<LoginPage />} />
      <Route path="/register"        element={<RegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password"  element={<ResetPasswordPage />} />
      <Route path="/payment/result"  element={<PaymentResult />} />

      {/* Admin */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute role="admin">
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index                 element={<AdminDashboard />} />
        <Route path="users"          element={<AdminUsers />} />
        <Route path="schedule"           element={<AdminSchedule />} />
        <Route path="schedule/generator" element={<ScheduleGeneratorPage />} />
        <Route path="groups"         element={<AdminGroups />} />
        <Route path="subscriptions"  element={<AdminSubscriptions />} />
        <Route path="payments"       element={<AdminPayments />} />
        <Route path="reports"        element={<AdminReports />} />
        <Route path="notifications"  element={<AdminNotifications />} />
        <Route path="settings"       element={<AdminSettings />} />
        <Route path="teachers"       element={<AdminTeachers />} />
      </Route>

      {/* Teacher */}
      <Route
        path="/teacher"
        element={
          <ProtectedRoute role="teacher">
            <TeacherLayout />
          </ProtectedRoute>
        }
      >
        <Route index                element={<TeacherDashboard />} />
        <Route path="schedule"      element={<TeacherSchedule />} />
        <Route path="groups"        element={<TeacherGroups />} />
        <Route path="lessons/:id"   element={<LessonPage />} />
        <Route path="stats"         element={<TeacherStats />} />
        <Route path="profile"       element={<TeacherProfile />} />
        <Route path="notifications" element={<TeacherNotifications />} />
      </Route>

      {/* Student */}
      <Route
        path="/student"
        element={
          <ProtectedRoute role="student">
            <StudentLayout />
          </ProtectedRoute>
        }
      >
        <Route index                element={<StudentDashboard />} />
        <Route path="schedule"      element={<StudentSchedule />} />
        <Route path="enroll"        element={<StudentEnroll />} />
        <Route path="subscription"  element={<StudentSubscription />} />
        <Route path="payments"      element={<StudentPayments />} />
        <Route path="attendance"    element={<StudentAttendance />} />
        <Route path="profile"       element={<StudentProfile />} />
        <Route path="notifications" element={<StudentNotifications />} />
        <Route path="checkout"        element={<StudentCheckout />} />
        <Route path="payment-success" element={<StudentPaymentSuccess />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  </Suspense>
);

const App = () => (
  <BrowserRouter>
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  </BrowserRouter>
);

export default App;
