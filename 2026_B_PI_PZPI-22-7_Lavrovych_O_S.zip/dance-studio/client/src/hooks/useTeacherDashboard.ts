import { useState, useEffect } from "react";
import { getLessons } from "../api/lessons";
import { getGroups } from "../api/groups";
import { getAttendanceByLesson } from "../api/attendance";
import type { Lesson, DanceGroup } from "../types";
import { getMondayOfWeek, localToday } from '../utils/dateUtils';

interface WeekStat {
  day: string;
  count: number;
  enrolled: number;
}

interface DashboardData {
  todayLessons: Lesson[];
  weekLessons: Lesson[];
  groups: DanceGroup[];
  markedLessonIds: Set<number>;
  weekStats: WeekStat[];
  totalStudents: number;
  weekAttended: number;
  weekOccupancy: number;
}

const DAYS_SHORT = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд"];

const getDayIndex = (dateStr: string) => {
  const [y, m, d] = dateStr.slice(0, 10).split('-').map(Number);
  const day = new Date(y, m - 1, d).getDay();
  return day === 0 ? 6 : day - 1;
};

export const useTeacherDashboard = (teacherId: number | undefined) => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!teacherId) return;

    const today = localToday();
    const week = getMondayOfWeek();

    Promise.all([getLessons({ teacherId, week }), getGroups({ teacherId })])
      .then(async ([allLessons, groups]) => {
        const todayLessons = allLessons.filter((l) => l.lesson_date === today);

        const markedLessonIds = new Set<number>();
        await Promise.all(
          todayLessons.map(async (l) => {
            const att = await getAttendanceByLesson(l.id);
            if (att.some(r => r.marked_at != null)) markedLessonIds.add(l.id);
          }),
        );

        const weekStats: WeekStat[] = DAYS_SHORT.map((day, i) => {
          const dayLessons = allLessons.filter(
            (l) => getDayIndex(l.lesson_date) === i,
          );
          const enrolled = dayLessons.reduce(
            (sum, l) => sum + (l.hall_capacity - (l.free_spots ?? 0)),
            0,
          );
          return { day, count: dayLessons.length, enrolled };
        });

        const totalStudents = groups.reduce(
          (s, g) => s + (g.students_count || 0),
          0,
        );

        const weekAttended = allLessons.reduce(
          (sum, l) => sum + (l.hall_capacity - (l.free_spots ?? 0)),
          0,
        );

        const totalCapacity = allLessons.reduce(
          (sum, l) => sum + l.hall_capacity,
          0,
        );
        const weekOccupancy =
          totalCapacity > 0
            ? Math.round((weekAttended / totalCapacity) * 100)
            : 0;

        setData({
          todayLessons,
          weekLessons: allLessons,
          groups,
          markedLessonIds,
          weekStats,
          totalStudents,
          weekAttended,
          weekOccupancy,
        });
      })
      .finally(() => setLoading(false));
  }, [teacherId]);

  return { data, loading };
};
