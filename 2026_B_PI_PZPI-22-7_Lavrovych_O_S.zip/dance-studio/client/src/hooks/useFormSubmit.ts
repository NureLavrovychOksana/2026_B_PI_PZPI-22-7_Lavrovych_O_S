import { useState } from 'react';
import { useToast } from './useToast';

interface Options {
  onSuccess?: string;
  onError?:   string;
  onDone?:    () => void;
}

export const useFormSubmit = (fn: () => Promise<void>, opts: Options = {}) => {
  const [saving, setSaving] = useState(false);
  const { toasts, showToast, removeToast } = useToast();

  const submit = async () => {
    setSaving(true);
    try {
      await fn();
      if (opts.onSuccess) showToast(opts.onSuccess, 'success');
      opts.onDone?.();
    } catch (err: any) {
      const msg = err?.response?.data?.message ?? opts.onError ?? 'Помилка';
      showToast(msg, 'error');
    } finally {
      setSaving(false);
    }
  };

  return { submit, saving, toasts, removeToast };
};
