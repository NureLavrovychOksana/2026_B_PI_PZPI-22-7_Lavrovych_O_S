﻿import { LINEUP, DOT_COLORS, PHOTO_HEIGHTS } from '../../../data/homeData';
import styles from './ClassLineup.module.css';

const ClassLineup = () => (
  <section className={styles.section}>
    <p className={styles.eyebrow}>професійні рівні підготовки</p>
    <h2 className={styles.title}>CLASS LINEUP</h2>
    <div className={styles.grid}>
      {LINEUP.map(level => (
        <div key={level.label} className={styles.item}>
          <div className={styles.top}>
            <span
              className={styles.dot}
              style={{ background: DOT_COLORS[level.dotClass] }}
            />
            <span className={styles.name}>{level.label}</span>
          </div>
          <p className={styles.desc}>{level.desc}</p>
          <div className={styles.spacer} />
          <div
            className={styles.imgWrap}
            style={{ height: PHOTO_HEIGHTS[level.dotClass] }}
          >
            <img src={level.imgSrc} alt={level.imgAlt} loading="lazy" />
          </div>
        </div>
      ))}
    </div>
  </section>
);

export default ClassLineup;