import { Link, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import HeroSection     from './HeroSection';
import StylesPhotoGrid from './StylesPhotoGrid';
import ClassLineup     from './ClassLineup';
import TeacherCard     from '../../../components/ui/display/TeacherCard';
import { getTeachers } from '../../../api/teachers';
import { getPublicStats } from '../../../api/public';
import type { PublicStats } from '../../../api/public';
import { useRevealOnScroll } from '../../../hooks/useRevealOnScroll';
import { STYLES, REVIEWS } from '../../../data/homeData';
import shared from '../../../styles/public.module.css';
import { IconArrowRight } from '../../../components/ui/Icon';
import styles from './HomePage.module.css';

const ArrowRight = ({ size = 11 }: { size?: number }) => <IconArrowRight size={size} strokeWidth={1.8} />;

const SectionHead = ({ title, linkLabel, linkHref }: {
  title: string;
  linkLabel?: string;
  linkHref?: string;
}) => (
  <div className={styles.sectionHead}>
    <div className={styles.sectionTitle}>{title}</div>
    <div className={styles.sectionLine} />
    {linkLabel && linkHref && (
      <Link to={linkHref} className={styles.sectionLink}>
        {linkLabel} <ArrowRight />
      </Link>
    )}
  </div>
);

const HomePage = () => {
  const navigate = useNavigate();
  const { ref: stylesRef,   visible: stylesVisible }   = useRevealOnScroll();
  const { ref: teachersRef, visible: teachersVisible } = useRevealOnScroll();
  const { ref: reviewsRef,  visible: reviewsVisible }  = useRevealOnScroll();
  const { ref: ctaRef,      visible: ctaVisible }      = useRevealOnScroll();

  const [teachers, setTeachers] = useState<any[]>([]);
  const [pubStats, setPubStats] = useState<PublicStats | undefined>(undefined);

  useEffect(() => {
    getTeachers().then((data: any[]) => setTeachers(data.slice(0, 6)));
    getPublicStats().then(setPubStats).catch(() => {});
  }, []);

  return (
    <div className={styles.page}>

      <HeroSection stats={pubStats} />
      <StylesPhotoGrid />

      {/* STYLES */}
      <div className={styles.sectionWrap}>
        <SectionHead title="Стилі танців" linkLabel="Весь розклад" linkHref="/schedule" />
        <div ref={stylesRef} className={shared.grid4} style={{ marginBottom: 48 }}>
          {STYLES.map((s, i) => (
            <Link
              key={s.name}
              to="/classes"
              className={`${styles.styleCard} ${stylesVisible ? styles.visible : ''}`}
              style={{ transitionDelay: `${i * 0.06}s` }}
            >
              <div className={styles.styleNum}>{String(i + 1).padStart(2, '0')}</div>
              <div className={styles.styleName}>{s.name}</div>
              <div className={styles.styleDesc}>{s.desc}</div>
              <div className={styles.styleMeta}>
                {s.levels.map(l => (
                  <span key={l} className={styles.levelPill}>{l}</span>
                ))}
              </div>
              <div className={styles.styleAccent} />
            </Link>
          ))}
        </div>
      </div>

      <ClassLineup />

      {/* TEACHERS */}
      <div className={styles.sectionWrap}>
        <SectionHead title="Наші викладачі" linkLabel="Всі викладачі" linkHref="/teachers" />
        <div ref={teachersRef} className={shared.grid3} style={{ marginBottom: 48 }}>
          {teachers.length === 0
            ? Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className={styles.teacherSkeleton} />
              ))
            : teachers.map((t, i) => (
                <TeacherCard
                  key={t.id}
                  teacher={t}
                  visible={teachersVisible}
                  delay={i * 0.07}
                  showEnroll={false}
                  onClick={() => navigate(`/teachers?open=${t.id}`)}
                />
              ))
          }
        </div>
      </div>

      {/* REVIEWS */}
      <div className={styles.sectionWrapDark}>
        <div>
          <SectionHead title="Відгуки учнів" />
          <div ref={reviewsRef} className={shared.grid3} style={{ marginBottom: 48 }}>
            {REVIEWS.map((r, i) => (
              <div
                key={i}
                className={`${styles.reviewCard} ${reviewsVisible ? styles.visible : ''}`}
                style={{ transitionDelay: `${i * 0.07}s` }}
              >
                <div className={styles.reviewStars}>{'★'.repeat(r.stars)}</div>
                <p className={styles.reviewText}>"{r.text}"</p>
                <div className={styles.reviewAuthor}>{r.author}</div>
                <div className={styles.reviewStyle}>{r.style}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div
        ref={ctaRef}
        className={`${styles.ctaBand} ${ctaVisible ? styles.visible : ''}`}
      >
        <div className={styles.ctaTitle}>
          Перше заняття — безкоштовно.<br />Без умов і підписок.
        </div>
        <Link to={`/login?redirectTo=${encodeURIComponent('/student/enroll')}`} className={styles.ctaBtn}>
          Спробувати зараз <ArrowRight size={14} />
        </Link>
      </div>

      {/* FOOTER */}
      <footer className={styles.footer}>
        <div>
          <div className={styles.footerLogo}>{pubStats?.studio_name ?? 'MOVE STUDIO'}</div>
          {(pubStats?.studio_address || pubStats?.studio_phone) && (
            <div className={styles.footerAddress}>
              {[pubStats.studio_address, pubStats.studio_phone].filter(Boolean).join(' · ')}
            </div>
          )}
          {pubStats?.studio_email && (
            <a href={`mailto:${pubStats.studio_email}`} className={styles.footerAddress} style={{ display: 'block', marginTop: 2 }}>
              {pubStats.studio_email}
            </a>
          )}
        </div>
        <div className={styles.footerLinks}>
          {['Instagram', 'TikTok', 'YouTube'].map(name => (
            <a key={name} href="#" className={styles.footerLink}>{name}</a>
          ))}
        </div>
        <div className={styles.footerCopy}>© {new Date().getFullYear()} {pubStats?.studio_name ?? 'Move Studio'}</div>
      </footer>

    </div>
  );
};

export default HomePage;
