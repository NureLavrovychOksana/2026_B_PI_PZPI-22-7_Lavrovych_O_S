﻿import { Link } from "react-router-dom";
import { useCountUp } from "../../../hooks/useCountUp";
import { useRevealOnScroll } from "../../../hooks/useRevealOnScroll";
import type { PublicStats } from "../../../api/public";
import { IconArrowRight, IconMusic } from "../../../components/ui/Icon";
import styles from "./HeroSection.module.css";

const ArrowRight = ({ size = 14 }: { size?: number }) => <IconArrowRight size={size} strokeWidth={1.8} />;
const MusicIcon  = () => <IconMusic size={14} strokeWidth={1.8} />;

const StatItem = ({ target, suffix, label }: { target: number; suffix: string; label: string }) => {
  const { ref, visible } = useRevealOnScroll();
  const value = useCountUp(target, 1200, visible);
  return (
    <div ref={ref}>
      <span className={styles.statVal}>{value}{suffix}</span>
      <div className={styles.statLbl}>{label}</div>
    </div>
  );
};

interface HeroSectionProps {
  stats?: PublicStats;
}

const HeroSection = ({ stats }: HeroSectionProps) => {
  const statsItems = [
    { target: stats?.students_count ?? 100, suffix: "+", label: "учнів зараз" },
    { target: stats?.styles_count   ?? 8,   suffix: "",  label: "стилів танцю" },
    { target: stats?.weekly_lessons ?? 50,  suffix: "+", label: "занять на тиждень" },
    { target: stats?.halls_count    ?? 3,   suffix: "",  label: "зали" },
    { target: stats?.years_active   ?? 4,   suffix: "+", label: "роки роботи" },
  ];

  const stylesCount  = stats?.styles_count ?? 8;
  const hallsCount   = stats?.halls_count  ?? 3;
  const studentsText = stats ? `понад ${stats.students_count}` : 'понад 100';

  return (
    <>
      <section className={styles.hero}>
        <div className={`${styles.glow} ${styles.glow1}`} />
        <div className={`${styles.glow} ${styles.glow2}`} />
        <div className={styles.inner}>
          <div className={styles.eyebrow}>
            <MusicIcon />
            ХАРКІВ · ТАНЦЮВАЛЬНА СТУДІЯ
          </div>
          <h1 className={styles.title}>
            <span className={styles.line1}>РУХАЙСЯ</span>
            <span className={styles.line2}>ІНАКШЕ.</span>
            <span className={styles.line3}>ВІДЧУВАЙ МУЗИКУ.</span>
          </h1>
          <p className={styles.sub}>
            Місце де хіп-хоп зустрічається з бачатою, а брейк – з контемп.{' '}
            {stylesCount} стилів, {hallsCount} зали, {studentsText} учнів.
          </p>
          <div className={styles.actions}>
            <Link to={`/login?redirectTo=${encodeURIComponent('/student/enroll')}`} className={styles.btnPrimary}>
              Записатись на пробне <ArrowRight />
            </Link>
            <Link to="/schedule" className={styles.btnSecondary}>
              Переглянути розклад
            </Link>
            <span className={styles.note}>Перше заняття безкоштовно</span>
          </div>
        </div>
      </section>

      <div className={styles.statsBar}>
        {statsItems.map((s) => (
          <StatItem key={s.label} {...s} />
        ))}
      </div>
    </>
  );
};

export default HeroSection;
