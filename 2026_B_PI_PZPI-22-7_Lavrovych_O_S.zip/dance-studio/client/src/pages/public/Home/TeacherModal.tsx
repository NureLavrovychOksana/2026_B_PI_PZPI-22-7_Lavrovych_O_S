import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getLessons } from '../../../api/lessons';
import { useAuth } from '../../../context/AuthContext';
import { getMondayOfWeek, localToday } from '../../../utils/dateUtils';
import type { Lesson } from '../../../types';
import s from './TeacherModal.module.css';

interface Teacher {
  id: number;
  user_id: number;
  first_name: string;
  last_name: string;
  bio?: string;
  experience_years?: number;
  styles?: { id: number; name: string }[];
  students_count?: number;
  lessons_count?: number;
}

interface Props {
  teacher: Teacher;
  onClose: () => void;
}

const UA_DAYS   = ['Нд', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
const UA_MONTHS = ['січ', 'лют', 'бер', 'кві', 'тра', 'чер', 'лип', 'сер', 'вер', 'жов', 'лис', 'гру'];

const fmtDate = (iso: string) => {
  const d = new Date(iso);
  return `${UA_DAYS[d.getDay()]}, ${d.getDate()} ${UA_MONTHS[d.getMonth()]}`;
};

const TeacherModal = ({ teacher, onClose }: Props) => {
  const { user } = useAuth();
  const navigate  = useNavigate();
  const [lessons, setLessons]   = useState<Lesson[]>([]);
  const [loading, setLoading]   = useState(true);

  const initials = `${teacher.first_name[0]}${teacher.last_name[0]}`.toUpperCase();

  useEffect(() => {
    const week = getMondayOfWeek();
    getLessons({ teacherId: teacher.user_id, week })
      .then(setLessons)
      .catch(() => setLessons([]))
      .finally(() => setLoading(false));
  }, [teacher.user_id]);

  const onOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onClose();
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [onClose]);

  const handleEnroll = () => {
    if (!user) {
      navigate(`/login?redirect=/enroll/${teacher.id}`);
    } else {
      navigate(`/enroll/${teacher.id}`);
    }
    onClose();
  };

  const upcoming = lessons.filter(l => l.lesson_date >= localToday());

  return (
    <div className={s.overlay} onClick={onOverlayClick}>
      <div className={s.modal} onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className={s.header}>
          <span className={s.headerName}>{teacher.first_name} {teacher.last_name}</span>
          <button className={s.closeBtn} onClick={onClose}>✕</button>
        </div>

        {/* Body */}
        <div className={s.body}>

          {/* Top row */}
          <div className={s.topRow}>
            <div className={s.avatar}>{initials}</div>
            <div className={s.topInfo}>
              <div className={s.name}>{teacher.first_name} {teacher.last_name}</div>
              <div className={s.exp}>
                {teacher.experience_years
                  ? `${teacher.experience_years} років педагогічного досвіду`
                  : 'Викладач студії'}
              </div>
              {teacher.styles && teacher.styles.length > 0 && (
                <div className={s.tags}>
                  {teacher.styles.map(st => (
                    <span key={st.id} className={s.tag}>{st.name}</span>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Bio */}
          {teacher.bio && <p className={s.bio}>{teacher.bio}</p>}

          {/* Stats */}
          <div className={s.statsGrid}>
            <div className={s.statBox}>
              <span className={s.statVal}>{teacher.students_count ?? '—'}</span>
              <span className={s.statLbl}>Учнів</span>
            </div>
            <div className={s.statBox}>
              <span className={s.statVal}>{teacher.lessons_count ?? '—'}</span>
              <span className={s.statLbl}>Занять проведено</span>
            </div>
            <div className={s.statBox}>
              <span className={s.statVal}>{teacher.experience_years ?? '—'}</span>
              <span className={s.statLbl}>Років досвіду</span>
            </div>
          </div>

          {/* Schedule */}
          <div className={s.scheduleSection}>
            <div className={s.scheduleLabel}>РОЗКЛАД НА ТИЖДЕНЬ</div>
            {loading ? (
              <div className={s.spinnerWrap}>
                <div style={{ width: 20, height: 20, border: '2px solid #2a2a27', borderTopColor: 'var(--lime)', borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} />
              </div>
            ) : upcoming.length === 0 ? (
              <div className={s.noSchedule}>Занять на цьому тижні не заплановано</div>
            ) : (
              upcoming.map(l => (
                <div key={l.id} className={s.lessonRow}>
                  <span className={s.lessonTime}>{l.start_time.slice(0, 5)}</span>
                  <span className={s.lessonInfo}>{fmtDate(l.lesson_date)} · {l.style_name}</span>
                  <span className={s.lessonHall}>{l.hall_name}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer */}
        <div className={s.footer}>
          <button className={s.enrollBtn} onClick={handleEnroll}>
            Записатись до {teacher.first_name} →
          </button>
        </div>
      </div>
    </div>
  );
};

export default TeacherModal;
