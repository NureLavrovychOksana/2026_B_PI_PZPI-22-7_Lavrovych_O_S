import { Link } from 'react-router-dom';
import { PHOTO_GRID } from '../../../data/homeData';
import styles from './StylesPhotoGrid.module.css';

const StylesPhotoGrid = () => (
  <div className={styles.grid}>
    {PHOTO_GRID.map(p => (
      <Link
        key={p.label}
        to="/schedule"
        className={`${styles.cell} ${p.tall ? styles.tall : ''}`}
      >
        <img src={p.src} alt={p.label} loading="lazy" />
        <div className={styles.overlay}>
          <span className={styles.label}>{p.label}</span>
        </div>
      </Link>
    ))}
  </div>
);

export default StylesPhotoGrid;
