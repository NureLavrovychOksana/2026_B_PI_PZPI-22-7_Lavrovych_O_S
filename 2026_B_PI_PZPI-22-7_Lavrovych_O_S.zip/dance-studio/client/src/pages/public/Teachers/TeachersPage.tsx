import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getTeachers } from '../../../api/teachers';
import { getStyles } from '../../../api/styles';
import TeacherCard from '../../../components/ui/display/TeacherCard';
import TeacherModal from '../Home/TeacherModal';
import FilterPill from '../../../components/ui/display/FilterPill';
import EmptyState from '../../../components/ui/feedback/EmptyState';
import { SkeletonCard, SkeletonLine } from '../../../components/ui/feedback/Skeleton';
import type { DanceStyle } from '../../../types';
import shared from '../../../styles/public.module.css';
import styles from './TeachersPage.module.css';

const TeachersPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [allTeachers, setAllTeachers]   = useState<any[]>([]);
  const [teachers, setTeachers]         = useState<any[]>([]);
  const [danceStyles, setDanceStyles]   = useState<DanceStyle[]>([]);
  const [activeStyle, setActiveStyle]   = useState<string | null>(null);
  const [loading, setLoading]           = useState(true);
  const [loadingStyles, setLoadingStyles] = useState(true);
  const [selected, setSelected]         = useState<any | null>(null);

  useEffect(() => {
    getTeachers()
      .then((data: any[]) => {
        setAllTeachers(data);
        setTeachers(data);
        const openId = searchParams.get('open');
        if (openId) {
          const found = data.find((t: any) => String(t.id) === openId);
          if (found) setSelected(found);
          setSearchParams({}, { replace: true });
        }
      })
      .finally(() => setLoading(false));
    getStyles().then(setDanceStyles).finally(() => setLoadingStyles(false));
  }, []); 

  const filterByStyle = (styleName: string | null) => {
    setActiveStyle(styleName);
    if (!styleName) { setTeachers(allTeachers); return; }
    setTeachers(
      allTeachers.filter((t: any) =>
        t.styles?.some((s: any) => {
          const name = typeof s === 'string' ? s : (s?.name ?? '');
          return name.toLowerCase() === styleName.toLowerCase();
        })
      )
    );
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={shared.pageTitle}>Наші викладачі</h1>
          <p className={shared.pageSub}>
            {allTeachers.length > 0
              ? `${allTeachers.length} педагог${allTeachers.length === 1 ? '' : allTeachers.length < 5 ? 'а' : 'ів'} · понад ${allTeachers.reduce((s, t) => s + (t.experience_years ?? 0), 0)} років спільного досвіду`
              : 'Досвідчені тренери з різних напрямів танцю'
            }
          </p>
        </div>
        <div className={styles.filterInline}>
          <span className={shared.filterLabel}>СТИЛЬ:</span>
          <FilterPill active={!activeStyle} onClick={() => filterByStyle(null)}>Всі стилі</FilterPill>
          {loadingStyles
            ? Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className={styles.pillSkeleton} />
              ))
            : danceStyles.map(s => (
                <FilterPill key={s.id} active={activeStyle === s.name} onClick={() => filterByStyle(s.name)}>
                  {s.name}
                </FilterPill>
              ))
          }
        </div>
      </div>

      <div className={shared.grid3}>
        {loading
          ? Array.from({ length: 6 }).map((_, i) => (
              <SkeletonCard key={i}>
                <SkeletonLine width="50%" height="14px" />
                <SkeletonLine width="35%" />
                <SkeletonLine width="80%" />
                <SkeletonLine width="65%" />
              </SkeletonCard>
            ))
          : teachers.length === 0
            ? (
              <div style={{ gridColumn: '1 / -1' }}>
                <EmptyState
                  title="Викладачів не знайдено"
                  text="Спробуйте змінити фільтр"
                  action={
                    <FilterPill active={false} onClick={() => filterByStyle(null)}>Показати всіх</FilterPill>
                  }
                />
              </div>
            )
            : teachers.map(t => (
                <TeacherCard
                  key={t.id}
                  teacher={t}
                  onClick={() => setSelected(t)}
                />
              ))
        }
      </div>

      {selected && (
        <TeacherModal
          teacher={selected}
          onClose={() => setSelected(null)}
        />
      )}
    </div>
  );
};

export default TeachersPage;
