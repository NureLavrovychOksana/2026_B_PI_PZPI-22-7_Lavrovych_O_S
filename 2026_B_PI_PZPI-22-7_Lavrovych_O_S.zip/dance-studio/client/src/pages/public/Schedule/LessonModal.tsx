﻿import { Link, useNavigate } from 'react-router-dom';
import type { Lesson } from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import { useAuth } from '../../../context/AuthContext';
import styles from './LessonModal.module.css';

const DAYS_FULL = ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пʼятниця', 'Субота', 'Неділя'];

const getDayOfWeek = (dateStr: string) => {
  const [y, mo, d] = String(dateStr).slice(0, 10).split('-').map(Number);
  const day = new Date(y, mo - 1, d).getDay();
  return day === 0 ? 6 : day - 1;
};

interface Props {
  lesson:  Lesson;
  onClose: () => void;
}

const LessonModal = ({ lesson, onClose }: Props) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const initials = `${lesson.teacher_first_name?.[0] ?? ''}${lesson.teacher_last_name?.[0] ?? ''}`.toUpperCase();
  const free     = lesson.free_spots ?? 0;
  const cap      = lesson.hall_capacity ?? 0;
  const enrolled = cap - free;
  const fillPct  = cap > 0 ? Math.min((enrolled / cap) * 100, 100) : 0;
  const isFull   = free <= 0;
  const isLow    = !isFull && free <= cap * 0.3;

  const spotsCls = isFull ? styles.badgeError : isLow ? styles.badgeWarn : styles.badgeSuccess;
  const fillCls  = isFull ? styles.fillError  : isLow ? styles.fillWarn  : '';

  const enrollDestination = `/student/enroll?groupId=${lesson.group_id}&lessonId=${lesson.id}`;

  const handleEnroll = () => {
    if (isFull) return;
    if (!user) {
      navigate(`/login?redirectTo=${encodeURIComponent(enrollDestination)}`);
    } else if (user.role === 'student') {
      navigate(enrollDestination);
    }
  };

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>

        <div className={styles.header}>
          <div className={styles.day}>
            {DAYS_FULL[getDayOfWeek(lesson.lesson_date)]} · {String(lesson.lesson_date).slice(0, 10).split('-').reverse().join('.')}
          </div>
          <button className={styles.close} onClick={onClose}>×</button>
        </div>

        <div className={styles.body}>
          <div className={styles.top}>
            <div>
              <div className={styles.time}>{lesson.start_time.slice(0, 5)}</div>
              <div className={styles.styleName}>{lesson.style_name}</div>
              <div className={styles.subInfo}>
                {lesson.group_name} · {lesson.hall_name} · до {lesson.end_time.slice(0, 5)}
              </div>
            </div>
            <div className={styles.badges}>
              <span className={`${styles.badge} ${spotsCls}`}>
                {isFull ? 'Місць немає' : `${free} вільних місць`}
              </span>
              <span className={`${styles.badge} ${styles.badgeNeutral}`}>
                {LEVEL_LABELS[lesson.group_level]}
              </span>
            </div>
          </div>

          <div className={styles.teacher}>
            <div className={styles.avatar}>{initials}</div>
            <div>
              <div className={styles.teacherName}>
                {lesson.teacher_first_name} {lesson.teacher_last_name}
              </div>
              <div className={styles.teacherInfo}>{lesson.style_name}</div>
            </div>
          </div>

          <div className={styles.progressWrap}>
            <div className={styles.bar}>
              <div className={`${styles.fill} ${fillCls}`} style={{ width: `${fillPct}%` }} />
            </div>
            <div className={styles.barLabels}>
              <span>{enrolled} записано</span>
              <span>{cap} місць у залі</span>
            </div>
          </div>

          {user?.role === 'admin' || user?.role === 'teacher' ? null : (
            <button
              className={`${styles.btn} ${isFull ? styles.btnFull : ''}`}
              onClick={handleEnroll}
              disabled={isFull}
            >
              {isFull ? 'Місць немає' : 'Записатись на заняття →'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default LessonModal;