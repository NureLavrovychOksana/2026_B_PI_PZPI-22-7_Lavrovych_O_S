import { useMemo, Fragment } from 'react';
import { localToday, localDateStr } from '../../../utils/dateUtils';
import type { Lesson } from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import s from './WeekGrid.module.css';

const DAYS_SHORT = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];
const START_HOUR = 8;
const SLOT_MIN   = 30;

const timeToMin = (t: string) => {
  const [h, m] = String(t).slice(0, 5).split(':').map(Number);
  return h * 60 + m;
};

const getDayIndex = (dateStr: string) => {
  const [y, mo, d] = String(dateStr).slice(0, 10).split('-').map(Number);
  const day = new Date(y, mo - 1, d).getDay();
  return day === 0 ? 6 : day - 1;
};

interface PlacedLesson extends Lesson {
  day_of_week: number;
  rowStart:    number;
  rowSpan:     number;
  offset:      number;
}

// layout: rowStart/rowSpan from time, offset from parallel-collision detection
function buildGrid(lessons: Lesson[]): Record<number, PlacedLesson[]> {
  const grid: Record<number, PlacedLesson[]> = {};

  const sorted = [...lessons].sort(
    (a, b) =>
      getDayIndex(a.lesson_date) - getDayIndex(b.lesson_date) ||
      timeToMin(a.start_time) - timeToMin(b.start_time)
  );

  sorted.forEach(lesson => {
    const col      = getDayIndex(lesson.lesson_date);
    const rowStart = (timeToMin(lesson.start_time) - START_HOUR * 60) / SLOT_MIN;
    const rowSpan  = (timeToMin(lesson.end_time) - timeToMin(lesson.start_time)) / SLOT_MIN;

    if (!grid[col]) grid[col] = [];

    let offset = 0;
    while (
      grid[col].some(
        placed =>
          placed.offset === offset &&
          placed.rowStart < rowStart + rowSpan &&
          placed.rowStart + placed.rowSpan > rowStart
      )
    ) { offset++; }

    grid[col].push({ ...lesson, day_of_week: col, rowStart, rowSpan, offset });
  });

  return grid;
}

const getWeekDates = (monday: string) =>
  Array.from({ length: 7 }, (_, i) => {
    const [y, m, d] = monday.split('-').map(Number);
    return localDateStr(new Date(y, m - 1, d + i));
  });

interface Props {
  lessons:   Lesson[];
  loading:   boolean;
  weekStart: string;
  onSelect:  (l: Lesson) => void;
}

const WeekGrid = ({ lessons, loading, weekStart, onSelect }: Props) => {
  const weekDates = useMemo(() => getWeekDates(weekStart), [weekStart]);
  const today     = localToday();

  const grid = useMemo(() => buildGrid(lessons), [lessons]);

  const timeSlots = useMemo(() => {
    const times = new Set<string>();
    Object.values(grid).forEach(col =>
      col.forEach(l => times.add(String(l.start_time).slice(0, 5)))
    );
    return [...times].sort();
  }, [grid]);

  const lessonMap = useMemo(() => {
    const map: Record<number, Record<string, PlacedLesson[]>> = {};
    Object.entries(grid).forEach(([dayStr, col]) => {
      const day = Number(dayStr);
      map[day] = {};
      col.forEach(l => {
        const time = String(l.start_time).slice(0, 5);
        if (!map[day][time]) map[day][time] = [];
        map[day][time].push(l);
      });
    });
    return map;
  }, [grid]);

  if (loading) return <div className={s.msg}>Завантаження...</div>;
  if (!lessons.length) return <div className={s.msg}>Занять на цьому тижні не знайдено</div>;

  return (
    <div className={s.gridWrap}>
      <div className={s.grid}>

        {/* header */}
        <div className={s.headerCell} />
        {weekDates.map((date, i) => (
          <div key={date} className={`${s.headerCell} ${date === today ? s.headerCellToday : ''}`}>
            {DAYS_SHORT[i]}<br />
            <span className={s.dateNum}>{new Date(date + 'T12:00:00').getDate()}</span>
          </div>
        ))}

        {/* rows */}
        {timeSlots.map(time => (
          <Fragment key={time}>
            <div className={s.timeCell}>{time}</div>
            {Array.from({ length: 7 }, (_, dayIdx) => {
              const cell = lessonMap[dayIdx]?.[time];
              if (!cell?.length) {
                return <div key={dayIdx} className={s.emptyCell} />;
              }
              return (
                <div key={dayIdx} className={s.cellGroup}>
                  {cell.map(l => {
                    const free   = l.free_spots ?? 0;
                    const cap    = l.hall_capacity ?? 0;
                    const isFull = free <= 0;
                    const isLow  = !isFull && cap > 0 && free <= cap * 0.3;
                    return (
                      <div
                        key={l.id}
                        className={`${s.lessonCell} ${isFull ? s.lessonFull : ''}`}
                        onClick={() => onSelect(l)}
                      >
                        <span className={s.lessonStyle}>{l.style_name}</span>
                        <span className={s.lessonGroup}>
                          {LEVEL_LABELS[l.group_level] ?? l.group_level}
                        </span>
                        {l.hall_name && <span className={s.lessonHall}>{l.hall_name}</span>}
                        <span className={`${s.lessonTime} ${isFull ? s.spotsFull : isLow ? s.spotsLow : ''}`}>
                          {String(l.start_time).slice(0, 5)}–{String(l.end_time).slice(0, 5)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </Fragment>
        ))}

      </div>
    </div>
  );
};

export default WeekGrid;
