﻿import { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { getLessons } from '../../../api/lessons';
import { getStyles } from '../../../api/styles';
import { getMondayOfWeek, localDateStr } from '../../../utils/dateUtils';
import { useAuth } from '../../../context/AuthContext';
import ScheduleSearch  from './ScheduleSearch';
import ScheduleFilters from './ScheduleFilters';
import WeekGrid        from './WeekGrid';
import ListView        from './ListView';
import LessonModal     from './LessonModal';
import type { Lesson, DanceStyle } from '../../../types';
import { IconPlus } from '../../../components/ui/Icon';
import styles from './SchedulePage.module.css';

const formatWeekLabel = (monday: string) => {
  const s = new Date(monday);
  const e = new Date(monday);
  e.setDate(e.getDate() + 6);
  const f = (d: Date) => `${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}`;
  return `${f(s)} — ${f(e)}.${e.getFullYear()}`;
};

const SchedulePage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [lessons, setLessons]         = useState<Lesson[]>([]);
  const [danceStyles, setDanceStyles] = useState<DanceStyle[]>([]);
  const [loading, setLoading]         = useState(true);
  const [view, setView]               = useState<'week' | 'list'>(
    typeof window !== 'undefined' && window.innerWidth < 768 ? 'list' : 'week'
  );
  const [activeStyle, setActiveStyle] = useState('all');
  const [activeLevel, setActiveLevel] = useState('all');
  const [week, setWeek]               = useState(getMondayOfWeek());
  const [selected, setSelected]       = useState<Lesson | null>(null);
  const [search, setSearch]           = useState('');

  useEffect(() => { getStyles().then(setDanceStyles); }, []);

  useEffect(() => {
    setLoading(true);
    getLessons({ week }).then(setLessons).finally(() => setLoading(false));
  }, [week]);

  const filtered = useMemo(() => {
    let r = lessons;
    if (activeStyle !== 'all') r = r.filter(l => l.style_name === activeStyle);
    if (activeLevel !== 'all') r = r.filter(l => l.group_level === activeLevel);
    return r;
  }, [lessons, activeStyle, activeLevel]);

  const searchResults = useMemo(() => {
    if (!search.trim()) return [];
    const q = search.toLowerCase();
    return lessons.filter(l =>
      l.style_name.toLowerCase().includes(q) ||
      l.group_name.toLowerCase().includes(q) ||
      `${l.teacher_first_name} ${l.teacher_last_name}`.toLowerCase().includes(q)
    ).slice(0, 6);
  }, [search, lessons]);

  const shiftWeek = useCallback((dir: 1 | -1) => {
    const [y, m, d] = week.split('-').map(Number);
    const date = new Date(y, m - 1, d + dir * 7);
    setWeek(localDateStr(date));
  }, [week]);

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <div>
          <h1 className={styles.title}>Розклад занять</h1>
          <div className={styles.weekLabel}>Тиждень {formatWeekLabel(week)}</div>
        </div>
        <div className={styles.spacer} />
        <ScheduleSearch
          value={search}
          results={searchResults}
          onChange={setSearch}
          onSelect={setSelected}
          onClose={() => setSearch('')}
        />
        {user?.role !== 'admin' && user?.role !== 'teacher' && (
          <button
            className={styles.registerBtn}
            onClick={() => navigate(user?.role === 'student' ? '/student/enroll' : `/login?redirectTo=${encodeURIComponent('/student/enroll')}`)}
          >
            <IconPlus size={13} strokeWidth={1.8} />
            Записатись
          </button>
        )}
      </div>

      <ScheduleFilters
        styles={danceStyles}
        activeStyle={activeStyle}
        activeLevel={activeLevel}
        onStyle={setActiveStyle}
        onLevel={setActiveLevel}
      />

      <div className={styles.viewRow}>
        <div className={styles.tabs}>
          <button className={`${styles.tab} ${view === 'week' ? styles.tabActive : ''}`} onClick={() => setView('week')}>По тижню</button>
          <button className={`${styles.tab} ${view === 'list' ? styles.tabActive : ''}`} onClick={() => setView('list')}>Список</button>
        </div>
        <button className={styles.weekBtn} onClick={() => shiftWeek(-1)}>←</button>
        <button className={styles.weekBtn} onClick={() => shiftWeek(1)}>→</button>
        <div className={styles.spacer} />
        <div className={styles.count}>{filtered.length} занять на тижні</div>
      </div>

      {view === 'week'
        ? <WeekGrid lessons={filtered} loading={loading} weekStart={week} onSelect={setSelected} />
        : <ListView lessons={filtered} loading={loading} onSelect={setSelected} />
      }

      {selected && <LessonModal lesson={selected} onClose={() => setSelected(null)} />}
    </div>
  );
};

export default SchedulePage;