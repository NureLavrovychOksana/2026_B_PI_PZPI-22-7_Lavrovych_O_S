﻿import type { DanceStyle, GroupLevel } from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import FilterPill from '../../../components/ui/display/FilterPill';
import shared from '../../../styles/public.module.css';

const LEVELS: { value: GroupLevel | 'all'; label: string }[] = [
  { value: 'all',        label: 'Всі рівні' },
  { value: 'first_step', label: LEVEL_LABELS.first_step },
  { value: 'starter',    label: LEVEL_LABELS.starter },
  { value: 'learner',    label: LEVEL_LABELS.learner },
  { value: 'master',     label: LEVEL_LABELS.master },
  { value: 'pro',        label: LEVEL_LABELS.pro },
];

interface Props {
  styles:       DanceStyle[];
  activeStyle:  string;
  activeLevel:  string;
  onStyle:      (v: string) => void;
  onLevel:      (v: string) => void;
}

const ScheduleFilters = ({ styles: danceStyles, activeStyle, activeLevel, onStyle, onLevel }: Props) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
    <div className={shared.filters}>
      <span className={shared.filterLabel}>СТИЛЬ:</span>
      <FilterPill active={activeStyle === 'all'} onClick={() => onStyle('all')}>Всі</FilterPill>
      {danceStyles.map(s => (
        <FilterPill key={s.id} active={activeStyle === s.name} onClick={() => onStyle(s.name)}>
          {s.name}
        </FilterPill>
      ))}
    </div>

    <div className={shared.filters}>
      <span className={shared.filterLabel}>РІВЕНЬ:</span>
      {LEVELS.map(l => (
        <FilterPill key={l.value} active={activeLevel === l.value} onClick={() => onLevel(l.value)}>
          {l.label}
        </FilterPill>
      ))}
    </div>
  </div>
);

export default ScheduleFilters;