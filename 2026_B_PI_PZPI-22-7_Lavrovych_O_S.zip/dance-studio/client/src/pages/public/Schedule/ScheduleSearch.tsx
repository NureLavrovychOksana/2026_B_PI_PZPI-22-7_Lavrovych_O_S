﻿import { useEffect, useRef } from 'react';
import type { Lesson } from '../../../types';
import { IconSearch } from '../../../components/ui/Icon';
import styles from './ScheduleSearch.module.css';

const DAYS_FULL = ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пʼятниця', 'Субота', 'Неділя'];

const getDayOfWeek = (dateStr: string) => {
  const [y, mo, d] = String(dateStr).slice(0, 10).split('-').map(Number);
  const day = new Date(y, mo - 1, d).getDay();
  return day === 0 ? 6 : day - 1;
};

interface Props {
  value:    string;
  results:  Lesson[];
  onChange: (v: string) => void;
  onSelect: (l: Lesson) => void;
  onClose:  () => void;
}

const ScheduleSearch = ({ value, results, onChange, onSelect, onClose }: Props) => {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [onClose]);

  return (
    <div className={styles.wrap} ref={ref}>
      <IconSearch className={styles.icon} size={14} strokeWidth={1.8} />
      <input
        className={styles.input}
        placeholder="Пошук занять..."
        value={value}
        onChange={e => onChange(e.target.value)}
      />
      {results.length > 0 && (
        <div className={styles.dropdown}>
          {results.map(l => (
            <div
              key={l.id}
              className={styles.item}
              onClick={() => { onSelect(l); onClose(); }}
            >
              <span className={styles.time}>{l.start_time.slice(0, 5)}</span>
              <div>
                <div className={styles.name}>{l.style_name}</div>
                <div className={styles.meta}>
                  {DAYS_FULL[getDayOfWeek(l.lesson_date)]} · {l.hall_name}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ScheduleSearch;