﻿import type { Lesson } from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import styles from './ListView.module.css';

const DAYS_FULL = ['Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пʼятниця', 'Субота', 'Неділя'];

const getDayOfWeek = (dateStr: string) => {
  const [y, mo, d] = String(dateStr).slice(0, 10).split('-').map(Number);
  const day = new Date(y, mo - 1, d).getDay();
  return day === 0 ? 6 : day - 1;
};

interface Props {
  lessons:  Lesson[];
  loading:  boolean;
  onSelect: (l: Lesson) => void;
}

const ListView = ({ lessons, loading, onSelect }: Props) => {
  if (loading) return <div className={styles.msg}>Завантаження...</div>;

  const byDay: Record<number, Lesson[]> = {};
  for (let d = 0; d < 7; d++) byDay[d] = [];
  lessons.forEach(l => byDay[getDayOfWeek(l.lesson_date)].push(l));

  return (
    <div>
      {DAYS_FULL.map((dayName, dayIdx) => {
        const dayLessons = (byDay[dayIdx] || [])
          .sort((a, b) => a.start_time.localeCompare(b.start_time));
        if (!dayLessons.length) return null;

        return (
          <div key={dayIdx} className={styles.dayBlock}>
            <div className={styles.dayLabel}>{dayName.toUpperCase()}</div>
            {dayLessons.map(l => {
              const free   = l.free_spots ?? 0;
              const cap    = l.hall_capacity ?? 0;
              const isFull = free <= 0;
              const spotsCls = isFull
                ? styles.badgeError
                : free <= cap * 0.3
                  ? styles.badgeWarn
                  : styles.badgeSuccess;

              return (
                <div key={l.id} className={styles.item} onClick={() => onSelect(l)}>
                  <div className={styles.time}>{l.start_time.slice(0, 5)}</div>
                  <div className={styles.info}>
                    <div className={styles.name}>{l.style_name}</div>
                    <div className={styles.meta}>
                      {l.hall_name} · {l.teacher_first_name} {l.teacher_last_name} · {LEVEL_LABELS[l.group_level]}
                    </div>
                  </div>
                  <span className={`${styles.badge} ${spotsCls}`}>
                    {isFull ? 'Повно' : `${free} місць`}
                  </span>
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
};

export default ListView;