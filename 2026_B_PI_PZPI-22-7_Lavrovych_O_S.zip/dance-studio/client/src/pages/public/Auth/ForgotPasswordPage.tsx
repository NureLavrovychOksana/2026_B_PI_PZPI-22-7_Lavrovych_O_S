﻿import { useState } from 'react';
import { Link } from 'react-router-dom';
import { forgotPassword } from '../../../api/auth';
import Toast from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import { IconLayers, IconCheck } from '../../../components/ui/Icon';
import styles from './ForgotPasswordPage.module.css';

const ForgotPasswordPage = () => {
  const { toasts, showToast, removeToast } = useToast();
  const [email, setEmail]     = useState('');
  const [emailError, setEmailError] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent]       = useState(false);

  const validate = () => {
    if (!email) { setEmailError('Введіть email'); return false; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setEmailError('Невірний формат email'); return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      await forgotPassword(email);
      setSent(true);
    } catch {
      setSent(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.wrap}>
      <div className={`${styles.box} fade-in`}>

        <div className={styles.logoArea}>
          <div className={styles.logoDot}>
            <IconLayers size={24} strokeWidth={2.5} />
          </div>
          <div className={styles.title}>MOVE STUDIO</div>
          <div className={styles.subtitle}>Відновлення пароля</div>
        </div>

        <div className={styles.card}>
          {sent ? (
            <div className={styles.successBox}>
              <div className={styles.successIcon}>
                <IconCheck size={24} />
              </div>
              <div className={styles.successTitle}>Лист надіслано</div>
              <div className={styles.successText}>
                Якщо акаунт з адресою <strong>{email}</strong> існує,
                ви отримаєте лист з інструкціями для відновлення пароля.
              </div>
              <Link to="/login" className={styles.btn} style={{ textDecoration: 'none' }}>
                Повернутися до входу
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.inputWrap}>
                <label className={styles.label}>EMAIL</label>
                <input
                  className={`${styles.input} ${emailError ? styles.inputError : ''}`}
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={e => { setEmail(e.target.value); setEmailError(''); }}
                  autoComplete="email"
                />
                {emailError && <div className={styles.errorMsg}>{emailError}</div>}
              </div>

              <button className={styles.btn} type="submit" disabled={loading}>
                {loading ? <div className={styles.spinner} /> : 'Надіслати інструкції'}
              </button>

              <Link to="/login" className={styles.backLink}>
                ← Повернутися до входу
              </Link>
            </form>
          )}
        </div>
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default ForgotPasswordPage;