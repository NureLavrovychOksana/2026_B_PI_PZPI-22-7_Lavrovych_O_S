﻿import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext';
import { register as registerApi } from '../../../api/auth';
import Toast from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import { validateName, validateEmail, validatePhone, validatePassword } from '../../../utils/validators';
import { IconLayers } from '../../../components/ui/Icon';
import styles from './RegisterPage.module.css';

interface FormData {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  password: string;
  confirm: string;
}

interface FormErrors {
  first_name?: string;
  last_name?: string;
  email?: string;
  phone?: string;
  password?: string;
  confirm?: string;
}

const RegisterPage = () => {
  const { login } = useAuth();
  const navigate  = useNavigate();
  const [searchParams] = useSearchParams();
  const { toasts, showToast, removeToast } = useToast();

  const [form, setForm]     = useState<FormData>({
    first_name: '', last_name: '', email: '',
    phone: '', password: '', confirm: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [loading, setLoading] = useState(false);

  const set = (field: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm(p => ({ ...p, [field]: e.target.value }));
    setErrors(p => ({ ...p, [field]: undefined }));
  };

  const validate = (): boolean => {
    const e: FormErrors = {};
    const firstErr = validateName(form.first_name);
    if (firstErr) e.first_name = firstErr;
    const lastErr = validateName(form.last_name);
    if (lastErr) e.last_name = lastErr;
    const emailErr = validateEmail(form.email);
    if (emailErr) e.email = emailErr;
    const phoneErr = validatePhone(form.phone);
    if (phoneErr) e.phone = phoneErr;
    const passErr = validatePassword(form.password);
    if (passErr) e.password = passErr;
    if (!e.password && form.password !== form.confirm) e.confirm = 'Паролі не співпадають';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      const data = await registerApi({
        first_name: form.first_name.trim(),
        last_name:  form.last_name.trim(),
        email:      form.email.trim(),
        password:   form.password,
        phone:      form.phone.trim(),
      });
      login(data.token, data.user);
      const redirectTo = searchParams.get('redirectTo');
      navigate(redirectTo || '/student');
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Помилка реєстрації';
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.wrap}>
      <div className={`${styles.box} fade-in`}>

        <Link to="/" className={styles.logoArea} style={{ textDecoration: 'none' }}>
          <div className={styles.logoDot}>
            <IconLayers size={24} strokeWidth={2.5} />
          </div>
          <div className={styles.title}>MOVE STUDIO</div>
          <div className={styles.subtitle}>Створіть акаунт учня</div>
        </Link>

        <div className={styles.card}>
          <form onSubmit={handleSubmit} noValidate>

            <div className={styles.row}>
              <div className={styles.inputWrap}>
                <label className={styles.label}>ІМʼЯ</label>
                <input
                  className={`${styles.input} ${errors.first_name ? styles.inputError : ''}`}
                  type="text"
                  placeholder="Оксана"
                  value={form.first_name}
                  onChange={set('first_name')}
                  autoComplete="given-name"
                />
                {errors.first_name && <div className={styles.errorMsg}>{errors.first_name}</div>}
              </div>

              <div className={styles.inputWrap}>
                <label className={styles.label}>ПРІЗВИЩЕ</label>
                <input
                  className={`${styles.input} ${errors.last_name ? styles.inputError : ''}`}
                  type="text"
                  placeholder="Іванова"
                  value={form.last_name}
                  onChange={set('last_name')}
                  autoComplete="family-name"
                />
                {errors.last_name && <div className={styles.errorMsg}>{errors.last_name}</div>}
              </div>
            </div>

            <div className={styles.inputWrap}>
              <label className={styles.label}>EMAIL</label>
              <input
                className={`${styles.input} ${errors.email ? styles.inputError : ''}`}
                type="email"
                placeholder="your@email.com"
                value={form.email}
                onChange={set('email')}
                autoComplete="email"
              />
              {errors.email && <div className={styles.errorMsg}>{errors.email}</div>}
            </div>

            <div className={styles.inputWrap}>
              <label className={styles.label}>ТЕЛЕФОН</label>
              <input
                className={`${styles.input} ${errors.phone ? styles.inputError : ''}`}
                type="tel"
                placeholder="+380991234567"
                value={form.phone}
                onChange={set('phone')}
                autoComplete="tel"
              />
              {errors.phone && <div className={styles.errorMsg}>{errors.phone}</div>}
            </div>

            <div className={styles.inputWrap}>
              <label className={styles.label}>ПАРОЛЬ</label>
              <input
                className={`${styles.input} ${errors.password ? styles.inputError : ''}`}
                type="password"
                placeholder="••••••••"
                value={form.password}
                onChange={set('password')}
                autoComplete="new-password"
              />
              {errors.password
                ? <div className={styles.errorMsg}>{errors.password}</div>
                : null
              }
            </div>

            <div className={styles.inputWrap}>
              <label className={styles.label}>ПІДТВЕРДЖЕННЯ ПАРОЛЯ</label>
              <input
                className={`${styles.input} ${errors.confirm ? styles.inputError : ''}`}
                type="password"
                placeholder="••••••••"
                value={form.confirm}
                onChange={set('confirm')}
                autoComplete="new-password"
              />
              {errors.confirm && <div className={styles.errorMsg}>{errors.confirm}</div>}
            </div>

            <button className={styles.btn} type="submit" disabled={loading}>
              {loading ? <div className={styles.spinner} /> : 'Зареєструватися'}
            </button>
          </form>

          <div className={styles.sep}>або</div>

          <Link to="/login" className={styles.loginLink}>
            Вже є акаунт? <span>Увійти</span>
          </Link>
        </div>
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default RegisterPage;