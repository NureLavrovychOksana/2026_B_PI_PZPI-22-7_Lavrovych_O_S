﻿import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { resetPassword } from '../../../api/auth';
import Toast from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import { IconLayers, IconCheck } from '../../../components/ui/Icon';
import styles from './ForgotPasswordPage.module.css';

const ResetPasswordPage = () => {
  const [searchParams]  = useSearchParams();
  const navigate        = useNavigate();
  const { toasts, showToast, removeToast } = useToast();
  const token = searchParams.get('token') || '';

  const [password, setPassword]   = useState('');
  const [confirm, setConfirm]     = useState('');
  const [errors, setErrors]       = useState<{ password?: string; confirm?: string }>({});
  const [loading, setLoading]     = useState(false);
  const [done, setDone]           = useState(false);

  const validate = () => {
    const e: typeof errors = {};
    if (!password)           e.password = 'Введіть пароль';
    else if (password.length < 6) e.password = 'Мінімум 6 символів';
    if (password !== confirm) e.confirm = 'Паролі не співпадають';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) { showToast('Недійсне посилання', 'error'); return; }
    if (!validate()) return;

    setLoading(true);
    try {
      await resetPassword(token, password);
      setDone(true);
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка. Спробуйте ще раз.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.wrap}>
      <div className={`${styles.box} fade-in`}>

        <div className={styles.logoArea}>
          <div className={styles.logoDot}>
            <IconLayers size={24} strokeWidth={2.5} />
          </div>
          <div className={styles.title}>MOVE STUDIO</div>
          <div className={styles.subtitle}>Новий пароль</div>
        </div>

        <div className={styles.card}>
          {done ? (
            <div className={styles.successBox}>
              <div className={styles.successIcon}>
                <IconCheck size={24} />
              </div>
              <div className={styles.successTitle}>Пароль змінено</div>
              <div className={styles.successText}>
                Тепер ви можете увійти з новим паролем.
              </div>
              <Link
                to="/login"
                className={styles.btn}
                style={{ textDecoration: 'none' }}
                onClick={() => navigate('/login')}
              >
                Увійти
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <div className={styles.inputWrap}>
                <label className={styles.label}>НОВИЙ ПАРОЛЬ</label>
                <input
                  className={`${styles.input} ${errors.password ? styles.inputError : ''}`}
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={e => { setPassword(e.target.value); setErrors(p => ({ ...p, password: undefined })); }}
                  autoComplete="new-password"
                />
                {errors.password && <div className={styles.errorMsg}>{errors.password}</div>}
              </div>

              <div className={styles.inputWrap}>
                <label className={styles.label}>ПІДТВЕРДЖЕННЯ ПАРОЛЯ</label>
                <input
                  className={`${styles.input} ${errors.confirm ? styles.inputError : ''}`}
                  type="password"
                  placeholder="••••••••"
                  value={confirm}
                  onChange={e => { setConfirm(e.target.value); setErrors(p => ({ ...p, confirm: undefined })); }}
                  autoComplete="new-password"
                />
                {errors.confirm && <div className={styles.errorMsg}>{errors.confirm}</div>}
              </div>

              <button className={styles.btn} type="submit" disabled={loading}>
                {loading ? <div className={styles.spinner} /> : 'Зберегти пароль'}
              </button>

              <Link to="/login" className={styles.backLink}>
                ← Повернутися до входу
              </Link>
            </form>
          )}
        </div>
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default ResetPasswordPage;