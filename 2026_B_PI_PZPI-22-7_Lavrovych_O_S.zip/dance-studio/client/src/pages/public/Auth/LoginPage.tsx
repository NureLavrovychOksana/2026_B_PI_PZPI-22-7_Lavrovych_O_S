﻿import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext';
import { login as loginApi } from '../../../api/auth';
import Toast from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import { validateEmail } from '../../../utils/validators';
import { IconLayers } from '../../../components/ui/Icon';
import styles from './LoginPage.module.css';

const LoginPage = () => {
  const { login } = useAuth();
  const navigate  = useNavigate();
  const [searchParams] = useSearchParams();
  const { toasts, showToast, removeToast } = useToast();

  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [errors, setErrors]     = useState<{ email?: string; password?: string }>({});

  const validate = () => {
    const e: typeof errors = {};
    if (!email)    e.email    = 'Введіть email';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = 'Невірний формат email';
    if (!password) e.password = 'Введіть пароль';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      const data = await loginApi(email, password);
      login(data.token, data.user);

      const redirectTo = searchParams.get('redirectTo');
      if (redirectTo && data.user.role === 'student') {
        navigate(redirectTo);
      } else {
        const redirectMap: Record<string, string> = {
          admin:   '/admin',
          teacher: '/teacher',
          student: '/student',
        };
        navigate(redirectMap[data.user.role] || '/');
      }
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Помилка входу';
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.wrap}>
      <div className={`${styles.box} fade-in`}>

        <Link to="/" className={styles.logoArea} style={{ textDecoration: 'none' }}>
          <div className={styles.logoDot}>
            <IconLayers size={24} strokeWidth={2.5} />
          </div>
          <div className={styles.title}>MOVE STUDIO</div>
          <div className={styles.subtitle}>Увійдіть до свого кабінету</div>
        </Link>

        <div className={styles.card}>
          <form onSubmit={handleSubmit} noValidate>
            <div className={styles.inputWrap}>
              <label className={styles.label}>EMAIL</label>
              <input
                className={`${styles.input} ${errors.email ? styles.inputError : ''}`}
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={e => { setEmail(e.target.value); setErrors(p => ({ ...p, email: undefined })); }}
                onBlur={() => { const err = validateEmail(email); if (err) setErrors(p => ({ ...p, email: err })); }}
                autoComplete="email"
              />
              {errors.email && <div className={styles.errorMsg}>{errors.email}</div>}
            </div>

            <div className={styles.inputWrap}>
              <label className={styles.label}>ПАРОЛЬ</label>
              <input
                className={`${styles.input} ${errors.password ? styles.inputError : ''}`}
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={e => { setPassword(e.target.value); setErrors(p => ({ ...p, password: undefined })); }}
                onBlur={() => { if (!password) setErrors(p => ({ ...p, password: 'Введіть пароль' })); }}
                autoComplete="current-password"
              />
              {errors.password && <div className={styles.errorMsg}>{errors.password}</div>}
            </div>

            <Link to="/forgot-password" className={styles.forgotLink}>
              Забули пароль?
            </Link>

            <button className={styles.btn} type="submit" disabled={loading}>
              {loading ? <div className={styles.spinner} /> : 'Увійти'}
            </button>
          </form>

          <div className={styles.sep}>або</div>

          <Link
            to={searchParams.get('redirectTo') ? `/register?redirectTo=${encodeURIComponent(searchParams.get('redirectTo')!)}` : '/register'}
            className={styles.registerLink}
          >
            Немає акаунту? <span>Зареєструватися</span>
          </Link>
        </div>
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default LoginPage;