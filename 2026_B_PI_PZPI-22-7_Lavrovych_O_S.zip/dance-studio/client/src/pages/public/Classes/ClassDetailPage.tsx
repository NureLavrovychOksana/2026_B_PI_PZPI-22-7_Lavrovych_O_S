﻿import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { localToday } from '../../../utils/dateUtils';
import { getGroupById } from '../../../api/groups';
import { getLessons } from '../../../api/lessons';
import { useAuth } from '../../../context/AuthContext';
import Spinner from '../../../components/ui/feedback/Spinner';
import EmptyState from '../../../components/ui/feedback/EmptyState';
import type { DanceGroup, Lesson } from '../../../types';
import { IconArrowLeft, IconHome, IconUser } from '../../../components/ui/Icon';
import styles from './ClassDetailPage.module.css';

const DAYS_UK = ['Нд', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];

const formatDate = (dateStr: string) => {
  const d = new Date(dateStr);
  return `${DAYS_UK[d.getDay()]}, ${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
};

const ClassDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [group, setGroup]     = useState<DanceGroup | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!id) return;
    Promise.all([
      getGroupById(Number(id)),
      getLessons({ groupId: Number(id) }),
    ])
      .then(([g, l]) => {
        setGroup(g);
        const today = localToday();
        setLessons(l.filter(lesson => lesson.lesson_date >= today).slice(0, 8));
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <Spinner size="lg" centered />;

  if (notFound || !group) return (
    <div style={{ padding: '40px 36px' }}>
      <EmptyState
        title="Групу не знайдено"
        text="Можливо, вона була видалена або ви перейшли за невірним посиланням"
        action={
          <Link to="/classes" className={styles.back}>← Повернутися до класів</Link>
        }
      />
    </div>
  );

  const initials = `${group.teacher_first_name?.[0] ?? ''}${group.teacher_last_name?.[0] ?? ''}`.toUpperCase();

  const handleCta = () => {
    if (!user) {
      navigate(`/login?redirectTo=${encodeURIComponent(`/student/enroll?groupId=${group!.id}`)}`);
    } else if (user.role === 'student') {
      navigate(`/student/enroll?groupId=${group!.id}`);
    }
  };

  return (
    <div className={styles.page}>
      <Link to="/classes" className={styles.back}>
        <IconArrowLeft size={14} />
        Всі класи
      </Link>

      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerInfo}>
          <div className={styles.style}>{group.style_name}</div>
          <h1 className={styles.name}>{group.name}</h1>

          <div className={styles.metaRow}>
            <IconHome size={14} strokeWidth={1.8} />
            {group.hall_name}, місткість {group.hall_capacity} осіб
          </div>

          <div className={styles.metaRow}>
            <IconUser size={14} strokeWidth={1.8} />
            {group.teacher_first_name} {group.teacher_last_name}
          </div>
        </div>

        {user?.role !== 'admin' && user?.role !== 'teacher' && (
          <div className={styles.ctaBox}>
            <button className={styles.btnPrimary} onClick={handleCta}>
              Записатися
            </button>
            {!user && <div className={styles.note}>Потрібна реєстрація</div>}
          </div>
        )}
      </div>

      {/* Details */}
      <div className={styles.grid}>

        {/* Teacher */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>ВИКЛАДАЧ</div>
          <div className={styles.teacherRow}>
            <div className={styles.teacherAvatar}>{initials}</div>
            <div>
              <div className={styles.teacherName}>
                {group.teacher_first_name} {group.teacher_last_name}
              </div>
              <div className={styles.teacherExp}>{group.style_name}</div>
            </div>
          </div>
        </div>

        {/* Hall */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>ЗАЛ</div>
          <div className={styles.metaRow} style={{ marginBottom: 0 }}>
            <IconHome size={16} strokeWidth={1.8} />
            <div>
              <div style={{ color: 'var(--paper)', fontWeight: 600, marginBottom: 2 }}>
                {group.hall_name}
              </div>
              <div style={{ fontSize: 12, color: 'var(--graphite)' }}>
                До {group.hall_capacity} осіб
              </div>
            </div>
          </div>
        </div>

        {/* Schedule */}
        <div className={styles.card} style={{ gridColumn: '1 / -1' }}>
          <div className={styles.cardTitle}>НАЙБЛИЖЧІ ЗАНЯТТЯ</div>
          {lessons.length === 0
            ? <EmptyState title="Занять не заплановано" />
            : lessons.map(l => (
                <div key={l.id} className={styles.lessonItem}>
                  <div className={styles.lessonDate}>{formatDate(l.lesson_date)}</div>
                  <div className={styles.lessonTime}>
                    {l.start_time.slice(0, 5)} – {l.end_time.slice(0, 5)}
                  </div>
                  <div className={styles.lessonHall}>{l.hall_name}</div>
                </div>
              ))
          }
        </div>

      </div>
    </div>
  );
};

export default ClassDetailPage;