﻿import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { getGroups } from '../../../api/groups';
import { getStyles } from '../../../api/styles';
import GroupCard from '../../../components/ui/display/GroupCard';
import EmptyState from '../../../components/ui/feedback/EmptyState';
import { SkeletonCard, SkeletonLine } from '../../../components/ui/feedback/Skeleton';
import type { DanceGroup, DanceStyle } from '../../../types';
import FilterPill from '../../../components/ui/display/FilterPill';
import shared from '../../../styles/public.module.css';
import styles from './ClassesPage.module.css';

const ClassesPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  const [groups, setGroups]       = useState<DanceGroup[]>([]);
  const [danceStyles, setStyles]  = useState<DanceStyle[]>([]);
  const [loading, setLoading]     = useState(true);
  const [loadingStyles, setLoadingStyles] = useState(true);

  const activeStyleId = searchParams.get('style') ? Number(searchParams.get('style')) : null;

  useEffect(() => {
    getStyles().then(setStyles).finally(() => setLoadingStyles(false));
  }, []);

  useEffect(() => {
    setLoading(true);
    getGroups(activeStyleId ? { styleId: activeStyleId } : undefined)
      .then(data => setGroups(data.filter(g => g.status === 'active')))
      .finally(() => setLoading(false));
  }, [activeStyleId]);

  const setFilter = (styleId: number | null) => {
    if (styleId) setSearchParams({ style: String(styleId) });
    else setSearchParams({});
  };

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        <h1 className={shared.pageTitle}>Класи та групи</h1>
      </div>

      <div className={shared.filters}>
        <span className={shared.filterLabel}>СТИЛЬ:</span>
        <FilterPill active={!activeStyleId} onClick={() => setFilter(null)}>Всі</FilterPill>
        {loadingStyles
          ? Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className={styles.pillSkeleton} />
            ))
          : danceStyles.map(s => (
              <FilterPill key={s.id} active={activeStyleId === s.id} onClick={() => setFilter(s.id)}>
                {s.name}
              </FilterPill>
            ))
        }
      </div>

      <div className={shared.grid3}>
        {loading
          ? Array.from({ length: 6 }).map((_, i) => (
              <SkeletonCard key={i}>
                <SkeletonLine width="60%" height="14px" />
                <SkeletonLine width="40%" height="10px" />
                <SkeletonLine width="80%" />
                <SkeletonLine width="50%" />
              </SkeletonCard>
            ))
          : groups.length === 0
            ? (
              <div style={{ gridColumn: '1 / -1' }}>
                <EmptyState
                  title="Груп не знайдено"
                  text="Спробуйте змінити фільтр або перегляньте всі доступні напрями"
                  action={
                    <FilterPill active={false} onClick={() => setFilter(null)}>Показати всі</FilterPill>
                  }
                />
              </div>
            )
            : groups.map(g => (
                <GroupCard
                  key={g.id}
                  group={g}
                  onClick={() => navigate(`/classes/${g.id}`)}
                />
              ))
        }
      </div>
    </div>
  );
};

export default ClassesPage;