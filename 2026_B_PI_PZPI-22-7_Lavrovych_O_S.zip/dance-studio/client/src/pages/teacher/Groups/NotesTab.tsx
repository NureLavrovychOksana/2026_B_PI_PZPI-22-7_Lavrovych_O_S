import { useEffect, useState, useMemo } from 'react';
import { getLessonNotesByGroup } from '../../../api/lessons';
import Spinner    from '../../../components/ui/feedback/Spinner';
import EmptyState from '../../../components/ui/feedback/EmptyState';
import s from './TeacherGroups.module.css';

const UA_DAYS   = ['Нд','Пн','Вт','Ср','Чт','Пт','Сб'];
const UA_MONTHS = ['січ','лют','бер','кві','тра','чер','лип','сер','вер','жов','лис','гру'];

type NoteEntry = {
  id: number;
  lesson_date: string;
  start_time: string;
  end_time: string;
  notes: string;
  style_name: string;
  author_first_name: string | null;
  author_last_name: string | null;
};

const NotesTab = ({ groupId }: { groupId: number }) => {
  const [notes, setNotes]               = useState<NoteEntry[]>([]);
  const [loading, setLoading]           = useState(true);
  const [authorFilter, setAuthorFilter] = useState('');

  useEffect(() => {
    getLessonNotesByGroup(groupId)
      .then(data => setNotes(data as NoteEntry[]))
      .finally(() => setLoading(false));
  }, [groupId]);

  const authors = useMemo(() => {
    const seen = new Set<string>();
    const list: string[] = [];
    notes.forEach(n => {
      if (n.author_first_name && n.author_last_name) {
        const full = `${n.author_first_name} ${n.author_last_name}`;
        if (!seen.has(full)) { seen.add(full); list.push(full); }
      }
    });
    return list;
  }, [notes]);

  const filtered = useMemo(() => {
    if (!authorFilter) return notes;
    return notes.filter(n => `${n.author_first_name} ${n.author_last_name}` === authorFilter);
  }, [notes, authorFilter]);

  if (loading) return <Spinner centered />;

  return (
    <div className={s.notesTab}>
      {authors.length > 1 && (
        <div className={s.notesFilter}>
          <select
            className={s.weekNavLabel}
            style={{ background: 'var(--coal-3)', border: '1px solid #2a2a27', borderRadius: 'var(--r)', color: 'var(--paper)', padding: '5px 10px', fontSize: 11 }}
            value={authorFilter}
            onChange={e => setAuthorFilter(e.target.value)}
          >
            <option value="">Всі викладачі</option>
            {authors.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>
      )}
      {filtered.length === 0 ? (
        <EmptyState title="Нотаток немає" text="Нотатки з'являться після занять" />
      ) : (
        <div className={s.notesList}>
          {filtered.map(n => {
            const d = new Date(n.lesson_date);
            const dateLabel = `${UA_DAYS[d.getDay()]}, ${d.getDate()} ${UA_MONTHS[d.getMonth()]}`;
            const author = n.author_first_name ? `${n.author_first_name} ${n.author_last_name}` : null;
            return (
              <div key={n.id} className={s.noteCard}>
                <div className={s.noteCardLine} />
                <div className={s.noteCardContent}>
                  <div className={s.noteMeta}>
                    <span className={s.noteDate}>{dateLabel}</span>
                    <span className={s.noteTime}>{n.start_time.slice(0, 5)}–{n.end_time.slice(0, 5)}</span>
                    <span className={s.noteStyle}>{n.style_name}</span>
                    {author && <span className={s.noteAuthor}>{author}</span>}
                  </div>
                  <p className={s.noteText}>{n.notes}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default NotesTab;
