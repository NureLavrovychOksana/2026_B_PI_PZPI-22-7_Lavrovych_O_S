import { useEffect, useState } from 'react';
import { getGroups }  from '../../../api/groups';
import PageHeader     from '../../../components/ui/display/PageHeader';
import GroupCard      from '../../../components/ui/display/GroupCard';
import Modal          from '../../../components/ui/overlay/Modal';
import Spinner        from '../../../components/ui/feedback/Spinner';
import EmptyState     from '../../../components/ui/feedback/EmptyState';
import { LEVEL_LABELS } from '../../../types';
import type { DanceGroup } from '../../../types';
import LessonsTab from './LessonsTab';
import NotesTab   from './NotesTab';
import s from './TeacherGroups.module.css';

type Tab = 'lessons' | 'notes';

const TeacherGroups = () => {
  const [groups, setGroups]   = useState<DanceGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive]   = useState<DanceGroup | null>(null);
  const [tab, setTab]         = useState<Tab>('lessons');

  useEffect(() => {
    getGroups().then(setGroups).finally(() => setLoading(false));
  }, []);

  const openGroup  = (g: DanceGroup) => { setActive(g); setTab('lessons'); };
  const closeGroup = () => setActive(null);

  if (loading) return <Spinner centered />;

  const activeCount = groups.filter(g => g.status === 'active').length;

  return (
    <div>
      <PageHeader title="Мої групи" sub={`${groups.length} груп · ${activeCount} активних`} />

      {groups.length === 0 ? (
        <EmptyState title="Груп немає" text="Зверніться до адміністратора" />
      ) : (
        <div className={s.grid}>
          {groups.map(g => (
            <GroupCard
              key={g.id}
              group={g}
              onClick={() => openGroup(g)}
              footer={
                <>
                  <span className={s.levelChip}>{LEVEL_LABELS[g.level]}</span>
                  <button
                    type="button"
                    className={s.viewBtn}
                    onClick={e => { e.stopPropagation(); openGroup(g); }}
                  >
                    Деталі →
                  </button>
                </>
              }
            />
          ))}
        </div>
      )}

      {active && (
        <Modal
          title={active.name}
          onClose={closeGroup}
          wide
          footer={
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flex: 1 }}>
              <span style={{ fontSize: 11, color: 'var(--graphite)', fontFamily: 'var(--font-mono)' }}>
                {active.style_name} · {LEVEL_LABELS[active.level]} · {active.hall_name}
              </span>
              <div style={{ flex: 1 }} />
              <button
                style={{ fontSize: 12, padding: '6px 14px', background: 'var(--coal-3)', border: '1px solid #2a2a27', borderRadius: 'var(--r)', color: 'var(--mid)', cursor: 'pointer' }}
                onClick={closeGroup}
              >
                Закрити
              </button>
            </div>
          }
        >
          <div className={s.tabs}>
            <button className={`${s.tab} ${tab === 'lessons' ? s.tabActive : ''}`} onClick={() => setTab('lessons')}>
              Заняття
            </button>
            <button className={`${s.tab} ${tab === 'notes' ? s.tabActive : ''}`} onClick={() => setTab('notes')}>
              Нотатки
            </button>
          </div>

          {tab === 'notes' ? <NotesTab groupId={active.id} /> : <LessonsTab groupId={active.id} />}
        </Modal>
      )}
    </div>
  );
};

export default TeacherGroups;
