import { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { getLessons } from '../../../api/lessons';
import { getMondayOfWeek, localDateStr, localToday } from '../../../utils/dateUtils';
import Spinner    from '../../../components/ui/feedback/Spinner';
import EmptyState from '../../../components/ui/feedback/EmptyState';
import SectionLabel from '../../../components/ui/display/SectionLabel';
import type { Lesson } from '../../../types';
import s from './TeacherGroups.module.css';

const UA_DAYS   = ['Нд','Пн','Вт','Ср','Чт','Пт','Сб'];
const UA_MONTHS = ['січ','лют','бер','кві','тра','чер','лип','сер','вер','жов','лис','гру'];

const shiftWeek = (iso: string, n: number): string => {
  const [y, m, d] = iso.split('-').map(Number);
  return localDateStr(new Date(y, m - 1, d + n * 7));
};
const fmtWeekLabel = (monday: string): string => {
  const start = new Date(monday);
  const end   = new Date(monday);
  end.setDate(end.getDate() + 6);
  const f = (d: Date) => `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
  return `${f(start)} — ${f(end)}`;
};
const fmtLessonDate = (iso: string): string => {
  const d = new Date(iso);
  return `${UA_DAYS[d.getDay()]}, ${d.getDate()} ${UA_MONTHS[d.getMonth()]}`;
};

const LessonsTab = ({ groupId }: { groupId: number }) => {
  const [monday, setMonday]     = useState(getMondayOfWeek());
  const [lessons, setLessons]   = useState<Lesson[]>([]);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    setLoading(true);
    getLessons({ groupId, week: monday }).then(setLessons).finally(() => setLoading(false));
  }, [groupId, monday]);

  const today = localToday();

  const { upcoming, past } = useMemo(() => {
    const sorted = [...lessons].sort((a, b) =>
      `${a.lesson_date}${a.start_time}`.localeCompare(`${b.lesson_date}${b.start_time}`)
    );
    return {
      upcoming: sorted.filter(l => l.lesson_date >= today),
      past:     sorted.filter(l => l.lesson_date < today).reverse(),
    };
  }, [lessons, today]);

  const renderLesson = (l: Lesson, isPast: boolean) => {
    const enrolled = l.hall_capacity - (l.free_spots ?? 0);
    return (
      <Link key={l.id} to={`/teacher/lessons/${l.id}`} className={`${s.lessonRow} ${isPast ? s.lessonRowPast : ''}`}>
        <div className={s.lessonDate}>
          <span className={`${s.lessonDateMain} ${!isPast ? s.lessonDateUpcoming : ''}`}>
            {fmtLessonDate(l.lesson_date)}
          </span>
          <span className={s.lessonTime}>{l.start_time.slice(0, 5)}–{l.end_time.slice(0, 5)}</span>
        </div>
        <div className={s.lessonInfo}>
          <div className={s.lessonName}>{l.style_name}</div>
          <div className={s.lessonMeta}>{l.hall_name} · {enrolled}/{l.hall_capacity}</div>
        </div>
        <span className={`${s.lessonLink} ${isPast ? s.lessonLinkPast : ''}`}>
          {isPast ? 'Журнал' : 'Відкрити'} →
        </span>
      </Link>
    );
  };

  return (
    <div className={s.lessonsTab}>
      <div className={s.weekNav}>
        <button className={s.weekNavBtn} onClick={() => setMonday(m => shiftWeek(m, -1))}>‹</button>
        <span className={s.weekNavLabel}>{fmtWeekLabel(monday)}</span>
        <button className={s.weekNavBtn} onClick={() => setMonday(m => shiftWeek(m, 1))}>›</button>
        <button className={s.weekNavToday} onClick={() => setMonday(getMondayOfWeek())}>
          Цей тиждень
        </button>
      </div>

      {loading ? (
        <Spinner centered />
      ) : lessons.length === 0 ? (
        <EmptyState title="Занять немає" text="На цьому тижні занять не заплановано" />
      ) : (
        <div className={s.lessonsList}>
          {upcoming.length > 0 && (
            <>
              <SectionLabel mb={8}>МАЙБУТНІ ({upcoming.length})</SectionLabel>
              {upcoming.map(l => renderLesson(l, false))}
            </>
          )}
          {past.length > 0 && (
            <>
              <SectionLabel mb={8}>ПРОВЕДЕНІ ({past.length})</SectionLabel>
              {past.map(l => renderLesson(l, true))}
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default LessonsTab;
