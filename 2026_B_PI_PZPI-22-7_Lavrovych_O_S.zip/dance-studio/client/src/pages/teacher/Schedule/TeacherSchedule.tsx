import { useEffect, useState, useCallback, useMemo } from 'react';
import { Link }       from 'react-router-dom';
import { localToday } from '../../../utils/dateUtils';
import { getLessons } from '../../../api/lessons';
import { getGroups }  from '../../../api/groups';
import { useAuth }    from '../../../context/AuthContext';
import PageHeader     from '../../../components/ui/display/PageHeader';
import Spinner        from '../../../components/ui/feedback/Spinner';
import ScheduleWeekGrid, {
  getMondayOfWeek,
  getWeekDates,
  formatWeekLabel,
} from '../../../components/schedule/ScheduleWeekGrid';
import AgendaView       from '../../../components/schedule/AgendaView';
import { ViewToggleBtn, DayPicker } from '../../../components/schedule/ViewToggle';
import type { ViewMode } from '../../../components/schedule/ViewToggle';
import useIsMobile      from '../../../hooks/useIsMobile';
import type { Lesson, DanceGroup } from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import { IconChevronRight } from '../../../components/ui/Icon';
import a from '../../../styles/admin.module.css';
import s from './TeacherSchedule.module.css';

const TeacherSchedule = () => {
  const { user }              = useAuth();
  const isMobile = useIsMobile();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [groups, setGroups]   = useState<DanceGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [week, setWeek]       = useState(getMondayOfWeek());
  const [viewMode,  setViewMode]  = useState<ViewMode>('grid');
  const [activeDay, setActiveDay] = useState<number | null>(null);
  const [filterGroup, setFilterGroup] = useState('');

  useEffect(() => { if (isMobile) setViewMode('agenda'); }, [isMobile]);

  const loadLessons = useCallback(() => {
    if (!user) return;
    setLoading(true);
    getLessons({ teacherId: user.id, week })
      .then(setLessons)
      .finally(() => setLoading(false));
  }, [user, week]);

  useEffect(() => { loadLessons(); }, [loadLessons]);
  useEffect(() => { getGroups().then(setGroups); }, []);

  const today     = localToday();
  const weekDates = useMemo(() => getWeekDates(week), [week]);

  const shiftWeek = (dir: 1 | -1) => {
    const [y, m, d] = week.split('-').map(Number);
    const date = new Date(y, m - 1, d + dir * 7);
    setWeek(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`);
  };

  const filtered = useMemo(
    () => lessons.filter(l => l.status !== 'cancelled' && (!filterGroup || String(l.group_id) === filterGroup)),
    [lessons, filterGroup],
  );

  const renderCard = (lesson: Lesson, mode?: 'agenda') => {
    const enrolled = lesson.hall_capacity - (lesson.free_spots ?? 0);
    const isPast   = lesson.lesson_date < today;

    if (mode === 'agenda') {
      return (
        <Link
          to={`/teacher/lessons/${lesson.id}`}
          className={`${s.agendaRow} ${isPast ? s.agendaPast : ''}`}
        >
          <div className={s.agendaTime}>
            <span className={s.agendaTimeStart}>{lesson.start_time.slice(0,5)}</span>
            <span className={s.agendaTimeEnd}>{lesson.end_time.slice(0,5)}</span>
          </div>
          <div className={s.agendaInfo}>
            <span className={s.agendaStyle}>{lesson.style_name}</span>
            <span className={s.agendaGroup}>{lesson.group_name}</span>
            <span className={s.agendaLevel}>{LEVEL_LABELS[lesson.group_level]}</span>
          </div>
          {lesson.hall_name && <span className={s.agendaHall}>{lesson.hall_name}</span>}
          <span className={s.agendaCount}>{enrolled}/{lesson.hall_capacity}</span>
          <IconChevronRight className={s.agendaChevron} size={16} strokeWidth={1.8} />
        </Link>
      );
    }

    return (
      <Link
        to={`/teacher/lessons/${lesson.id}`}
        className={`${s.lessonCell} ${isPast ? s.lessonCellPast : ''}`}
      >
        <span className={s.lessonStyle}>{lesson.style_name}</span>
        <span className={s.lessonLevel}>{LEVEL_LABELS[lesson.group_level]}</span>
        <span className={s.lessonHall}>{lesson.hall_name}</span>
        <span className={s.lessonTime}>{lesson.start_time.slice(0,5)}–{lesson.end_time.slice(0,5)}</span>
        <span className={s.lessonEnrolled}>{enrolled}/{lesson.hall_capacity}</span>
      </Link>
    );
  };

  return (
    <div>
      <PageHeader title="Мій розклад" sub={formatWeekLabel(week)} />

      <div className={a.toolbar}>
        {viewMode === 'grid' ? (
          <>
            <button className={s.navBtn} onClick={() => shiftWeek(-1)}>←</button>
            <span className={s.navLabel}>{formatWeekLabel(week)}</span>
            <button className={s.navBtn} onClick={() => shiftWeek(1)}>→</button>
            <button className={s.todayBtn} onClick={() => setWeek(getMondayOfWeek())}>Сьогодні</button>
          </>
        ) : (
          <>
            <button className={s.navBtn} onClick={() => shiftWeek(-1)}>←</button>
            <DayPicker weekDates={weekDates} today={today} activeDay={activeDay} onChange={setActiveDay} />
            <button className={s.navBtn} onClick={() => shiftWeek(1)}>→</button>
          </>
        )}
        <div className={a.spacer} />
        {groups.length > 1 && (
          <select className={a.filterSelect} value={filterGroup} onChange={e => setFilterGroup(e.target.value)}>
            <option value="">Всі групи</option>
            {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        )}
        <ViewToggleBtn mode={viewMode} onChange={mode => { setViewMode(mode); setActiveDay(null); }} />
      </div>

      {loading ? <Spinner centered /> : viewMode === 'grid' ? (
        <ScheduleWeekGrid
          lessons={filtered}
          weekDates={weekDates}
          today={today}
          renderCard={renderCard}
        />
      ) : (
        <AgendaView
          lessons={filtered}
          weekDates={weekDates}
          today={today}
          activeDay={activeDay}
          renderCard={renderCard}
        />
      )}
    </div>
  );
};

export default TeacherSchedule;
