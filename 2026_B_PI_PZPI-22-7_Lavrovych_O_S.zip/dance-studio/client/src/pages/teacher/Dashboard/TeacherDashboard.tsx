﻿import { Link }                from 'react-router-dom';
import { useAuth }             from '../../../context/AuthContext';
import { localToday } from '../../../utils/dateUtils';
import { useTeacherDashboard } from '../../../hooks/useTeacherDashboard';
import PageHeader    from '../../../components/ui/display/PageHeader';
import NotifBell     from '../../../components/ui/display/NotifBell';
import Spinner       from '../../../components/ui/feedback/Spinner';
import KpiCard       from '../../../components/ui/display/KpiCard';
import SectionLabel  from '../../../components/ui/display/SectionLabel';
import { IconCalendar, IconUsers, IconBarChart, IconUser, IconCheck } from '../../../components/ui/Icon';
import styles from './TeacherDashboard.module.css';

interface QuickProps { to: string; label: string; icon: React.ReactNode; }

const QuickCard = ({ to, label, icon }: QuickProps) => (
  <Link to={to} className={styles.quickCard}>
    <div className={styles.quickIcon}>{icon}</div>
    <div className={styles.quickLabel}>{label}</div>
  </Link>
);

const QUICK_ACTIONS = [
  { to: '/teacher/schedule', label: 'Розклад',    icon: <IconCalendar size={26} strokeWidth={1.5} /> },
  { to: '/teacher/groups',   label: 'Групи',      icon: <IconUsers size={26} strokeWidth={1.5} /> },
  { to: '/teacher/stats',    label: 'Статистика', icon: <IconBarChart size={26} strokeWidth={1.5} /> },
  { to: '/teacher/profile',  label: 'Профіль',    icon: <IconUser size={26} strokeWidth={1.5} /> },
];

const TeacherDashboard = () => {
  const { user }          = useAuth();
  const { data, loading } = useTeacherDashboard(user?.id);

  if (loading) return <Spinner centered />;
  if (!data)   return null;

  const { todayLessons, weekStats, groups, markedLessonIds, totalStudents, weekAttended, weekOccupancy } = data;

  const today    = localToday();
  const todayIdx = new Date().getDay() === 0 ? 6 : new Date().getDay() - 1;
  const maxCount = Math.max(...weekStats.map(s => s.count), 1);
  const avgAttendance = weekStats.some(s => s.count > 0) ? weekOccupancy : 87;

  return (
    <div>
      <PageHeader
        title={`Вітаємо, ${user?.first_name}!`}
        sub={new Date().toLocaleDateString('uk-UA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
        actions={<NotifBell to="/teacher/notifications" />}
      />

      {/* KPI */}
      <div className={styles.kpiGrid}>
        <KpiCard label="МОЇ УЧНІ"       value={totalStudents}          accent />
        <KpiCard label="ЗАНЯТЬ ТИЖНЯ"   value={data.weekLessons.length} />
        <KpiCard label="ВІДВІДУВАНІСТЬ" value={`${avgAttendance}%`}    accent />
        <KpiCard label="МОЇ ГРУПИ"      value={groups.length} />
      </div>

      {/* Main 2-column grid */}
      <div className={styles.mainGrid}>

        {/* Today */}
        <div className={styles.card}>
          <div className={styles.cardHead}>
            <span className={styles.cardLabel}>СЬОГОДНІ</span>
            <div style={{ flex: 1 }} />
            <Link to="/teacher/schedule" className={styles.cardLink}>Розклад →</Link>
          </div>

          {todayLessons.length === 0 ? (
            <div className={styles.empty}>Сьогодні занять немає</div>
          ) : (
            todayLessons
              .sort((a, b) => a.start_time.localeCompare(b.start_time))
              .map(l => {
                const enrolled = l.hall_capacity - (l.free_spots ?? 0);
                const isMarked = markedLessonIds.has(l.id);
                return (
                  <div key={l.id} className={styles.lessonRow}>
                    <div className={styles.lessonTimeBlock}>
                      <span className={styles.lessonTimeVal}>{l.start_time.slice(0, 5)}</span>
                      <span className={styles.lessonHall}>{l.hall_name}</span>
                    </div>
                    <div className={styles.lessonName}>
                      <div className={styles.lessonTitle}>{l.style_name}</div>
                      <div className={styles.lessonSub}>{l.group_name} · {enrolled}/{l.hall_capacity} учнів</div>
                    </div>
                    {isMarked ? (
                      <Link to={`/teacher/lessons/${l.id}`} className={styles.markedBadge}>
                        <IconCheck size={12} strokeWidth={2.5} />
                        Відмічено
                      </Link>
                    ) : (
                      <Link to={`/teacher/lessons/${l.id}`} className={styles.markBtn}>
                        Відмітити
                      </Link>
                    )}
                  </div>
                );
              })
          )}
        </div>

        {/* Week chart */}
        <div className={styles.card}>
          <div className={styles.cardHead}>
            <span className={styles.cardLabel}>ТИЖДЕНЬ — МОЄ ЗАВАНТАЖЕННЯ</span>
          </div>

          <div className={styles.barChart}>
            {weekStats.map((s, i) => (
              <div key={s.day} className={styles.barWrap}>
                <div
                  className={`${styles.bar} ${s.count >= Math.max(...weekStats.map(w => w.count)) && s.count > 0 ? styles.barAccent : ''}`}
                  style={{ height: `${s.count > 0 ? (s.count / maxCount) * 90 : 4}%` }}
                  title={`${s.day}: ${s.count} занять`}
                />
                <span className={`${styles.barDay} ${i === todayIdx ? styles.barDayToday : ''}`}>{s.day}</span>
              </div>
            ))}
          </div>

          <div className={styles.weekMiniGrid}>
            <div className={styles.weekMiniCard}>
              <span className={styles.weekMiniVal}>{data.weekLessons.length}</span>
              <div className={styles.weekMiniLabel}>занять цього тижня</div>
            </div>
            <div className={styles.weekMiniCard}>
              <span className={styles.weekMiniVal} style={{ color: 'var(--lime-hot)' }}>{weekAttended}</span>
              <div className={styles.weekMiniLabel}>учнів відвідало</div>
            </div>
            <div className={styles.weekMiniCard}>
              <span className={styles.weekMiniVal} style={{ color: 'var(--success)' }}>{weekOccupancy}%</span>
              <div className={styles.weekMiniLabel}>заповненість</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <SectionLabel mb={12}>ШВИДКІ ДІЇ</SectionLabel>
      <div className={styles.quickGrid}>
        {QUICK_ACTIONS.map(q => <QuickCard key={q.label} {...q} />)}
      </div>
    </div>
  );
};

export default TeacherDashboard;
