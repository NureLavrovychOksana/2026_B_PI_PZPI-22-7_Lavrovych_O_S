﻿import { useEffect, useMemo, useState } from 'react';
import { getAttendanceByLesson, markBulk } from '../../../api/attendance';
import { useToast }       from '../../../hooks/useToast';
import Toast              from '../../../components/ui/feedback/Toast';
import Spinner            from '../../../components/ui/feedback/Spinner';
import AvatarInitials     from '../../../components/ui/display/AvatarInitials';
import type { Lesson, AttendanceRecord } from '../../../types';
import css from './AttendanceSheet.module.css';

type Status = 'present' | 'absent' | 'excused';

interface StudentRow {
  student_id: number;
  first_name: string;
  last_name: string;
  sessions_left?: number;
  plan_name?: string;
}

interface Props {
  lesson: Lesson;
}

const getSubLabel = (st: StudentRow): string => {
  if (!st.plan_name) return 'Без абонементу';
  if (st.sessions_left === 0) return 'Вичерпано';
  if (st.sessions_left !== undefined && st.sessions_left <= 2) return `Залишилось ${st.sessions_left}`;
  return st.plan_name;
};

const getSubClass = (st: StudentRow): string => {
  if (!st.plan_name) return css.subNone;
  if (st.sessions_left === 0) return css.subNone;
  if (st.sessions_left !== undefined && st.sessions_left <= 2) return css.subExpiring;
  return css.subActive;
};

const AttendanceSheet = ({ lesson }: Props) => {
  const [records, setRecords]     = useState<AttendanceRecord[]>([]);
  const [statuses, setStatuses]   = useState<Record<number, Status>>({});
  const [loading, setLoading]     = useState(true);
  const [saving, setSaving]       = useState(false);
  const [search, setSearch]       = useState('');
  const { toasts, showToast, removeToast } = useToast();

  useEffect(() => {
    setLoading(true);
    getAttendanceByLesson(lesson.id)
      .then(rec => {
        setRecords(rec);
        const init: Record<number, Status> = {};
        for (const r of rec) init[r.student_id] = r.status;
        setStatuses(init);
      })
      .finally(() => setLoading(false));
  }, [lesson.id]);

  const filtered = useMemo(
    () => records.filter(st => {
      const q = search.toLowerCase();
      return `${st.first_name} ${st.last_name}`.toLowerCase().includes(q);
    }),
    [records, search],
  );

  const setStatus = (studentId: number, status: Status) =>
    setStatuses(prev => ({ ...prev, [studentId]: status }));

  const handleSave = async () => {
    setSaving(true);
    try {
      await markBulk({
        lesson_id: lesson.id,
        records: Object.entries(statuses).map(([id, status]) => ({
          student_id: Number(id),
          status,
        })),
      });
      showToast('Відвідуваність збережена', 'success');
    } catch {
      showToast('Помилка збереження', 'error');
    } finally {
      setSaving(false);
    }
  };

  const presentCount = Object.values(statuses).filter(s => s === 'present').length;
  const total = records.length;

  const lessonTime = `${lesson.start_time.slice(0, 5)}–${lesson.end_time.slice(0, 5)}`;
  const lessonDate = new Date(lesson.lesson_date).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long' });

  if (loading) return <Spinner centered />;

  return (
    <div className={css.sheet}>
      <div className={css.header}>
        <div className={css.lessonInfo}>
          <div className={css.lessonName}>{lesson.group_name}</div>
          <div className={css.lessonMeta}>
            {lessonDate} · {lessonTime} · {lesson.hall_name}
          </div>
        </div>
      </div>

      <div className={css.searchBar}>
        <input
          className={css.searchInput}
          placeholder="Пошук учня..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {filtered.length === 0 && (
        <div style={{ padding: '20px', color: 'var(--graphite)', fontSize: 13, textAlign: 'center' }}>
          Учнів не знайдено
        </div>
      )}

      {filtered.map(st => (
        <div key={st.student_id} className={css.row}>
          <AvatarInitials firstName={st.first_name} lastName={st.last_name} />
          <div className={css.info}>
            <div className={css.name}>{st.first_name} {st.last_name}</div>
            <span className={`${css.sub} ${getSubClass(st)}`}>{getSubLabel(st)}</span>
          </div>
          <div className={css.statusGroup}>
            {(['present', 'absent', 'excused'] as Status[]).map(s => (
              <button
                key={s}
                onClick={() => setStatus(st.student_id, s)}
                className={`${css.statusBtn} ${css[`btn${s.charAt(0).toUpperCase() + s.slice(1)}` as 'btnPresent' | 'btnAbsent' | 'btnExcused']} ${statuses[st.student_id] === s ? css.active : ''}`}
              >
                {s === 'present' ? 'Присутній' : s === 'absent' ? 'Відсутній' : 'Поважна'}
              </button>
            ))}
          </div>
        </div>
      ))}

      <div className={css.footer}>
        <span className={css.footerStats}>
          {presentCount} / {total} присутні
        </span>
        <button className={css.saveBtn} onClick={handleSave} disabled={saving || total === 0}>
          {saving && <span style={{ width: 12, height: 12, border: '2px solid currentColor', borderTopColor: 'transparent', borderRadius: '50%', display: 'inline-block', animation: 'spin 0.6s linear infinite' }} />}
          Зберегти
        </button>
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default AttendanceSheet;
