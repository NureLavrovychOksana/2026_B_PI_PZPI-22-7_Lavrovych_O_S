﻿import React, { useEffect, useState, useMemo } from 'react';
import {
  getMyNotifications,
  markRead,
  markAllRead,
} from '../../../api/notifications';
import PageHeader from '../../../components/ui/display/PageHeader';
import Spinner    from '../../../components/ui/feedback/Spinner';
import Toast      from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import { IconCheck, IconAlertTriangle, IconX, IconDollar, IconInfo } from '../../../components/ui/Icon';
import type { Notification } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './TeacherNotifications.module.css';

type Filter = 'all' | 'unread' | 'schedule' | 'student' | 'finance';

const FILTERS: { value: Filter; label: string }[] = [
  { value: 'all',      label: 'Всі' },
  { value: 'unread',   label: 'Непрочитані' },
  { value: 'schedule', label: 'Розклад' },
  { value: 'student',  label: 'Учні' },
  { value: 'finance',  label: 'Фінанси' },
];

const SCHEDULE_TYPES = ['schedule_change', 'lesson_cancelled', 'lesson_changed', 'teacher_replacement', 'lesson_added'];
const STUDENT_TYPES  = ['new_enrollment', 'enrollment_cancelled', 'group_full'];
const FINANCE_TYPES  = ['payout_received', 'rate_changed'];

const ICON_SVG: Record<string, React.ReactElement> = {
  success: <IconCheck size={14} strokeWidth={2.5} />,
  warn:    <IconAlertTriangle size={14} />,
  error:   <IconX size={14} strokeWidth={2.5} />,
  money:   <IconDollar size={14} />,
  info:    <IconInfo size={14} />,
};

const ICON_STYLE: Record<string, { bg: string; color: string }> = {
  success: { bg: 'rgba(200,250,58,.1)',  color: 'var(--lime)' },
  warn:    { bg: 'var(--warn-bg)',        color: 'var(--warn)' },
  error:   { bg: 'var(--error-bg)',       color: 'var(--error)' },
  money:   { bg: 'var(--success-bg)',     color: 'var(--success)' },
  info:    { bg: 'var(--info-bg)',        color: 'var(--info)' },
};

const getIconKey = (type: string): keyof typeof ICON_SVG => {
  if (['payout_received'].includes(type))                                        return 'money';
  if (['rate_changed', 'lesson_changed', 'teacher_replacement'].includes(type))  return 'warn';
  if (['enrollment_cancelled', 'lesson_cancelled'].includes(type))               return 'error';
  if (['new_enrollment', 'group_full', 'waitlist_promoted'].includes(type))      return 'success';
  return 'info';
};

const normalizeDate = (s: string) =>
  s.includes('Z') || s.includes('+') ? s : s.replace(' ', 'T') + 'Z';

const formatTime = (dateStr: string) => {
  const diff = Date.now() - new Date(normalizeDate(dateStr)).getTime();
  const min  = Math.floor(diff / 60000);
  if (min < 1)    return 'щойно';
  if (min < 60)   return `${min} хв тому`;
  if (min < 1440) return `${Math.floor(min / 60)} год тому`;
  if (min < 2880) return 'Вчора';
  return `${Math.floor(min / 1440)} дні тому`;
};

const TeacherNotifications = () => {
  const [items, setItems]     = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter]   = useState<Filter>('all');
  const { toasts, showToast, removeToast } = useToast();

  const load = () => {
    setLoading(true);
    getMyNotifications().then(setItems).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    switch (filter) {
      case 'unread':   return items.filter(n => !n.is_read);
      case 'schedule': return items.filter(n => SCHEDULE_TYPES.includes(n.type) || n.type === 'manual');
      case 'student':  return items.filter(n => STUDENT_TYPES.includes(n.type));
      case 'finance':  return items.filter(n => FINANCE_TYPES.includes(n.type));
      default:         return items;
    }
  }, [items, filter]);

  const unreadCount = items.filter(n => !n.is_read).length;

  const handleRead = async (id: number) => {
    await markRead(id);
    setItems(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
  };

  const handleMarkAll = async () => {
    await markAllRead();
    setItems(prev => prev.map(n => ({ ...n, is_read: true })));
    showToast('Всі прочитані', 'success');
  };

  const handleDelete = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    setItems(prev => prev.filter(n => n.id !== id));
  };

  const handleClearAll = () => {
    setItems([]);
    showToast('Список очищено', 'success');
  };

  return (
    <div>
      <PageHeader
        title="Сповіщення"
        sub={unreadCount > 0 ? `${unreadCount} непрочитаних` : undefined}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            {unreadCount > 0 && (
              <button className={a.btnSecondary} style={{ fontSize: 12 }} onClick={handleMarkAll}>
                Прочитати всі
              </button>
            )}
            {items.length > 0 && (
              <button className={a.btnSecondary} style={{ fontSize: 12, color: 'var(--graphite)' }} onClick={handleClearAll}>
                Очистити
              </button>
            )}
          </div>
        }
      />

      {/* Filters */}
      <div className={s.filters}>
        {FILTERS.map(f => (
          <button
            key={f.value}
            className={`${s.pill} ${filter === f.value ? s.pillActive : ''}`}
            onClick={() => setFilter(f.value)}
          >
            {f.label}
            {f.value === 'unread' && unreadCount > 0 && (
              <span style={{
                marginLeft: 5, background: 'var(--lime-hot)', color: 'var(--coal)',
                borderRadius: 10, padding: '1px 6px', fontSize: 10, fontWeight: 700,
              }}>
                {unreadCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* List */}
      {loading ? (
        <Spinner centered />
      ) : filtered.length === 0 ? (
        <div className={s.list}>
          <div className={s.empty}>
            {filter === 'unread' ? 'Непрочитаних немає' : 'Сповіщень немає'}
          </div>
        </div>
      ) : (
        <div className={s.list}>
          {filtered.map(n => {
            const iconKey = getIconKey(n.type);
            const ic      = ICON_STYLE[iconKey];
            return (
              <div
                key={n.id}
                className={`${s.item} ${!n.is_read ? s.itemUnread : ''}`}
                onClick={() => !n.is_read && handleRead(n.id)}
              >
                <div className={s.icon} style={{ background: ic.bg, color: ic.color }}>
                  {ICON_SVG[iconKey]}
                </div>
                <div className={s.body}>
                  <div className={s.title}>
                    {n.title}
                    {!n.is_read && <span className={s.unreadDot} />}
                  </div>
                  {n.body && <div className={s.text}>{n.body}</div>}
                  <div className={s.time}>{formatTime(n.created_at)}</div>
                </div>
                <button
                  className={s.deleteBtn}
                  onClick={e => handleDelete(e, n.id)}
                  title="Видалити"
                >
                  <IconX size={12} />
                </button>
              </div>
            );
          })}
        </div>
      )}

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default TeacherNotifications;