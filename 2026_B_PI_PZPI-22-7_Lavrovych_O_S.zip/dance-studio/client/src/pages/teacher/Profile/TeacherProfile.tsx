import { useEffect, useRef, useState } from 'react';
import { useAuth }             from '../../../context/AuthContext';
import { getMyTeacherProfile, updateTeacherProfile } from '../../../api/teachers';
import { getStyles }           from '../../../api/styles';
import { getGroups }           from '../../../api/groups';
import { uploadUserAvatar }    from '../../../api/lessons';
import api                     from '../../../api/axios';
import Spinner                 from '../../../components/ui/feedback/Spinner';
import Toast                   from '../../../components/ui/feedback/Toast';
import FormField               from '../../../components/ui/form/FormField';
import SectionLabel            from '../../../components/ui/display/SectionLabel';
import { useToast }            from '../../../hooks/useToast';
import type { DanceStyle, DanceGroup } from '../../../types';
import { IconCamera } from '../../../components/ui/Icon';
import a from '../../../styles/admin.module.css';
import s from './TeacherProfile.module.css';

interface ProfileForm {
  first_name:       string;
  last_name:        string;
  email:            string;
  phone:            string;
  bio:              string;
  experience_years: string;
  education:        string;
  style_ids:        number[];
}

interface PwForm { current: string; next: string; confirm: string; }

const TeacherProfile = () => {
  const { user, updateUser } = useAuth();
  const [profileId, setProfileId]   = useState<number | null>(null);
  const [allStyles, setAllStyles]   = useState<DanceStyle[]>([]);
  const [groups, setGroups]         = useState<DanceGroup[]>([]);
  const [loading, setLoading]       = useState(true);
  const [saving, setSaving]         = useState(false);
  const [pwSaving, setPwSaving]     = useState(false);
  const [avatarUrl, setAvatarUrl]   = useState<string | null>(null);
  const [avatarError, setAvatarError] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toasts, showToast, removeToast } = useToast();

  const [form, setForm] = useState<ProfileForm>({
    first_name: '', last_name: '', email: '',
    phone: '', bio: '', experience_years: '', education: '', style_ids: [],
  });
  const [pwForm, setPwForm] = useState<PwForm>({ current: '', next: '', confirm: '' });

  useEffect(() => {
    Promise.all([
      getMyTeacherProfile(),
      getStyles(),
      getGroups(),
    ]).then(([profile, styles, grps]) => {
      setProfileId(profile.id);
      setAllStyles(styles);
      setGroups(grps);
      setAvatarUrl(profile.avatar_url ?? null);
      setForm({
        first_name:       profile.first_name  ?? '',
        last_name:        profile.last_name   ?? '',
        email:            profile.email       ?? '',
        phone:            profile.phone       ?? '',
        bio:              profile.bio         ?? '',
        experience_years: profile.experience_years ? String(profile.experience_years) : '',
        education:        profile.education   ?? '',
        style_ids:        profile.styles?.map((st: any) => st.id) ?? [],
      });
    }).finally(() => setLoading(false));
  }, []);

  const set = (key: keyof ProfileForm) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm(p => ({ ...p, [key]: e.target.value }));

  const toggleStyle = (id: number) =>
    setForm(p => ({
      ...p,
      style_ids: p.style_ids.includes(id)
        ? p.style_ids.filter(s => s !== id)
        : [...p.style_ids, id],
    }));

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarUploading(true);
    try {
      const res = await uploadUserAvatar(file);
      setAvatarUrl(res.avatar_url);
      setAvatarError(false);
      updateUser({ avatar_url: res.avatar_url });
      showToast('Аватар оновлено', 'success');
    } catch {
      showToast('Помилка завантаження', 'error');
    } finally {
      setAvatarUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSave = async () => {
    if (!profileId) return;
    setSaving(true);
    try {
      await updateTeacherProfile(profileId, {
        first_name:       form.first_name,
        last_name:        form.last_name,
        email:            form.email,
        phone:            form.phone     || undefined,
        bio:              form.bio       || undefined,
        experience_years: form.experience_years ? Number(form.experience_years) : undefined,
        education:        form.education || undefined,
        style_ids:        form.style_ids,
      });
      updateUser({ first_name: form.first_name, last_name: form.last_name, email: form.email, phone: form.phone || undefined });
      showToast('Профіль оновлено', 'success');
    } catch (err: any) {
      showToast(err?.response?.data?.message ?? 'Помилка збереження', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordSave = async () => {
    if (pwForm.next !== pwForm.confirm) { showToast('Паролі не збігаються', 'error'); return; }
    if (pwForm.next.length < 6)         { showToast('Мінімум 6 символів', 'error');   return; }
    setPwSaving(true);
    try {
      await api.put('/auth/change-password', { current_password: pwForm.current, new_password: pwForm.next });
      showToast('Пароль змінено', 'success');
      setPwForm({ current: '', next: '', confirm: '' });
    } catch (err: any) {
      showToast(err?.response?.data?.message ?? 'Помилка', 'error');
    } finally {
      setPwSaving(false);
    }
  };

  if (loading || !user) return <Spinner centered />;

  const styleNames = allStyles.filter(st => form.style_ids.includes(st.id)).map(st => st.name);
  const totalStudents = groups.reduce((s, g) => s + (g.students_count || 0), 0);
  const initials = `${form.first_name[0] ?? ''}${form.last_name[0] ?? ''}`.toUpperCase();

  return (
    <div>
      {/* ── Hero ── */}
      <div className={s.hero}>
        <div className={s.avatarWrap}>
        {avatarUrl && !avatarError ? (
          <img
            src={`${(import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/api$/, '')}${avatarUrl}`}
            alt="avatar"
            className={s.avatarImg}
            onError={() => setAvatarError(true)}
          />
        ) : (
          <div className={s.avatarLg}>{initials}</div>
        )}
        <button
          className={s.avatarEditBtn}
          onClick={() => fileInputRef.current?.click()}
          disabled={avatarUploading}
          title="Змінити фото"
          aria-label="Змінити фото профілю"
        >
          {avatarUploading ? (
            <span className={a.spinner} style={{ width: 14, height: 14 }} />
          ) : (
            <IconCamera size={14} />
          )}
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          style={{ display: 'none' }}
          onChange={handleAvatarChange}
        />
      </div>

        <div className={s.heroInfo}>
          <div className={s.heroName}>{form.first_name} {form.last_name}</div>
          <div className={s.heroSub}>
            Викладач{styleNames.length > 0 ? ` · ${styleNames.join(', ')}` : ''}
          </div>
          <div className={s.heroBadges}>
            {styleNames.map(n => <span key={n} className={s.badge}>{n}</span>)}
            {form.experience_years && (
              <span className={`${s.badge} ${s.badgeGold}`}>{form.experience_years} {Number(form.experience_years) === 1 ? 'рік' : Number(form.experience_years) < 5 ? 'роки' : 'років'} досвіду</span>
            )}
          </div>
        </div>

        <div className={s.heroSaveRow}>
          <button className={a.btnPrimary} onClick={handleSave} disabled={saving}>
            {saving && <span className={a.spinner} />}
            Зберегти
          </button>
        </div>
      </div>

      {/* ── Two-column grid ── */}
      <div className={s.grid}>

        {/* Left — Personal data */}
        <div className={s.card}>
          <SectionLabel mb={18}>ОСОБИСТІ ДАНІ</SectionLabel>

          <div className={a.formRow}>
            <FormField label="ІМʼЯ">
              <input className={a.input} value={form.first_name} onChange={set('first_name')} />
            </FormField>
            <FormField label="ПРІЗВИЩЕ">
              <input className={a.input} value={form.last_name} onChange={set('last_name')} />
            </FormField>
          </div>

          <FormField label="EMAIL">
            <input className={a.input} type="email" value={form.email} onChange={set('email')} />
          </FormField>

          <FormField label="ТЕЛЕФОН">
            <input className={a.input} value={form.phone} onChange={set('phone')} placeholder="+380..." />
          </FormField>

          <FormField label="БІО">
            <textarea
              className={a.input}
              style={{ minHeight: 90, resize: 'vertical' }}
              value={form.bio}
              onChange={set('bio')}
              placeholder="Коротко про себе..."
            />
          </FormField>

          {/* Password */}
          <hr className={s.pwDivider} />
          <SectionLabel mb={18}>ЗМІНА ПАРОЛЮ</SectionLabel>

          <FormField label="ПОТОЧНИЙ ПАРОЛЬ">
            <input className={a.input} type="password" value={pwForm.current} onChange={e => setPwForm(p => ({ ...p, current: e.target.value }))} />
          </FormField>
          <FormField label="НОВИЙ ПАРОЛЬ">
            <input className={a.input} type="password" value={pwForm.next} onChange={e => setPwForm(p => ({ ...p, next: e.target.value }))} />
          </FormField>
          <FormField label="ПІДТВЕРДЖЕННЯ">
            <input className={a.input} type="password" value={pwForm.confirm} onChange={e => setPwForm(p => ({ ...p, confirm: e.target.value }))} />
          </FormField>

          <button
            className={a.btnSecondary}
            style={{ marginTop: 8 }}
            onClick={handlePasswordSave}
            disabled={pwSaving || !pwForm.current || !pwForm.next || !pwForm.confirm}
          >
            {pwSaving && <span className={a.spinner} />}
            Змінити пароль
          </button>
        </div>

        {/* Right — Specialization + stats */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className={s.card}>
            <SectionLabel mb={14}>СПЕЦІАЛІЗАЦІЯ</SectionLabel>

            <FormField label="СТИЛІ">
              <div className={s.pillGrid}>
                {allStyles.map(st => (
                  <button
                    key={st.id}
                    type="button"
                    className={`${s.pill} ${form.style_ids.includes(st.id) ? s.pillActive : ''}`}
                    onClick={() => toggleStyle(st.id)}
                  >
                    {st.name}
                  </button>
                ))}
              </div>
            </FormField>

            <FormField label="ДОСВІД (РОКІВ)" className={a.formGroupMt}>
              <input
                className={a.input}
                type="number"
                min={0}
                value={form.experience_years}
                onChange={set('experience_years')}
                placeholder="5"
              />
            </FormField>

            <FormField label="ОСВІТА / СЕРТИФІКАТИ">
              <textarea
                className={a.input}
                style={{ minHeight: 80, resize: 'vertical' }}
                value={form.education}
                onChange={set('education')}
                placeholder="Хореографічний факультет, сертифікати..."
              />
            </FormField>
          </div>

          <div className={s.card}>
            <SectionLabel mb={14}>МОЯ СТАТИСТИКА</SectionLabel>
            <div className={s.statsRow}>
              <div className={s.statItem}>
                <div className={s.statVal}>{groups.length}</div>
                <div className={s.statLabel}>ГРУП</div>
              </div>
              <div className={s.statItem}>
                <div className={s.statVal}>{totalStudents}</div>
                <div className={s.statLabel}>УЧНІВ</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default TeacherProfile;
