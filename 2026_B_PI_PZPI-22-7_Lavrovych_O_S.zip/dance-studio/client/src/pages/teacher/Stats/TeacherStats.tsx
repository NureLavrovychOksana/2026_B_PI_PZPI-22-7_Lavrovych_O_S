import { useEffect, useMemo, useState } from 'react';
import { getTeacherTimesheet, getTeacherDisciplineStats } from '../../../api/reports';
import { getMyTeacherFinance, type MyTeacherFinance } from '../../../api/teachers';
import { useAuth }    from '../../../context/AuthContext';
import PageHeader     from '../../../components/ui/display/PageHeader';
import Spinner        from '../../../components/ui/feedback/Spinner';
import { FinanceBlock, WorkloadBlock, QualityBlock } from './TeacherStatBlocks';
import type { TeacherTimesheetLesson, TeacherDisciplineStats } from '../../../types';
import s from './TeacherStats.module.css';

const toISO = (d: Date) => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};

const periodOf = (type: 'current' | 'prev') => {
  const now = new Date();
  if (type === 'current') {
    return { from: toISO(new Date(now.getFullYear(), now.getMonth(), 1)), to: toISO(new Date(now.getFullYear(), now.getMonth() + 1, 0)) };
  }
  return { from: toISO(new Date(now.getFullYear(), now.getMonth() - 1, 1)), to: toISO(new Date(now.getFullYear(), now.getMonth(), 0)) };
};

type PeriodMode = 'current' | 'prev' | 'custom';
type DrillBlock = 'finance' | 'quality' | null;

const TeacherStats = () => {
  const { user } = useAuth();

  const [mode, setMode]     = useState<PeriodMode>('current');
  const [custom, setCustom] = useState({ from: '', to: '' });
  const [drill, setDrill]   = useState<DrillBlock>(null);

  const [timesheet,   setTimesheet]   = useState<TeacherTimesheetLesson[]>([]);
  const [discipline,  setDiscipline]  = useState<TeacherDisciplineStats | null>(null);
  const [loading,     setLoading]     = useState(true);
  const [finance, setFinance] = useState<MyTeacherFinance | null>(null);

  const period = useMemo(() => {
    if (mode === 'custom') return { from: custom.from, to: custom.to };
    return periodOf(mode);
  }, [mode, custom]);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    Promise.all([
      getTeacherTimesheet(user.id, { date_from: period.from, date_to: period.to }),
      getTeacherDisciplineStats(user.id),
      getMyTeacherFinance({ date_from: period.from, date_to: period.to }),
    ]).then(([ts, disc, fin]) => {
      setTimesheet(ts);
      setDiscipline(disc);
      setFinance(fin);
    }).finally(() => setLoading(false));
  }, [user, period.from, period.to]);

  const { totalHours, totalEarnings, weeklyEarnings, journalPct } = useMemo(() => {
    const rateType   = finance?.rate_type   ?? 'per_lesson';
    const rateAmount = finance?.rate_amount ?? 0;
    const totalHours    = timesheet.reduce((acc, l) => acc + l.duration_hours, 0);
    const totalEarnings = finance?.total_earnings ?? 0;
    const journalFilled = timesheet.filter(l => l.present_count + l.absent_count > 0).length;
    const journalPct    = timesheet.length > 0 ? Math.round((journalFilled / timesheet.length) * 100) : 100;

    const lessonEarning = (l: typeof timesheet[0]) =>
      rateType === 'per_student' ? l.present_count * rateAmount : rateAmount;

    const byWeek: Record<string, number> = {};
    timesheet.forEach(l => {
      // Parse date parts directly to avoid UTC↔local timezone shift
      const [yStr, mStr, dStr] = l.lesson_date.split('-');
      const d = new Date(Number(yStr), Number(mStr) - 1, Number(dStr));
      const day = d.getDay() || 7;
      const mon = new Date(d);
      mon.setDate(d.getDate() - day + 1);
      const key = toISO(mon).slice(5, 10);
      byWeek[key] = (byWeek[key] || 0) + lessonEarning(l);
    });
    const weeklyEarnings = Object.entries(byWeek)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([label, value]) => ({ label, value }));

    return { totalHours, totalEarnings, weeklyEarnings, journalPct };
  }, [timesheet, finance]);

  const { totalLessons, avgStudentsPerLesson, densityScore } = useMemo(() => {
    const totalLessons = timesheet.length;
    const avgStudentsPerLesson = totalLessons > 0
      ? Math.round(timesheet.reduce((acc, l) => acc + l.present_count, 0) / totalLessons) : 0;
    const byDay: Record<string, number> = {};
    timesheet.forEach(l => { byDay[l.lesson_date] = (byDay[l.lesson_date] || 0) + 1; });
    const days = Object.values(byDay);
    const densityScore = days.length > 0 ? (days.reduce((a, b) => a + b, 0) / days.length).toFixed(1) : '0';
    return { totalLessons, avgStudentsPerLesson, densityScore };
  }, [timesheet]);

  const toggleDrill = (b: DrillBlock) => setDrill(d => d === b ? null : b);

  if (loading) return <Spinner centered />;

  const rateType   = finance?.rate_type   ?? 'per_lesson';
  const rateAmount = finance?.rate_amount ?? 0;
  const paidTotal  = finance?.total_paid  ?? 0;
  const balance    = finance?.balance     ?? 0;
  const absRate    = discipline?.absence_rate  ?? 0;
  const retention  = discipline?.retention_rate ?? 0;

  return (
    <div>
      <PageHeader title="Статистика" />

      {/* Period filter */}
      <div className={s.periodBar}>
        {(['current', 'prev'] as PeriodMode[]).map(m => (
          <button key={m}
            className={`${s.periodBtn} ${mode === m ? s.periodBtnActive : ''}`}
            onClick={() => setMode(m)}
          >
            {m === 'current' ? 'Цей місяць' : 'Минулий місяць'}
          </button>
        ))}
        <span className={s.periodSep}>|</span>
        <button
          className={`${s.periodBtn} ${mode === 'custom' ? s.periodBtnActive : ''}`}
          onClick={() => setMode('custom')}
        >
          Довільний
        </button>
        {mode === 'custom' && (
          <>
            <input type="date" className={s.periodInput} value={custom.from}
              onChange={e => setCustom(p => ({ ...p, from: e.target.value }))} />
            <span className={s.periodSep}>—</span>
            <input type="date" className={s.periodInput} value={custom.to}
              onChange={e => setCustom(p => ({ ...p, to: e.target.value }))} />
          </>
        )}
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--graphite)' }}>
          {period.from && period.to ? `${period.from} — ${period.to}` : ''}
        </span>
      </div>

      <div className={s.blocks}>
        <FinanceBlock
          balance={balance}
          totalEarnings={totalEarnings}
          paidTotal={paidTotal}
          totalHours={totalHours}
          totalLessons={totalLessons}
          rateType={rateType}
          rateAmount={rateAmount}
          weeklyEarnings={weeklyEarnings}
          drillOpen={drill === 'finance'}
          onToggle={() => toggleDrill('finance')}
          timesheet={timesheet}
        />
        <WorkloadBlock
          totalLessons={totalLessons}
          totalHours={totalHours}
          avgStudentsPerLesson={avgStudentsPerLesson}
          densityScore={densityScore}
          timesheet={timesheet}
        />
        <QualityBlock
          retention={retention}
          absRate={absRate}
          journalPct={journalPct}
          drillOpen={drill === 'quality'}
          onToggle={() => toggleDrill('quality')}
          timesheet={timesheet}
        />
      </div>
    </div>
  );
};

export default TeacherStats;
