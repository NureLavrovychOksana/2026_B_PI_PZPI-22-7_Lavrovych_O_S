import TeacherBarChart from './TeacherBarChart';
import type { ChartPoint } from './TeacherBarChart';
import type { TeacherTimesheetLesson } from '../../../types';
import type { RateType } from '../../../api/teachers';
import { IconDollar, IconActivity, IconStar, IconChevronRight } from '../../../components/ui/Icon';
import s from './TeacherStats.module.css';

const RATE_LABEL: Record<RateType, string> = {
  per_lesson:  'за заняття',
  per_student: 'за учня',
  percent:     '% від виручки',
};

export const IcoMoney   = () => <IconDollar size={14} strokeWidth={1.8} />;
export const IcoLoad    = () => <IconActivity size={14} strokeWidth={1.8} />;
export const IcoStar    = () => <IconStar size={14} strokeWidth={1.8} />;
export const IcoChevron = ({ open }: { open: boolean }) => (
  <span style={{ display: 'flex', transform: open ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s' }}>
    <IconChevronRight size={12} />
  </span>
);

const Chip = ({ val, warn, danger }: { val: string; warn?: boolean; danger?: boolean }) => (
  <span className={`${s.chip} ${danger ? s.chipRed : warn ? s.chipYellow : s.chipGreen}`}>{val}</span>
);

interface FinanceProps {
  balance:        number;
  totalEarnings:  number;
  paidTotal:      number;
  totalHours:     number;
  totalLessons:   number;
  rateType:       RateType;
  rateAmount:     number;
  weeklyEarnings: ChartPoint[];
  drillOpen:      boolean;
  onToggle:       () => void;
  timesheet:      TeacherTimesheetLesson[];
}

const lessonEarning = (l: TeacherTimesheetLesson, rateType: RateType, rateAmount: number) =>
  rateType === 'per_student' ? l.present_count * rateAmount : rateAmount;

export const FinanceBlock = ({
  balance, totalEarnings, paidTotal, totalHours, totalLessons,
  rateType, rateAmount, weeklyEarnings, drillOpen, onToggle, timesheet,
}: FinanceProps) => (
  <div className={s.block}>
    <div className={s.blockHead}>
      <span className={s.blockIcon}><IcoMoney /></span>
      <span className={s.blockTitle}>ФІНАНСИ ТА ВИПЛАТИ</span>
      <button className={s.blockDrill} onClick={onToggle}>
        <IcoChevron open={drillOpen} />
        {drillOpen ? 'Сховати' : 'Табель'}
      </button>
    </div>

    <div className={s.kpiRow}>
      <div className={`${s.kpi} ${s.kpiGold}`} onClick={onToggle}>
        <div className={s.kpiLabel}>БАЛАНС ДО ВИПЛАТИ</div>
        <div className={s.kpiValue}>{Math.round(balance).toLocaleString()} ₴</div>
        <div className={s.kpiSub}>з {Math.round(totalEarnings).toLocaleString()} ₴ нараховано</div>
      </div>
      <div className={s.kpi}>
        <div className={s.kpiLabel}>ВИПЛАЧЕНО</div>
        <div className={s.kpiValue}>{paidTotal.toLocaleString()} ₴</div>
        <div className={s.kpiSub}>&nbsp;</div>
      </div>
      <div className={s.kpi}>
        <div className={s.kpiLabel}>ГОДИН</div>
        <div className={s.kpiValue}>{totalHours.toFixed(1)}</div>
        <div className={s.kpiSub}>{totalLessons} занять</div>
      </div>
    </div>

    <div className={s.financeInfo}>
      <div className={s.financeInfoRow}>
        <span className={s.financeInfoLabel}>Ставка:</span>
        <span className={s.financeInfoValue}>
          {rateAmount > 0
            ? `${rateAmount.toLocaleString()} ₴ ${RATE_LABEL[rateType] ?? ''}`
            : <span className={s.financeInfoEmpty}>не встановлено</span>}
        </span>
      </div>
      <div className={s.financeInfoRow}>
        <span className={s.financeInfoLabel}>Вже виплачено:</span>
        <span className={s.financeInfoValue}>{paidTotal.toLocaleString()} ₴</span>
      </div>
    </div>

    {weeklyEarnings.length > 0 && rateAmount > 0 && (
      <div className={s.chartWrap}>
        <div className={s.chartTitle}>НАРАХУВАННЯ ПО ТИЖНЯХ (ГРН)</div>
        <TeacherBarChart data={weeklyEarnings} />
      </div>
    )}

    {drillOpen && (
      <div className={s.drillTable}>
        <table className={s.tbl}>
          <thead>
            <tr>
              <th>Дата</th><th>Час</th><th>Група</th><th>Стиль</th><th>Год.</th>
              {rateAmount > 0 && <th>Сума</th>}
              <th>Присутніх</th>
            </tr>
          </thead>
          <tbody>
            {timesheet.map(l => (
              <tr key={l.lesson_id}>
                <td>{l.lesson_date}</td>
                <td>{l.start_time}–{l.end_time}</td>
                <td>{l.group_name}</td>
                <td>{l.style_name}</td>
                <td>{l.duration_hours.toFixed(2)}</td>
                {rateAmount > 0 && (
                  <td className={s.tdAmt}>{Math.round(lessonEarning(l, rateType, rateAmount)).toLocaleString()} ₴</td>
                )}
                <td>{l.present_count}/{l.enrolled_count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )}
  </div>
);

interface WorkloadProps {
  totalLessons:         number;
  totalHours:           number;
  avgStudentsPerLesson: number;
  densityScore:         string;
  timesheet:            TeacherTimesheetLesson[];
}

export const WorkloadBlock = ({ totalLessons, totalHours, avgStudentsPerLesson, densityScore, timesheet }: WorkloadProps) => {
  const byGroup: Record<string, { name: string; style: string; hrs: number }> = {};
  timesheet.forEach(l => {
    if (!byGroup[l.group_name]) byGroup[l.group_name] = { name: l.group_name, style: l.style_name, hrs: 0 };
    byGroup[l.group_name].hrs += l.duration_hours;
  });
  const maxHrs = Math.max(1, ...Object.values(byGroup).map(g => g.hrs));

  return (
    <div className={s.block}>
      <div className={s.blockHead}>
        <span className={s.blockIcon}><IcoLoad /></span>
        <span className={s.blockTitle}>НАВАНТАЖЕННЯ ТА УТИЛІЗАЦІЯ</span>
      </div>

      <div className={s.kpiRow}>
        <div className={s.kpi}>
          <div className={s.kpiLabel}>ВСЬОГО ЗАНЯТЬ</div>
          <div className={s.kpiValue}>{totalLessons}</div>
          <div className={s.kpiSub}>{totalHours.toFixed(1)} год</div>
        </div>
        <div className={s.kpi}>
          <div className={s.kpiLabel}>СЕРЕДНЬО УЧНІВ</div>
          <div className={s.kpiValue}>{avgStudentsPerLesson}</div>
          <div className={s.kpiSub}>на занятті (присутніх)</div>
        </div>
        <div className={s.kpi}>
          <div className={s.kpiLabel}>ЩІЛЬНІСТЬ</div>
          <div className={s.kpiValue}>{densityScore}</div>
          <div className={s.kpiSub}>зан. підряд / день</div>
        </div>
      </div>

      {timesheet.length > 0 && (
        <div className={s.groupBars}>
          {Object.values(byGroup).map(g => (
            <div key={g.name} className={s.barRow}>
              <span className={s.barName}>{g.name}</span>
              <span className={s.barStyle}>{g.style}</span>
              <div className={s.barTrack}>
                <div className={s.barFill} style={{ width: `${(g.hrs / maxHrs) * 100}%` }} />
              </div>
              <span className={s.barVal}>{g.hrs.toFixed(1)}г</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

interface QualityProps {
  retention:   number;
  absRate:     number;
  journalPct:  number;
  drillOpen:   boolean;
  onToggle:    () => void;
  timesheet:   TeacherTimesheetLesson[];
}

export const QualityBlock = ({ retention, absRate, journalPct, drillOpen, onToggle, timesheet }: QualityProps) => (
  <div className={s.block}>
    <div className={s.blockHead}>
      <span className={s.blockIcon}><IcoStar /></span>
      <span className={s.blockTitle}>ЯКІСТЬ РОБОТИ</span>
      <button className={s.blockDrill} onClick={onToggle}>
        <IcoChevron open={drillOpen} />
        {drillOpen ? 'Сховати' : 'Деталі'}
      </button>
    </div>

    <div className={s.kpiRow}>
      <div className={`${s.kpi} ${retention >= 70 ? s.kpiLime : retention >= 50 ? s.kpiWarn : s.kpiRed}`} onClick={onToggle}>
        <div className={s.kpiLabel}>RETENTION RATE</div>
        <div className={s.kpiValue}>{retention}%</div>
        <div className={s.kpiSub}>
          <Chip val={retention >= 70 ? 'Добре' : retention >= 50 ? 'Нормально' : 'Ризик'} warn={retention < 70 && retention >= 50} danger={retention < 50} />
        </div>
      </div>
      <div className={`${s.kpi} ${absRate <= 10 ? s.kpiLime : absRate <= 20 ? s.kpiWarn : s.kpiRed}`} onClick={onToggle}>
        <div className={s.kpiLabel}>ДИСЦИПЛІНА (ПРОПУСКИ)</div>
        <div className={s.kpiValue}>{Math.round(absRate)}%</div>
        <div className={s.kpiSub}>
          <Chip val={absRate <= 10 ? 'Норма' : absRate <= 20 ? 'Підвищений' : 'Критично'} warn={absRate > 10 && absRate <= 20} danger={absRate > 20} />
        </div>
      </div>
      <div className={`${s.kpi} ${journalPct >= 90 ? s.kpiLime : journalPct >= 70 ? s.kpiWarn : s.kpiRed}`}>
        <div className={s.kpiLabel}>СВОЄЧАСНІСТЬ ЖУРНАЛУ</div>
        <div className={s.kpiValue}>{journalPct}%</div>
        <div className={s.kpiSub}>занять з відмітками</div>
      </div>
    </div>

    {drillOpen && (
      <div className={s.drillTable}>
        <table className={s.tbl}>
          <thead>
            <tr><th>Дата</th><th>Група</th><th>Присутніх</th><th>Відсутніх</th><th>Пропуск %</th><th>Журнал</th></tr>
          </thead>
          <tbody>
            {timesheet.map(l => {
              const total  = l.present_count + l.absent_count;
              const absPct = total > 0 ? Math.round((l.absent_count / total) * 100) : 0;
              return (
                <tr key={l.lesson_id}>
                  <td>{l.lesson_date}</td>
                  <td>{l.group_name}</td>
                  <td>{l.present_count}</td>
                  <td className={l.absent_count > 0 ? s.tdWarn : ''}>{l.absent_count}</td>
                  <td className={absPct > 20 ? s.tdRed : absPct > 10 ? s.tdWarn : ''}>{absPct}%</td>
                  <td>{total > 0 ? '✓' : <span className={s.tdRed}>—</span>}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    )}
  </div>
);
