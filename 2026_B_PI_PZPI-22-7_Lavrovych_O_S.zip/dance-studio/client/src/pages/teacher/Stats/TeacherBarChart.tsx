import s from './TeacherStats.module.css';

export type ChartPoint = { label: string; value: number };

const TeacherBarChart = ({ data }: { data: ChartPoint[] }) => {
  if (!data.length) return null;
  const W = 560;
  const H = 80;
  const BAR_W = Math.max(8, Math.min(40, W / data.length - 6));
  const maxV  = Math.max(1, ...data.map(d => d.value));
  const step  = W / data.length;
  return (
    <svg viewBox={`0 0 ${W} ${H + 20}`} className={s.chart}>
      {data.map((d, i) => {
        const barH = Math.max(2, (d.value / maxV) * H);
        const x = i * step + (step - BAR_W) / 2;
        const y = H - barH;
        return (
          <g key={i}>
            <rect x={x} y={y} width={BAR_W} height={barH} rx="2" className={s.chartBar} />
            <text x={x + BAR_W / 2} y={H + 14} textAnchor="middle"
              fontSize="8" fill="var(--graphite)" fontFamily="var(--font-mono)">
              {d.label}
            </text>
            {d.value > 0 && (
              <text x={x + BAR_W / 2} y={y - 3} textAnchor="middle"
                fontSize="8" fill="var(--lime)" fontFamily="var(--font-mono)">
                {Math.round(d.value)}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
};

export default TeacherBarChart;
