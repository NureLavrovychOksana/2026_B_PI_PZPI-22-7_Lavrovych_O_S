import type { Lesson } from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import { IconCalendar, IconClock, IconHome, IconUsers } from '../../../components/ui/Icon';
import s from './LessonPage.module.css';

const UA_DAYS   = ['Неділя','Понеділок','Вівторок','Середа','Четвер','П\'ятниця','Субота'];
const UA_MONTHS = ['січня','лютого','березня','квітня','травня','червня','липня','серпня','вересня','жовтня','листопада','грудня'];

const fmtDate = (iso: string) => {
  const d = new Date(iso);
  return `${UA_DAYS[d.getDay()]}, ${d.getDate()} ${UA_MONTHS[d.getMonth()]}`;
};

interface Props { lesson: Lesson; isDone: boolean; enrolled: number }

const LessonHero = ({ lesson, isDone, enrolled }: Props) => (
  <div className={s.hero}>
    <div className={s.heroRow}>
      <span className={`${s.status} ${isDone ? s.statusDone : s.statusPlan}`}>
        {isDone ? 'Проведено' : 'Заплановано'}
      </span>
      <span className={s.levelChip}>{LEVEL_LABELS[lesson.group_level]}</span>
    </div>

    <h1 className={s.heroTitle}>{lesson.style_name}</h1>
    <div className={s.heroGroup}>{lesson.group_name}</div>

    <div className={s.heroMeta}>
      <div className={s.heroMetaItem}>
        <IconCalendar size={13} strokeWidth={1.8} />
        {fmtDate(lesson.lesson_date)}
      </div>
      <div className={s.heroMetaItem}>
        <IconClock size={13} strokeWidth={1.8} />
        {lesson.start_time.slice(0, 5)}–{lesson.end_time.slice(0, 5)}
      </div>
      <div className={s.heroMetaItem}>
        <IconHome size={13} strokeWidth={1.8} />
        {lesson.hall_name}
      </div>
      <div className={s.heroMetaItem}>
        <IconUsers size={13} strokeWidth={1.8} />
        {enrolled}/{lesson.hall_capacity} учнів
      </div>
    </div>
  </div>
);

export default LessonHero;
