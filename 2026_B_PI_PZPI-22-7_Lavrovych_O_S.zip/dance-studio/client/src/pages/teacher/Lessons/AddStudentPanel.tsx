import { useState, useEffect } from 'react';
import { searchStudents }            from '../../../api/users';
import { getAttendanceByLesson }     from '../../../api/attendance';
import { teacherManualEnroll }       from '../../../api/enrollments';
import type { AttendanceRecord }     from '../../../types';
import { IconPlus } from '../../../components/ui/Icon';
import s from './LessonPage.module.css';

type Student = { id: number; first_name: string; last_name: string; email: string };

interface Props {
  lessonId:  number;
  isLocked:  boolean;
  onAdded:   (updatedRecords: AttendanceRecord[]) => void;
  showToast: (msg: string, type: 'success' | 'error') => void;
}

const AddStudentPanel = ({ lessonId, isLocked, onAdded, showToast }: Props) => {
  const [open,    setOpen]    = useState(false);
  const [query,   setQuery]   = useState('');
  const [results, setResults] = useState<Student[]>([]);
  const [loading, setLoading] = useState(false);
  const [adding,  setAdding]  = useState(false);

  useEffect(() => {
    if (!query.trim()) { setResults([]); return; }
    const timer = setTimeout(async () => {
      setLoading(true);
      try { setResults(await searchStudents(query)); }
      finally { setLoading(false); }
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);

  const handleAdd = async (studentId: number) => {
    setAdding(true);
    try {
      await teacherManualEnroll(lessonId, studentId);
      const att = await getAttendanceByLesson(lessonId);
      onAdded(att);
      setQuery(''); setResults([]); setOpen(false);
      showToast('Учня додано', 'success');
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    } finally { setAdding(false); }
  };

  return (
    <>
      <button
        className={s.markAllBtn}
        onClick={() => setOpen(v => !v)}
        disabled={isLocked}
        style={{ marginRight: 4 }}
      >
        <IconPlus size={12} strokeWidth={2.5} />
        Додати учня
      </button>

      {open && !isLocked && (
        <div className={s.addStudentPanel}>
          <div style={{ position: 'relative' }}>
            <input
              className={s.searchInput}
              placeholder="Пошук учня за іменем або email..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              autoFocus
            />
            {(results.length > 0 || loading) && (
              <div className={s.searchDropdown}>
                {loading && (
                  <div className={s.searchDropdownItem} style={{ color: 'var(--graphite)' }}>Пошук...</div>
                )}
                {results.map(r => (
                  <button
                    key={r.id}
                    className={s.searchDropdownItem}
                    onClick={() => handleAdd(r.id)}
                    disabled={adding}
                  >
                    {r.first_name} {r.last_name}
                    <span style={{ color: 'var(--graphite)', marginLeft: 6, fontSize: 11 }}>{r.email}</span>
                  </button>
                ))}
                {results.length === 0 && !loading && query.trim() && (
                  <div className={s.searchDropdownItem} style={{ color: 'var(--graphite)' }}>Нікого не знайдено</div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default AddStudentPanel;
