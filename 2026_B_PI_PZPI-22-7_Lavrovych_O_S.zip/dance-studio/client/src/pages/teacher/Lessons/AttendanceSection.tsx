import { useEffect, useMemo, useState } from 'react';
import { getAttendanceByLesson, markBulk } from '../../../api/attendance';
import AvatarInitials  from '../../../components/ui/display/AvatarInitials';
import SectionLabel    from '../../../components/ui/display/SectionLabel';
import AddStudentPanel from './AddStudentPanel';
import type { AttendanceRecord } from '../../../types';
import { IconX, IconCheck, IconLock } from '../../../components/ui/Icon';
import s from './LessonPage.module.css';

type Status = 'present' | 'absent' | 'excused';

const STATUS_LABELS: Record<Status, string> = {
  present: 'Присутній',
  absent:  'Відсутній',
  excused: 'Поважна',
};

const STATUS_CLS: Record<Status, string> = {
  present: s.btnPresent,
  absent:  s.btnAbsent,
  excused: s.btnExcused,
};

const subLabel = (r: AttendanceRecord) => {
  if (!r.plan_name)           return 'Без абонементу';
  if (r.sessions_left === 0)  return 'Вичерпано';
  if ((r.sessions_left ?? 99) <= 2) return `Залишилось ${r.sessions_left}`;
  return r.plan_name;
};

const subCls = (r: AttendanceRecord) => {
  if (!r.plan_name)           return s.subNone;
  if (r.sessions_left === 0)  return s.subNone;
  if ((r.sessions_left ?? 99) <= 2) return s.subExpiring;
  return s.subActive;
};

interface Props {
  lessonId:  number;
  isLocked:  boolean;
  showToast: (msg: string, type: 'success' | 'error') => void;
}

const AttendanceSection = ({ lessonId, isLocked, showToast }: Props) => {
  const [records,  setRecords]  = useState<AttendanceRecord[]>([]);
  const [statuses, setStatuses] = useState<Record<number, Status>>({});
  const [search,   setSearch]   = useState('');
  const [saving,   setSaving]   = useState(false);

  useEffect(() => {
    getAttendanceByLesson(lessonId).then(att => {
      setRecords(att);
      const init: Record<number, Status> = {};
      att.forEach(r => { init[r.student_id] = r.status; });
      setStatuses(init);
    });
  }, [lessonId]);

  const filtered = useMemo(
    () => records.filter(r =>
      `${r.first_name} ${r.last_name}`.toLowerCase().includes(search.toLowerCase())
    ),
    [records, search],
  );

  const setStatus = (id: number, st: Status) =>
    setStatuses(prev => ({ ...prev, [id]: st }));

  const allPresent = records.length > 0 && records.every(r => statuses[r.student_id] === 'present');

  const toggleAllPresent = () =>
    setStatuses(prev => {
      const next   = { ...prev };
      const target = allPresent ? 'absent' : 'present';
      records.forEach(r => { next[r.student_id] = target; });
      return next;
    });

  const handleStudentAdded = (att: AttendanceRecord[]) => {
    setRecords(att);
    setStatuses(prev => {
      const next = { ...prev };
      att.forEach(r => { if (!(r.student_id in next)) next[r.student_id] = r.status; });
      return next;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await markBulk({
        lesson_id: lessonId,
        records: Object.entries(statuses).map(([sid, st]) => ({
          student_id: Number(sid), status: st,
        })),
      });
      showToast('Відвідуваність збережена', 'success');
    } catch {
      showToast('Помилка збереження', 'error');
    } finally { setSaving(false); }
  };

  const presentCount = Object.values(statuses).filter(st => st === 'present').length;

  return (
    <div className={s.attendanceBlock}>
      <div className={s.attendanceHead}>
        <SectionLabel mb={0}>ВІДВІДУВАНІСТЬ</SectionLabel>
        <div className={s.headRight}>
          <AddStudentPanel
            lessonId={lessonId} isLocked={isLocked}
            onAdded={handleStudentAdded} showToast={showToast}
          />
          {records.length > 0 && (
            <>
              <button className={s.markAllBtn} onClick={toggleAllPresent} disabled={isLocked}>
                {allPresent ? (
                  <IconX size={12} strokeWidth={2.5} />
                ) : (
                  <IconCheck size={12} strokeWidth={2.5} />
                )}
                {allPresent ? 'Всі відсутні' : 'Всі присутні'}
              </button>
              <span className={s.attendanceStat}>{presentCount} / {records.length}</span>
            </>
          )}
        </div>
      </div>

      {isLocked && (
        <div className={s.lockedBanner}>
          <IconLock size={14} />
          Відмітка буде доступна в день заняття (за годину до початку)
        </div>
      )}

      <input
        className={s.searchInput}
        placeholder="Пошук за іменем..."
        value={search}
        onChange={e => setSearch(e.target.value)}
      />

      {records.length === 0 ? (
        <div className={s.emptyMsg}>У занятті немає записаних учнів</div>
      ) : filtered.length === 0 ? (
        <div className={s.emptyMsg}>Нічого не знайдено</div>
      ) : (
        <div className={s.studentList}>
          {filtered.map(r => (
            <div key={r.student_id} className={s.studentRow}>
              <AvatarInitials firstName={r.first_name} lastName={r.last_name} src={r.avatar_url} size={36} fontSize={12} />
              <div className={s.studentInfo}>
                <div className={s.studentName}>{r.first_name} {r.last_name}</div>
                <span className={`${s.subBadge} ${subCls(r)}`}>{subLabel(r)}</span>
              </div>
              <div className={s.statusGroup}>
                {(['present', 'absent', 'excused'] as Status[]).map(st => (
                  <button
                    key={st}
                    onClick={() => setStatus(r.student_id, st)}
                    disabled={isLocked}
                    className={`${s.statusBtn} ${STATUS_CLS[st]} ${statuses[r.student_id] === st ? s.btnActive : ''}`}
                  >
                    {STATUS_LABELS[st]}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className={s.footer}>
        <div className={s.footerLeft}>
          {records.length > 0 && (
            <span className={s.footerStat}>{presentCount} / {records.length} присутні</span>
          )}
        </div>
        <button
          className={s.saveBtn}
          onClick={handleSave}
          disabled={saving || records.length === 0 || isLocked}
        >
          {saving && <span className={s.spinnerEl} />}
          Зберегти
        </button>
      </div>
    </div>
  );
};

export default AttendanceSection;
