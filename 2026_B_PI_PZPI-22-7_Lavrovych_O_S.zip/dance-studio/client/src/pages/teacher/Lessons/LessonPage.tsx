import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { localToday } from '../../../utils/dateUtils';
import { getLessonById }           from '../../../api/lessons';
import { useToast }                from '../../../hooks/useToast';
import Spinner          from '../../../components/ui/feedback/Spinner';
import Toast            from '../../../components/ui/feedback/Toast';
import LessonHero       from './LessonHero';
import LessonNotes      from './LessonNotes';
import AttendanceSection from './AttendanceSection';
import type { Lesson } from '../../../types';
import { IconChevronLeft } from '../../../components/ui/Icon';
import s from './LessonPage.module.css';

const LessonPage = () => {
  const { id }   = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toasts, showToast, removeToast } = useToast();

  const [lesson,  setLesson]  = useState<Lesson | null>(null);
  const [notes,   setNotes]   = useState('');
  const [loading, setLoading] = useState(true);

  const lessonId = Number(id);

  useEffect(() => {
    if (!lessonId) return;
    getLessonById(lessonId)
      .then(l => { setLesson(l); setNotes((l as any).notes ?? ''); })
      .finally(() => setLoading(false));
  }, [lessonId]);

  if (loading) return <Spinner centered />;
  if (!lesson) return null;

  const today   = localToday();
  const nowTime = new Date().toTimeString().slice(0, 5);
  const isDone  = lesson.lesson_date < today ||
    (lesson.lesson_date === today && lesson.end_time.slice(0, 5) <= nowTime);

  const toMinutes = (t: string) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
  const nowMin    = toMinutes(nowTime);
  const startMin  = toMinutes(lesson.start_time.slice(0, 5));
  const isLocked  = !(lesson.lesson_date < today || (lesson.lesson_date === today && nowMin >= startMin - 60));
  const enrolled  = lesson.hall_capacity - (lesson.free_spots ?? 0);

  return (
    <div className={s.page}>
      <button className={s.backBtn} onClick={() => navigate(-1)}>
        <IconChevronLeft size={14} />
        Назад
      </button>

      <LessonHero lesson={lesson} isDone={isDone} enrolled={enrolled} />
      <AttendanceSection lessonId={lessonId} isLocked={isLocked} showToast={showToast} />
      <LessonNotes lessonId={lessonId} initialNotes={notes} showToast={showToast} />

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default LessonPage;
