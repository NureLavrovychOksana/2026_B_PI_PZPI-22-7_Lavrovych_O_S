import { useState } from 'react';
import { updateLessonNotes } from '../../../api/lessons';
import SectionLabel from '../../../components/ui/display/SectionLabel';
import s from './LessonPage.module.css';

interface Props {
  lessonId:     number;
  initialNotes: string;
  showToast:    (msg: string, type: 'success' | 'error') => void;
}

const LessonNotes = ({ lessonId, initialNotes, showToast }: Props) => {
  const [notes,       setNotes]       = useState(initialNotes);
  const [notesSaving, setNotesSaving] = useState(false);

  const handleSave = async () => {
    setNotesSaving(true);
    try {
      await updateLessonNotes(lessonId, notes);
      showToast('Нотатку збережено', 'success');
    } catch {
      showToast('Помилка збереження нотатки', 'error');
    } finally {
      setNotesSaving(false);
    }
  };

  return (
    <div className={s.attendanceBlock} style={{ marginTop: 16 }}>
      <div className={s.attendanceHead}>
        <SectionLabel mb={0}>НОТАТКА ДО ЗАНЯТТЯ</SectionLabel>
      </div>
      <textarea
        className={s.searchInput}
        style={{ minHeight: 96, resize: 'vertical', width: '100%', marginTop: 10 }}
        placeholder="Залиште нотатку про це заняття — матеріал, прогрес, зауваження..."
        value={notes}
        onChange={e => setNotes(e.target.value)}
      />
      <div className={s.footer}>
        <div className={s.footerLeft} />
        <button className={s.saveBtn} onClick={handleSave} disabled={notesSaving}>
          {notesSaving && <span className={s.spinnerEl} />}
          Зберегти нотатку
        </button>
      </div>
    </div>
  );
};

export default LessonNotes;
