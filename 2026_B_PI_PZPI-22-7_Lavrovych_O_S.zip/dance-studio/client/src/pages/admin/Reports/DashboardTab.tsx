import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getDashboard } from '../../../api/reports';
import Spinner                from '../../../components/ui/feedback/Spinner';
import RevenueChart           from './RevenueChart';
import TeacherPanel           from './TeacherPanel';
import StylesTable            from './StylesTable';
import RiskRadar              from './RiskRadar';
import ActivityFeed           from './ActivityFeed';
import DashboardRevenueBlock  from './DashboardRevenueBlock';
import DashboardAttendanceBlock from './DashboardAttendanceBlock';
import { IconAlertTriangle, IconChevronRight, IconTrendUp, IconTrendDown } from '../../../components/ui/Icon';
import type { DashboardData } from '../../../types';
import s from './DashboardTab.module.css';

const IconAlert   = () => <IconAlertTriangle size={15} />;
const IconChevron = () => <IconChevronRight size={13} />;
const IconTrendDwn = () => <IconTrendDown size={11} strokeWidth={2.5} />;

const DashboardTab = () => {
  const navigate = useNavigate();
  const [dash,        setDash]        = useState<DashboardData | null>(null);
  const [loading,     setLoading]     = useState(true);
  const [openTeacher, setOpenTeacher] = useState<number | null>(null);

  useEffect(() => {
    getDashboard()
      .then(setDash)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner centered />;
  if (!dash) return null;

  const { stats, revenue_split, revenue_by_month, styles_popularity, teacher_utilization, anomalies, expiring_soon, funnel, recent_activity, attendance_by_group } = dash;

  const avgUtil = teacher_utilization.length > 0
    ? Math.round(teacher_utilization.reduce((s, t) => s + t.utilization_percent, 0) / teacher_utilization.length)
    : 0;

  const alerts: string[] = [];
  if (stats.churn_risk_count > 0) alerts.push(`${stats.churn_risk_count} учнів у ризику відтоку`);
  if (expiring_soon.length > 0)   alerts.push(`${expiring_soon.length} абонементів закінчується за 3 дні`);
  if (anomalies.length > 0)       alerts.push(`${anomalies.length} груп з критичними пропусками`);
  if (stats.debtors > 0)          alerts.push(`${stats.debtors} боржників без абонементу`);

  return (
    <div>
      {alerts.length > 0 && (
        <div className={s.alertStrip}>
          <span className={s.alertIcon}><IconAlert /></span>
          <div className={s.alertItems}>
            {alerts.map((a, i) => (
              <span key={i} className={s.alertItem}>
                <strong>{a}</strong>
                {i < alerts.length - 1 && <span className={s.alertDot}> ·</span>}
              </span>
            ))}
          </div>
        </div>
      )}

      <DashboardRevenueBlock stats={stats} revenue_split={revenue_split} funnel={funnel} />

      {/* KPI row */}
      <div className={s.row3} style={{ marginBottom: 12 }}>
        <div className={s.kpiCard}>
          <div className={s.kpiLabel}>LTV (СЕРЕДНІЙ ДОХІД)</div>
          <div className={s.kpiValue}>₴ {stats.ltv.toLocaleString('uk-UA')}</div>
          <div className={s.kpiSub}>з одного студента за весь час</div>
        </div>
        <div className={s.kpiCard}>
          <div className={s.kpiLabel}>УТИЛІЗАЦІЯ ВИКЛАДАЧІВ</div>
          <div className={s.kpiValue}>{avgUtil}%</div>
          <div className={`${s.kpiSub} ${avgUtil >= 70 ? s.kpiUp : avgUtil >= 40 ? '' : s.kpiDown}`}>
            {avgUtil >= 70 ? <><IconTrendUp size={11} strokeWidth={2.5} /> ефективно</> : avgUtil >= 40 ? 'є резерв' : <><IconTrendDwn /> низька</>}
          </div>
        </div>
        <div className={s.kpiCard}>
          <div className={s.kpiLabel}>РИЗИК ВІДТОКУ</div>
          <div className={`${s.kpiValue} ${stats.churn_risk_count > 0 ? s.kpiDown : ''}`}
               style={{ color: stats.churn_risk_count > 0 ? 'var(--error)' : undefined }}>
            {stats.churn_risk_count}
          </div>
          <div className={`${s.kpiSub} ${stats.churn_risk_count > 0 ? s.kpiDown : s.kpiUp}`}>
            {stats.churn_risk_count > 0
              ? <><IconTrendDwn /> учнів з аб. але без занять цього місяця</>
              : <><IconTrendUp size={11} strokeWidth={2.5} /> всі активні студенти ходять</>}
          </div>
        </div>
      </div>

      <div className={s.card}>
        <div className={s.cardHead}>
          <div className={s.cardTitle}>ТРЕНД ВИРУЧКИ</div>
          <div className={s.cardBadge}>6 місяців</div>
        </div>
        <div className={s.chartWrap}>
          <RevenueChart data={revenue_by_month} />
        </div>
      </div>

      {teacher_utilization.length > 0 && (
        <div className={s.card}>
          <div className={s.cardHead}>
            <div className={s.cardTitle}>УТИЛІЗАЦІЯ ВИКЛАДАЧІВ</div>
            <div className={s.cardBadge}>{teacher_utilization.length} викл.</div>
          </div>
          {teacher_utilization.map(t => {
            const pct    = t.utilization_percent;
            const barCls = pct >= 70 ? s.barGood : pct >= 40 ? s.barWarn : s.barDanger;
            const pctCls = pct >= 70 ? s.kpiUp   : pct >= 40 ? ''        : s.kpiDown;
            return (
              <div key={t.teacher_id}>
                <div
                  className={s.teacherRow}
                  onClick={() => setOpenTeacher(openTeacher === t.teacher_id ? null : t.teacher_id)}
                >
                  <div className={s.teacherName}>{t.teacher_name}</div>
                  <div className={s.teacherBar}>
                    <div className={`${s.teacherBarFill} ${barCls}`} style={{ width: `${pct}%` }} />
                  </div>
                  <div className={`${s.teacherPct} ${pctCls}`}>{pct}%</div>
                  <div className={s.teacherMeta}>{t.total_hours}г · {t.students_count} уч.</div>
                  <div className={s.teacherArrow}><IconChevron /></div>
                </div>
                {openTeacher === t.teacher_id && (
                  <TeacherPanel
                    t={t}
                    onClose={() => setOpenTeacher(null)}
                    onNavigate={id => navigate(`/admin/reports?tab=teacher&id=${id}`)}
                  />
                )}
              </div>
            );
          })}
        </div>
      )}

      <StylesTable data={styles_popularity} />
      <DashboardAttendanceBlock data={attendance_by_group} />
      <RiskRadar expiring={expiring_soon} anomalies={anomalies} />
      <ActivityFeed events={recent_activity} />
    </div>
  );
};

export default DashboardTab;
