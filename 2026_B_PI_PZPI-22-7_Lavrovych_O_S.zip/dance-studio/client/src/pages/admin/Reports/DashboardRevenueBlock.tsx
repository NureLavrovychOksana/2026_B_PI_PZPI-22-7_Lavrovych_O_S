import type { DashboardStats, RevenueSplit, FunnelData } from '../../../types';
import { IconTrendUp, IconTrendDown } from '../../../components/ui/Icon';
import s from './DashboardTab.module.css';

const fmt  = (n: number) => n.toLocaleString('uk-UA');
const fmtK = (n: number) => n >= 1000 ? `${(n / 1000).toFixed(0)}к` : String(Math.round(n));
const IconTrendDwn = () => <IconTrendDown size={11} strokeWidth={2.5} />;

interface Props {
  stats:         DashboardStats;
  revenue_split: RevenueSplit;
  funnel:        FunnelData;
}

const DashboardRevenueBlock = ({ stats, revenue_split, funnel }: Props) => {
  const revDiff = stats.prev_month_revenue > 0
    ? Math.round(((stats.month_revenue - stats.prev_month_revenue) / stats.prev_month_revenue) * 100)
    : null;

  const totalSplit = revenue_split.new_revenue + revenue_split.renewal_revenue || 1;
  const conv1 = funnel.registered > 0 ? Math.round((funnel.paid_once / funnel.registered) * 100) : 0;
  const conv2 = funnel.paid_once   > 0 ? Math.round((funnel.active_subscription / funnel.paid_once) * 100) : 0;

  return (
    <div className={s.row2} style={{ marginBottom: 12 }}>

      {/* Revenue card */}
      <div className={s.card} style={{ margin: 0 }}>
        <div className={s.cardHead}>
          <div className={s.cardTitle}>ВИРУЧКА / МІСЯЦЬ</div>
          {revDiff !== null && (
            <span className={`${s.revenueTrend} ${revDiff >= 0 ? s.trendUp : s.trendDown}`}>
              {revDiff >= 0 ? <IconTrendUp size={11} strokeWidth={2.5} /> : <IconTrendDwn />}
              {revDiff >= 0 ? '+' : ''}{revDiff}% до мин. місяця
            </span>
          )}
        </div>
        <div className={s.revenueMain}>
          <div className={s.revenueValue}>₴ {fmt(stats.month_revenue)}</div>
        </div>
        <div className={s.splitRow}>
          {[
            { label: 'Нові',       amount: revenue_split.new_revenue,     cls: s.splitBarNew },
            { label: 'Продовження',amount: revenue_split.renewal_revenue,  cls: s.splitBarRenewal },
          ].map(({ label, amount, cls }) => (
            <div key={label} className={s.splitItem}>
              <div className={s.splitLabel}>{label}</div>
              <div className={s.splitBar}>
                <div className={`${s.splitBarFill} ${cls}`}
                     style={{ width: `${Math.round((amount / totalSplit) * 100)}%` }} />
              </div>
              <div className={s.splitAmount}>₴{fmtK(amount)}</div>
              <div className={s.splitPct}>{Math.round((amount / totalSplit) * 100)}%</div>
            </div>
          ))}
        </div>
      </div>

      {/* Funnel card */}
      <div className={s.card} style={{ margin: 0 }}>
        <div className={s.cardHead}>
          <div className={s.cardTitle}>ВОРОНКА КОНВЕРСІЇ</div>
        </div>
        <div className={s.funnel}>
          {[
            { label: 'Зареєстровані', count: funnel.registered, fillCls: s.funnelFill1, pct: null, width: 100 },
            { label: 'Платили ≥1 раз', count: funnel.paid_once, fillCls: s.funnelFill2, pct: conv1, width: funnel.registered > 0 ? (funnel.paid_once / funnel.registered) * 100 : 0 },
            { label: 'Активний аб.',   count: funnel.active_subscription, fillCls: s.funnelFill3, pct: conv2, width: funnel.registered > 0 ? (funnel.active_subscription / funnel.registered) * 100 : 0 },
          ].map(({ label, count, fillCls, pct, width }) => (
            <div key={label} className={s.funnelStep}>
              <div className={s.funnelLabel}>{label}</div>
              <div className={s.funnelBar}>
                <div className={`${s.funnelFill} ${fillCls}`} style={{ width: `${width}%` }} />
              </div>
              <div className={s.funnelNum}>{count}</div>
              <div className={s.funnelConv}>{pct !== null ? `${pct}%` : ''}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardRevenueBlock;
