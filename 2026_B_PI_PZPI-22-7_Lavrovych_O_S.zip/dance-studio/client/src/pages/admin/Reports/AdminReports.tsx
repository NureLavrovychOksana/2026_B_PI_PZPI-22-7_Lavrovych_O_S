import { useSearchParams } from 'react-router-dom';
import PageHeader   from '../../../components/ui/display/PageHeader';
import Tabs         from '../../../components/ui/display/Tabs';
import DashboardTab from './DashboardTab';
import FinanceTab   from './FinanceTab';
import TeacherTab   from './TeacherTab';
import ExportTab    from './ExportTab';

type Tab = 'dashboard' | 'finance' | 'teacher' | 'export';

const TABS: { value: Tab; label: string }[] = [
  { value: 'dashboard', label: 'Дашборд' },
  { value: 'finance',   label: 'Фінансова безпека' },
  { value: 'teacher',   label: 'Викладачі' },
  { value: 'export',    label: 'Експорт' },
];

const AdminReports = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const rawTab    = searchParams.get('tab') as Tab | null;
  const activeTab: Tab = rawTab && TABS.some(t => t.value === rawTab) ? rawTab : 'dashboard';
  const teacherId = Number(searchParams.get('id')) || undefined;

  const handleTabChange = (t: Tab) => setSearchParams({ tab: t });

  return (
    <div>
      <PageHeader title="Звіти" />
      <Tabs tabs={TABS} active={activeTab} onChange={handleTabChange} />

      {activeTab === 'dashboard' && <DashboardTab />}
      {activeTab === 'finance'   && <FinanceTab />}
      {activeTab === 'teacher'   && <TeacherTab initialTeacherId={teacherId} />}
      {activeTab === 'export'    && <ExportTab />}
    </div>
  );
};

export default AdminReports;
