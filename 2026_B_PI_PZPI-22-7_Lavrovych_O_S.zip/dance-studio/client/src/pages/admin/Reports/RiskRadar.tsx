import type { ExpiringSubscription, Anomaly } from '../../../types';
import s from './DashboardTab.module.css';

interface RiskRadarProps {
  expiring:  ExpiringSubscription[];
  anomalies: Anomaly[];
}

const RiskRadar = ({ expiring, anomalies }: RiskRadarProps) => (
  <div className={s.riskGrid}>

    <div className={s.riskCard}>
      <div className={s.riskTitle}>
        ЗАКІНЧУЮТЬСЯ ЗА 3 ДНІ
        <span className={`${s.riskBadge} ${expiring.length > 0 ? s.riskRowBadgeRed : s.riskRowBadgeGreen}`}>
          {expiring.length}
        </span>
      </div>
      {expiring.length === 0
        ? <div className={s.empty}>Все в порядку</div>
        : expiring.slice(0, 5).map(e => (
          <div key={e.subscription_id} className={s.riskRow}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className={s.riskRowName}>{e.first_name} {e.last_name}</div>
              <div className={s.riskRowSub}>{e.plan_name}</div>
            </div>
            <div className={`${s.riskRowBadge} ${e.days_left <= 1 ? s.riskRowBadgeRed : s.riskRowBadgeYellow}`}>
              {e.days_left === 0 ? 'Сьогодні' : `${e.days_left} дн.`}
            </div>
          </div>
        ))
      }
    </div>

    <div className={s.riskCard}>
      <div className={s.riskTitle}>
        АНОМАЛІЇ ВІДВІДУВАНОСТІ
        <span className={`${s.riskBadge} ${anomalies.length > 0 ? s.riskRowBadgeRed : s.riskRowBadgeGreen}`}>
          {anomalies.length}
        </span>
      </div>
      {anomalies.length === 0
        ? <div className={s.empty}>Аномалій немає</div>
        : anomalies.map(a => (
          <div key={a.group_id} className={s.riskRow}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className={s.riskRowName}>{a.group_name}</div>
              <div className={s.riskRowSub}>{a.teacher_name} · {a.style_name}</div>
            </div>
            <div className={`${s.riskRowBadge} ${a.absence_rate >= 50 ? s.riskRowBadgeRed : s.riskRowBadgeYellow}`}>
              {a.absence_rate}% пр.
            </div>
          </div>
        ))
      }
    </div>
  </div>
);

export default RiskRadar;
