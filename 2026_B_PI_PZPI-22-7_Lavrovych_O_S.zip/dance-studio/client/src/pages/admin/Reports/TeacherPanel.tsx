import type { TeacherUtilization } from '../../../types';
import { IconArrowRight, IconX } from '../../../components/ui/Icon';
import s from './DashboardTab.module.css';

const IconArrow = () => <IconArrowRight size={13} />;

interface TeacherPanelProps {
  t:          TeacherUtilization;
  onClose:    () => void;
  onNavigate: (id: number) => void;
}

const TeacherPanel = ({ t, onClose, onNavigate }: TeacherPanelProps) => {
  const pct      = t.utilization_percent;
  const barCls   = pct >= 70 ? s.barGood : pct >= 40 ? s.barWarn : s.barDanger;
  const pctColor = pct >= 70 ? 'var(--success)' : pct >= 40 ? 'var(--warn)' : 'var(--error)';

  return (
    <div className={s.detailPanel}>
      <div className={s.detailHead}>
        <div className={s.detailTitle}>{t.teacher_name}</div>
        <button className={s.detailClose} onClick={onClose} aria-label="Закрити"><IconX size={14} /></button>
      </div>
      <div className={s.detailGrid}>
        <div className={s.detailStat}>
          <div className={s.detailStatVal}>{t.total_lessons}</div>
          <div className={s.detailStatLbl}>ЗАНЯТЬ</div>
        </div>
        <div className={s.detailStat}>
          <div className={s.detailStatVal}>{t.attended_lessons}</div>
          <div className={s.detailStatLbl}>ПРОВЕДЕНІ</div>
        </div>
        <div className={s.detailStat}>
          <div className={s.detailStatVal}>{t.total_hours}г</div>
          <div className={s.detailStatLbl}>ГОДИН</div>
        </div>
        <div className={s.detailStat}>
          <div className={s.detailStatVal}>{t.students_count}</div>
          <div className={s.detailStatLbl}>УЧНІВ</div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
        <div style={{ flex: 1, height: 8, background: 'var(--coal-2)', borderRadius: 4, overflow: 'hidden' }}>
          <div className={`${s.teacherBarFill} ${barCls}`} style={{ width: `${pct}%` }} />
        </div>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 700, color: pctColor }}>
          {pct}%
        </span>
        <span style={{ fontSize: 11, color: 'var(--graphite)' }}>утилізація</span>
      </div>
      {t.total_lessons === 0 && (
        <p style={{ fontSize: 12, color: 'var(--warn)', margin: '0 0 10px' }}>
          Немає занять цього місяця
        </p>
      )}
      <button className={s.detailLink} onClick={() => onNavigate(t.teacher_id)}>
        Повний звіт викладача <IconArrow />
      </button>
    </div>
  );
};

export default TeacherPanel;
