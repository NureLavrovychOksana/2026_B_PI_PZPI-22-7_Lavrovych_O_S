import type { RevenuePoint } from '../../../types';
import s from './DashboardTab.module.css';

const fmtK      = (n: number) => n >= 1000 ? `${(n / 1000).toFixed(0)}к` : String(Math.round(n));
const UA_MONTHS = ['Січ','Лют','Бер','Кві','Тра','Чер','Лип','Сер','Вер','Жов','Лис','Гру'];

const RevenueChart = ({ data }: { data: RevenuePoint[] }) => {
  if (!data.length) return <div className={s.empty}>Немає даних</div>;

  const totals = data.map(d => Number(d.total));
  const maxVal = Math.max(...totals, 1);
  const CW = 580, CH = 130, XO = 38, LH = 24, TP = 18, BP = 8;
  const colW = CW / data.length;
  const barW = Math.max(6, Math.min(44, colW * 0.55));

  return (
    <svg viewBox={`0 0 ${XO + CW} ${TP + CH + LH + BP}`} width="100%" style={{ display: 'block' }}>
      {[0, 0.5, 1].map(f => {
        const y = TP + CH * (1 - f);
        return (
          <g key={f}>
            <line x1={XO} y1={y} x2={XO + CW} y2={y} stroke="#1e1e1c" strokeWidth="1" />
            <text x={XO - 5} y={y + 3} fontSize="9" fill="#3a3a36" textAnchor="end">{fmtK(maxVal * f)}</text>
          </g>
        );
      })}
      {data.map((d, i) => {
        const val = Number(d.total);
        const bH  = val > 0 ? Math.max(3, (val / maxVal) * CH) : 0;
        const x   = XO + i * colW + (colW - barW) / 2;
        const y   = TP + CH - bH;
        const cx  = XO + i * colW + colW / 2;
        const lbl = d.month ? (UA_MONTHS[parseInt(d.month.split('-')[1]) - 1] ?? '') : '';
        return (
          <g key={i}>
            {bH > 0 && <rect x={x} y={y} width={barW} height={bH} fill="#c8fa3a" rx="2" opacity="0.88" />}
            <text x={cx} y={TP + CH + LH + 2} fontSize="10" fill="#3a3a36" textAnchor="middle">{lbl}</text>
            {val > 0 && bH > 20 && (
              <text x={cx} y={y - 4} fontSize="9" fill="#c8fa3a" textAnchor="middle">{fmtK(val)}</text>
            )}
          </g>
        );
      })}
    </svg>
  );
};

export default RevenueChart;
