import type { StyleEnhanced } from '../../../types';
import s from './DashboardTab.module.css';


const ChurnPill = ({ rate }: { rate: number }) => {
  const cls  = rate <= 10 ? s.pillGood : rate <= 30 ? s.pillWarn : s.pillDanger;
  const icon = rate <= 10 ? '✓' : rate <= 30 ? '!' : '↑';
  return <span className={`${s.pill} ${cls}`}>{icon} {rate}%</span>;
};

const AttPill = ({ rate }: { rate: number }) => {
  const cls = rate >= 75 ? s.pillGood : rate >= 50 ? s.pillWarn : rate > 0 ? s.pillDanger : s.pillNeutral;
  return <span className={`${s.pill} ${cls}`}>{rate > 0 ? `${rate}%` : '—'}</span>;
};

const StylesTable = ({ data }: { data: StyleEnhanced[] }) => {
  if (!data.length) return null;
  return (
    <div className={s.card}>
      <div className={s.cardHead}>
        <div className={s.cardTitle}>АНАЛІТИКА НАПРЯМІВ</div>
      </div>
      <div className={s.tableScroll}>
        <table className={s.stylesTable}>
          <thead>
            <tr>
              <th>НАПРЯМ</th>
              <th>УЧН.</th>
              <th>ВІДТІК</th>
              <th>ВІДВІДУВАНІСТЬ</th>
            </tr>
          </thead>
          <tbody>
            {data.map(st => {
              return (
              <tr key={st.style_id}>
                <td>
                  <div className={s.styleNameCell}>{st.style}</div>
                  <div className={s.styleSub}>{st.groups_count} гр. · {st.lessons_count} зан.</div>
                </td>
                <td className={s.mono}>{st.students_count}</td>
                <td><ChurnPill rate={st.churn_rate} /></td>
                <td><AttPill  rate={st.attendance_rate} /></td>
              </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default StylesTable;
