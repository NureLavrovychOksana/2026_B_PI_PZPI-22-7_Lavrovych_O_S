import { useEffect, useState, useCallback, useMemo } from 'react';
import { getTeachers, getTeacherFinance }                from '../../../api/teachers';
import { getTeacherTimesheet, getTeacherDisciplineStats } from '../../../api/reports';
import EmptyState from '../../../components/ui/feedback/EmptyState';
import Spinner    from '../../../components/ui/feedback/Spinner';
import TeacherTimesheetBlock  from './TeacherTimesheetBlock';
import TeacherDisciplineBlock from './TeacherDisciplineBlock';
import type { TeacherTimesheetLesson, TeacherDisciplineStats } from '../../../types';
import type { TeacherFinance } from '../../../api/teachers';
import a from '../../../styles/admin.module.css';
import s from './TeacherTab.module.css';

const MONTHS = [
  'Січень','Лютий','Березень','Квітень','Травень','Червень',
  'Липень','Серпень','Вересень','Жовтень','Листопад','Грудень',
];

const pad = (n: number) => String(n).padStart(2, '0');

const monthRange = (month: number, year: number) => {
  const lastDay = new Date(year, month, 0).getDate();
  return { dateFrom: `${year}-${pad(month)}-01`, dateTo: `${year}-${pad(month)}-${pad(lastDay)}` };
};

const fmtMoney = (n: number) => `₴ ${Math.round(n).toLocaleString('uk-UA')}`;

const rateLabel = (type: string, amount: number) => {
  if (type === 'per_student') return `₴${amount.toLocaleString('uk-UA')} / учень`;
  return `₴${amount.toLocaleString('uk-UA')} / заняття`;
};

interface Props { initialTeacherId?: number }

const TeacherTab = ({ initialTeacherId }: Props = {}) => {
  const now = new Date();

  const [teachers,      setTeachers]      = useState<{ id: number; user_id: number; first_name: string; last_name: string }[]>([]);
  const [teacherUserId, setTeacherUserId] = useState(initialTeacherId ? String(initialTeacherId) : '');
  const [selMonth,      setSelMonth]      = useState(now.getMonth() + 1);
  const [selYear,       setSelYear]       = useState(now.getFullYear());
  const [timesheet,     setTimesheet]     = useState<TeacherTimesheetLesson[]>([]);
  const [discipline,    setDiscipline]    = useState<TeacherDisciplineStats | null>(null);
  const [finance,       setFinance]       = useState<TeacherFinance | null>(null);
  const [loading,       setLoading]       = useState(false);

  useEffect(() => { getTeachers().then(setTeachers); }, []);

  const uid       = Number(teacherUserId);
  const profileId = teachers.find(t => t.user_id === uid)?.id;
  const { dateFrom, dateTo } = useMemo(() => monthRange(selMonth, selYear), [selMonth, selYear]);

  const load = useCallback(() => {
    if (!uid || !profileId) { setTimesheet([]); setDiscipline(null); setFinance(null); return; }
    setLoading(true);
    Promise.all([
      getTeacherTimesheet(uid, { date_from: dateFrom, date_to: dateTo }),
      getTeacherDisciplineStats(uid),
      getTeacherFinance(profileId, { date_from: dateFrom, date_to: dateTo }),
    ]).then(([ts, disc, fin]) => {
      setTimesheet(ts); setDiscipline(disc); setFinance(fin);
    }).finally(() => setLoading(false));
  }, [uid, profileId, dateFrom, dateTo]);

  useEffect(() => { load(); }, [load]);

  const attendedLess   = timesheet.filter(r => r.present_count > 0).length;
  const conductedHours = timesheet.filter(r => r.present_count > 0).reduce((acc, r) => acc + r.duration_hours, 0);

  const rateType   = finance?.rate_type   ?? 'per_lesson';
  const rateAmount = finance?.rate_amount ?? 0;
  const earnings   = finance?.total_earnings ?? 0;
  const totalPaid  = finance?.total_paid ?? 0;
  const balance    = finance?.balance ?? 0;

  const yearOptions = Array.from({ length: 4 }, (_, i) => now.getFullYear() - i);

  return (
    <div className={s.wrap}>
      <div className={s.selector} style={{ gap: 12, flexWrap: 'wrap' }}>
        <span className={s.selectorLabel}>ВИКЛАДАЧ</span>
        <select className={a.filterSelect} value={teacherUserId} onChange={e => setTeacherUserId(e.target.value)} style={{ minWidth: 200 }}>
          <option value="">Оберіть викладача…</option>
          {teachers.map(t => <option key={t.user_id} value={t.user_id}>{t.first_name} {t.last_name}</option>)}
        </select>

        <span className={s.selectorLabel} style={{ marginLeft: 8 }}>МІСЯЦЬ</span>
        <select className={a.filterSelect} value={selMonth} onChange={e => setSelMonth(Number(e.target.value))}>
          {MONTHS.map((m, i) => <option key={i + 1} value={i + 1}>{m}</option>)}
        </select>
        <select className={a.filterSelect} value={selYear} onChange={e => setSelYear(Number(e.target.value))}>
          {yearOptions.map(y => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>

      {!teacherUserId ? (
        <EmptyState title="Оберіть викладача" text="Виберіть викладача зі списку для перегляду табеля та розрахунку зарплати" />
      ) : loading ? (
        <Spinner centered />
      ) : (
        <>
          {/* Block A: Payroll KPIs */}
          <div className={s.block}>
            <div className={s.blockHead}>
              <div className={s.blockLetter}>A</div>
              <div className={s.blockTitle}>РОЗРАХУНОК ЗП — {MONTHS[selMonth - 1]} {selYear}</div>
            </div>
            <div className={s.blockBody}>
              <div className={s.kpiGrid}>
                <div className={s.kpiCard}>
                  <div className={s.kpiLbl}>ЗАНЯТЬ</div>
                  <div className={s.kpiVal}>{attendedLess}</div>
                  <div className={s.kpiSub}>{conductedHours.toFixed(1)} год · проведено</div>
                </div>
                <div className={s.kpiCard}>
                  <div className={s.kpiLbl}>ВІДВІДУВАНЬ УЧНІВ</div>
                  <div className={s.kpiVal}>{finance?.total_attendance ?? 0}</div>
                  <div className={s.kpiSub}>присутніх за місяць</div>
                </div>
                <div className={s.kpiCard}>
                  <div className={s.kpiLbl}>НАРАХОВАНО</div>
                  <div className={s.kpiVal} style={{ color: 'var(--lime-hot)' }}>{fmtMoney(earnings)}</div>
                  <div className={s.kpiSub}>{rateLabel(rateType, rateAmount)}</div>
                </div>
                <div className={s.kpiCard}>
                  <div className={s.kpiLbl}>ДО ВИПЛАТИ</div>
                  <div className={s.kpiVal} style={{ color: balance > 0 ? 'var(--warn)' : 'var(--success)' }}>
                    {fmtMoney(balance)}
                  </div>
                  <div className={s.kpiSub}>{fmtMoney(earnings)} − {fmtMoney(totalPaid)} виплачено</div>
                </div>
              </div>
              <div className={s.rateRow}>
                <span className={s.rateLabel}>Ставка:</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--lime)' }}>
                  {rateLabel(rateType, rateAmount)}
                </span>
                {rateAmount === 0 && (
                  <span style={{ fontSize: 11, color: 'var(--warn)', marginLeft: 8 }}>
                    ⚠ Ставку не встановлено — встановіть у картці викладача
                  </span>
                )}
              </div>
            </div>
          </div>

          <TeacherTimesheetBlock
            timesheet={timesheet} rateType={rateType} rateAmount={rateAmount}
            earnings={earnings} totalHours={conductedHours}
            selMonth={selMonth} selYear={selYear} loading={false}
          />

          <TeacherDisciplineBlock discipline={discipline} />
        </>
      )}
    </div>
  );
};

export default TeacherTab;
