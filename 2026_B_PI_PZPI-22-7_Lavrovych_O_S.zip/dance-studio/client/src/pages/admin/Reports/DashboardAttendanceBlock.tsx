import type { AttendanceGroupReport } from '../../../types';
import s from './DashboardTab.module.css';

interface Props { data: AttendanceGroupReport[] }

const DashboardAttendanceBlock = ({ data }: Props) => {
  if (data.length === 0) return null;
  return (
    <div className={s.card}>
      <div className={s.cardHead}>
        <div className={s.cardTitle}>ВІДВІДУВАНІСТЬ ГРУП — ПОТОЧНИЙ МІСЯЦЬ</div>
        <div className={s.cardBadge}>{data.length} груп</div>
      </div>
      {[...data]
        .sort((a, b) => Number(a.attendance_percent) - Number(b.attendance_percent))
        .map(g => {
          const pct    = Number(g.attendance_percent) || 0;
          const barCls = pct >= 75 ? s.barGood : pct >= 50 ? s.barWarn : s.barDanger;
          const pctCls = pct >= 75 ? s.kpiUp   : pct >= 50 ? ''        : s.kpiDown;
          return (
            <div key={g.id} className={s.teacherRow} style={{ cursor: 'default' }}>
              <div className={s.teacherName} style={{ width: 160 }}>
                <div style={{ fontWeight: 600, fontSize: 12 }}>{g.group_name}</div>
                <div style={{ fontSize: 10, color: 'var(--graphite)' }}>{g.teacher_name}</div>
              </div>
              <div className={s.teacherBar}>
                <div className={`${s.teacherBarFill} ${barCls}`} style={{ width: `${pct}%` }} />
              </div>
              <div className={`${s.teacherPct} ${pctCls}`}>{pct}%</div>
              <div className={s.teacherMeta}>
                {g.present_count === 0 && g.absent_count === 0 ? (
                  <span style={{ color: 'var(--graphite)' }}>без відміток</span>
                ) : (
                  <>
                    <span style={{ color: 'var(--success)' }}>{g.present_count}</span>
                    {' / '}
                    <span style={{ color: 'var(--error)' }}>{g.absent_count}</span>
                  </>
                )}
                {' · '}
                {g.total_lessons} зан.
              </div>
            </div>
          );
        })
      }
    </div>
  );
};

export default DashboardAttendanceBlock;
