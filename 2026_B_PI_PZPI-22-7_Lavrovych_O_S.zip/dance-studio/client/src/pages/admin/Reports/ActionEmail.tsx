import { useState } from 'react';
import api from '../../../api/axios';
import { IconMail, IconCheck } from '../../../components/ui/Icon';
import a from '../../../styles/admin.module.css';
import s from './FinanceTab.module.css';

interface Props { email: string; name: string; type?: string }

const ActionEmail = ({ email, name, type }: Props) => {
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');

  const handleSend = async () => {
    if (status !== 'idle') return;
    setStatus('sending');
    try {
      await api.post('/notifications/send-email', { to: email, name, type: type ?? 'debtor' });
      setStatus('sent');
      setTimeout(() => setStatus('idle'), 3000);
    } catch {
      setStatus('error');
      setTimeout(() => setStatus('idle'), 3000);
    }
  };

  return (
    <button
      className={`${s.actionBtn} ${status === 'sent' ? s.actionBtnSent : status === 'error' ? s.actionBtnError : ''}`}
      onClick={handleSend}
      disabled={status === 'sending'}
      title={`Відправити email на ${email}`}
    >
      {status === 'sending'
        ? <span className={a.spinner} style={{ width: 11, height: 11 }} />
        : status === 'sent' ? <IconCheck size={13} strokeWidth={2.5} /> : <IconMail size={13} />}
      {status === 'sending' ? 'Надсилаю…' : status === 'sent' ? 'Надіслано' : status === 'error' ? 'Помилка' : 'Email'}
    </button>
  );
};

export default ActionEmail;
