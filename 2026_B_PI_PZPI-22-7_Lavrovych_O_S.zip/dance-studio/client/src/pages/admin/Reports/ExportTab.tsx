import api from '../../../api/axios';
import { ExportCard, SectionHeader, IconTable, IconRows, IconUsers, IconPrint, IconDoc } from './ExportCard';
import { exportPayrollPdf, exportDirectorReportPdf } from './exportPdf.utils';
import s from './ExportTab.module.css';

const downloadFromApi = async (path: string, filename: string) => {
  const { data } = await api.get(path, { responseType: 'blob' });
  const url = URL.createObjectURL(data);
  const a   = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a); URL.revokeObjectURL(url);
};

const ExportTab = () => {
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className={s.wrap}>

      <div className={s.section}>
        <SectionHeader icon={<IconTable />} title="Excel / CSV — Сирі дані" />
        <div className={s.grid}>
          <ExportCard
            icon={<IconRows />}
            title="Лог відвідуваності"
            btnLabel="Завантажити Excel"
            onExport={() => downloadFromApi('/reports/attendance-csv', `log_vidviduvanosti_${today}.xlsx`)}
          />
          <ExportCard
            icon={<IconRows />}
            title="Лог транзакцій"
            btnLabel="Завантажити Excel"
            onExport={() => downloadFromApi('/reports/transaction-csv', `log_tranzaktsii_${today}.xlsx`)}
          />
          <ExportCard
            icon={<IconUsers />}
            title="Список боржників"
            btnLabel="Завантажити Excel"
            onExport={() => downloadFromApi('/reports/debtors-csv', `borgnyky_${today}.xlsx`)}
          />
        </div>
      </div>

      <div className={s.section}>
        <SectionHeader icon={<IconPrint />} title="PDF / Друк — Фіксовані документи" />
        <div className={s.grid}>
          <ExportCard
            icon={<IconDoc />}
            title="Табель зарплат викладачів"
            btnLabel="Відкрити PDF"
            secondary
            onExport={exportPayrollPdf}
          />
          <ExportCard
            icon={<IconDoc />}
            title="Звіт директора — підсумок місяця"
            btnLabel="Відкрити PDF"
            secondary
            onExport={exportDirectorReportPdf}
          />
        </div>
      </div>

    </div>
  );
};

export default ExportTab;
