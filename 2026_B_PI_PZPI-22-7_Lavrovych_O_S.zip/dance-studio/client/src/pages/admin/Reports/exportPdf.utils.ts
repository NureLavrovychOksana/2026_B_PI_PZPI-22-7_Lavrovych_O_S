import { getDashboard } from '../../../api/reports';
import { getTeacherPayrollSummary } from '../../../api/teachers';

const printStyles = `
  body { font-family: Arial, sans-serif; font-size: 12px; color: #000; margin: 30px; }
  h1 { font-size: 18px; margin: 0 0 4px; }
  h2 { font-size: 14px; color: #444; font-weight: normal; margin: 0 0 20px; }
  .header { border-bottom: 2px solid #000; padding-bottom: 12px; margin-bottom: 20px; }
  .meta { font-size: 11px; color: #666; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
  th { background: #f4f4f4; border: 1px solid #ccc; padding: 7px 10px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; }
  td { border: 1px solid #ddd; padding: 7px 10px; font-size: 12px; }
  tr:nth-child(even) td { background: #fafafa; }
  .total td { font-weight: bold; background: #f0f0f0 !important; border-top: 2px solid #999; }
  .footer { margin-top: 40px; display: flex; justify-content: space-between; }
  .sign { width: 200px; border-top: 1px solid #000; text-align: center; padding-top: 6px; font-size: 11px; }
  @media print { @page { margin: 20mm; } }
`;

const openPrintWindow = (title: string, body: string) => {
  const w = window.open('', '_blank', 'width=900,height=700');
  if (!w) { alert('Браузер заблокував вікно. Дозвольте pop-up для цього сайту.'); return; }
  w.document.write(`<!DOCTYPE html><html><head><title>${title}</title><style>${printStyles}</style></head><body>${body}</body></html>`);
  w.document.close();
  w.focus();
  setTimeout(() => { w.print(); }, 600);
};

const fmtMoney = (n: number) => n.toLocaleString('uk-UA');

export const exportPayrollPdf = async () => {
  const now     = new Date();
  const month   = now.toLocaleDateString('uk-UA', { month: 'long', year: 'numeric' });
  const payroll = await getTeacherPayrollSummary(now.getMonth() + 1, now.getFullYear());

  const rateLabel = (type: string, amount: number) =>
    type === 'per_student' ? `${amount.toLocaleString()} ₴/учень` : `${amount.toLocaleString()} ₴/заняття`;

  const rows = payroll.map(t => `
    <tr>
      <td>${t.last_name} ${t.first_name}</td>
      <td style="text-align:center">${t.conducted_lessons}</td>
      <td style="text-align:center">${t.conducted_hours.toFixed(1)}</td>
      <td style="text-align:center">${t.total_enrollments}</td>
      <td style="text-align:center">${rateLabel(t.rate_type, t.rate_amount)}</td>
      <td style="text-align:right;font-weight:bold">₴ ${fmtMoney(Math.round(t.total_earnings))}</td>
    </tr>`).join('');
  const totalEarnings = payroll.reduce((s, t) => s + t.total_earnings, 0);
  const totalHours    = payroll.reduce((s, t) => s + t.conducted_hours, 0).toFixed(1);

  openPrintWindow('Табель зарплат', `
    <div class="header">
      <h1>Танцювальна студія</h1>
      <h2>Табель нарахування заробітної плати — ${month}</h2>
      <div class="meta">Дата формування: ${now.toLocaleDateString('uk-UA')}</div>
    </div>
    <table>
      <thead><tr>
        <th>Викладач</th><th>Занять</th><th>Годин</th>
        <th>Присутніх</th><th>Ставка</th><th>Нараховано</th>
      </tr></thead>
      <tbody>${rows || '<tr><td colspan="6" style="text-align:center;color:#999">Даних за поточний місяць немає</td></tr>'}</tbody>
      <tr class="total">
        <td>РАЗОМ</td><td></td>
        <td style="text-align:center">${totalHours}</td>
        <td></td><td></td>
        <td style="text-align:right">₴ ${fmtMoney(Math.round(totalEarnings))}</td>
      </tr>
    </table>
    <div class="footer">
      <div class="sign">Директор</div>
      <div class="sign">Бухгалтер</div>
    </div>
  `);
};

export const exportDirectorReportPdf = async () => {
  const now   = new Date();
  const month = now.toLocaleDateString('uk-UA', { month: 'long', year: 'numeric' });
  const dash  = await getDashboard();
  const st    = dash.stats;
  const rs    = dash.revenue_split;
  const total = rs.new_revenue + rs.renewal_revenue;
  const newPct = total > 0 ? Math.round(rs.new_revenue / total * 100) : 0;
  const avgUtil = dash.teacher_utilization.length > 0
    ? Math.round(dash.teacher_utilization.reduce((sum, t) => sum + t.utilization_percent, 0) / dash.teacher_utilization.length)
    : 0;

  openPrintWindow('Звіт директора', `
    <div class="header">
      <h1>Танцювальна студія</h1>
      <h2>Управлінський звіт — ${month}</h2>
      <div class="meta">Дата формування: ${now.toLocaleDateString('uk-UA')}</div>
    </div>
    <table>
      <thead><tr><th>Показник</th><th>Значення</th><th>Примітка</th></tr></thead>
      <tbody>
        <tr><td>Виручка за місяць</td><td>₴ ${fmtMoney(st.month_revenue)}</td><td>vs попередній місяць ₴ ${fmtMoney(st.prev_month_revenue)}</td></tr>
        <tr><td>Нові клієнти (виручка)</td><td>₴ ${fmtMoney(rs.new_revenue)} (${newPct}%)</td><td></td></tr>
        <tr><td>Поновлення (виручка)</td><td>₴ ${fmtMoney(rs.renewal_revenue)} (${100 - newPct}%)</td><td></td></tr>
        <tr><td>LTV (сер. цінність клієнта)</td><td>₴ ${fmtMoney(st.ltv)}</td><td></td></tr>
        <tr><td>Учнів в базі</td><td>${st.students}</td><td>всі зареєстровані</td></tr>
        <tr><td>Боржників</td><td>${st.debtors}</td><td>без активного абонементу</td></tr>
        <tr><td>Активних груп</td><td>${st.active_groups}</td><td></td></tr>
        <tr><td>Занять сьогодні</td><td>${st.today_lessons}</td><td></td></tr>
        <tr><td>Заповнюваність залів</td><td>${st.occupancy_percent}%</td><td>середнє за місяць</td></tr>
        <tr><td>Утилізація викладачів</td><td>${avgUtil}%</td><td>серед. по студії</td></tr>
        <tr><td>Ризик відтоку</td><td>${st.churn_risk_count}</td><td>активний абонемент, але не ходить цього місяця</td></tr>
      </tbody>
    </table>
    <div class="footer">
      <div class="sign">Директор</div>
      <div></div>
      <div class="sign">Дата</div>
    </div>
  `);
};
