import Spinner from '../../../components/ui/feedback/Spinner';
import type { TeacherDisciplineStats } from '../../../types';
import s from './TeacherTab.module.css';

const TrafficCard = ({ label, value, sub, status, statusText }: {
  label: string; value: string | number; sub: string;
  status: 'green' | 'yellow' | 'red' | 'gray'; statusText: string;
}) => {
  const dotCls = { green: s.dotGreen, yellow: s.dotYellow, red: s.dotRed, gray: s.dotGray }[status];
  const color  = { green: 'var(--success)', yellow: 'var(--warn)', red: 'var(--error)', gray: 'var(--graphite)' }[status];
  return (
    <div className={s.trafficCard}>
      <div className={`${s.trafficDot} ${dotCls}`} />
      <div className={s.trafficLabel}>{label}</div>
      <div className={s.trafficVal}>{value}</div>
      <div className={s.trafficSub}>{sub}</div>
      <div className={s.trafficStatus} style={{ color }}>{statusText}</div>
    </div>
  );
};

interface Props {
  discipline: TeacherDisciplineStats | null;
}

const TeacherDisciplineBlock = ({ discipline }: Props) => {
  const util = discipline && discipline.total_lessons > 0
    ? Math.round(discipline.conducted_lessons / discipline.total_lessons * 100)
    : 0;

  return (
  <div className={s.block}>
    <div className={s.blockHead}>
      <div className={s.blockLetter}>C</div>
      <div className={s.blockTitle}>ДИСЦИПЛІНА ТА РИЗИКИ — ПОТОЧНИЙ МІСЯЦЬ</div>
    </div>
    <div className={s.blockBody}>
      {!discipline ? <Spinner centered /> : (
        <div className={s.trafficGrid}>
          <TrafficCard
            label="ПРОПУСКИ УЧНІВ"
            value={`${discipline.absence_rate}%`}
            sub={`${discipline.absent_count} пропусків із ${discipline.total_marks} записів`}
            status={discipline.absence_rate <= 20 ? 'green' : discipline.absence_rate <= 40 ? 'yellow' : 'red'}
            statusText={discipline.absence_rate <= 20 ? 'В нормі' : discipline.absence_rate <= 40 ? 'Потребує уваги' : 'Критично'}
          />
          <TrafficCard
            label="RETENTION УЧНІВ"
            value={`${discipline.retention_rate}%`}
            sub={`${discipline.retained} із ${discipline.total_students} учнів повернулись ≥2 рази цього місяця`}
            status={discipline.retention_rate >= 70 ? 'green' : discipline.retention_rate >= 50 ? 'yellow' : discipline.total_students > 0 ? 'red' : 'gray'}
            statusText={discipline.total_students === 0 ? 'Немає даних' : discipline.retention_rate >= 70 ? 'Відмінно' : discipline.retention_rate >= 50 ? 'Задовільно' : 'Низька'}
          />
          <TrafficCard
            label="ЗАНЯТЬ ЦЬОГО МІСЯЦЯ"
            value={discipline.conducted_lessons}
            sub={`із ${discipline.total_lessons} запланованих · ${discipline.excused_count} поважних`}
            status={discipline.conducted_lessons > 0 ? 'green' : discipline.total_lessons > 0 ? 'yellow' : 'gray'}
            statusText={discipline.total_lessons === 0 ? 'Немає занять' : discipline.conducted_lessons === discipline.total_lessons ? 'Всі проведено' : `${discipline.total_lessons - discipline.conducted_lessons} без відміток`}
          />
          <TrafficCard
            label="УТИЛІЗАЦІЯ"
            value={`${util}%`}
            sub={`${discipline.conducted_lessons} із ${discipline.total_lessons} занять проведено`}
            status={util >= 70 ? 'green' : util >= 40 ? 'yellow' : discipline.total_lessons > 0 ? 'red' : 'gray'}
            statusText={discipline.total_lessons === 0 ? 'Немає даних' : util >= 70 ? 'Відмінно' : util >= 40 ? 'Задовільно' : 'Низька'}
          />
        </div>
      )}
    </div>
  </div>
  );
};

export default TeacherDisciplineBlock;
