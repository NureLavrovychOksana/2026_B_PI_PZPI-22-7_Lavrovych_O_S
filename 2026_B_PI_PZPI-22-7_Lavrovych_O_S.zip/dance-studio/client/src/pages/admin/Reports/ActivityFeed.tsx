import type { ActivityItem } from '../../../types';
import { IconUsers } from '../../../components/ui/Icon';
import s from './DashboardTab.module.css';

const ActivityFeed = ({ events }: { events: ActivityItem[] }) => {
  if (!events.length) return null;
  return (
    <div className={s.card}>
      <div className={s.cardHead}>
        <div className={s.cardTitle}>ОСТАННЯ АКТИВНІСТЬ</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <IconUsers size={14} strokeWidth={1.8} />
          <span style={{ fontSize: 10, color: 'var(--graphite)', fontFamily: 'var(--font-mono)' }}>
            {events.length} подій
          </span>
        </div>
      </div>
      {events.map((a, i) => (
        <div key={i} className={s.activityRow}>
          <div className={`${s.activityDot} ${s[`dot_${a.type}`] ?? ''}`} />
          <div className={s.activityBody}>
            <div className={s.activitySubject}>{a.subject}</div>
            <div className={s.activityDesc}>{a.description}</div>
          </div>
          <div className={s.activityTime}>
            {new Date(a.created_at).toLocaleDateString('uk-UA', { day: 'numeric', month: 'short' })}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ActivityFeed;
