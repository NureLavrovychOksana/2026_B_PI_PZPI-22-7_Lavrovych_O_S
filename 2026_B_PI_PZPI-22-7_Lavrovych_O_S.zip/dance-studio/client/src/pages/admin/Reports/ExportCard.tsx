import { useState } from 'react';
import {
  IconTable as _IconTable, IconRows as _IconRows, IconUsers as _IconUsers,
  IconPrinter, IconFile, IconDownload,
} from '../../../components/ui/Icon';
import s from './ExportTab.module.css';

export const IconTable  = () => <_IconTable size={16} strokeWidth={1.8} />;
export const IconRows   = () => <_IconRows size={16} strokeWidth={1.8} />;
export const IconUsers  = () => <_IconUsers size={16} strokeWidth={1.8} />;
export const IconPrint  = () => <IconPrinter size={16} strokeWidth={1.8} />;
export const IconDoc    = () => <IconFile size={16} strokeWidth={1.8} />;
const IconDown = () => <IconDownload size={14} />;

interface CardProps {
  icon:      React.ReactNode;
  title:     string;
  desc?:     string;
  btnLabel:  string;
  onExport:  () => Promise<void>;
  secondary?: boolean;
}

export const ExportCard = ({ icon, title, desc, btnLabel, onExport, secondary }: CardProps) => {
  const [loading, setLoading] = useState(false);
  const handle = async () => {
    setLoading(true);
    try { await onExport(); } catch { /* silent */ } finally { setLoading(false); }
  };
  return (
    <div className={s.card}>
      <div className={s.iconWrap}>{icon}</div>
      <div className={s.info}>
        <div className={s.title}>{title}</div>
        {desc && <div className={s.desc}>{desc}</div>}
      </div>
      <button className={`${s.btn} ${secondary ? s.btnSecondary : ''}`} onClick={handle} disabled={loading}>
        {loading ? <span style={{ opacity: 0.7 }}>Зачекайте…</span> : <><IconDown /> {btnLabel}</>}
      </button>
    </div>
  );
};

export const SectionHeader = ({ icon, title }: { icon: React.ReactNode; title: string }) => (
  <div className={s.sectionHeader}>
    <div className={s.sectionIcon}>{icon}</div>
    <div className={s.sectionTitle}>{title}</div>
  </div>
);
