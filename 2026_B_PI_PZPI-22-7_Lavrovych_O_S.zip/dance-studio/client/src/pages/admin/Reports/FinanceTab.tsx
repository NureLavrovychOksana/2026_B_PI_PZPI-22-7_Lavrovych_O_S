import { useEffect, useState } from 'react';
import { getDebtors, getStudentsAtRisk } from '../../../api/reports';
import Spinner     from '../../../components/ui/feedback/Spinner';
import ActionEmail from './ActionEmail';
import type { Debtor, StudentAtRisk } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './FinanceTab.module.css';

const fmtDate = (d?: string) =>
  d ? new Date(d).toLocaleDateString('uk-UA', { day: 'numeric', month: 'short' }) : '—';

const daysSince = (d?: string): string => {
  if (!d) return 'ніколи';
  const diff = Math.floor((Date.now() - new Date(d).getTime()) / 86_400_000);
  if (diff === 0) return 'сьогодні';
  if (diff === 1) return 'вчора';
  return `${diff} дн. тому`;
};

const SectionHead = ({
  title,
  count,
  level,
  children,
}: {
  title: string;
  count: number;
  level: 'critical' | 'risk';
  children?: React.ReactNode;
}) => (
  <div className={s.sectionHead}>
    <div className={s.sectionTitle}>
      <span className={`${s.dot} ${level === 'critical' ? s.dotCritical : s.dotRisk}`} />
      {title}
      <span className={`${s.countBadge} ${level === 'critical' ? s.countBadgeCritical : s.countBadgeRisk}`}>
        {count}
      </span>
    </div>
    {children}
  </div>
);

const SectionEmpty = ({ msg }: { msg: string }) => (
  <div className={s.emptySection}>{msg}</div>
);

const FinanceTab = () => {
  const [debtors,  setDebtors]  = useState<Debtor[]>([]);
  const [atRisk,   setAtRisk]   = useState<StudentAtRisk[]>([]);
  const [search,   setSearch]   = useState('');
  const [loading,  setLoading]  = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([getDebtors(), getStudentsAtRisk(2)])
      .then(([d, r]) => { setDebtors(d); setAtRisk(r); })
      .finally(() => setLoading(false));
  }, []);

  const filteredDebtors = debtors.filter(d =>
    !search || `${d.first_name} ${d.last_name} ${d.email}`.toLowerCase().includes(search.toLowerCase())
  );
  const filteredRisk = atRisk.filter(r =>
    !search || `${r.first_name} ${r.last_name} ${r.email}`.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <Spinner centered />;

  return (
    <div className={s.wrap}>

      {/* Global search */}
      <div className={s.searchRow}>
        <input
          className={a.searchInput}
          placeholder="Пошук по імені або email…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ maxWidth: 280 }}
        />
        <div className={s.legend}>
          <span className={s.legendDot} style={{ background: 'var(--error)' }} /> Критично
          <span className={s.legendDot} style={{ background: 'var(--warn)', marginLeft: 14 }} /> Зона ризику
        </div>
      </div>

      <div className={s.section}>
        <SectionHead title="Критичний рівень — Боржники" count={debtors.length} level="critical">
        </SectionHead>

        {filteredDebtors.length === 0 ? (
          <SectionEmpty
            msg={debtors.length === 0 ? '✓ Боржників немає — всі учні з активними абонементами' : 'Нічого не знайдено'}
          />
        ) : (
          <div className={s.table}>
            <div className={`${s.tableRow} ${s.tableHead} ${s.tableRowCritical}`}>
              <div className={s.colName}>Учень</div>
              <div className={s.colContact}>Контакт</div>
              <div className={s.colDate}>Остання оплата</div>
              <div className={s.colActions}>Дія</div>
            </div>
            {filteredDebtors.map(d => (
              <div key={d.id} className={`${s.tableRow} ${s.tableRowCritical}`}>
                <div className={s.colName}>
                  <div className={`${a.avatar} ${s.avatarSmall}`}>
                    {d.first_name[0]}{d.last_name[0]}
                  </div>
                  <div>
                    <div className={s.name}>{d.first_name} {d.last_name}</div>
                    <div className={s.sub}>{d.email}</div>
                  </div>
                </div>
                <div className={s.colContact}>
                  {d.phone ? <span className={s.phone}>{d.phone}</span> : <span className={s.noData}>—</span>}
                </div>
                <div className={s.colDate}>
                  <span className={s.dateVal}>
                    {d.last_payment ? fmtDate(d.last_payment) : 'ніколи'}
                  </span>
                  <span className={s.dateSub}>{daysSince(d.last_payment ?? undefined)}</span>
                </div>
                <div className={s.colActions}>
                  <ActionEmail email={d.email} name={`${d.first_name} ${d.last_name}`} type="debtor" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className={s.section}>
        <SectionHead title="Зона ризику — Закінчується абонемент" count={atRisk.length} level="risk">
        </SectionHead>

        {filteredRisk.length === 0 ? (
          <SectionEmpty
            msg={atRisk.length === 0 ? '✓ Всі активні учні мають достатньо занять' : 'Нічого не знайдено'}
          />
        ) : (
          <div className={s.table}>
            <div className={`${s.tableRow} ${s.tableHead} ${s.tableRowRisk}`}>
              <div className={s.colName}>Учень</div>
              <div className={s.colPlan}>Абонемент</div>
              <div className={s.colSessions}>Залишилось</div>
              <div className={s.colDate}>Останнє заняття</div>
              <div className={s.colActions}>Нагадування</div>
            </div>
            {filteredRisk.map(r => (
              <div key={r.subscription_id} className={`${s.tableRow} ${s.tableRowRisk}`}>
                <div className={s.colName}>
                  <div className={`${a.avatar} ${s.avatarSmall}`}>
                    {r.first_name[0]}{r.last_name[0]}
                  </div>
                  <div>
                    <div className={s.name}>{r.first_name} {r.last_name}</div>
                    <div className={s.sub}>{r.email}</div>
                  </div>
                </div>
                <div className={s.colPlan}>
                  <div className={s.planName}>{r.plan_name}</div>
                  {r.expiry_date && (
                    <div className={s.sub}>до {fmtDate(r.expiry_date)}</div>
                  )}
                </div>
                <div className={s.colSessions}>
                  <span className={`${s.sessionsBadge} ${r.sessions_left === 0 ? s.sessionsBadgeRed : s.sessionsBadgeYellow}`}>
                    {r.sessions_left === 0 ? '0 занять' : `${r.sessions_left} зан.`}
                  </span>
                </div>
                <div className={s.colDate}>
                  <span className={s.dateVal}>{fmtDate(r.last_lesson_date ?? undefined)}</span>
                  <span className={s.dateSub}>{daysSince(r.last_lesson_date ?? undefined)}</span>
                </div>
                <div className={s.colActions}>
                  <ActionEmail email={r.email} name={`${r.first_name} ${r.last_name}`} type="risk" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};

export default FinanceTab;
