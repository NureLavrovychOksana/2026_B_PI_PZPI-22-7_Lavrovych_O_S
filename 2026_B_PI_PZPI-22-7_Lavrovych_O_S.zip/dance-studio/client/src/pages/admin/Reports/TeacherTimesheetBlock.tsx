import Spinner from '../../../components/ui/feedback/Spinner';
import type { TeacherTimesheetLesson } from '../../../types';
import s from './TeacherTab.module.css';

const MONTHS = [
  'Січень','Лютий','Березень','Квітень','Травень','Червень',
  'Липень','Серпень','Вересень','Жовтень','Листопад','Грудень',
];

const fmtDate  = (iso: string) => { const [y, m, d] = iso.split('-'); return `${d}.${m}.${y}`; };
const fmtMoney = (n: number) => `₴ ${Math.round(n).toLocaleString('uk-UA')}`;

const rowAmount = (type: string, amount: number, row: TeacherTimesheetLesson) =>
  type === 'per_student' ? amount * row.present_count : amount;

interface Props {
  timesheet:   TeacherTimesheetLesson[];
  rateType:    string;
  rateAmount:  number;
  earnings:    number;
  totalHours:  number;
  selMonth:    number;
  selYear:     number;
  loading:     boolean;
}

const TeacherTimesheetBlock = ({ timesheet, rateType, rateAmount, earnings, totalHours, selMonth, selYear, loading }: Props) => (
  <div className={s.block}>
    <div className={s.blockHead}>
      <div className={s.blockLetter}>B</div>
      <div className={s.blockTitle}>ТАБЕЛЬ ЗАНЯТЬ</div>
      <div className={s.blockBadge}>{timesheet.length} зан.</div>
    </div>
    <div className={s.blockBody}>
      {loading ? <Spinner centered /> : timesheet.length === 0 ? (
        <div style={{ fontSize: 12, color: 'var(--graphite)', textAlign: 'center', padding: '20px 0' }}>
          Немає занять за {MONTHS[selMonth - 1]} {selYear}
        </div>
      ) : (
        <div className={s.timesheetScroll}>
          <table className={s.timesheetTable}>
            <thead>
              <tr>
                <th>ДАТА</th>
                <th>ЧАС</th>
                <th>ГРУПА / СТИЛЬ</th>
                <th style={{ textAlign: 'center' }}>УЧНІВ / ПРИС.</th>
                <th style={{ textAlign: 'right' }}>ГОД.</th>
                <th style={{ textAlign: 'right' }}>СУМА</th>
              </tr>
            </thead>
            <tbody>
              {timesheet.map(row => {
                const amt = rowAmount(rateType, rateAmount, row);
                return (
                  <tr key={row.lesson_id}>
                    <td className={s.timesheetDate}>{fmtDate(row.lesson_date)}</td>
                    <td className={s.timesheetTime}>{row.start_time}–{row.end_time}</td>
                    <td>
                      <div className={s.timesheetGroup}>{row.group_name}</div>
                      <div className={s.timesheetStyle}>{row.style_name}</div>
                    </td>
                    <td>
                      <div className={s.attCell}>
                        <span className={s.attPresent}>{row.present_count}</span>
                        <span className={s.attSlash}>/</span>
                        <span className={s.attTotal}>{row.enrolled_count}</span>
                      </div>
                    </td>
                    <td className={s.mono} style={{ textAlign: 'right' }}>{row.duration_hours.toFixed(1)}</td>
                    <td className={s.amountCell}>{fmtMoney(amt)}</td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className={s.timesheetTotalRow}>
                <td colSpan={4}>РАЗОМ</td>
                <td style={{ textAlign: 'right' }}>{totalHours.toFixed(1)}</td>
                <td style={{ textAlign: 'right', color: 'var(--lime-hot)', fontWeight: 700 }}>{fmtMoney(earnings)}</td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </div>
  </div>
);

export default TeacherTimesheetBlock;
