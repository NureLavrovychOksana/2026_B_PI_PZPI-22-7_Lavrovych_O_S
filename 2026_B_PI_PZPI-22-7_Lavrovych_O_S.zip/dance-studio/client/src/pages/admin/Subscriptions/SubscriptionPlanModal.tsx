﻿import { useState } from 'react';
import Modal     from '../../../components/ui/overlay/Modal';
import FormField from '../../../components/ui/form/FormField';
import type { SubscriptionPlan } from '../../../types';
import a from '../../../styles/admin.module.css';

interface PlanFormData {
  name:           string;
  type:           'COUNT' | 'UNLIMITED';
  sessions_count: string;
  validity_days:  string;
  price:          string;
}

interface Props {
  plan?:   SubscriptionPlan | null;
  loading: boolean;
  onSave:  (data: PlanFormData) => Promise<void>;
  onClose: () => void;
}

const SubscriptionPlanModal = ({ plan, loading, onSave, onClose }: Props) => {
  const [form, setForm]     = useState<PlanFormData>({
    name:           plan?.name                            ?? '',
    type:           plan?.type                            ?? 'COUNT',
    sessions_count: plan?.sessions_count != null ? String(plan.sessions_count) : '',
    validity_days:  plan?.validity_days  != null ? String(plan.validity_days)  : '',
    price:          plan?.price          != null ? String(plan.price)          : '',
  });
  const [errors, setErrors] = useState<Partial<PlanFormData>>({});

  const set = (field: keyof PlanFormData) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setForm(p => ({ ...p, [field]: e.target.value }));
      setErrors(p => ({ ...p, [field]: undefined }));
    };

  const validate = () => {
    const e: Partial<PlanFormData> = {};
    if (!form.name.trim())                       e.name  = "Обовʼязкове поле";
    if (!form.price || Number(form.price) < 0)   e.price = 'Вкажіть коректну ціну';
    if (form.type === 'COUNT' && !form.sessions_count)
      e.sessions_count = 'Вкажіть кількість занять';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onSave(form);
  };

  return (
    <Modal
      title={plan ? 'Редагувати тариф' : 'Новий тариф'}
      onClose={onClose}
      footer={
        <>
          <div style={{ flex: 1 }} />
          <button type="button" className={a.btnSecondary} onClick={onClose}>Скасувати</button>
          <button type="button" className={a.btnPrimary} disabled={loading} onClick={handleSubmit}>
            {loading && <span className={a.spinner} />}
            {plan ? 'Зберегти' : 'Створити'}
          </button>
        </>
      }
    >
      <FormField label="НАЗВА" error={errors.name}>
        <input
          className={`${a.input} ${errors.name ? a.inputError : ''}`}
          value={form.name}
          onChange={set('name')}
          placeholder="Абонемент 8 занять"
        />
      </FormField>

      <div className={a.formRow}>
        <FormField label="ТИП">
          <select className={a.input} value={form.type} onChange={set('type')}>
            <option value="COUNT">Кількісний</option>
            <option value="UNLIMITED">Безлімітний</option>
          </select>
        </FormField>

        <FormField label="ЦІНА (₴)" error={errors.price}>
          <input
            type="number" min="0" step="0.01"
            className={`${a.input} ${errors.price ? a.inputError : ''}`}
            value={form.price}
            onChange={set('price')}
            placeholder="1600"
          />
        </FormField>
      </div>

      <div className={a.formRow}>
        <FormField
          label="КІЛЬКІСТЬ ЗАНЯТЬ"
          error={errors.sessions_count}
        >
          <input
            type="number" min="1"
            className={`${a.input} ${errors.sessions_count ? a.inputError : ''}`}
            value={form.sessions_count}
            onChange={set('sessions_count')}
            placeholder="8"
            disabled={form.type === 'UNLIMITED'}
          />
        </FormField>

        <FormField label="ТЕРМІН ДІЇ (днів)">
          <input
            type="number" min="1"
            className={a.input}
            value={form.validity_days}
            onChange={set('validity_days')}
            placeholder="60"
          />
        </FormField>
      </div>
    </Modal>
  );
};

export default SubscriptionPlanModal;
export type { PlanFormData };
