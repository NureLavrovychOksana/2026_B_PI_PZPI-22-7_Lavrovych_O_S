import { useEffect, useState } from 'react';
import {
  getPlans, createPlan, updatePlan, removePlan,
  getAllSubscriptions, assignSubscription, cancelSubscription,
} from '../../../api/subscriptions';
import PageHeader    from '../../../components/ui/display/PageHeader';
import Tabs          from '../../../components/ui/display/Tabs';
import ConfirmModal  from '../../../components/ui/overlay/ConfirmModal';
import Toast         from '../../../components/ui/feedback/Toast';
import Spinner       from '../../../components/ui/feedback/Spinner';
import SubscriptionPlanModal  from './SubscriptionPlanModal';
import AssignSubscriptionModal from './AssignSubscriptionModal';
import SubscriptionPlanCards  from './SubscriptionPlanCards';
import SubscriptionsTable     from './SubscriptionsTable';
import type { PlanFormData }   from './SubscriptionPlanModal';
import type { AssignFormData } from './AssignSubscriptionModal';
import { useToast } from '../../../hooks/useToast';
import type { SubscriptionPlan, StudentSubscription } from '../../../types';
import a from '../../../styles/admin.module.css';

const AdminSubscriptions = () => {
  const [plans, setPlans]                   = useState<SubscriptionPlan[]>([]);
  const [subscriptions, setSubscriptions]   = useState<StudentSubscription[]>([]);
  const [loading, setLoading]               = useState(true);
  const [saving, setSaving]                 = useState(false);
  const [activeTab, setActiveTab]           = useState<'plans' | 'subscriptions'>('plans');
  const [planModal, setPlanModal]           = useState<SubscriptionPlan | null | undefined>(undefined);
  const [assignModal, setAssignModal]       = useState(false);
  const [cancelTarget, setCancelTarget]     = useState<StudentSubscription | null>(null);
  const [deletePlanTarget, setDeletePlanTarget] = useState<SubscriptionPlan | null>(null);
  const { toasts, showToast, removeToast }  = useToast();

  const loadPlans         = () => getPlans().then(setPlans);
  const loadSubscriptions = () => getAllSubscriptions().then(setSubscriptions);

  useEffect(() => {
    setLoading(true);
    Promise.all([loadPlans(), loadSubscriptions()]).finally(() => setLoading(false));
  }, []);

  const handleSavePlan = async (form: PlanFormData) => {
    setSaving(true);
    try {
      const payload = {
        name:           form.name,
        type:           form.type,
        sessions_count: form.type === 'COUNT' && form.sessions_count ? Number(form.sessions_count) : undefined,
        validity_days:  form.validity_days ? Number(form.validity_days) : undefined,
        price:          Number(form.price),
      };
      if (planModal) {
        await updatePlan(planModal.id, payload);
        showToast('Тариф оновлено', 'success');
      } else {
        await createPlan(payload);
        showToast('Тариф створено', 'success');
      }
      setPlanModal(undefined);
      loadPlans();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    } finally { setSaving(false); }
  };

  const handleDeletePlan = async () => {
    if (!deletePlanTarget) return;
    setSaving(true);
    try {
      await removePlan(deletePlanTarget.id);
      showToast('Тариф видалено', 'success');
      setDeletePlanTarget(null);
      loadPlans();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    } finally { setSaving(false); }
  };

  const handleRestorePlan = async (plan: SubscriptionPlan) => {
    try {
      await updatePlan(plan.id, { is_active: 1 });
      showToast('Тариф відновлено', 'success');
      loadPlans();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    }
  };

  const handleAssign = async (form: AssignFormData) => {
    setSaving(true);
    try {
      await assignSubscription({ student_id: Number(form.student_id), plan_id: Number(form.plan_id), activation_date: form.activation_date });
      showToast('Абонемент призначено', 'success');
      setAssignModal(false);
      loadSubscriptions();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    } finally { setSaving(false); }
  };

  const handleCancel = async () => {
    if (!cancelTarget) return;
    setSaving(true);
    try {
      await cancelSubscription(cancelTarget.id);
      showToast('Абонемент скасовано', 'success');
      setCancelTarget(null);
      loadSubscriptions();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    } finally { setSaving(false); }
  };

  return (
    <div>
      <PageHeader
        title="Абонементи"
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <button className={a.btnSecondary} onClick={() => setPlanModal(null)}>+ Тариф</button>
            <button className={a.addBtn} onClick={() => setAssignModal(true)}>+ Призначити</button>
          </div>
        }
      />

      <Tabs
        tabs={[
          { value: 'plans',         label: `Тарифи (${plans.length})` },
          { value: 'subscriptions', label: `Абонементи учнів (${subscriptions.length})` },
        ]}
        active={activeTab}
        onChange={v => setActiveTab(v as 'plans' | 'subscriptions')}
      />

      {loading ? <Spinner centered /> : (
        <>
          {activeTab === 'plans' && (
            <SubscriptionPlanCards plans={plans} onEdit={setPlanModal} onDelete={setDeletePlanTarget} onRestore={handleRestorePlan} />
          )}
          {activeTab === 'subscriptions' && (
            <SubscriptionsTable subscriptions={subscriptions} onCancel={setCancelTarget} onAssign={() => setAssignModal(true)} />
          )}
        </>
      )}

      {planModal !== undefined && (
        <SubscriptionPlanModal plan={planModal} loading={saving} onSave={handleSavePlan} onClose={() => setPlanModal(undefined)} />
      )}
      {assignModal && (
        <AssignSubscriptionModal plans={plans.filter(p => p.price > 0)} loading={saving} onSave={handleAssign} onClose={() => setAssignModal(false)} />
      )}
      {deletePlanTarget && (
        <ConfirmModal
          title="Видалити тариф?"
          message={`Тариф "${deletePlanTarget.name}" буде видалено. Існуючі абонементи залишаться.`}
          onConfirm={handleDeletePlan} onCancel={() => setDeletePlanTarget(null)} loading={saving}
        />
      )}
      {cancelTarget && (
        <ConfirmModal
          title="Скасувати абонемент?"
          message={`Скасувати абонемент «${cancelTarget.plan_name}» для ${cancelTarget.first_name} ${cancelTarget.last_name}? Оплата не повертається.`}
          onConfirm={handleCancel} onCancel={() => setCancelTarget(null)} loading={saving}
        />
      )}

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default AdminSubscriptions;
