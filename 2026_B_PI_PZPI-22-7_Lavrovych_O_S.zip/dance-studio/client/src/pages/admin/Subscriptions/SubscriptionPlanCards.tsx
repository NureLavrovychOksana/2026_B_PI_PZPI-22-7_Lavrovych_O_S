import { useState } from 'react';
import EmptyState from '../../../components/ui/feedback/EmptyState';
import Badge from '../../../components/ui/feedback/Badge';
import { IconReset, IconTrash, IconChevronRight } from '../../../components/ui/Icon';
import type { SubscriptionPlan } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './AdminSubscriptions.module.css';

interface Props {
  plans:     SubscriptionPlan[];
  onEdit:    (plan: SubscriptionPlan) => void;
  onDelete:  (plan: SubscriptionPlan) => void;
  onRestore: (plan: SubscriptionPlan) => void;
}

const IcoRestore = () => <IconReset size={13} strokeWidth={1.8} />;
const IcoTrash   = () => <IconTrash size={13} strokeWidth={1.8} />;

const PlanCard = ({ plan, onEdit, onDelete, onRestore }: {
  plan: SubscriptionPlan;
  onEdit:    (p: SubscriptionPlan) => void;
  onDelete:  (p: SubscriptionPlan) => void;
  onRestore: (p: SubscriptionPlan) => void;
}) => {
  const archived = plan.is_active === 0;

  return (
    <div className={s.planCard} style={archived ? { opacity: 0.6 } : undefined}>
      <div style={{ position: 'absolute', top: 14, right: 14, display: 'flex', gap: 6 }}>
        {archived && <Badge variant="neutral">Архівний</Badge>}
        <Badge variant={plan.type === 'COUNT' ? 'lime' : 'info'}>
          {plan.type === 'COUNT' ? 'Кількісний' : 'Безлімітний'}
        </Badge>
      </div>

      <div className={s.planName}>{plan.name}</div>
      <div className={s.planPrice}>₴{plan.price}</div>
      <div className={s.planMeta}>
        {plan.sessions_count && `${plan.sessions_count} занять`}
        {plan.sessions_count && plan.validity_days && ' · '}
        {plan.validity_days  && `${plan.validity_days} днів`}
        {plan.type === 'UNLIMITED' && !plan.validity_days && 'Без обмежень'}
      </div>

      <div className={s.planActions}>
        {archived ? (
          <button
            className={a.btnSecondary}
            style={{ flex: 1, fontSize: 12, padding: '6px 10px' }}
            onClick={() => onRestore(plan)}
          >
            Відновити
          </button>
        ) : (
          <>
            <button
              className={a.btnSecondary}
              style={{ flex: 1, fontSize: 12, padding: '6px 10px' }}
              onClick={() => onEdit(plan)}
            >
              Редагувати
            </button>
            <button className={`${a.iconBtn} ${a.iconBtnDanger}`} onClick={() => onDelete(plan)}>
              <IcoTrash />
            </button>
          </>
        )}
      </div>
    </div>
  );
};

const SubscriptionPlanCards = ({ plans, onEdit, onDelete, onRestore }: Props) => {
  const [archivedOpen, setArchivedOpen] = useState(false);

  const active   = plans.filter(p => p.is_active !== 0);
  const archived = plans.filter(p => p.is_active === 0);

  if (plans.length === 0) return <EmptyState title="Тарифів немає" text="Створіть перший тариф" />;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      {active.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14 }}>
          {active.map(plan => (
            <PlanCard key={plan.id} plan={plan} onEdit={onEdit} onDelete={onDelete} onRestore={onRestore} />
          ))}
        </div>
      )}
      {active.length === 0 && archived.length > 0 && (
        <EmptyState title="Активних тарифів немає" text="Усі тарифи архівовано" />
      )}

      {archived.length > 0 && (
        <div>
          <button
            onClick={() => setArchivedOpen(o => !o)}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--graphite)', fontSize: 12, display: 'flex',
              alignItems: 'center', gap: 6, padding: '4px 0',
            }}
          >
            <span style={{ display: 'flex', transform: archivedOpen ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s' }}>
              <IconChevronRight size={10} />
            </span>
            Архівні ({archived.length})
          </button>

          {archivedOpen && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14, marginTop: 12 }}>
              {archived.map(plan => (
                <PlanCard key={plan.id} plan={plan} onEdit={onEdit} onDelete={onDelete} onRestore={onRestore} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SubscriptionPlanCards;
