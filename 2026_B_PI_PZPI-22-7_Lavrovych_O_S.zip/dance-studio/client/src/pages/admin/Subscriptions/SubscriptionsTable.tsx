import { useMemo, useState } from 'react';
import DataTable  from '../../../components/ui/display/DataTable';
import UserCell   from '../../../components/ui/display/UserCell';
import ProgressBar from '../../../components/ui/display/ProgressBar';
import EmptyState     from '../../../components/ui/feedback/EmptyState';
import FilterPill from '../../../components/ui/display/FilterPill';
import { IconX, IconSearch } from '../../../components/ui/Icon';
import type { StudentSubscription } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './AdminSubscriptions.module.css';

type SubStatus = 'active' | 'pending' | 'exhausted' | 'expired' | 'cancelled';

const STATUS_LABEL: Record<SubStatus, string> = {
  active:    'Активний',
  pending:   'Очікує',
  exhausted: 'Вичерпано',
  expired:   'Прострочено',
  cancelled: 'Скасовано',
};

const STATUS_CLS: Record<SubStatus, string> = {
  active:    a.statusActive,
  pending:   a.statusPending ?? '',
  exhausted: a.statusExhausted,
  expired:   a.statusExpired,
  cancelled: a.statusCancelled,
};

const STATUS_FILTERS: { value: SubStatus | 'all'; label: string }[] = [
  { value: 'all',       label: 'Всі' },
  { value: 'active',    label: 'Активні' },
  { value: 'pending',   label: 'Очікують' },
  { value: 'exhausted', label: 'Вичерпано' },
  { value: 'expired',   label: 'Прострочено' },
  { value: 'cancelled', label: 'Скасовано' },
];

const fmtDate = (iso?: string) =>
  iso ? new Date(iso).toLocaleDateString('uk-UA', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '—';

interface Props {
  subscriptions: StudentSubscription[];
  onCancel:      (sub: StudentSubscription) => void;
  onAssign:      () => void;
}

const SubscriptionsTable = ({ subscriptions, onCancel, onAssign }: Props) => {
  const [search, setSearch]           = useState('');
  const [statusFilter, setStatusFilter] = useState<SubStatus | 'all'>('all');

  const filtered = useMemo(() => {
    let list = subscriptions;
    if (statusFilter !== 'all') {
      list = list.filter(sub => (sub.effective_status ?? sub.status) === statusFilter);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(sub =>
        `${sub.first_name ?? ''} ${sub.last_name ?? ''}`.toLowerCase().includes(q) ||
        (sub.student_email ?? '').toLowerCase().includes(q) ||
        sub.plan_name.toLowerCase().includes(q)
      );
    }
    return list;
  }, [subscriptions, statusFilter, search]);

  const activeCount    = subscriptions.filter(sub => (sub.effective_status ?? sub.status) === 'active').length;
  const exhaustedCount = subscriptions.filter(sub => (sub.effective_status ?? sub.status) === 'exhausted').length;
  const expiredCount   = subscriptions.filter(sub => (sub.effective_status ?? sub.status) === 'expired').length;

  const columns = [
    {
      key: 'student', label: 'УЧЕНЬ',
      render: (sub: StudentSubscription) => (
        <UserCell firstName={sub.first_name ?? '?'} lastName={sub.last_name ?? ''} sub={sub.student_email} />
      ),
    },
    {
      key: 'plan_name', label: 'ТАРИФ',
      render: (sub: StudentSubscription) => (
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--paper)' }}>{sub.plan_name}</div>
          <div style={{ fontSize: 11, color: 'var(--graphite)' }}>
            {sub.plan_type === 'UNLIMITED' ? 'Безлімітний' : `${sub.plan_sessions_count} занять`}
            {' · '}
            <span style={{ color: 'var(--gold)' }}>₴{Number(sub.plan_price).toLocaleString('uk-UA')}</span>
          </div>
        </div>
      ),
    },
    {
      key: 'sessions', label: 'ЗАЛИШОК',
      render: (sub: StudentSubscription) => {
        if (sub.plan_type === 'UNLIMITED') return <span style={{ fontSize: 12, color: 'var(--info)' }}>∞ Безлімітний</span>;
        const total = sub.plan_sessions_count ?? 1;
        const left  = sub.sessions_left ?? 0;
        const pct   = Math.max((left / total) * 100, 0);
        const color = pct <= 20 ? 'error' : pct <= 40 ? 'warn' : 'lime' as const;
        return (
          <div className={s.subProgress}>
            <ProgressBar value={pct} color={color} height={4} />
            <span className={s.progressText}>{left}/{total}</span>
          </div>
        );
      },
    },
    {
      key: 'purchase_date', label: 'КУПЛЕНО',
      render: (sub: StudentSubscription) => (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12 }}>
          <div style={{ color: 'var(--paper)' }}>{fmtDate(sub.purchase_date)}</div>
          {sub.expiry_date && <div style={{ color: 'var(--graphite)', marginTop: 2 }}>до {fmtDate(sub.expiry_date)}</div>}
        </div>
      ),
    },
    {
      key: 'status', label: 'СТАТУС',
      render: (sub: StudentSubscription) => {
        const st = (sub.effective_status ?? sub.status) as SubStatus;
        return <span className={`${a.roleBadge} ${STATUS_CLS[st] ?? ''}`}>{STATUS_LABEL[st] ?? st}</span>;
      },
    },
    {
      key: 'actions', label: '', width: '60px',
      render: (sub: StudentSubscription) => {
        const st = sub.effective_status ?? sub.status;
        return st === 'active' || st === 'pending' ? (
          <button className={`${a.iconBtn} ${a.iconBtnDanger}`} onClick={() => onCancel(sub)} title="Скасувати абонемент">
            <IconX size={13} strokeWidth={1.8} />
          </button>
        ) : null;
      },
    },
  ];

  return (
    <>
      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        {[
          { label: 'Активних',    val: activeCount,    color: 'var(--lime-hot)' },
          { label: 'Вичерпано',   val: exhaustedCount, color: 'var(--graphite)' },
          { label: 'Прострочено', val: expiredCount,   color: 'var(--error)' },
        ].map(kpi => (
          <div key={kpi.label} style={{ background: 'var(--coal-2)', border: '1px solid #1e1e1c', borderRadius: 'var(--r)', padding: '10px 18px', display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 20, fontWeight: 700, color: kpi.color, fontFamily: 'var(--font-mono)' }}>{kpi.val}</span>
            <span style={{ fontSize: 12, color: 'var(--graphite)' }}>{kpi.label}</span>
          </div>
        ))}
      </div>

      <div className={a.toolbar} style={{ marginBottom: 12 }}>
        <div className={a.searchWrap}>
          <IconSearch className={a.searchIcon} size={14} />
          <input
            className={a.searchInput}
            placeholder="Пошук за іменем, email або тарифом..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {STATUS_FILTERS.map(f => (
            <FilterPill
              key={f.value}
              active={statusFilter === f.value}
              onClick={() => setStatusFilter(f.value as SubStatus | 'all')}
            >
              {f.label}
            </FilterPill>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        subscriptions.length === 0 ? (
          <EmptyState
            title="Абонементів немає"
            text="Призначте перший абонемент учню"
            action={<button className={a.addBtn} onClick={onAssign}>Призначити абонемент</button>}
          />
        ) : (
          <EmptyState title="Нічого не знайдено" text="Спробуйте змінити пошук або фільтр" />
        )
      ) : (
        <DataTable columns={columns} data={filtered} keyField="id" />
      )}
    </>
  );
};

export default SubscriptionsTable;
