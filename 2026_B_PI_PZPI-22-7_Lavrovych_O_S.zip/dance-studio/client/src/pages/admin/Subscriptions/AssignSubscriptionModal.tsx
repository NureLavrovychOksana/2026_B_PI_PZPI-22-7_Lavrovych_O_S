﻿import { useState, useEffect } from 'react';
import { getUsers }  from '../../../api/users';
import { localToday } from '../../../utils/dateUtils';
import Modal         from '../../../components/ui/overlay/Modal';
import FormField     from '../../../components/ui/form/FormField';
import type { SubscriptionPlan } from '../../../types';
import a from '../../../styles/admin.module.css';

const today = localToday();

interface AssignFormData {
  student_id:      string;
  plan_id:         string;
  activation_date: string;
}

interface Props {
  plans:   SubscriptionPlan[];
  loading: boolean;
  onSave:  (data: AssignFormData) => Promise<void>;
  onClose: () => void;
}

const AssignSubscriptionModal = ({ plans, loading, onSave, onClose }: Props) => {
  const [students, setStudents] = useState<any[]>([]);
  const [form, setForm]         = useState<AssignFormData>({
    student_id:      '',
    plan_id:         '',
    activation_date: localToday(),
  });
  const [errors, setErrors] = useState<Partial<AssignFormData>>({});

  useEffect(() => { getUsers({ role: 'student' }).then(setStudents); }, []);

  const set = (field: keyof AssignFormData) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setForm(p => ({ ...p, [field]: e.target.value }));
      setErrors(p => ({ ...p, [field]: undefined }));
    };

  const validate = () => {
    const e: Partial<AssignFormData> = {};
    if (!form.student_id) e.student_id = 'Оберіть учня';
    if (!form.plan_id)    e.plan_id    = 'Оберіть тариф';
    if (form.activation_date && form.activation_date < today)
      e.activation_date = 'Дата активації не може бути в минулому';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onSave(form);
  };

  const selectedPlan = plans.find(p => String(p.id) === form.plan_id);

  return (
    <Modal
      title="Призначити абонемент"
      onClose={onClose}
      footer={
        <>
          <div style={{ flex: 1 }} />
          <button type="button" className={a.btnSecondary} onClick={onClose}>Скасувати</button>
          <button type="button" className={a.btnPrimary} disabled={loading} onClick={handleSubmit}>
            {loading && <span className={a.spinner} />}
            Призначити
          </button>
        </>
      }
    >
      <FormField label="УЧЕНЬ" error={errors.student_id}>
        <select
          className={`${a.input} ${errors.student_id ? a.inputError : ''}`}
          value={form.student_id}
          onChange={set('student_id')}
        >
          <option value="">Оберіть учня</option>
          {students.map(s => (
            <option key={s.id} value={s.id}>
              {s.first_name} {s.last_name} — {s.email}
            </option>
          ))}
        </select>
      </FormField>

      <FormField label="ТАРИФ" error={errors.plan_id}>
        <select
          className={`${a.input} ${errors.plan_id ? a.inputError : ''}`}
          value={form.plan_id}
          onChange={set('plan_id')}
        >
          <option value="">Оберіть тариф</option>
          {plans.map(p => (
            <option key={p.id} value={p.id}>{p.name} — ₴{p.price}</option>
          ))}
        </select>
      </FormField>

      <FormField label="ДАТА АКТИВАЦІЇ" error={errors.activation_date}>
        <input
          type="date"
          className={`${a.input} ${errors.activation_date ? a.inputError : ''}`}
          value={form.activation_date}
          onChange={set('activation_date')}
        />
      </FormField>

      {selectedPlan && (
        <div style={{
          background: 'var(--coal-3)', border: '1px solid #2a2a27',
          borderRadius: 'var(--r)', padding: 12, fontSize: 12, color: 'var(--mid)',
        }}>
          <div style={{ marginBottom: 4, color: 'var(--paper)', fontWeight: 600 }}>{selectedPlan.name}</div>
          {selectedPlan.sessions_count && <div>Занять: {selectedPlan.sessions_count}</div>}
          {selectedPlan.validity_days   && <div>Термін: {selectedPlan.validity_days} днів</div>}
          {selectedPlan.type === 'UNLIMITED' && <div>Тип: Безлімітний</div>}
          <div style={{ color: 'var(--lime)', marginTop: 4, fontFamily: 'var(--font-mono)' }}>
            ₴{selectedPlan.price}
          </div>
        </div>
      )}
    </Modal>
  );
};

export default AssignSubscriptionModal;
export type { AssignFormData };
