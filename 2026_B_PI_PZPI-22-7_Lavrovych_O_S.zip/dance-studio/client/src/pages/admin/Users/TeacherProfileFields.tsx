import FormField    from '../../../components/ui/form/FormField';
import SectionLabel from '../../../components/ui/display/SectionLabel';
import type { DanceStyle } from '../../../types';
import type { UserFormData } from './UserModal';
import a from '../../../styles/admin.module.css';

interface Props {
  form:          UserFormData;
  onField:       (field: keyof UserFormData) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onToggleStyle: (id: number) => void;
  danceStyles:   DanceStyle[];
}

const TeacherProfileFields = ({ form, onField, onToggleStyle, danceStyles }: Props) => (
  <>
    <div style={{ margin: '20px 0 14px', borderTop: '1px solid #1e1e1c', paddingTop: 20 }}>
      <SectionLabel>ПРОФІЛЬ ВИКЛАДАЧА</SectionLabel>
    </div>

    <div className={a.formRow}>
      <FormField label="ДОСВІД (РОКІВ)">
        <input className={a.input} type="number" min={0} value={form.experience_years} onChange={onField('experience_years')} placeholder="5" />
      </FormField>
      <FormField label="ОСВІТА">
        <input className={a.input} value={form.education} onChange={onField('education')} placeholder="Хореографічний факультет..." />
      </FormField>
    </div>

    <FormField label="БІО">
      <textarea className={a.input} style={{ minHeight: 72, resize: 'vertical' }} value={form.bio} onChange={onField('bio')} placeholder="Коротко про викладача..." />
    </FormField>

    {danceStyles.length > 0 && (
      <FormField label="СТИЛІ ВИКЛАДАННЯ">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 4 }}>
          {danceStyles.map(st => {
            const active = form.style_ids.includes(st.id);
            return (
              <button
                key={st.id}
                type="button"
                onClick={() => onToggleStyle(st.id)}
                style={{
                  padding: '5px 12px',
                  borderRadius: 'var(--r)',
                  border: `1px solid ${active ? 'var(--gold)' : '#2a2a27'}`,
                  background: active ? 'rgba(212,175,55,.12)' : 'var(--coal-3)',
                  color: active ? 'var(--gold)' : 'var(--mid)',
                  fontSize: 12,
                  fontFamily: 'var(--font-mono)',
                  cursor: 'pointer',
                  transition: 'var(--transition)',
                }}
              >
                {st.name}
              </button>
            );
          })}
        </div>
      </FormField>
    )}

    <div style={{ margin: '20px 0 14px', borderTop: '1px solid #1e1e1c', paddingTop: 20 }}>
      <SectionLabel>ОПЛАТА</SectionLabel>
    </div>

    <div className={a.formRow}>
      <FormField label="ТИП СТАВКИ">
        <select className={a.input} value={form.rate_type} onChange={onField('rate_type')}>
          <option value="per_lesson">Фіксована за заняття</option>
          <option value="per_student">За кожного присутнього учня</option>
        </select>
      </FormField>
      <FormField label={form.rate_type === 'per_student' ? 'СТАВКА (₴ / учень)' : 'СТАВКА (₴ / заняття)'}>
        <input
          className={a.input}
          type="number" min={0} step={1}
          value={form.rate_amount}
          onChange={onField('rate_amount')}
          placeholder={form.rate_type === 'per_student' ? 'напр. 50' : 'напр. 400'}
        />
      </FormField>
    </div>
  </>
);

export default TeacherProfileFields;
