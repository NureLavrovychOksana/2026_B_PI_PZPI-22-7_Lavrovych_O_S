import { useEffect, useState } from 'react';
import { getGroups }   from '../../../api/groups';
import { bulkEnroll }  from '../../../api/enrollments';
import Modal           from '../../../components/ui/overlay/Modal';
import FormField       from '../../../components/ui/form/FormField';
import { validateDateRange } from '../../../utils/validators';
import type { User, DanceGroup } from '../../../types';
import a from '../../../styles/admin.module.css';

interface BulkEnrollModalProps {
  student:   User;
  onClose:   () => void;
  onSuccess: (count: number) => void;
}

const BulkEnrollModal = ({ student, onClose, onSuccess }: BulkEnrollModalProps) => {
  const [groups, setGroups]     = useState<DanceGroup[]>([]);
  const [groupId, setGroupId]   = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo]     = useState('');
  const [saving, setSaving]     = useState(false);
  const [error, setError]       = useState('');

  useEffect(() => { getGroups().then(setGroups); }, []);

  const handleSave = async () => {
    if (!groupId || !dateFrom || !dateTo) { setError('Заповніть всі поля'); return; }
    const rangeErr = validateDateRange(dateFrom, dateTo);
    if (rangeErr) { setError(rangeErr); return; }
    setSaving(true); setError('');
    try {
      const result = await bulkEnroll({
        student_id: student.id,
        group_id:   Number(groupId),
        date_from:  dateFrom,
        date_to:    dateTo,
      });
      onSuccess(result.enrolled);
      onClose();
    } catch (err: any) {
      setError(err.response?.data?.message ?? 'Помилка');
    } finally { setSaving(false); }
  };

  return (
    <Modal
      title={`Записати на период — ${student.first_name} ${student.last_name}`}
      onClose={onClose}
      footer={
        <>
          <div style={{ flex: 1 }} />
          <button type="button" className={a.btnSecondary} onClick={onClose}>Скасувати</button>
          <button type="button" className={a.btnPrimary} disabled={saving} onClick={handleSave}>
            {saving && <span className={a.spinner} />}
            Записати
          </button>
        </>
      }
    >
      <FormField label="НАПРЯМОК (ГРУПА)">
        <select className={a.input} value={groupId} onChange={e => setGroupId(e.target.value)}>
          <option value="">— Оберіть групу —</option>
          {groups.map(g => (
            <option key={g.id} value={g.id}>{g.name}</option>
          ))}
        </select>
      </FormField>

      <div className={a.formRow}>
        <FormField label="З ДАТИ">
          <input type="date" className={a.input} value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
        </FormField>
        <FormField label="ПО ДАТУ">
          <input type="date" className={a.input} value={dateTo} onChange={e => setDateTo(e.target.value)} />
        </FormField>
      </div>

      {error && <p style={{ color: 'var(--error)', fontSize: 12, marginTop: 8 }}>{error}</p>}
    </Modal>
  );
};

export default BulkEnrollModal;
