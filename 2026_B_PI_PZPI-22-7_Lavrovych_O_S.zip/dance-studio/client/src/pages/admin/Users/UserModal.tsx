import { useState } from 'react';
import Modal       from '../../../components/ui/overlay/Modal';
import FormField   from '../../../components/ui/form/FormField';
import TeacherProfileFields from './TeacherProfileFields';
import { validateName, validateEmail, validatePhone, validatePassword } from '../../../utils/validators';
import type { DanceStyle } from '../../../types';
import type { RateType }   from '../../../api/teachers';
import a from '../../../styles/admin.module.css';

export interface UserFormData {
  first_name:       string;
  last_name:        string;
  email:            string;
  phone:            string;
  role:             string;
  password:         string;
  bio:              string;
  experience_years: string;
  education:        string;
  style_ids:        number[];
  rate_type:        RateType;
  rate_amount:      string;
}

export const EMPTY_FORM: UserFormData = {
  first_name: '', last_name: '', email: '',
  phone: '', role: 'student', password: '',
  bio: '', experience_years: '', education: '', style_ids: [],
  rate_type: 'per_lesson', rate_amount: '',
};

export interface TeacherProfileData {
  id:               number;
  user_id:          number;
  bio?:             string;
  experience_years: number;
  education?:       string;
  styles:           { id: number; name: string }[];
  rate_type?:       RateType;
  rate_amount?:     number;
}

interface UserModalProps {
  user:            { id: number; first_name: string; last_name: string; email: string; phone?: string | null; role: string } | null;
  teacherProfile?: TeacherProfileData;
  danceStyles:     DanceStyle[];
  onSave:          (data: UserFormData) => Promise<void>;
  onClose:         () => void;
  loading:         boolean;
}

const UserModal = ({ user, teacherProfile, danceStyles, onSave, onClose, loading }: UserModalProps) => {
  const [form, setForm] = useState<UserFormData>(
    user
      ? {
          first_name:       user.first_name,
          last_name:        user.last_name,
          email:            user.email,
          phone:            user.phone ?? '',
          role:             user.role,
          password:         '',
          bio:              teacherProfile?.bio ?? '',
          experience_years: teacherProfile?.experience_years ? String(teacherProfile.experience_years) : '',
          education:        teacherProfile?.education ?? '',
          style_ids:        teacherProfile?.styles?.map(s => s.id) ?? [],
          rate_type:        teacherProfile?.rate_type ?? 'per_lesson',
          rate_amount:      teacherProfile?.rate_amount != null ? String(teacherProfile.rate_amount) : '',
        }
      : EMPTY_FORM
  );
  const [errors, setErrors] = useState<Partial<Record<keyof UserFormData, string>>>({});

  const set = (field: keyof UserFormData) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      setForm(p => ({ ...p, [field]: e.target.value }));
      setErrors(p => ({ ...p, [field]: undefined }));
    };

  const toggleStyle = (id: number) =>
    setForm(p => ({
      ...p,
      style_ids: p.style_ids.includes(id)
        ? p.style_ids.filter(s => s !== id)
        : [...p.style_ids, id],
    }));

  const validate = () => {
    const e: Partial<Record<keyof UserFormData, string>> = {};
    const firstErr = validateName(form.first_name);
    if (firstErr) e.first_name = firstErr;
    const lastErr = validateName(form.last_name);
    if (lastErr) e.last_name = lastErr;
    const emailErr = validateEmail(form.email);
    if (emailErr) e.email = emailErr;
    const phoneErr = validatePhone(form.phone);
    if (phoneErr) e.phone = phoneErr;
    if (!user && !form.password && form.role !== 'teacher') {
      e.password = "Обовʼязкове для нового користувача";
    } else if (form.password) {
      const passErr = validatePassword(form.password);
      if (passErr) e.password = passErr;
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  return (
    <Modal
      title={user ? 'Редагувати користувача' : 'Додати користувача'}
      onClose={onClose}
      footer={
        <>
          <div style={{ flex: 1 }} />
          <button type="button" className={a.btnSecondary} onClick={onClose}>Скасувати</button>
          <button type="button" className={a.btnPrimary} disabled={loading} onClick={() => { if (validate()) onSave(form); }}>
            {loading && <span className={a.spinner} />}
            {user ? 'Зберегти' : 'Створити'}
          </button>
        </>
      }
    >
      <div className={a.formRow}>
        <FormField label="ІМʼЯ" error={errors.first_name}>
          <input className={`${a.input} ${errors.first_name ? a.inputError : ''}`} value={form.first_name} onChange={set('first_name')} placeholder="Оксана" autoComplete="off" />
        </FormField>
        <FormField label="ПРІЗВИЩЕ" error={errors.last_name}>
          <input className={`${a.input} ${errors.last_name ? a.inputError : ''}`} value={form.last_name} onChange={set('last_name')} placeholder="Іванова" autoComplete="off" />
        </FormField>
      </div>

      <FormField label="EMAIL" error={errors.email}>
        <input className={`${a.input} ${errors.email ? a.inputError : ''}`} type="email" value={form.email} onChange={set('email')} placeholder="user@email.com" autoComplete="off" />
      </FormField>

      <div className={a.formRow}>
        <FormField label="ТЕЛЕФОН" error={errors.phone}>
          <input className={`${a.input} ${errors.phone ? a.inputError : ''}`} value={form.phone} onChange={set('phone')} placeholder="+380991234567" autoComplete="off" />
        </FormField>
        <FormField label="РОЛЬ">
          <select className={a.input} value={form.role} onChange={set('role')} disabled={!!user}>
            <option value="student">Учень</option>
            <option value="teacher">Викладач</option>
            <option value="admin">Адмін</option>
          </select>
        </FormField>
      </div>

      <FormField
        label="ПАРОЛЬ"
        hint={user ? '(залиш порожнім щоб не змінювати)' : undefined}
        error={errors.password}
      >
        <input className={`${a.input} ${errors.password ? a.inputError : ''}`} type="password" value={form.password} onChange={set('password')} placeholder="••••••••" autoComplete="new-password" />
      </FormField>

      {form.role === 'teacher' && (
        <TeacherProfileFields
          form={form}
          onField={set}
          onToggleStyle={toggleStyle}
          danceStyles={danceStyles}
        />
      )}
    </Modal>
  );
};

export default UserModal;
