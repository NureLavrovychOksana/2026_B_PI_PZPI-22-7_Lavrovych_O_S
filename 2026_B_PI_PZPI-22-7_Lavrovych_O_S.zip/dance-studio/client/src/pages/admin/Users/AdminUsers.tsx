import { useEffect, useState } from 'react';
import { getUsers, createUser, updateUser, deleteUser } from '../../../api/users';
import { getTeachers, createTeacher, updateTeacherProfile, setTeacherRate } from '../../../api/teachers';
import { getStyles } from '../../../api/styles';
import PageHeader      from '../../../components/ui/display/PageHeader';
import ConfirmModal    from '../../../components/ui/overlay/ConfirmModal';
import Toast           from '../../../components/ui/feedback/Toast';
import Spinner         from '../../../components/ui/feedback/Spinner';
import UserModal       from './UserModal';
import BulkEnrollModal from './BulkEnrollModal';
import AdminUsersTable from './AdminUsersTable';
import { useToast }    from '../../../hooks/useToast';
import type { User, DanceStyle } from '../../../types';
import type { UserFormData, TeacherProfileData } from './UserModal';
import a from '../../../styles/admin.module.css';

const AdminUsers = () => {
  const { toasts, showToast, removeToast } = useToast();

  const [users,       setUsers]       = useState<User[]>([]);
  const [danceStyles, setDanceStyles] = useState<DanceStyle[]>([]);
  const [teacherMap,  setTeacherMap]  = useState<Record<number, TeacherProfileData>>({});
  const [loading,     setLoading]     = useState(true);
  const [saving,      setSaving]      = useState(false);
  const [editUser,    setEditUser]    = useState<User | null | undefined>(undefined);
  const [deleteId,    setDeleteId]    = useState<number | null>(null);
  const [bulkEnrollStudent, setBulkEnrollStudent] = useState<User | null>(null);

  const loadUsers = () => {
    setLoading(true);
    getUsers().then(setUsers).finally(() => setLoading(false));
  };
  const loadTeachers = () =>
    getTeachers().then((teachers: TeacherProfileData[]) => {
      const map: Record<number, TeacherProfileData> = {};
      teachers.forEach(t => { map[t.user_id] = t; });
      setTeacherMap(map);
    });

  useEffect(() => { loadUsers(); loadTeachers(); getStyles().then(setDanceStyles); }, []);

  const handleSave = async (form: UserFormData) => {
    setSaving(true);
    try {
      if (editUser) {
        if (editUser.role === 'teacher') {
          const tp = teacherMap[editUser.id];
          if (tp) {
            await updateTeacherProfile(tp.id, {
              first_name:       form.first_name,
              last_name:        form.last_name,
              email:            form.email,
              phone:            form.phone || undefined,
              bio:              form.bio   || undefined,
              experience_years: form.experience_years ? Number(form.experience_years) : undefined,
              education:        form.education || undefined,
              style_ids:        form.style_ids,
            });
            if (form.rate_amount !== '') await setTeacherRate(tp.id, form.rate_type, Number(form.rate_amount));
          }
          if (form.password) await updateUser(editUser.id, { password: form.password } as any);
        } else {
          const payload: any = {
            first_name: form.first_name,
            last_name:  form.last_name,
            email:      form.email,
            phone:      form.phone || undefined,
            role:       form.role,
          };
          if (form.password) payload.password = form.password;
          await updateUser(editUser.id, payload);
        }
        showToast('Користувача оновлено', 'success');
      } else {
        if (form.role === 'teacher') {
          await createTeacher({
            email:            form.email,
            password:         form.password || undefined,
            first_name:       form.first_name,
            last_name:        form.last_name,
            phone:            form.phone || undefined,
            bio:              form.bio   || undefined,
            experience_years: form.experience_years ? Number(form.experience_years) : undefined,
            education:        form.education || undefined,
            style_ids:        form.style_ids.length > 0 ? form.style_ids : undefined,
          });
        } else {
          await createUser({
            email:      form.email,
            password:   form.password,
            role:       form.role,
            first_name: form.first_name,
            last_name:  form.last_name,
            phone:      form.phone || undefined,
          });
        }
        showToast('Користувача створено', 'success');
      }
      setEditUser(undefined);
      loadUsers();
      loadTeachers();
    } catch (err: any) {
      showToast(err.response?.data?.message ?? 'Помилка', 'error');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    try {
      await deleteUser(deleteId);
      showToast('Користувача видалено', 'success');
      setDeleteId(null);
      loadUsers();
      loadTeachers();
    } catch (err: any) {
      showToast(err.response?.data?.message ?? 'Помилка', 'error');
    } finally { setSaving(false); }
  };

  if (loading) return <Spinner centered />;

  return (
    <div>
      <PageHeader
        title="Користувачі"
        sub={`${users.length} користувачів`}
        actions={<button className={a.btnPrimary} onClick={() => setEditUser(null)}>+ Додати</button>}
      />

      <AdminUsersTable
        users={users}
        onEdit={u => setEditUser(u)}
        onDelete={id => setDeleteId(id)}
        onBulkEnroll={u => setBulkEnrollStudent(u)}
      />

      {editUser !== undefined && (
        <UserModal
          user={editUser}
          teacherProfile={editUser ? teacherMap[editUser.id] : undefined}
          danceStyles={danceStyles}
          onSave={handleSave}
          onClose={() => setEditUser(undefined)}
          loading={saving}
        />
      )}

      {deleteId !== null && (
        <ConfirmModal
          title="Видалити користувача?"
          message="Цю дію неможливо скасувати. Всі дані користувача буде видалено."
          onConfirm={handleDelete}
          onCancel={() => setDeleteId(null)}
        />
      )}

      {bulkEnrollStudent && (
        <BulkEnrollModal
          student={bulkEnrollStudent}
          onClose={() => setBulkEnrollStudent(null)}
          onSuccess={count => showToast(`Записано на ${count} занять`, 'success')}
        />
      )}

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default AdminUsers;
