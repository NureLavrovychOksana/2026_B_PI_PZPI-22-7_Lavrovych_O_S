import { useState, useMemo } from 'react';
import DataTable  from '../../../components/ui/display/DataTable';
import UserCell   from '../../../components/ui/display/UserCell';
import FilterPill from '../../../components/ui/display/FilterPill';
import type { User } from '../../../types';
import a from '../../../styles/admin.module.css';

type RoleFilter = 'all' | 'admin' | 'teacher' | 'student';

const ROLE_TABS: { value: RoleFilter; label: string }[] = [
  { value: 'all',     label: 'Всі' },
  { value: 'student', label: 'Учні' },
  { value: 'teacher', label: 'Викладачі' },
  { value: 'admin',   label: 'Адміни' },
];

const ROLE_LABELS: Record<string, string> = {
  admin: 'Адмін', teacher: 'Викладач', student: 'Учень',
};

interface Props {
  users:        User[];
  onEdit:       (u: User) => void;
  onDelete:     (id: number) => void;
  onBulkEnroll: (u: User) => void;
}

const AdminUsersTable = ({ users, onEdit, onDelete, onBulkEnroll }: Props) => {
  const [search,  setSearch]  = useState('');
  const [roleTab, setRoleTab] = useState<RoleFilter>('all');

  const filtered = useMemo(() => {
    let r = users;
    if (roleTab !== 'all') r = r.filter(u => u.role === roleTab);
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter(u =>
        `${u.first_name} ${u.last_name}`.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q),
      );
    }
    return r;
  }, [users, roleTab, search]);

  const columns = [
    {
      key: 'user',
      label: 'КОРИСТУВАЧ',
      render: (u: User) => (
        <UserCell firstName={u.first_name} lastName={u.last_name} sub={u.email} />
      ),
    },
    {
      key: 'role',
      label: 'РОЛЬ',
      render: (u: User) => (
        <span className={`${a.badge} ${(a as any)[`badge_${u.role}`] ?? ''}`}>
          {ROLE_LABELS[u.role] ?? u.role}
        </span>
      ),
    },
    {
      key: 'phone',
      label: 'ТЕЛЕФОН',
      render: (u: User) => (
        <span style={{ color: 'var(--graphite)', fontSize: 12 }}>{u.phone ?? '—'}</span>
      ),
    },
    {
      key: 'actions',
      label: '',
      render: (u: User) => (
        <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
          {u.role === 'student' && (
            <button className={a.btnGhost} onClick={() => onBulkEnroll(u)} title="Записати на период">
              Записати на период
            </button>
          )}
          <button className={a.btnGhost} onClick={() => onEdit(u)}>Редагувати</button>
          <button className={a.btnDanger} onClick={() => onDelete(u.id)}>Видалити</button>
        </div>
      ),
    },
  ];

  return (
    <>
      <div className={a.toolbar}>
        {ROLE_TABS.map(tab => (
          <FilterPill
            key={tab.value}
            active={roleTab === tab.value}
            onClick={() => setRoleTab(tab.value)}
          >
            {tab.label}
          </FilterPill>
        ))}
        <div className={a.spacer} />
        <input
          className={a.searchInput}
          style={{ maxWidth: 220 }}
          placeholder="Пошук..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>
      <DataTable columns={columns} data={filtered} keyField="id" />
    </>
  );
};

export default AdminUsersTable;
