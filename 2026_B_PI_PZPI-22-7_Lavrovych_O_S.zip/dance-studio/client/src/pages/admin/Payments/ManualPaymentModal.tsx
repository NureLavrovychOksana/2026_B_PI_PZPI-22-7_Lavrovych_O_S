﻿import { useState, useEffect } from 'react';
import { getUsers }                from '../../../api/users';
import { getStudentSubscriptions } from '../../../api/subscriptions';
import Modal     from '../../../components/ui/overlay/Modal';
import FormField from '../../../components/ui/form/FormField';
import { validatePositiveNumber } from '../../../utils/validators';
import a from '../../../styles/admin.module.css';

interface PaymentFormData {
  user_id:         string;
  subscription_id: string;
  amount:          string;
  method:          'cash';
}

interface Props {
  loading: boolean;
  onSave:  (data: PaymentFormData) => Promise<void>;
  onClose: () => void;
}

const ManualPaymentModal = ({ loading, onSave, onClose }: Props) => {
  const [students, setStudents]           = useState<any[]>([]);
  const [subscriptions, setSubscriptions] = useState<any[]>([]);
  const [form, setForm]                   = useState<PaymentFormData>({
    user_id: '', subscription_id: '', amount: '', method: 'cash',
  });
  const [errors, setErrors] = useState<Partial<PaymentFormData>>({});

  useEffect(() => { getUsers({ role: 'student' }).then(setStudents); }, []);

  useEffect(() => {
    if (!form.user_id) { setSubscriptions([]); return; }
    getStudentSubscriptions(Number(form.user_id)).then(setSubscriptions);
  }, [form.user_id]);

  const set = (field: keyof PaymentFormData) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setForm(p => ({ ...p, [field]: e.target.value }));
      setErrors(p => ({ ...p, [field]: undefined }));
    };

  const validate = () => {
    const e: Partial<PaymentFormData> = {};
    if (!form.user_id) e.user_id = 'Оберіть учня';
    if (!form.amount || Number(form.amount) <= 0) {
      e.amount = 'Вкажіть суму';
    } else {
      const amountErr = validatePositiveNumber(form.amount, 100_000);
      if (amountErr) e.amount = amountErr;
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onSave(form);
  };

  return (
    <Modal
      title="Фіксація оплати"
      onClose={onClose}
      footer={
        <>
          <div style={{ flex: 1 }} />
          <button type="button" className={a.btnSecondary} onClick={onClose}>Скасувати</button>
          <button type="button" className={a.btnPrimary} disabled={loading} onClick={handleSubmit}>
            {loading && <span className={a.spinner} />}
            Зафіксувати
          </button>
        </>
      }
    >
      <FormField label="УЧЕНЬ" error={errors.user_id}>
        <select
          className={`${a.input} ${errors.user_id ? a.inputError : ''}`}
          value={form.user_id}
          onChange={set('user_id')}
        >
          <option value="">Оберіть учня</option>
          {students.map(s => (
            <option key={s.id} value={s.id}>
              {s.first_name} {s.last_name} — {s.email}
            </option>
          ))}
        </select>
      </FormField>

      <FormField label="АБОНЕМЕНТ">
        <select
          className={a.input}
          value={form.subscription_id}
          onChange={set('subscription_id')}
          disabled={!form.user_id}
        >
          <option value="">Без прив'язки</option>
          {subscriptions.map(s => (
            <option key={s.id} value={s.id}>{s.plan_name} — {s.status}</option>
          ))}
        </select>
      </FormField>

      <div className={a.formRow}>
        <FormField label="СУМА (₴)" error={errors.amount}>
          <input
            type="number" min="0" step="0.01"
            className={`${a.input} ${errors.amount ? a.inputError : ''}`}
            value={form.amount}
            onChange={set('amount')}
            placeholder="1600"
          />
        </FormField>

        <FormField label="МЕТОД ОПЛАТИ">
          <select className={a.input} value={form.method} onChange={set('method')}>
            <option value="cash">Готівка</option>
          </select>
        </FormField>
      </div>
    </Modal>
  );
};

export default ManualPaymentModal;
export type { PaymentFormData };
