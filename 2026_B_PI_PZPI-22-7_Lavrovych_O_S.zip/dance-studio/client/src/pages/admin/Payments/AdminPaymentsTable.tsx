import { useEffect, useState, useMemo } from 'react';
import { getPayments, confirmCashPayment } from '../../../api/payments';
import { localDateStr } from '../../../utils/dateUtils';
import DataTable       from '../../../components/ui/display/DataTable';
import StatCard        from '../../../components/ui/display/StatCard';
import UserCell        from '../../../components/ui/display/UserCell';
import EmptyState      from '../../../components/ui/feedback/EmptyState';
import Spinner         from '../../../components/ui/feedback/Spinner';
import type { Payment } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './AdminPayments.module.css';

const METHOD_LABEL: Record<string, string> = { cash: 'Готівка', card: 'Картка', liqpay: 'LiqPay' };
const METHOD_CLS:   Record<string, string> = { cash: s.methodCash, card: s.methodCard, liqpay: s.methodLiqpay };
const STATUS_CLS:   Record<string, string> = { success: s.statusSuccess, pending: s.statusPending, failed: s.statusFailed, refunded: s.statusFailed };
const STATUS_LABEL: Record<string, string> = { success: 'Успішно', pending: 'Очікує', failed: 'Помилка', refunded: 'Повернено' };

const getMonthRange = () => {
  const now  = new Date();
  const from = new Date(now.getFullYear(), now.getMonth(), 1);
  const to   = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  return { from: localDateStr(from), to: localDateStr(to) };
};

const columns = [
  {
    key: 'user',
    label: 'УЧЕНЬ',
    render: (p: Payment) => (
      <UserCell firstName={p.first_name ?? ''} lastName={p.last_name ?? ''} sub={p.plan_name} />
    ),
  },
  {
    key: 'amount',
    label: 'СУМА',
    render: (p: Payment) => (
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 700, color: 'var(--lime)' }}>
        ₴{Number(p.amount).toLocaleString('uk-UA')}
      </span>
    ),
  },
  {
    key: 'payment_method',
    label: 'МЕТОД',
    render: (p: Payment) => (
      <span className={`${s.methodBadge} ${METHOD_CLS[p.payment_method]}`}>
        {METHOD_LABEL[p.payment_method]}
      </span>
    ),
  },
  {
    key: 'status',
    label: 'СТАТУС',
    render: (p: Payment) => (
      <span className={`${a.roleBadge} ${STATUS_CLS[p.status]}`}>{STATUS_LABEL[p.status]}</span>
    ),
  },
  {
    key: 'payment_date',
    label: 'ДАТА',
    render: (p: Payment) => (
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--graphite)' }}>
        {new Date(p.payment_date).toLocaleDateString('uk-UA')}
      </span>
    ),
  },
];

interface Props { refreshTrigger: number }

const AdminPaymentsTable = ({ refreshTrigger }: Props) => {
  const [confirming, setConfirming] = useState<number | null>(null);
  const { from: defaultFrom, to: defaultTo } = getMonthRange();

  const [payments,     setPayments]     = useState<Payment[]>([]);
  const [loading,      setLoading]      = useState(true);
  const [filterMethod, setFilterMethod] = useState('');
  const [filterStatus, setFilterStatus] = useState('success');
  const [dateFrom,     setDateFrom]     = useState(defaultFrom);
  const [dateTo,       setDateTo]       = useState(defaultTo);

  useEffect(() => {
    setLoading(true);
    getPayments({ date_from: dateFrom, date_to: dateTo, method: filterMethod || undefined, status: filterStatus || undefined })
      .then(setPayments)
      .finally(() => setLoading(false));
  }, [dateFrom, dateTo, filterMethod, filterStatus, refreshTrigger]);

  const handleConfirm = async (p: Payment) => {
    setConfirming(p.id);
    try {
      await confirmCashPayment(p.id);
      setPayments(prev => prev.map(x => x.id === p.id ? { ...x, status: 'success' } : x));
    } finally {
      setConfirming(null);
    }
  };

  const totalRevenue = useMemo(
    () => payments.filter(p => p.status === 'success').reduce((sum, p) => sum + Number(p.amount), 0),
    [payments],
  );

  const byMethod = useMemo(() => ({
    cash:   payments.filter(p => p.payment_method === 'cash'   && p.status === 'success').reduce((s, p) => s + Number(p.amount), 0),
    liqpay: payments.filter(p => p.payment_method === 'liqpay' && p.status === 'success').reduce((s, p) => s + Number(p.amount), 0),
  }), [payments]);

  return (
    <>
      <div className={s.summaryRow}>
        <StatCard label="ВСЬОГО ЗА ПЕРІОД" value={`₴${totalRevenue.toLocaleString('uk-UA')}`} valueColor="accent" accentBorder />
        <StatCard label="ГОТІВКА"  value={`₴${byMethod.cash.toLocaleString('uk-UA')}`} />
        <StatCard label="LIQPAY"   value={`₴${byMethod.liqpay.toLocaleString('uk-UA')}`} />
      </div>

      <div className={s.filterRow}>
        <input type="date" className={s.dateInput} value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
        <span style={{ color: 'var(--graphite)', fontSize: 12 }}>—</span>
        <input type="date" className={s.dateInput} value={dateTo}   onChange={e => setDateTo(e.target.value)} />
        <div className={a.spacer} />
        <select className={a.filterSelect} value={filterMethod} onChange={e => setFilterMethod(e.target.value)}>
          <option value="">Всі методи</option>
          <option value="cash">Готівка</option>
          <option value="liqpay">LiqPay</option>
        </select>
        <select className={a.filterSelect} value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
          <option value="">Всі статуси</option>
          <option value="success">Успішні</option>
          <option value="pending">Очікують</option>
          <option value="failed">Помилки</option>
        </select>
      </div>

      {loading ? (
        <Spinner centered />
      ) : payments.length === 0 ? (
        <EmptyState title="Платежів не знайдено" text="Спробуйте змінити фільтри або зафіксуйте першу оплату" />
      ) : (
        <DataTable
          columns={[
            ...columns,
            {
              key: 'actions',
              label: '',
              render: (p: Payment) =>
                p.status === 'pending' && p.payment_method === 'cash' ? (
                  <button
                    className={s.confirmBtn}
                    onClick={() => handleConfirm(p)}
                    disabled={confirming === p.id}
                  >
                    {confirming === p.id ? '...' : 'Підтвердити'}
                  </button>
                ) : null,
            },
          ]}
          data={payments}
          keyField="id"
        />
      )}
    </>
  );
};

export default AdminPaymentsTable;
