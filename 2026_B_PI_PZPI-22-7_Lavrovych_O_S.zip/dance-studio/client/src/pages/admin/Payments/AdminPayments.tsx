import { useState } from 'react';
import { createManualPayment } from '../../../api/payments';
import PageHeader        from '../../../components/ui/display/PageHeader';
import Toast             from '../../../components/ui/feedback/Toast';
import ManualPaymentModal from './ManualPaymentModal';
import AdminPaymentsTable from './AdminPaymentsTable';
import { IconPlus } from '../../../components/ui/Icon';
import type { PaymentFormData } from './ManualPaymentModal';
import { useToast } from '../../../hooks/useToast';
import a from '../../../styles/admin.module.css';

const AdminPayments = () => {
  const [modal,          setModal]          = useState(false);
  const [saving,         setSaving]         = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const { toasts, showToast, removeToast } = useToast();

  const handleSave = async (form: PaymentFormData) => {
    setSaving(true);
    try {
      await createManualPayment({
        user_id:         Number(form.user_id),
        subscription_id: form.subscription_id ? Number(form.subscription_id) : undefined,
        amount:          Number(form.amount),
        method:          form.method,
      });
      showToast('Оплату зафіксовано', 'success');
      setModal(false);
      setRefreshTrigger(t => t + 1);
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Оплати"
        actions={
          <button className={a.addBtn} onClick={() => setModal(true)}>
            <IconPlus size={14} strokeWidth={1.8} />
            Додати оплату
          </button>
        }
      />

      <AdminPaymentsTable refreshTrigger={refreshTrigger} />

      {modal && (
        <ManualPaymentModal
          loading={saving}
          onSave={handleSave}
          onClose={() => setModal(false)}
        />
      )}

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default AdminPayments;
