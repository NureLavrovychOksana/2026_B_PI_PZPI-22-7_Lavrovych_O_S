import { useEffect, useState } from 'react';
import { getTeacherFinance, setTeacherRate, getTeacherPayouts, addTeacherPayout } from '../../../api/teachers';
import type { RateType, TeacherFinance } from '../../../api/teachers';
import AvatarInitials from '../../../components/ui/display/AvatarInitials';
import Spinner from '../../../components/ui/feedback/Spinner';
import Modal   from '../../../components/ui/overlay/Modal';
import { IconWallet, IconEdit, IconDollar } from '../../../components/ui/Icon';
import type { Teacher } from './AdminTeachers';
import a from '../../../styles/admin.module.css';
import s from './AdminTeachers.module.css';

type Payout = {
  id: number; amount: number; note: string | null; created_at: string;
  admin_first_name: string; admin_last_name: string;
};

const RATE_TYPE_OPTIONS: { value: RateType; label: string }[] = [
  { value: 'per_lesson',  label: 'Фіксована за урок' },
  { value: 'per_student', label: 'За кожного учня' },
  { value: 'percent',     label: 'Відсоток від виручки' },
];

const formatRate = (type: RateType, amount: number): string => {
  if (type === 'per_lesson')  return `${amount.toLocaleString()} ₴ / урок`;
  if (type === 'per_student') return `${amount.toLocaleString()} ₴ / учень`;
  if (type === 'percent')     return `${amount}% від виручки`;
  return `${amount}`;
};

const formatEarningsBasis = (fin: TeacherFinance): string => {
  if (fin.rate_type === 'per_lesson')
    return `${fin.conducted_lessons} проведених × ${fin.rate_amount.toLocaleString()} ₴`;
  if (fin.rate_type === 'per_student')
    return `${fin.total_attendance} відвідувань × ${fin.rate_amount.toLocaleString()} ₴`;
  if (fin.rate_type === 'percent')
    return `${fin.rate_amount}% від виручки за уроки`;
  return '';
};

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleDateString('uk-UA', { day: '2-digit', month: '2-digit', year: 'numeric' });

interface Props {
  selected:  Teacher | null;
  showToast: (msg: string, type: 'success' | 'error') => void;
}

const TeacherFinancePanel = ({ selected, showToast }: Props) => {
  const [finance,      setFinance]      = useState<TeacherFinance | null>(null);
  const [payouts,      setPayouts]      = useState<Payout[]>([]);
  const [panelLoading, setPanelLoading] = useState(false);

  const [rateEdit,   setRateEdit]   = useState(false);
  const [rateType,   setRateType]   = useState<RateType>('per_lesson');
  const [rateAmount, setRateAmount] = useState('');
  const [rateSaving, setRateSaving] = useState(false);

  const [payoutModal,  setPayoutModal]  = useState(false);
  const [payoutAmt,    setPayoutAmt]    = useState('');
  const [payoutNote,   setPayoutNote]   = useState('');
  const [payoutSaving, setPayoutSaving] = useState(false);

  useEffect(() => {
    if (!selected) { setFinance(null); setPayouts([]); return; }
    setFinance(null); setPayouts([]); setRateEdit(false);
    setPanelLoading(true);
    Promise.all([getTeacherFinance(selected.id), getTeacherPayouts(selected.id)])
      .then(([fin, pays]) => {
        setFinance(fin);
        setPayouts(pays);
        setRateType(fin.rate_type || 'per_lesson');
        setRateAmount(String(fin.rate_amount || ''));
      })
      .finally(() => setPanelLoading(false));
  }, [selected?.id]);

  const handleSaveRate = async () => {
    if (!selected) return;
    const amount = Number(rateAmount);
    if (isNaN(amount) || amount < 0) return;
    setRateSaving(true);
    try {
      await setTeacherRate(selected.id, rateType, amount);
      const fin = await getTeacherFinance(selected.id);
      setFinance(fin);
      setRateEdit(false);
      showToast('Ставку оновлено', 'success');
    } catch {
      showToast('Помилка збереження', 'error');
    } finally { setRateSaving(false); }
  };

  const handlePayout = async () => {
    if (!selected) return;
    const amount = Number(payoutAmt);
    if (isNaN(amount) || amount <= 0) return;
    setPayoutSaving(true);
    try {
      await addTeacherPayout(selected.id, amount, payoutNote || undefined);
      const [fin, pays] = await Promise.all([
        getTeacherFinance(selected.id),
        getTeacherPayouts(selected.id),
      ]);
      setFinance(fin);
      setPayouts(pays);
      setPayoutModal(false);
      setPayoutAmt('');
      setPayoutNote('');
      showToast(`Виплату ${amount.toLocaleString()} ₴ зараховано`, 'success');
    } catch {
      showToast('Помилка виплати', 'error');
    } finally { setPayoutSaving(false); }
  };

  if (!selected) return (
    <div className={s.panelEmpty}>
      <span style={{ color: 'var(--graphite)', marginBottom: 12, display: 'flex' }}>
        <IconWallet size={40} strokeWidth={1.2} />
      </span>
      Оберіть викладача для перегляду фінансів
    </div>
  );

  if (panelLoading) return <Spinner centered />;

  return (
    <>
      <div className={s.panelHead}>
        <AvatarInitials firstName={selected.first_name} lastName={selected.last_name} src={selected.avatar_url} size={48} fontSize={16} />
        <div>
          <div className={s.panelName}>{selected.first_name} {selected.last_name}</div>
          <div className={s.panelEmail}>{selected.email}</div>
        </div>
      </div>

      {finance && (
        <div className={s.kpiRow}>
          <div className={`${s.kpi} ${s.kpiGold}`}>
            <div className={s.kpiLabel}>БАЛАНС ДО ВИПЛАТИ</div>
            <div className={s.kpiValue}>{Math.round(finance.balance).toLocaleString()} ₴</div>
            <div className={s.kpiSub}>з {Math.round(finance.total_earnings).toLocaleString()} ₴ нараховано</div>
          </div>
          <div className={s.kpi}>
            <div className={s.kpiLabel}>ВИПЛАЧЕНО</div>
            <div className={s.kpiValue}>{finance.total_paid.toLocaleString()} ₴</div>
            <div className={s.kpiSub}>&nbsp;</div>
          </div>
          <div className={s.kpi}>
            <div className={s.kpiLabel}>ГОДИН</div>
            <div className={s.kpiValue}>{finance.conducted_hours.toFixed(1)}</div>
            <div className={s.kpiSub}>{finance.conducted_lessons} занять</div>
          </div>
        </div>
      )}

      {finance && finance.total_earnings > 0 && (
        <div className={s.earningsBasis}>{formatEarningsBasis(finance)}</div>
      )}

      <div className={s.rateRow}>
        <span className={s.rateLabel}>Ставка:</span>
        {rateEdit ? (
          <div className={s.rateEditWrap}>
            <select className={s.rateSelect} value={rateType} onChange={e => setRateType(e.target.value as RateType)}>
              {RATE_TYPE_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <input
              className={s.rateInput} type="number" min={0} value={rateAmount} autoFocus
              onChange={e => setRateAmount(e.target.value)}
              placeholder={rateType === 'percent' ? '%' : 'грн'}
            />
            <span className={s.rateUnit}>{rateType === 'percent' ? '%' : '₴'}</span>
            <button className={s.btnSave} onClick={handleSaveRate} disabled={rateSaving}>
              {rateSaving ? '...' : 'Зберегти'}
            </button>
            <button className={s.btnCancel} onClick={() => setRateEdit(false)}>Скасувати</button>
          </div>
        ) : (
          <div className={s.rateDisplay}>
            <span className={s.rateValue}>
              {finance?.rate_amount ? formatRate(finance.rate_type, finance.rate_amount) : 'не встановлено'}
            </span>
            <button className={s.btnEdit} onClick={() => setRateEdit(true)}>
              <IconEdit size={12} />
              Редагувати
            </button>
          </div>
        )}
      </div>

      <div className={s.payoutBtnWrap}>
        <button className={s.btnPayout} onClick={() => { setPayoutAmt(''); setPayoutNote(''); setPayoutModal(true); }}>
          <IconDollar size={14} />
          Виплатити
        </button>
      </div>

      <div className={s.historyHead}>ІСТОРІЯ ВИПЛАТ</div>
      {payouts.length === 0 ? (
        <div className={s.historyEmpty}>Виплат ще не було</div>
      ) : (
        <div className={s.historyList}>
          {payouts.map(p => (
            <div key={p.id} className={s.historyRow}>
              <div className={s.historyLeft}>
                <span className={s.historyAmt}>+{p.amount.toLocaleString()} ₴</span>
                {p.note && <span className={s.historyNote}>{p.note}</span>}
              </div>
              <div className={s.historyRight}>
                <span className={s.historyDate}>{fmtDate(p.created_at)}</span>
                <span className={s.historyAdmin}>{p.admin_first_name} {p.admin_last_name}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {payoutModal && (
        <Modal title="Виплата викладачу" onClose={() => setPayoutModal(false)}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label style={{ fontSize: 12, color: 'var(--graphite)', display: 'block', marginBottom: 6 }}>
                Сума виплати (₴) *
              </label>
              <input
                className={a.searchInput} style={{ paddingLeft: 12, width: '100%' }}
                type="number" min={1} placeholder="напр. 5000" value={payoutAmt} autoFocus
                onChange={e => setPayoutAmt(e.target.value)}
              />
            </div>
            <div>
              <label style={{ fontSize: 12, color: 'var(--graphite)', display: 'block', marginBottom: 6 }}>
                Коментар (необов'язково)
              </label>
              <input
                className={a.searchInput} style={{ paddingLeft: 12, width: '100%' }}
                type="text" placeholder="напр. Зарплата за червень" value={payoutNote}
                onChange={e => setPayoutNote(e.target.value)}
              />
            </div>
            {finance && Number(payoutAmt) > 0 && (
              <div style={{ fontSize: 12, color: 'var(--graphite)', padding: '8px 12px', background: 'var(--coal-3)', borderRadius: 'var(--r)' }}>
                Баланс після виплати: <strong style={{ color: 'var(--paper)' }}>
                  {Math.max(0, finance.balance - Number(payoutAmt)).toLocaleString()} ₴
                </strong>
              </div>
            )}
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 4 }}>
              <button className={s.btnCancel} onClick={() => setPayoutModal(false)}>Скасувати</button>
              <button
                className={s.btnPayout} onClick={handlePayout}
                disabled={payoutSaving || !payoutAmt || Number(payoutAmt) <= 0}
              >
                {payoutSaving ? 'Збереження...' : 'Підтвердити виплату'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
};

export default TeacherFinancePanel;
