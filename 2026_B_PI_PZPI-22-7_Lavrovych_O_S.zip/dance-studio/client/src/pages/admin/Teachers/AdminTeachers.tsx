import { useEffect, useState } from 'react';
import { getTeachers } from '../../../api/teachers';
import type { RateType } from '../../../api/teachers';
import PageHeader     from '../../../components/ui/display/PageHeader';
import AvatarInitials from '../../../components/ui/display/AvatarInitials';
import Spinner        from '../../../components/ui/feedback/Spinner';
import Toast          from '../../../components/ui/feedback/Toast';
import { useToast }   from '../../../hooks/useToast';
import TeacherFinancePanel from './TeacherFinancePanel';
import { IconSearch } from '../../../components/ui/Icon';
import a from '../../../styles/admin.module.css';
import s from './AdminTeachers.module.css';

export type Teacher = {
  id: number; user_id: number;
  first_name: string; last_name: string; email: string; phone?: string; avatar_url?: string;
  rate_type?: RateType; rate_amount?: number;
  students_count: number; lessons_count: number;
  styles: { id: number; name: string }[];
};

const AdminTeachers = () => {
  const { toasts, showToast, removeToast } = useToast();
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState('');
  const [selected, setSelected] = useState<Teacher | null>(null);

  useEffect(() => {
    getTeachers().then(setTeachers).finally(() => setLoading(false));
  }, []);

  const filtered = teachers.filter(t =>
    `${t.first_name} ${t.last_name} ${t.email}`.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <Spinner centered />;

  return (
    <div className={s.layout}>
      {/* ── Left: teacher list ── */}
      <div className={s.list}>
        <PageHeader title="Викладачі" />

        <div className={a.toolbar}>
          <div className={a.searchWrap}>
            <IconSearch className={a.searchIcon} size={14} />
            <input
              className={a.searchInput}
              placeholder="Пошук за іменем або email..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className={s.teacherCards}>
          {filtered.map(t => (
            <button
              key={t.id}
              className={`${s.teacherCard} ${selected?.id === t.id ? s.teacherCardActive : ''}`}
              onClick={() => setSelected(t)}
            >
              <AvatarInitials firstName={t.first_name} lastName={t.last_name} src={t.avatar_url} size={40} fontSize={14} />
              <div className={s.teacherCardInfo}>
                <div className={s.teacherCardName}>{t.first_name} {t.last_name}</div>
                <div className={s.teacherCardMeta}>{t.email}</div>
                {t.styles.length > 0 && (
                  <div className={s.teacherCardStyles}>
                    {t.styles.map(st => <span key={st.id} className={s.styleTag}>{st.name}</span>)}
                  </div>
                )}
              </div>
              <div className={s.teacherCardStats}>
                <span>{t.students_count} учн.</span>
                <span>{t.lessons_count} зан.</span>
              </div>
            </button>
          ))}
          {filtered.length === 0 && <div className={s.empty}>Викладачів не знайдено</div>}
        </div>
      </div>

      {/* ── Right: finance panel ── */}
      <div className={s.panel}>
        <TeacherFinancePanel selected={selected} showToast={showToast} />
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default AdminTeachers;
