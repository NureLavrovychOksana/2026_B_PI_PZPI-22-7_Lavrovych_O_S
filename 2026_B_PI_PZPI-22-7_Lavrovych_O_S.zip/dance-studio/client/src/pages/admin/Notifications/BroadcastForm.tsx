import { useState } from 'react';
import { broadcast } from '../../../api/notifications';
import type { DanceGroup } from '../../../types';
import { IconSend, IconCheck } from '../../../components/ui/Icon';
import a from '../../../styles/admin.module.css';

const NOTIFICATION_TYPES = [
  { value: 'manual',           label: 'Загальне повідомлення' },
  { value: 'schedule_change',  label: 'Зміна розкладу' },
  { value: 'studio_news',      label: 'Новини студії' },
  { value: 'payment_reminder', label: 'Нагадування про оплату' },
];

interface Props {
  groups:  DanceGroup[];
  onSent:  (count: number) => void;
  onError: (msg: string) => void;
}

const BroadcastForm = ({ groups, onSent, onError }: Props) => {
  const [saving, setSaving] = useState(false);
  const [form, setForm]     = useState({ title: '', body: '', type: 'manual', group_id: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent]     = useState<{ sent: number } | null>(null);

  const set = (field: string) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      setForm(p => ({ ...p, [field]: e.target.value }));
      setErrors(p => ({ ...p, [field]: '' }));
      setSent(null);
    };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.title.trim()) e.title = 'Введіть заголовок';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      const result = await broadcast({
        title:    form.title,
        body:     form.body || undefined,
        type:     form.type,
        group_id: form.group_id ? Number(form.group_id) : undefined,
      });
      setSent(result);
      setForm({ title: '', body: '', type: 'manual', group_id: '' });
      onSent(result.sent);
    } catch (err: any) {
      onError(err.response?.data?.message || 'Помилка');
    } finally {
      setSaving(false);
    }
  };

  const recipientLabel = form.group_id
    ? `Учні групи "${groups.find(g => String(g.id) === form.group_id)?.name || ''}"`
    : 'Всі учні студії';

  return (
    <div style={{ background: 'var(--coal-2)', border: '1px solid #1e1e1c', borderRadius: 'var(--r-lg)', padding: 24 }}>
      <form onSubmit={handleSubmit} noValidate>
        <div className={a.formRow}>
          <div className={a.formGroup}>
            <label className={a.label}>ТИП СПОВІЩЕННЯ</label>
            <select className={a.input} value={form.type} onChange={set('type')}>
              {NOTIFICATION_TYPES.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
          </div>

          <div className={a.formGroup}>
            <label className={a.label}>ОТРИМУВАЧІ</label>
            <select className={a.input} value={form.group_id} onChange={set('group_id')}>
              <option value="">Всі учні</option>
              {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
          </div>
        </div>

        <div className={a.formGroup}>
          <label className={a.label}>ЗАГОЛОВОК</label>
          <input
            className={`${a.input} ${errors.title ? a.inputError : ''}`}
            value={form.title}
            onChange={set('title')}
            placeholder="Зміна розкладу на цьому тижні"
          />
          {errors.title && <div className={a.errorMsg}>{errors.title}</div>}
        </div>

        <div className={a.formGroup}>
          <label className={a.label}>
            ТЕКСТ
            <span style={{ color: 'var(--graphite)', marginLeft: 4 }}>(необовʼязково)</span>
          </label>
          <textarea
            className={a.input}
            style={{ resize: 'vertical', minHeight: 100 }}
            value={form.body}
            onChange={set('body')}
            placeholder="Детальний текст повідомлення..."
          />
        </div>

        <div style={{
          background: 'var(--coal-3)', border: '1px solid #2a2a27',
          borderRadius: 'var(--r)', padding: 12, marginBottom: 16,
        }}>
          <div style={{ fontSize: 10, color: 'var(--graphite)', fontFamily: 'var(--font-mono)', marginBottom: 6, letterSpacing: '0.06em' }}>
            ПЕРЕГЛЯД
          </div>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--paper)', marginBottom: 4 }}>
            {form.title || 'Заголовок сповіщення'}
          </div>
          {form.body && (
            <div style={{ fontSize: 12, color: 'var(--mid)', lineHeight: 1.5 }}>{form.body}</div>
          )}
          <div style={{ fontSize: 10, color: 'var(--graphite)', marginTop: 8, fontFamily: 'var(--font-mono)' }}>
            → {recipientLabel}
          </div>
        </div>

        <button type="submit" className={a.btnPrimary} disabled={saving} style={{ width: '100%', justifyContent: 'center' }}>
          {saving
            ? <><span className={a.spinner} /> Надсилання...</>
            : <><IconSend size={14} strokeWidth={1.8} /> Надіслати</>
          }
        </button>
      </form>

      {sent && (
        <div style={{
          marginTop: 16, padding: '14px 16px',
          background: 'var(--success-bg)', border: '1px solid rgba(110,231,160,0.2)',
          borderRadius: 'var(--r)', fontSize: 13, color: 'var(--success)',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <IconCheck size={16} />
          Сповіщення надіслано {sent.sent} отримувачам
        </div>
      )}
    </div>
  );
};

export default BroadcastForm;
