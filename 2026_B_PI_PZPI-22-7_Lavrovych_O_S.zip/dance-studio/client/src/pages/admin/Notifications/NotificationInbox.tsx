import React, { useState, useEffect } from 'react';
import { getMyNotifications, markAllRead } from '../../../api/notifications';
import Spinner from '../../../components/ui/feedback/Spinner';
import {
  IconUser, IconDollar, IconX, IconAlertTriangle, IconCheck,
  IconUserX, IconClock, IconBell, IconRefresh,
} from '../../../components/ui/Icon';
import type { Notification } from '../../../types';
import s from './AdminNotifications.module.css';

const ICONS: Record<string, { svg: React.ReactElement; bg: string; color: string }> = {
  new_student:          { svg: <IconUser size={14} />,          bg: 'var(--info-bg)',    color: 'var(--info)'    },
  payment_received:     { svg: <IconDollar size={14} />,        bg: 'var(--success-bg)', color: 'var(--success)' },
  lesson_cancelled:     { svg: <IconX size={14} strokeWidth={2.5} />, bg: 'var(--error-bg)',   color: 'var(--error)'   },
  rate_changed:         { svg: <IconAlertTriangle size={14} />, bg: 'var(--warn-bg)',    color: 'var(--warn)'    },
  payout_received:      { svg: <IconCheck size={14} strokeWidth={2.5} />, bg: 'var(--success-bg)', color: 'var(--success)' },
  enrollment_cancelled: { svg: <IconUserX size={14} />,         bg: 'var(--error-bg)',   color: 'var(--error)'   },
  subscription_expiring:{ svg: <IconClock size={14} />,         bg: 'var(--warn-bg)',    color: 'var(--warn)'    },
  manual:               { svg: <IconBell size={14} />,          bg: 'var(--info-bg)',    color: 'var(--info)'    },
};
const DEFAULT_ICON = {
  svg: <IconBell size={14} />,
  bg: 'var(--info-bg)', color: 'var(--info)',
};

const fmtDate = (iso: string) => {
  const d    = new Date(iso);
  const diff = Date.now() - d.getTime();
  if (diff < 60_000)    return 'щойно';
  if (diff < 3600_000)  return `${Math.floor(diff / 60_000)} хв. тому`;
  if (diff < 86400_000) return `${Math.floor(diff / 3600_000)} год. тому`;
  return d.toLocaleDateString('uk-UA', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
};

const NotificationInbox = () => {
  const [history, setHistory] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    getMyNotifications().then(setHistory).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleMarkAllRead = async () => {
    await markAllRead();
    setHistory(prev => prev.map(n => ({ ...n, is_read: true })));
  };

  const unreadCount = history.filter(n => !n.is_read).length;

  return (
    <div className={s.inbox}>
      <div className={s.inboxHead}>
        <div>
          <div className={s.inboxTitle}>Вхідні сповіщення</div>
          {unreadCount > 0 && <span className={s.unreadBadge}>{unreadCount} нових</span>}
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <button className={s.refreshBtn} onClick={load} title="Оновити">
            <IconRefresh size={13} />
          </button>
          {unreadCount > 0 && (
            <button className={s.markAllBtn} onClick={handleMarkAllRead}>
              Позначити всі прочитаними
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <Spinner centered />
      ) : history.length === 0 ? (
        <div className={s.empty}>
          <span style={{ color: 'var(--graphite)', marginBottom: 10, display: 'flex' }}>
            <IconBell size={32} strokeWidth={1.2} />
          </span>
          Сповіщень поки немає
        </div>
      ) : (
        <div className={s.list}>
          {history.map(n => (
            <div key={n.id} className={`${s.notifRow} ${!n.is_read ? s.notifUnread : ''}`}>
              <div className={s.notifIcon} style={{ background: (ICONS[n.type] ?? DEFAULT_ICON).bg, color: (ICONS[n.type] ?? DEFAULT_ICON).color }}>
                {(ICONS[n.type] ?? DEFAULT_ICON).svg}
              </div>
              <div className={s.notifBody}>
                <div className={s.notifTitle}>{n.title}</div>
                {n.body && <div className={s.notifText}>{n.body}</div>}
              </div>
              <div className={s.notifTime}>{fmtDate(n.created_at)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NotificationInbox;
