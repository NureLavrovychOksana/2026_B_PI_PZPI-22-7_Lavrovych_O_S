import { useState, useEffect } from 'react';
import { getGroups } from '../../../api/groups';
import PageHeader        from '../../../components/ui/display/PageHeader';
import Toast             from '../../../components/ui/feedback/Toast';
import BroadcastForm     from './BroadcastForm';
import NotificationInbox from './NotificationInbox';
import { useToast }      from '../../../hooks/useToast';
import type { DanceGroup } from '../../../types';
import s from './AdminNotifications.module.css';

const AdminNotifications = () => {
  const [groups, setGroups] = useState<DanceGroup[]>([]);
  const { toasts, showToast, removeToast } = useToast();

  useEffect(() => {
    getGroups().then(g => setGroups(g.filter(gr => gr.status === 'active')));
  }, []);

  return (
    <div className={s.layout}>
      <div>
        <PageHeader title="Сповіщення" />
        <BroadcastForm
          groups={groups}
          onSent={count => showToast(`Надіслано ${count} отримувачам`, 'success')}
          onError={msg  => showToast(msg, 'error')}
        />
      </div>

      <NotificationInbox />

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default AdminNotifications;
