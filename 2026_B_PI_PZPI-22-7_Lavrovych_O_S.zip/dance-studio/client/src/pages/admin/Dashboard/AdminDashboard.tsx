﻿import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getDashboard, getRevenue } from '../../../api/reports';
import PageHeader            from '../../../components/ui/display/PageHeader';
import NotifBell            from '../../../components/ui/display/NotifBell';
import StatCard              from '../../../components/ui/display/StatCard';
import ProgressBar           from '../../../components/ui/display/ProgressBar';
import Button                from '../../../components/ui/form/Button';
import Spinner               from '../../../components/ui/feedback/Spinner';
import DashboardRevenueChart from './DashboardRevenueChart';
import {
  IconDollar, IconUser, IconCalendar, IconUsers, IconBarChart, IconCreditCard, IconInfo, IconPlus,
} from '../../../components/ui/Icon';
import type { DashboardData, RevenuePoint } from '../../../types';
import styles from './AdminDashboard.module.css';

const ACTIVITY_ICONS: Record<string, { bg: string; color: string; icon: React.ReactNode }> = {
  payment:      { bg: 'var(--success-bg)', color: 'var(--success)',    icon: <IconDollar size={14} /> },
  registration: { bg: 'var(--info-bg)',    color: 'var(--info)',       icon: <IconUser size={14} /> },
  lesson_added: { bg: 'var(--lime-deep)', color: 'var(--lime-hot)',   icon: <IconCalendar size={14} /> },
};

const formatMoney = (n: number) =>
  `₴${Number(n).toLocaleString('uk-UA')}`;

const formatDate = (d: string) => {
  // MySQL returns datetime without timezone — force UTC parsing
  const normalized = d.includes('Z') || d.includes('+') ? d : d.replace(' ', 'T') + 'Z';
  const date = new Date(normalized);
  const now  = new Date();
  const diff = Math.floor((now.getTime() - date.getTime()) / 60000);
  if (diff < 1)    return 'щойно';
  if (diff < 60)   return `${diff} хв тому`;
  if (diff < 1440) return `${Math.floor(diff / 60)} год тому`;
  return `${Math.floor(diff / 1440)} дн тому`;
};

const AdminDashboard = () => {
  const [data, setData]       = useState<DashboardData | null>(null);
  const [revenue, setRevenue] = useState<RevenuePoint[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getDashboard(), getRevenue({ group_by: 'week' })])
      .then(([dash, rev]) => { setData(dash); setRevenue(rev); })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner size="lg" centered />;
  if (!data)   return null;

  const { stats, styles_popularity, recent_activity } = data;

  const revenueChange = stats.prev_month_revenue > 0
    ? `${stats.month_revenue > stats.prev_month_revenue ? '+' : ''}${Math.round(((stats.month_revenue - stats.prev_month_revenue) / stats.prev_month_revenue) * 100)}% до минулого місяця`
    : undefined;

  const maxStudents = Math.max(...styles_popularity.map(s => s.students_count), 1);

  return (
    <div className={styles.page}>
      <PageHeader
        title="Дашборд"
        sub={new Date().toLocaleDateString('uk-UA', { weekday: 'long', day: 'numeric', month: 'long' })}
        actions={
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <NotifBell to="/admin/notifications" />
            <Button href="/admin/schedule">
              <IconPlus size={14} strokeWidth={1.8} />
              Додати заняття
            </Button>
          </div>
        }
      />

      {/* KPI */}
      <div className={styles.kpiGrid}>
        <StatCard
          label="ДОХІД МІСЯЦЯ"
          value={formatMoney(stats.month_revenue)}
          change={revenueChange}
          changeNeg={stats.month_revenue < stats.prev_month_revenue}
          accentBorder
          valueColor="accent"
        />
        <StatCard
          label="АКТИВНІ УЧНІ"
          value={stats.students}
          change={`${stats.active_groups} активних груп`}
        />
        <StatCard
          label="ЗАНЯТЬ СЬОГОДНІ"
          value={stats.today_lessons}
          change={`${stats.occupancy_percent}% заповнюваність`}
        />
        <StatCard
          label="БОРЖНИКИ"
          value={stats.debtors}
          valueColor={stats.debtors > 0 ? 'warn' : 'default'}
          change={stats.debtors > 0 ? 'Без активного абонементу' : 'Всі з абонементом'}
        />
      </div>

      {/* Charts row */}
      <div className={styles.chartsRow}>

        <DashboardRevenueChart data={revenue} />

        {/* Styles popularity */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>ПОПУЛЯРНІСТЬ СТИЛІВ</div>
          {styles_popularity.slice(0, 6).map(s => (
            <div key={s.style} className={styles.styleRow}>
              <div className={styles.styleName}>{s.style}</div>
              <ProgressBar value={(s.students_count / maxStudents) * 100} height={6} />
              <div className={styles.styleCount}>{s.students_count}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom row */}
      <div className={styles.bottomRow}>

        {/* Activity feed */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>ОСТАННІ ПОДІЇ</div>
          <div className={styles.activityList}>
            {recent_activity.slice(0, 8).map((item, i) => {
              const ic = ACTIVITY_ICONS[item.type] ?? {
                bg: 'var(--coal-3)', color: 'var(--graphite)',
                icon: <IconInfo size={14} />,
              };
              return (
                <div key={i} className={styles.activityItem}>
                  <div className={styles.activityIcon} style={{ background: ic.bg, color: ic.color }}>
                    {ic.icon}
                  </div>
                  <div className={styles.activityText}>
                    <strong>{item.subject}</strong> — {item.description}
                  </div>
                  <div className={styles.activityTime}>{formatDate(item.created_at)}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick actions */}
        <div className={styles.card}>
          <div className={styles.cardTitle}>ШВИДКИЙ ДОСТУП</div>
          <div className={styles.quickActions}>
            {[
              { label: 'Користувачі', href: '/admin/users',          icon: <IconUsers size={22} strokeWidth={1.5} /> },
              { label: 'Розклад',     href: '/admin/schedule',       icon: <IconCalendar size={22} strokeWidth={1.5} /> },
              { label: 'Абонементи', href: '/admin/subscriptions',   icon: <IconCreditCard size={22} strokeWidth={1.5} /> },
              { label: 'Звіти',      href: '/admin/reports',         icon: <IconBarChart size={22} strokeWidth={1.5} /> },
            ].map(a => (
              <Link key={a.label} to={a.href} className={styles.quickBtn}>
                {a.icon}
                {a.label}
              </Link>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default AdminDashboard;