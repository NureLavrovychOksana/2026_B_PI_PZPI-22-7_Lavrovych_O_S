import { useState } from 'react';
import type { RevenuePoint } from '../../../types';
import styles from './AdminDashboard.module.css';

const formatMoney = (n: number) => `₴${Number(n).toLocaleString('uk-UA')}`;
const fmtK = (n: number) => `₴${Math.round(n / 1000)}к`;

interface Props { data: RevenuePoint[] }

const DashboardRevenueChart = ({ data }: Props) => {
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);

  const vals       = data.map(r => Number(r.total));
  const maxRevenue = Math.max(...vals, 1);
  const minRevenue = vals.length ? Math.min(...vals) : 0;
  const avgRevenue = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;

  return (
    <div className={styles.card}>
      <div className={styles.cardTitle}>ДОХІД ПО ТИЖНЯХ (₴)</div>
      <div className={styles.barsScroll}>
        <div className={styles.barsWrap}>
          {data.map((r, i) => {
            const h        = Math.max((Number(r.total) / maxRevenue) * 90, 3);
            const ws       = String(r.week_start ?? '').slice(0, 10);
            const [, wm, wd] = ws.split('-');
            const label    = wd && wm ? `${wd}.${wm}` : `${i + 1}`;
            const wsMs     = ws.length === 10 ? new Date(ws).getTime() : 0;
            const isCurrent = wsMs > 0 && Date.now() >= wsMs && Date.now() < wsMs + 7 * 86400000;
            const isHovered = hoveredBar === i;
            return (
              <div
                key={r.week_start ?? r.month ?? i}
                className={styles.barCol}
                onMouseEnter={() => setHoveredBar(i)}
                onMouseLeave={() => setHoveredBar(null)}
              >
                <div className={`${styles.bar} ${isCurrent ? styles.barCurrent : ''}`} style={{ height: `${h}px` }}>
                  {isHovered && <div className={styles.barTooltip}>{formatMoney(Number(r.total))}</div>}
                </div>
                <span className={styles.barLabel}>{label}</span>
              </div>
            );
          })}
        </div>
      </div>
      <div className={styles.chartStats}>
        <span><span className={styles.chartStatLabel}>Мін:</span> {fmtK(minRevenue)}</span>
        <span><span className={styles.chartStatLabel}>Середнє:</span> {fmtK(avgRevenue)}</span>
        <span><span className={styles.chartStatLabel}>Макс:</span> {fmtK(maxRevenue)}</span>
      </div>
    </div>
  );
};

export default DashboardRevenueChart;
