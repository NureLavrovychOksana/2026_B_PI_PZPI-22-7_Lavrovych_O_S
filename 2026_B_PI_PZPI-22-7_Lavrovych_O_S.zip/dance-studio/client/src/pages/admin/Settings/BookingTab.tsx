import { useState } from 'react';
import { updateSettings } from '../../../api/settings';
import Toast        from '../../../components/ui/feedback/Toast';
import FormField    from '../../../components/ui/form/FormField';
import SectionLabel from '../../../components/ui/display/SectionLabel';
import { useToast } from '../../../hooks/useToast';
import a from '../../../styles/admin.module.css';

interface Props {
  settings: Record<string, string>;
  onChange: (key: string, val: string) => void;
}

const BookingTab = ({ settings, onChange }: Props) => {
  const [saving, setSaving] = useState(false);
  const { toasts, showToast, removeToast } = useToast();

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateSettings(settings);
      showToast('Налаштування збережено', 'success');
    } catch {
      showToast('Помилка збереження', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <SectionLabel>НАЛАШТУВАННЯ ЗАПИСУ</SectionLabel>

      <FormField
        label="СКАСУВАННЯ ЗАПИСУ (годин до заняття)"
        hint="Учень не зможе скасувати запис пізніше, ніж за вказану кількість годин до початку заняття. 0 = без обмежень."
      >
        <input className={a.input} type="number" min={0}
          value={settings['cancel_hours_before'] ?? '2'}
          onChange={e => onChange('cancel_hours_before', e.target.value)} />
      </FormField>

      <FormField
        label="МІНІМУМ УЧНІВ (автоскасування заняття)"
        hint="Якщо кількість записаних учнів падає нижче цього порогу — заняття скасовується автоматично. 0 = вимкнено."
      >
        <input className={a.input} type="number" min={0}
          value={settings['min_students_cancel'] ?? '0'}
          onChange={e => onChange('min_students_cancel', e.target.value)} />
      </FormField>

      <button
        className={a.btnPrimary}
        style={{ marginTop: 20 }}
        onClick={handleSave}
        disabled={saving}
      >
        {saving && <span className={a.spinner} />}
        Зберегти
      </button>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default BookingTab;
