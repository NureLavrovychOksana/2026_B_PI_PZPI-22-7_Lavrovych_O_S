﻿import { useState } from 'react';
import { updateSettings } from '../../../api/settings';
import Toast        from '../../../components/ui/feedback/Toast';
import FormField    from '../../../components/ui/form/FormField';
import SectionLabel from '../../../components/ui/display/SectionLabel';
import { useToast } from '../../../hooks/useToast';
import a from '../../../styles/admin.module.css';

interface Props {
  settings: Record<string, string>;
  onChange: (key: string, val: string) => void;
}

const toggle = (val: string | undefined) => (val === '1' ? '0' : '1');

const NotificationsTab = ({ settings, onChange }: Props) => {
  const [saving, setSaving] = useState(false);
  const { toasts, showToast, removeToast } = useToast();

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateSettings(settings);
      showToast('Налаштування збережено', 'success');
    } catch {
      showToast('Помилка збереження', 'error');
    } finally {
      setSaving(false);
    }
  };

  const row = (key: string, label: string) => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid #1e1e1c' }}>
      <span style={{ fontSize: 13, color: 'var(--paper)' }}>{label}</span>
      <button
        onClick={() => onChange(key, toggle(settings[key]))}
        style={{
          width: 44, height: 24, borderRadius: 12, border: 'none', cursor: 'pointer',
          background: settings[key] === '1' ? 'var(--gold)' : 'var(--coal-3)',
          position: 'relative', transition: 'background 0.2s',
        }}
      >
        <span style={{
          position: 'absolute', top: 3, left: settings[key] === '1' ? 22 : 3,
          width: 18, height: 18, borderRadius: '50%', background: '#fff',
          transition: 'left 0.2s',
        }} />
      </button>
    </div>
  );

  return (
    <div>
      <SectionLabel>НАЛАШТУВАННЯ СПОВІЩЕНЬ</SectionLabel>

      {row('notify_new_student',     'Новий учень зареєстрований')}
      {row('notify_payment',         'Надходження оплати')}
      {row('notify_subscription_exp','Закінчення абонементу (за 3 дні)')}
      {row('notify_lesson_cancel',   'Скасування заняття')}
      {row('notify_no_subscription', 'Учень без абонементу намагається записатись')}

      <div style={{ marginTop: 20 }}>
        <FormField label="EMAIL ДЛЯ АДМІН-СПОВІЩЕНЬ">
          <input
            className={a.input}
            type="email"
            value={settings['admin_notify_email'] ?? ''}
            onChange={e => onChange('admin_notify_email', e.target.value)}
            placeholder="admin@studio.com"
          />
        </FormField>
      </div>

      <button
        className={a.btnPrimary}
        style={{ marginTop: 20 }}
        onClick={handleSave}
        disabled={saving}
      >
        {saving && <span className={a.spinner} />}
        Зберегти
      </button>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default NotificationsTab;
