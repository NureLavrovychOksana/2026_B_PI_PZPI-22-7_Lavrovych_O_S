﻿import { useState } from 'react';
import { updateSettings } from '../../../api/settings';
import Toast        from '../../../components/ui/feedback/Toast';
import FormField    from '../../../components/ui/form/FormField';
import SectionLabel from '../../../components/ui/display/SectionLabel';
import { useToast } from '../../../hooks/useToast';
import { validateEmail } from '../../../utils/validators';
import a from '../../../styles/admin.module.css';

interface Props {
  settings: Record<string, string>;
  onChange: (key: string, val: string) => void;
}

const StudioTab = ({ settings, onChange }: Props) => {
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toasts, showToast, removeToast } = useToast();

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!settings.studio_name?.trim()) e.studio_name = "Обовʼязкове поле";
    const emailVal = settings.studio_email?.trim();
    if (emailVal) {
      const emailErr = validateEmail(emailVal);
      if (emailErr) e.studio_email = emailErr;
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      await updateSettings(settings);
      showToast('Налаштування збережено', 'success');
    } catch {
      showToast('Помилка збереження', 'error');
    } finally {
      setSaving(false);
    }
  };

  const field = (key: string, label: string, placeholder = '') => (
    <FormField label={label} error={errors[key]}>
      <input
        className={`${a.input} ${errors[key] ? a.inputError : ''}`}
        value={settings[key] ?? ''}
        onChange={e => { onChange(key, e.target.value); setErrors(p => ({ ...p, [key]: '' })); }}
        placeholder={placeholder}
      />
    </FormField>
  );

  return (
    <div>
      <SectionLabel>ІНФОРМАЦІЯ ПРО СТУДІЮ</SectionLabel>

      {field('studio_name',     'НАЗВА СТУДІЇ',  'Move Studio')}
      {field('studio_address',  'АДРЕСА',        'м. Харків, вул. Сумська 45')}
      {field('studio_phone',    'ТЕЛЕФОН',       '+380 50 123-45-67')}
      {field('studio_email',    'EMAIL',         'info@movestudio.com')}
      {field('studio_instagram','INSTAGRAM',     '@movestudio')}

      <button className={a.btnPrimary} style={{ marginTop: 20 }} onClick={handleSave} disabled={saving}>
        {saving && <span className={a.spinner} />}
        Зберегти
      </button>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default StudioTab;
