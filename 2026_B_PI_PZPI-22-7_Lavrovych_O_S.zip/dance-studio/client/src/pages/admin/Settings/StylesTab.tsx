import { useState } from 'react';
import { createStyle, updateStyle, deleteStyle } from '../../../api/styles';
import FormField from '../../../components/ui/form/FormField';
import type { DanceStyle } from '../../../types';
import a from '../../../styles/admin.module.css';

interface Props {
  styles: DanceStyle[];
  onReload: () => void;
}

// editing: undefined = closed, null = new, DanceStyle = editing existing
type EditState = DanceStyle | null | undefined;

const StylesTab = ({ styles, onReload }: Props) => {
  const [editing, setEditing]   = useState<EditState>(undefined);
  const [name, setName]         = useState('');
  const [desc, setDesc]         = useState('');
  const [saving, setSaving]     = useState(false);
  const [deleting, setDeleting] = useState<DanceStyle | null>(null);
  const [nameErr, setNameErr]   = useState('');
  const [deleteErr, setDeleteErr] = useState('');

  const formOpen = editing !== undefined;

  const openAdd = () => { setEditing(null); setName(''); setDesc(''); setNameErr(''); };
  const openEdit = (st: DanceStyle) => { setEditing(st); setName(st.name); setDesc(st.description ?? ''); setNameErr(''); };
  const cancel = () => { setEditing(undefined); setNameErr(''); };
  const closeDelete = () => { setDeleting(null); setDeleteErr(''); };

  const save = async () => {
    if (!name.trim()) { setNameErr("Назва обовʼязкова"); return; }
    setSaving(true);
    try {
      if (editing) {
        await updateStyle(editing.id, { name: name.trim(), description: desc.trim() || undefined });
      } else {
        await createStyle({ name: name.trim(), description: desc.trim() || undefined });
      }
      cancel();
      onReload();
    } catch (e: any) {
      setNameErr(e.response?.data?.message ?? 'Помилка збереження');
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    setSaving(true);
    setDeleteErr('');
    try {
      await deleteStyle(deleting.id);
      closeDelete();
      onReload();
    } catch (e: any) {
      setDeleteErr(e.response?.data?.message ?? 'Помилка видалення');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div style={{ fontSize: 10, color: 'var(--graphite)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}>
          СТИЛІ ТАНЦІВ · {styles.length}
        </div>
        {!formOpen && (
          <button className={a.btnPrimary} onClick={openAdd}>+ Додати стиль</button>
        )}
      </div>

      {/* Add / Edit form */}
      {formOpen && (
        <div style={{ background: 'var(--coal-3)', border: '1px solid #2a2a27', borderRadius: 'var(--r-lg)', padding: 16, marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--paper)', marginBottom: 14 }}>
            {editing ? `Редагувати: ${editing.name}` : 'Новий стиль'}
          </div>
          <FormField label="НАЗВА" error={nameErr}>
            <input
              className={a.input}
              value={name}
              onChange={e => { setName(e.target.value); setNameErr(''); }}
              placeholder="Напр. Hip-Hop"
              maxLength={60}
              autoFocus
            />
          </FormField>
          <FormField label="ОПИС (необовʼязково)">
            <input
              className={a.input}
              value={desc}
              onChange={e => setDesc(e.target.value)}
              placeholder="Короткий опис стилю"
              maxLength={200}
            />
          </FormField>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 14 }}>
            <button className={a.btnSecondary} onClick={cancel}>Скасувати</button>
            <button className={a.btnPrimary} onClick={save} disabled={saving}>
              {saving ? '...' : editing ? 'Зберегти' : 'Створити'}
            </button>
          </div>
        </div>
      )}

      {/* Empty state */}
      {styles.length === 0 && !formOpen && (
        <div style={{ color: 'var(--graphite)', fontSize: 13, textAlign: 'center', padding: '32px 0' }}>
          Стилів ще немає. Натисніть «+ Додати стиль»
        </div>
      )}

      {/* Styles list */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {styles.map(st => (
          <div
            key={st.id}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              background: editing?.id === st.id ? 'var(--lime-deep)' : 'var(--coal-3)',
              border: `1px solid ${editing?.id === st.id ? 'var(--lime-dark)' : '#1e1e1c'}`,
              borderRadius: 'var(--r)',
              padding: '10px 14px',
              transition: 'background 0.15s, border-color 0.15s',
            }}
          >
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--paper)' }}>{st.name}</div>
              {st.description && (
                <div style={{ fontSize: 11, color: 'var(--graphite)', marginTop: 2 }}>{st.description}</div>
              )}
            </div>
            <button
              className={a.btnGhost}
              style={{ padding: '4px 12px', fontSize: 12 }}
              onClick={() => openEdit(st)}
              disabled={formOpen}
            >
              Змінити
            </button>
            <button
              className={a.btnDanger}
              style={{ padding: '4px 12px', fontSize: 12 }}
              onClick={() => setDeleting(st)}
              disabled={formOpen || saving}
            >
              Видалити
            </button>
          </div>
        ))}
      </div>

      {/* Delete confirmation */}
      {deleting && (
        <div className={a.modalOverlay} onClick={closeDelete}>
          <div className={a.modalBox} onClick={e => e.stopPropagation()}>
            <div className={a.modalHeader}>
              <div className={a.modalTitle}>Видалити стиль?</div>
              <button className={a.modalClose} onClick={closeDelete}>×</button>
            </div>
            <div className={a.modalBody}>
              <p style={{ fontSize: 13, color: 'var(--mid)', lineHeight: 1.6 }}>
                Стиль <strong style={{ color: 'var(--paper)' }}>{deleting.name}</strong> буде видалено назавжди.
                Це може вплинути на групи що використовують цей стиль.
              </p>
              {deleteErr && (
                <p style={{ fontSize: 12, color: 'var(--danger, #e55)', marginTop: 10, fontWeight: 500 }}>
                  {deleteErr}
                </p>
              )}
            </div>
            <div className={a.modalFooter}>
              <div style={{ flex: 1 }} />
              <button className={a.btnSecondary} onClick={closeDelete}>Скасувати</button>
              <button className={a.btnDanger} onClick={confirmDelete} disabled={saving}>
                {saving ? '...' : 'Видалити'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StylesTab;
