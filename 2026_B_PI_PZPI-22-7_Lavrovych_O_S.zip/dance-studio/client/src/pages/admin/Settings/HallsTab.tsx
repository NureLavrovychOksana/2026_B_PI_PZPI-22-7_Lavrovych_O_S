import { useState } from 'react';
import { createHall, updateHall, deleteHall, restoreHall } from '../../../api/halls';
import SectionLabel from '../../../components/ui/display/SectionLabel';
import { useToast } from '../../../hooks/useToast';
import Toast from '../../../components/ui/feedback/Toast';
import { IconChevronRight } from '../../../components/ui/Icon';
import type { Hall } from '../../../types';
import a from '../../../styles/admin.module.css';

interface Props {
  halls: Hall[];
  onReload: () => void;
}

interface FormState { name: string; capacity: string }
const emptyForm: FormState = { name: '', capacity: '' };

const HallsTab = ({ halls, onReload }: Props) => {
  const activeHalls   = halls.filter(h => h.is_active);
  const archivedHalls = halls.filter(h => !h.is_active);

  const [form, setForm]               = useState<FormState>(emptyForm);
  const [editId, setEditId]           = useState<number | null>(null);
  const [archiveTarget, setArchiveTarget] = useState<Hall | null>(null);
  const [relocateTarget, setRelocateTarget] = useState<string>('');
  const [archiveOpen, setArchiveOpen] = useState(false);
  const [saving, setSaving]           = useState(false);
  const { toasts, showToast, removeToast } = useToast();

  const startEdit = (h: Hall) => {
    setEditId(h.id);
    setForm({ name: h.name, capacity: String(h.capacity) });
  };
  const cancelEdit = () => { setEditId(null); setForm(emptyForm); };

  const handleSave = async () => {
    if (!form.name.trim() || !form.capacity) return;
    setSaving(true);
    try {
      const payload = { name: form.name.trim(), capacity: Number(form.capacity) };
      if (editId !== null) {
        await updateHall(editId, payload);
        showToast('Зал оновлено', 'success');
        setEditId(null);
      } else {
        await createHall(payload);
        showToast('Зал додано', 'success');
      }
      setForm(emptyForm);
      onReload();
    } catch {
      showToast('Помилка збереження', 'error');
    } finally {
      setSaving(false);
    }
  };

  const openArchiveModal = (h: Hall) => {
    setArchiveTarget(h);
    setRelocateTarget('');
  };
  const closeArchiveModal = () => { setArchiveTarget(null); setRelocateTarget(''); };

  const handleArchive = async () => {
    if (!archiveTarget) return;
    setSaving(true);
    try {
      const res = await deleteHall(
        archiveTarget.id,
        relocateTarget ? Number(relocateTarget) : undefined,
      );
      showToast(
        res.relocated
          ? `Зал архівовано. ${res.relocated} занять перенесено.`
          : `Зал «${archiveTarget.name}» архівовано.`,
        'success',
      );
      closeArchiveModal();
      onReload();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleRestore = async (h: Hall) => {
    try {
      await restoreHall(h.id);
      showToast(`Зал «${h.name}» відновлено`, 'success');
      onReload();
    } catch {
      showToast('Помилка відновлення', 'error');
    }
  };

  const futureCount = archiveTarget?.future_lessons_count ?? 0;
  const canConfirm  = futureCount === 0 || !!relocateTarget;

  return (
    <div>
      <SectionLabel>ЗАЛИ СТУДІЇ</SectionLabel>

      <div style={{ marginBottom: 24 }}>
        {activeHalls.length === 0 && (
          <div style={{ color: 'var(--graphite)', fontSize: 13 }}>Жодного залу не додано</div>
        )}
        {activeHalls.map(h => (
          <div
            key={h.id}
            style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid #1e1e1c' }}
          >
            {editId === h.id ? (
              <>
                <input
                  className={a.input} style={{ flex: 2 }}
                  value={form.name}
                  onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  placeholder="Назва залу"
                />
                <input
                  className={a.input} style={{ flex: 1 }}
                  type="number" min={1}
                  value={form.capacity}
                  onChange={e => setForm(p => ({ ...p, capacity: e.target.value }))}
                  placeholder="Місць"
                />
                <button className={a.btnPrimary} onClick={handleSave} disabled={saving}>
                  {saving && <span className={a.spinner} />}Зберегти
                </button>
                <button className={a.btnGhost} onClick={cancelEdit}>Скасувати</button>
              </>
            ) : (
              <>
                <span style={{ flex: 2, fontSize: 13, color: 'var(--paper)' }}>{h.name}</span>
                <span style={{ flex: 1, fontSize: 12, color: 'var(--graphite)', fontFamily: 'var(--font-mono)' }}>
                  {h.capacity} місць
                </span>
                <button className={a.btnGhost} onClick={() => startEdit(h)}>Редагувати</button>
                <button className={a.btnDanger} onClick={() => openArchiveModal(h)}>Архівувати</button>
              </>
            )}
          </div>
        ))}
      </div>

      {/* Add new hall */}
      {editId === null && (
        <div>
          <SectionLabel mb={12}>ДОДАТИ ЗАЛ</SectionLabel>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <input
              className={a.input} style={{ flex: 2 }}
              value={form.name}
              onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
              placeholder="Назва залу"
            />
            <input
              className={a.input} style={{ flex: 1 }}
              type="number" min={1}
              value={form.capacity}
              onChange={e => setForm(p => ({ ...p, capacity: e.target.value }))}
              placeholder="Місць"
            />
            <button
              className={a.btnPrimary}
              onClick={handleSave}
              disabled={saving || !form.name.trim() || !form.capacity}
            >
              {saving && <span className={a.spinner} />}Додати
            </button>
          </div>
        </div>
      )}

      {/* Archived halls */}
      {archivedHalls.length > 0 && (
        <div style={{ marginTop: 32 }}>
          <button
            onClick={() => setArchiveOpen(o => !o)}
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--graphite)', fontSize: 11,
              fontFamily: 'var(--font-mono)', letterSpacing: '0.08em',
              marginBottom: 12, padding: 0,
            }}
          >
            <span style={{ display: 'flex', transform: archiveOpen ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s' }}>
              <IconChevronRight size={12} />
            </span>
            АРХІВНІ ЗАЛИ · {archivedHalls.length}
          </button>

          {archiveOpen && (
            <div style={{ opacity: 0.65 }}>
              {archivedHalls.map(h => (
                <div
                  key={h.id}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 12,
                    padding: '10px 12px', marginBottom: 6,
                    borderRadius: 8,
                    border: '1px solid #1e1e1c',
                    background: 'var(--coal-3)',
                  }}
                >
                  <span style={{ flex: 2, fontSize: 13, color: 'var(--paper)' }}>{h.name}</span>
                  <span style={{ flex: 1, fontSize: 12, color: 'var(--graphite)', fontFamily: 'var(--font-mono)' }}>
                    {h.capacity} місць
                  </span>
                  <span style={{
                    fontSize: 9, fontFamily: 'var(--font-mono)', letterSpacing: '0.08em',
                    color: 'var(--graphite)', border: '1px solid #2a2a27',
                    padding: '2px 6px', borderRadius: 4, background: 'var(--coal-2)',
                  }}>
                    АРХІВ
                  </span>
                  <button
                    className={a.btnGhost}
                    style={{ fontSize: 12 }}
                    onClick={() => handleRestore(h)}
                  >
                    Відновити
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Archive / Relocate modal */}
      {archiveTarget && (
        <div className={a.modalOverlay} onClick={closeArchiveModal}>
          <div
            className={a.modalBox}
            style={{ maxWidth: 420 }}
            onClick={e => e.stopPropagation()}
          >
            <div className={a.modalHeader}>
              <span className={a.modalTitle}>Архівувати «{archiveTarget.name}»?</span>
              <button className={a.modalClose} onClick={closeArchiveModal}>✕</button>
            </div>

            <div className={a.modalBody}>
              {futureCount > 0 ? (
                <>
                  <p style={{ color: 'var(--warn)', fontSize: 13, marginBottom: 12, lineHeight: 1.5 }}>
                    <b>{futureCount}</b> майбутніх занять прив'язані до цього залу.
                  </p>
                  <p style={{ fontSize: 13, color: 'var(--graphite)', marginBottom: 12 }}>
                    Оберіть зал для масового переносу всіх занять:
                  </p>
                  <select
                    className={a.input}
                    value={relocateTarget}
                    onChange={e => setRelocateTarget(e.target.value)}
                  >
                    <option value="">— оберіть зал —</option>
                    {activeHalls
                      .filter(h => h.id !== archiveTarget.id)
                      .map(h => (
                        <option key={h.id} value={h.id}>
                          {h.name} ({h.capacity} місць)
                        </option>
                      ))}
                  </select>
                </>
              ) : (
                <p style={{ fontSize: 13, color: 'var(--graphite)', lineHeight: 1.6 }}>
                  Майбутніх занять немає. Зал перейде в архів і більше не відображатиметься у розкладі.
                </p>
              )}
            </div>

            <div className={a.modalFooter} style={{ justifyContent: 'flex-end' }}>
              <button className={a.btnGhost} onClick={closeArchiveModal} disabled={saving}>
                Скасувати
              </button>
              <button
                className={a.btnDanger}
                onClick={handleArchive}
                disabled={saving || !canConfirm}
              >
                {saving && <span className={a.spinner} />}
                {relocateTarget ? 'Перенести та архівувати' : 'Архівувати'}
              </button>
            </div>
          </div>
        </div>
      )}

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default HallsTab;
