﻿import { useEffect, useState } from 'react';
import { getSettings }  from '../../../api/settings';
import { getHalls }     from '../../../api/halls';
import { getStyles }    from '../../../api/styles';
import PageHeader       from '../../../components/ui/display/PageHeader';
import Spinner          from '../../../components/ui/feedback/Spinner';
import StudioTab        from './StudioTab';
import BookingTab       from './BookingTab';
import HallsTab         from './HallsTab';
import StylesTab        from './StylesTab';
import NotificationsTab from './NotificationsTab';
import { IconHome, IconCalendar, IconGrid, IconSmile, IconBell } from '../../../components/ui/Icon';
import type { Hall, DanceStyle } from '../../../types';
import s from './AdminSettings.module.css';

type Tab = 'studio' | 'booking' | 'halls' | 'styles' | 'notifications';

const NAV: { value: Tab; label: string; icon: React.ReactNode }[] = [
  { value: 'studio',        label: 'Студія',      icon: <IconHome size={14} strokeWidth={1.8} /> },
  { value: 'booking',       label: 'Бронювання',  icon: <IconCalendar size={14} strokeWidth={1.8} /> },
  { value: 'halls',         label: 'Зали',         icon: <IconGrid size={14} strokeWidth={1.8} /> },
  { value: 'styles',        label: 'Стилі',        icon: <IconSmile size={14} strokeWidth={1.8} /> },
  { value: 'notifications', label: 'Сповіщення',  icon: <IconBell size={14} strokeWidth={1.8} /> },
];

const AdminSettings = () => {
  const [tab, setTab]           = useState<Tab>('studio');
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [halls, setHalls]       = useState<Hall[]>([]);
  const [styles, setStyles]     = useState<DanceStyle[]>([]);
  const [loading, setLoading]   = useState(true);

  const load = async () => {
    setLoading(true);
    const [cfg, h, st] = await Promise.all([getSettings(), getHalls({ includeArchived: true }), getStyles()]);
    setSettings(cfg);
    setHalls(h);
    setStyles(st);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleChange = (key: string, val: string) => {
    setSettings(p => ({ ...p, [key]: val }));
  };

  if (loading) return <Spinner centered />;

  return (
    <div>
      <PageHeader title="Налаштування" />
      <div className={s.layout}>
        <nav className={s.nav}>
          {NAV.map(n => (
            <button
              key={n.value}
              className={`${s.navItem} ${tab === n.value ? s.navItemActive : ''}`}
              onClick={() => setTab(n.value)}
            >
              {n.icon}
              {n.label}
            </button>
          ))}
        </nav>

        <div className={s.content}>
          {tab === 'studio'        && <StudioTab        settings={settings} onChange={handleChange} />}
          {tab === 'booking'       && <BookingTab       settings={settings} onChange={handleChange} />}
          {tab === 'halls'         && <HallsTab         halls={halls}   onReload={load} />}
          {tab === 'styles'        && <StylesTab        styles={styles} onReload={load} />}
          {tab === 'notifications' && <NotificationsTab settings={settings} onChange={handleChange} />}
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;
