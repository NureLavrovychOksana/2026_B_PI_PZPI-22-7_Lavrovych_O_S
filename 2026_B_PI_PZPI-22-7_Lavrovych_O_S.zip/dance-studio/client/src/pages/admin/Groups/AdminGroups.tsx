import { useEffect, useState, useMemo } from 'react';
import { getGroups, createGroup, updateGroup, deleteGroup } from '../../../api/groups';
import { getStyles }   from '../../../api/styles';
import { getHalls }    from '../../../api/halls';
import { getTeachers } from '../../../api/teachers';
import PageHeader   from '../../../components/ui/display/PageHeader';
import ConfirmModal from '../../../components/ui/overlay/ConfirmModal';
import EmptyState   from '../../../components/ui/feedback/EmptyState';
import Toast        from '../../../components/ui/feedback/Toast';
import Spinner      from '../../../components/ui/feedback/Spinner';
import GroupModal   from './GroupModal';
import GroupCard    from '../../../components/ui/display/GroupCard';
import type { GroupFormData } from './GroupModal';
import { useToast } from '../../../hooks/useToast';
import { IconPlus, IconEdit, IconTrash, IconChevronRight, IconReset } from '../../../components/ui/Icon';
import type { DanceGroup, DanceStyle, Hall } from '../../../types';
import a from '../../../styles/admin.module.css';

const AdminGroups = () => {
  const [groups,  setGroups]  = useState<DanceGroup[]>([]);
  const [styles,  setStyles]  = useState<DanceStyle[]>([]);
  const [halls,   setHalls]   = useState<Hall[]>([]);
  const [teachers,setTeachers]= useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving,  setSaving]  = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterStyle,  setFilterStyle]  = useState('');
  const [modal,        setModal]        = useState<DanceGroup | null | undefined>(undefined);
  const [deleteTarget, setDeleteTarget] = useState<DanceGroup | null>(null);
  const [archiveOpen,  setArchiveOpen]  = useState(false);
  const { toasts, showToast, removeToast } = useToast();

  const load = () => {
    setLoading(true);
    getGroups().then(setGroups).finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    Promise.all([getStyles(), getHalls(), getTeachers()])
      .then(([st, h, t]) => { setStyles(st); setHalls(h); setTeachers(t); });
  }, []);

  const activeGroups = useMemo(() => groups.filter(g => g.status !== 'closed'), [groups]);
  const archivedGroups = useMemo(() => groups.filter(g => g.status === 'closed'), [groups]);

  const filtered = useMemo(() => {
    let r = activeGroups;
    if (filterStatus !== 'all') r = r.filter(g => g.status === filterStatus);
    if (filterStyle)            r = r.filter(g => String(g.style_id) === filterStyle);
    return r;
  }, [activeGroups, filterStatus, filterStyle]);

  const handleSave = async (form: GroupFormData) => {
    setSaving(true);
    try {
      const payload = {
        name:             form.name,
        style_id:         Number(form.style_id),
        level:            form.level,
        teacher_id:       Number(form.teacher_id),
        hall_id:          Number(form.hall_id),
        status:           form.status,
        lessons_per_week: form.lessons_per_week,
        lesson_duration:  form.lesson_duration,
        is_children:      form.is_children,
      };
      if (modal) {
        await updateGroup(modal.id, payload);
        showToast('Групу оновлено', 'success');
      } else {
        await createGroup(payload);
        showToast('Групу створено', 'success');
      }
      setModal(undefined);
      load();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      const result = await deleteGroup(deleteTarget.id);
      showToast(
        result.action === 'archived'
          ? `Групу "${deleteTarget.name}" переведено в архів. Майбутні заняття скасовано.`
          : `Групу "${deleteTarget.name}" видалено.`,
        'success'
      );
      setDeleteTarget(null);
      load();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
      setDeleteTarget(null);
    } finally {
      setSaving(false);
    }
  };

  const handleRestore = async (group: DanceGroup) => {
    try {
      await updateGroup(group.id, { status: 'active' });
      showToast(`Групу "${group.name}" відновлено`, 'success');
      load();
    } catch (err: any) {
      showToast(err.response?.data?.message || 'Помилка', 'error');
    }
  };

  return (
    <div>
      <PageHeader
        title="Групи"
        sub={`${filtered.length} з ${activeGroups.length}`}
        actions={
          <button className={a.addBtn} onClick={() => setModal(null)}>
            <IconPlus size={14} strokeWidth={1.8} />
            Нова група
          </button>
        }
      />

      <div className={a.toolbar}>
        <div className={a.tabs}>
          {[
            { value: 'all',    label: 'Всі' },
            { value: 'active', label: 'Активні' },
            { value: 'paused', label: 'Призупинені' },
          ].map(t => (
            <button
              key={t.value}
              className={`${a.tab} ${filterStatus === t.value ? a.tabActive : ''}`}
              onClick={() => setFilterStatus(t.value)}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className={a.spacer} />
        <select className={a.filterSelect} value={filterStyle} onChange={e => setFilterStyle(e.target.value)}>
          <option value="">Всі стилі</option>
          {styles.map(st => <option key={st.id} value={st.id}>{st.name}</option>)}
        </select>
      </div>

      {loading ? (
        <Spinner centered />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="Груп не знайдено"
          text="Спробуйте змінити фільтр або створіть нову групу"
          action={<button className={a.addBtn} onClick={() => setModal(null)}>Створити групу</button>}
        />
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14 }}>
          {filtered.map(g => (
            <GroupCard
              key={g.id}
              group={g}
              actions={
                <>
                  <button className={a.iconBtn} onClick={e => { e.stopPropagation(); setModal(g); }} title="Редагувати" aria-label="Редагувати групу">
                    <IconEdit size={13} strokeWidth={1.8} />
                  </button>
                  <button className={`${a.iconBtn} ${a.iconBtnDanger}`} onClick={e => { e.stopPropagation(); setDeleteTarget(g); }} title="Архівувати / видалити" aria-label="Видалити групу">
                    <IconTrash size={13} strokeWidth={1.8} />
                  </button>
                </>
              }
            />
          ))}
        </div>
      )}

      {/* Archived groups section */}
      {archivedGroups.length > 0 && (
        <div style={{ marginTop: 32 }}>
          <button
            onClick={() => setArchiveOpen(o => !o)}
            style={{
              display: 'flex', alignItems: 'center', gap: 8,
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--graphite)', fontSize: 11,
              fontFamily: 'var(--font-mono)', letterSpacing: '0.08em',
              marginBottom: 12, padding: 0,
            }}
          >
            <span style={{ display: 'flex', transform: archiveOpen ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s' }}>
              <IconChevronRight size={12} />
            </span>
            АРХІВНІ ГРУПИ · {archivedGroups.length}
          </button>

          {archiveOpen && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14, opacity: 0.6 }}>
              {archivedGroups.map(g => (
                <div key={g.id} style={{ position: 'relative' }}>
                  <GroupCard
                    group={g}
                    actions={
                      <button
                        className={a.iconBtn}
                        onClick={e => { e.stopPropagation(); handleRestore(g); }}
                        title="Відновити групу"
                        aria-label="Відновити групу"
                      >
                        <IconReset size={13} strokeWidth={1.8} />
                      </button>
                    }
                  />
                  <span style={{
                    position: 'absolute', top: 8, right: 40,
                    background: 'var(--coal-3)', border: '1px solid var(--graphite)',
                    color: 'var(--graphite)', fontSize: 9,
                    fontFamily: 'var(--font-mono)', letterSpacing: '0.08em',
                    padding: '2px 6px', borderRadius: 4,
                  }}>
                    АРХІВ
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {modal !== undefined && (
        <GroupModal
          group={modal}
          styles={styles}
          halls={halls}
          teachers={teachers}
          loading={saving}
          onSave={handleSave}
          onClose={() => setModal(undefined)}
        />
      )}

      {deleteTarget && (
        <ConfirmModal
          title="Видалити / архівувати групу?"
          message={`Група "${deleteTarget.name}": якщо вже були проведені заняття — група перейде в архів, а майбутні заняття будуть скасовані. Якщо занять ще не було — група буде видалена повністю.`}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
          loading={saving}
        />
      )}

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default AdminGroups;
