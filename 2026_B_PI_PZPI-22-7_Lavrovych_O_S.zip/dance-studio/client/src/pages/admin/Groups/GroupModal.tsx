﻿import { useState } from 'react';
import Modal     from '../../../components/ui/overlay/Modal';
import FormField from '../../../components/ui/form/FormField';
import type { DanceGroup, DanceStyle, Hall } from '../../../types';
import { LEVEL_LABELS, GroupLevel } from '../../../types';
import a from '../../../styles/admin.module.css';

interface GroupFormData {
  name:             string;
  style_id:         string;
  level:            GroupLevel;
  teacher_id:       string;
  hall_id:          string;
  status:           string;
  lessons_per_week: number;
  lesson_duration:  number;
  is_children:      boolean;
}

interface Props {
  group?:   DanceGroup | null;
  styles:   DanceStyle[];
  halls:    Hall[];
  teachers: any[];
  loading:  boolean;
  onSave:   (data: GroupFormData) => Promise<void>;
  onClose:  () => void;
}

const GroupModal = ({ group, styles: danceStyles, halls, teachers, loading, onSave, onClose }: Props) => {
  const [form, setForm]     = useState<GroupFormData>({
    name:             group?.name             ?? '',
    style_id:         group ? String(group.style_id)   : '',
    level:            group?.level            ?? 'starter',
    teacher_id:       group ? String(group.teacher_id) : '',
    hall_id:          group ? String(group.hall_id)    : '',
    status:           group?.status           ?? 'active',
    lessons_per_week: group?.lessons_per_week ?? 2,
    lesson_duration:  group?.lesson_duration  ?? 60,
    is_children:      group?.is_children      ?? false,
  });
  const [errors, setErrors] = useState<Partial<GroupFormData>>({});

  const set = (field: keyof GroupFormData) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setForm(p => ({ ...p, [field]: e.target.value }));
      setErrors(p => ({ ...p, [field]: undefined }));
    };

  const validate = () => {
    const e: Partial<GroupFormData> = {};
    if (!form.name.trim()) e.name       = "Обовʼязкове поле";
    if (!form.style_id)    e.style_id   = 'Оберіть стиль';
    if (!form.teacher_id)  e.teacher_id = 'Оберіть викладача';
    if (!form.hall_id)     e.hall_id    = 'Оберіть зал';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onSave(form);
  };

  return (
    <Modal
      title={group ? 'Редагувати групу' : 'Нова група'}
      onClose={onClose}
      footer={
        <>
          <div style={{ flex: 1 }} />
          <button type="button" className={a.btnSecondary} onClick={onClose}>Скасувати</button>
          <button type="button" className={a.btnPrimary} disabled={loading} onClick={handleSubmit}>
            {loading && <span className={a.spinner} />}
            {group ? 'Зберегти' : 'Створити'}
          </button>
        </>
      }
    >
      <FormField label="НАЗВА ГРУПИ" error={errors.name}>
        <input
          className={`${a.input} ${errors.name ? a.inputError : ''}`}
          value={form.name}
          onChange={set('name')}
          placeholder="Хіп-хоп Початківці"
        />
      </FormField>

      <div className={a.formRow}>
        <FormField label="СТИЛЬ" error={errors.style_id}>
          <select
            className={`${a.input} ${errors.style_id ? a.inputError : ''}`}
            value={form.style_id}
            onChange={set('style_id')}
          >
            <option value="">Оберіть стиль</option>
            {danceStyles.map(s => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </FormField>

        <FormField label="РІВЕНЬ">
          <select className={a.input} value={form.level} onChange={set('level')}>
            {(Object.keys(LEVEL_LABELS) as GroupLevel[]).map(k => (
              <option key={k} value={k}>{LEVEL_LABELS[k]}</option>
            ))}
          </select>
        </FormField>
      </div>

      <FormField label="ВИКЛАДАЧ" error={errors.teacher_id}>
        <select
          className={`${a.input} ${errors.teacher_id ? a.inputError : ''}`}
          value={form.teacher_id}
          onChange={set('teacher_id')}
        >
          <option value="">Оберіть викладача</option>
          {teachers.map(t => (
            <option key={t.id} value={t.user_id}>{t.first_name} {t.last_name}</option>
          ))}
        </select>
      </FormField>

      <div className={a.formRow}>
        <FormField label="ЗАЛ" error={errors.hall_id}>
          <select
            className={`${a.input} ${errors.hall_id ? a.inputError : ''}`}
            value={form.hall_id}
            onChange={set('hall_id')}
          >
            <option value="">Оберіть зал</option>
            {halls.map(h => (
              <option key={h.id} value={h.id}>{h.name} (до {h.capacity} осіб)</option>
            ))}
          </select>
        </FormField>

        <FormField label="СТАТУС">
          <select className={a.input} value={form.status} onChange={set('status')}>
            <option value="active">Активна</option>
            <option value="paused">Призупинена</option>
            <option value="closed">Закрита</option>
          </select>
        </FormField>
      </div>

      <div className={a.formRow}>
        <FormField label="ЗАНЯТЬ НА ТИЖДЕНЬ (за замовч.)">
          <input
            type="number"
            className={a.input}
            min={1}
            max={7}
            value={form.lessons_per_week}
            onChange={e => setForm(p => ({ ...p, lessons_per_week: Number(e.target.value) }))}
          />
        </FormField>

        <FormField label="ТРИВАЛІСТЬ ЗАНЯТТЯ (ХВ)">
          <input
            type="number"
            className={a.input}
            min={30}
            max={240}
            step={15}
            value={form.lesson_duration}
            onChange={e => setForm(p => ({ ...p, lesson_duration: Number(e.target.value) }))}
          />
        </FormField>
      </div>

      <FormField label="ДИТЯЧА ГРУПА">
        <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', paddingTop: 6 }}>
          <input
            type="checkbox"
            checked={form.is_children}
            onChange={e => setForm(p => ({ ...p, is_children: e.target.checked }))}
            style={{ width: 16, height: 16, accentColor: 'var(--lime-hot)', cursor: 'pointer' }}
          />
        </label>
      </FormField>

    </Modal>
  );
};

export default GroupModal;
export type { GroupFormData };
