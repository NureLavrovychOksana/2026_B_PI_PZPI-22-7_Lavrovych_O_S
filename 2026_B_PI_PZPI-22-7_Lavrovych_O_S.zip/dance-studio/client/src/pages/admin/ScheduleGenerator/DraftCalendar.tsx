import { useState, useMemo, useRef, useCallback } from 'react';
import type { DraftLesson } from '../../../types/schedule';
import type { Hall } from '../../../types';
import {
  CAL_START, CAL_H, CAL_MAX_H, SLOT_H, TIME_COL_W, HALL_COL_W,
  DAYS_UA, PX_PER_MIN, TIME_LABELS, DROP_SLOTS,
  toMin, toTime, getDayIdx, addDays, fmtDate,
  validateSlot, type SlotTarget,
} from './draftCalendar.utils';
import WarningBadge          from './WarningBadge';
import { LessonCard, UnplacedCard } from './DraftLessonCards';
import { IconInfo, IconCheck, IconResize } from '../../../components/ui/Icon';
import s from './DraftCalendar.module.css';

interface Props {
  lessons:         DraftLesson[];
  halls:           Hall[];
  weekStart:       string;
  onLessonsChange: (ls: DraftLesson[]) => void;
}

const DraftCalendar = ({ lessons, halls, weekStart, onLessonsChange }: Props) => {
  const [dragging,  setDragging]  = useState<DraftLesson | null>(null);
  const [hoverSlot, setHoverSlot] = useState<SlotTarget | null>(null);
  const [toast,     setToast]     = useState('');
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const unplaced = useMemo(() => lessons.filter(l => l.is_unplaced), [lessons]);

  const hoverValidation = useMemo(() => {
    if (!dragging || !hoverSlot) return null;
    return validateSlot(dragging, hoverSlot, lessons);
  }, [dragging, hoverSlot, lessons]);

  const showToast = (msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3000);
  };

  const handleDragStart = useCallback((e: React.DragEvent, lesson: DraftLesson) => {
    setDragging(lesson);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('lesson_id', String(lesson.id));
  }, []);

  const handleDragEnd = useCallback(() => {
    setDragging(null);
    setHoverSlot(null);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent, dayIdx: number, startMin: number, hallId: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setHoverSlot(prev =>
      prev?.dayIdx === dayIdx && prev.startMin === startMin && prev.hallId === hallId
        ? prev
        : { dayIdx, startMin, hallId }
    );
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, dayIdx: number, startMin: number, hallId: number) => {
    e.preventDefault();
    if (!dragging) return;

    const validation = validateSlot(dragging, { dayIdx, startMin, hallId }, lessons);
    if (validation.level === 'error') {
      showToast(validation.msgs[0]);
      setDragging(null);
      setHoverSlot(null);
      return;
    }

    onLessonsChange(lessons.map(l => l.id === dragging.id
      ? { ...l, hall_id: hallId, lesson_date: addDays(weekStart, dayIdx),
          start_time: toTime(startMin), end_time: toTime(startMin + dragging.duration_min),
          is_unplaced: false, unplaced_reason: null }
      : l
    ));
    setDragging(null);
    setHoverSlot(null);
  }, [dragging, lessons, weekStart, onLessonsChange]);

  const handleUnplace = useCallback((lesson: DraftLesson) => {
    onLessonsChange(lessons.map(l => l.id === lesson.id
      ? { ...l, is_unplaced: true, lesson_date: null, start_time: null, end_time: null }
      : l
    ));
  }, [lessons, onLessonsChange]);

  const lessonsByKey = useMemo(() => {
    const map: Record<string, DraftLesson[]> = {};
    for (const l of lessons) {
      if (l.is_unplaced || !l.lesson_date || !l.start_time) continue;
      const key = `${getDayIdx(l.lesson_date)}-${l.hall_id}`;
      (map[key] = map[key] || []).push(l);
    }
    return map;
  }, [lessons]);

  const cellLevel = (dayIdx: number, startMin: number, hallId: number) => {
    if (!dragging || !hoverSlot) return '';
    if (hoverSlot.dayIdx !== dayIdx || hoverSlot.startMin !== startMin || hoverSlot.hallId !== hallId) return '';
    if (hoverValidation?.level === 'error') return s.cellRed;
    if (hoverValidation?.level === 'warn')  return s.cellYellow;
    return s.cellGreen;
  };

  const totalWidth = TIME_COL_W + 7 * halls.length * HALL_COL_W;

  return (
    <div className={s.outerWrap}>
      <div className={s.sidebar}>
        <div className={s.sidebarHead}>
          <IconInfo size={12} />
          НЕРОЗМІЩЕНІ
          {unplaced.length > 0 && <span className={s.sidebarBadge}>{unplaced.length}</span>}
        </div>
        {unplaced.length === 0 ? (
          <div className={s.sidebarEmpty}>
            <span style={{ color: 'var(--lime)' }}><IconCheck size={20} strokeWidth={1.5} /></span>
            Всі заняття розміщено
          </div>
        ) : (
          <div className={s.sidebarList}>
            {unplaced.map(l => (
              <UnplacedCard key={l.id} lesson={l} onDragStart={handleDragStart} />
            ))}
          </div>
        )}
        <div className={s.sidebarHint}>
          <IconResize size={11} />
          перетягніть до розкладу
        </div>
      </div>

      <div
        className={s.calOuter}
        style={{ maxHeight: CAL_MAX_H }}
        onDragEnd={handleDragEnd}
        onDragOver={e => e.preventDefault()}
      >
        {/*  Frozen top header  */}
        <div className={s.calHead} style={{ minWidth: totalWidth }}>
          <div className={s.cornerCell} style={{ width: TIME_COL_W }} />
          {Array.from({ length: 7 }, (_, dayIdx) => (
            <div key={dayIdx} className={s.dayGroup} style={{ width: halls.length * HALL_COL_W }}>
              <div className={s.dayLabel}>
                {DAYS_UA[dayIdx]}
                <span className={s.dayDate}> {fmtDate(addDays(weekStart, dayIdx))}</span>
              </div>
              <div className={s.hallHeaders}>
                {halls.map(hall => (
                  <div key={hall.id} className={s.hallLabel} style={{ width: HALL_COL_W }}>
                    {hall.name}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Body: time col + day×hall grid */}
        <div className={s.calBody} style={{ minWidth: totalWidth }}>
          <div className={s.timeColSticky} style={{ width: TIME_COL_W }}>
            <div className={s.timeColInner} style={{ height: CAL_H }}>
              {TIME_LABELS.map((t, i) => (
                <div key={t} className={s.timeLabel} style={{ top: i * 60 * PX_PER_MIN - 7 }}>
                  {t}
                </div>
              ))}
            </div>
          </div>

          {Array.from({ length: 7 }, (_, dayIdx) => (
            <div key={dayIdx} className={s.dayCol}>
              {halls.map(hall => {
                const dayLessons = lessonsByKey[`${dayIdx}-${hall.id}`] || [];
                return (
                  <div key={hall.id} className={s.hallCol} style={{ width: HALL_COL_W, height: CAL_H }}>
                    {DROP_SLOTS.map(startMin => {
                      const lvl = cellLevel(dayIdx, startMin, hall.id);
                      return (
                        <div
                          key={startMin}
                          className={`${s.cell} ${lvl}`}
                          style={{ top: (startMin - CAL_START) * PX_PER_MIN, height: SLOT_H }}
                          onDragOver={e => handleDragOver(e, dayIdx, startMin, hall.id)}
                          onDrop={e => handleDrop(e, dayIdx, startMin, hall.id)}
                        >
                          {!!lvl && dragging && (
                            <div
                              className={`${s.dropGhost} ${lvl === s.cellRed ? s.ghostRed : lvl === s.cellYellow ? s.ghostYellow : s.ghostGreen}`}
                              style={{ height: dragging.duration_min * PX_PER_MIN }}
                            >
                              <div className={s.ghostName}>{dragging.group_name}</div>
                              <div className={s.ghostTime}>
                                {toTime(startMin)}–{toTime(startMin + dragging.duration_min)}
                              </div>
                              {hoverValidation?.msgs[0] && (
                                <div className={s.ghostMsg}>{hoverValidation.msgs[0]}</div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {dayLessons.map(lesson => {
                      const top    = (toMin(lesson.start_time!) - CAL_START) * PX_PER_MIN;
                      const height = lesson.duration_min * PX_PER_MIN;
                      return (
                        <div
                          key={lesson.id}
                          className={s.cardWrap}
                          style={{ top, height }}
                          onDoubleClick={() => handleUnplace(lesson)}
                          title="2× клік — повернути до нерозміщених"
                        >
                          <LessonCard
                            lesson={lesson}
                            isDragging={dragging?.id === lesson.id}
                            onDragStart={handleDragStart}
                          />
                          {lesson.warnings.length > 0 && (
                            <WarningBadge warnings={lesson.warnings} />
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {toast && <div className={s.toast}>{toast}</div>}
    </div>
  );
};

export default DraftCalendar;
