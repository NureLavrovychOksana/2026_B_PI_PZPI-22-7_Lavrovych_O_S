import type { DraftLesson } from '../../../types/schedule';

export const CAL_START  = 8 * 60;
export const CAL_END    = 22 * 60;
export const PX_PER_MIN = 1.0;
export const SLOT_MIN   = 30;
export const CAL_H      = (CAL_END - CAL_START) * PX_PER_MIN;
export const SLOT_H     = SLOT_MIN * PX_PER_MIN;
export const TIME_COL_W = 46;
export const HALL_COL_W = 110;
export const CAL_MAX_H  = 540;

export const DAYS_UA = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];

export const toMin  = (t: string) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
export const toTime = (m: number) =>
  `${String(Math.floor(m / 60)).padStart(2,'0')}:${String(m % 60).padStart(2,'0')}`;

export const getDayIdx = (dateStr: string) => {
  const [y, m, d] = dateStr.slice(0, 10).split('-').map(Number);
  const day = new Date(y, m - 1, d).getDay();
  return day === 0 ? 6 : day - 1;
};

export const addDays = (base: string, n: number) => {
  const [y, m, d] = base.split('-').map(Number);
  const date = new Date(y, m - 1, d + n);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
};

export const fmtDate = (iso: string) => {
  const [, m, d] = iso.split('-');
  return `${d}.${m}`;
};

export const TIME_LABELS = Array.from(
  { length: (CAL_END - CAL_START) / 60 + 1 },
  (_, i) => toTime(CAL_START + i * 60)
);

export const DROP_SLOTS = Array.from(
  { length: (CAL_END - CAL_START) / SLOT_MIN },
  (_, i) => CAL_START + i * SLOT_MIN
);

export const WARNING_ICONS: Record<string, string> = {
  timing:           '⏰',
  teacher_gap:      '⏸',
  day_spread:       '📅',
  hall_utilization: '🏛',
  hall_capacity:    '🏛',
  hall_gap:         '⚡',
  day_center:       '📍',
  day_pattern:      '🔄',
  day_popularity:   '📊',
};

export interface SlotTarget { dayIdx: number; startMin: number; hallId: number; }

export const validateSlot = (
  dragged: DraftLesson,
  target: SlotTarget,
  allLessons: DraftLesson[]
): { level: 'ok' | 'warn' | 'error'; msgs: string[] } => {
  const endMin = target.startMin + dragged.duration_min;
  const hardMsgs: string[] = [];

  for (const other of allLessons) {
    if (other.id === dragged.id || other.is_unplaced || !other.lesson_date || !other.start_time) continue;
    const otherDay = getDayIdx(other.lesson_date);
    if (otherDay !== target.dayIdx) continue;
    const oS = toMin(other.start_time), oE = toMin(other.end_time!);
    if (target.startMin >= oE || endMin <= oS) continue;
    if (other.hall_id === target.hallId)      hardMsgs.push(`Зал зайнятий: ${other.group_name}`);
    if (other.teacher_id === dragged.teacher_id) hardMsgs.push(`Викладач веде: ${other.group_name}`);
  }
  if (allLessons.find(o =>
    o.id !== dragged.id && !o.is_unplaced && o.lesson_date &&
    o.group_id === dragged.group_id && getDayIdx(o.lesson_date) === target.dayIdx
  )) hardMsgs.push('Група вже має заняття цього дня');

  if (hardMsgs.length) return { level: 'error', msgs: hardMsgs };

  const softMsgs: string[] = [];
  for (const tl of allLessons.filter(o =>
    o.id !== dragged.id && !o.is_unplaced && o.lesson_date &&
    o.teacher_id === dragged.teacher_id && getDayIdx(o.lesson_date) === target.dayIdx
  )) {
    const tlS = toMin(tl.start_time!), tlE = toMin(tl.end_time!);
    const gap = Math.max(0, target.startMin > tlE ? target.startMin - tlE : tlS - endMin);
    if (gap > 60 && gap < 480) softMsgs.push(`Простій ${(gap / 60).toFixed(1)} год між заняттями`);
  }
  return softMsgs.length ? { level: 'warn', msgs: softMsgs } : { level: 'ok', msgs: [] };
};
