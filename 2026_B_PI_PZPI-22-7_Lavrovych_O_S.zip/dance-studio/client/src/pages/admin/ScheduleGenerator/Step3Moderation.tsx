import { useEffect, useState } from 'react';
import { getHalls } from '../../../api/halls';
import { publishSchedule, getWeekStatus } from '../../../api/schedule';
import DraftCalendar from './DraftCalendar';
import type { DraftLesson, WeekStatus } from '../../../types/schedule';
import type { Hall } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './Step3Moderation.module.css';

interface Props {
  initialLessons: DraftLesson[];
  hallIds:        number[];
  weekStart:      string;
  onPublished:    () => void;
  onDiscard:      () => void;
}

const Step3Moderation = ({ initialLessons, hallIds, weekStart, onPublished, onDiscard }: Props) => {
  const [lessons,    setLessons]    = useState<DraftLesson[]>(initialLessons);
  const [halls,      setHalls]      = useState<Hall[]>([]);
  const [publishing, setPublishing] = useState(false);
  const [weekStatus, setWeekStatus] = useState<WeekStatus | null>(null);
  const [showModal,  setShowModal]  = useState(false);

  useEffect(() => {
    getHalls().then(all => setHalls(hallIds.length ? all.filter(h => hallIds.includes(h.id)) : all));
  }, [hallIds]);

  const placed   = lessons.filter(l => !l.is_unplaced);
  const unplaced = lessons.filter(l => l.is_unplaced);
  const warnings = placed.filter(l => l.warnings.length > 0);

  const doPublish = async (mode: 'append' | 'overwrite') => {
    setShowModal(false);
    setPublishing(true);
    try {
      const result = await publishSchedule(lessons, mode, weekStart);
      if (!result.published) {
        alert('Жодного заняття не збережено — перевірте що є розміщені картки');
        return;
      }
      onPublished();
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Помилка публікації');
    } finally {
      setPublishing(false);
    }
  };

  const handlePublish = async () => {
    if (placed.length === 0) return;
    const status = await getWeekStatus(weekStart);
    if (status.has_lessons) {
      setWeekStatus(status);
      setShowModal(true);
    } else {
      if (!confirm(`Опублікувати ${placed.length} занять до основного розкладу?`)) return;
      doPublish('append');
    }
  };

  return (
    <div className={s.wrap}>

      {/* ── Header ──────────────────────────────────────────── */}
      <div className={s.header}>
        <div className={s.headerInfo}>
          <div className={s.draftName}>Модерація розкладу</div>
          <div className={s.statsRow}>
            <span className={s.statGreen}>{placed.length} розміщено</span>
            {unplaced.length > 0 && <span className={s.statRed}>{unplaced.length} не розміщено</span>}
            {warnings.length > 0 && <span className={s.statYellow}>{warnings.length} попереджень</span>}
          </div>
        </div>
        <div className={s.headerActions}>
          <button className={a.btnSecondary} onClick={onDiscard}>
            ✕ Відхилити
          </button>
          <button
            className={a.btnPrimary}
            onClick={handlePublish}
            disabled={publishing || placed.length === 0}
          >
            {publishing ? 'Публікація…' : `↗ Опублікувати (${placed.length})`}
          </button>
        </div>
      </div>

      {/* ── Legend ──────────────────────────────────────────── */}
      <div className={s.legend}>
        <div className={s.legendItem}><div className={s.dotGreen} />Відмінно (score ≥80)</div>
        <div className={s.legendItem}><div className={s.dotYellow} />М'яке попередження</div>
        <div className={s.legendItem}><div className={s.dotRed} />Не розміщено</div>
      </div>

      {/* ── Calendar ────────────────────────────────────────── */}
      {halls.length > 0 ? (
        <DraftCalendar
          lessons={lessons}
          halls={halls}
          weekStart={weekStart}
          onLessonsChange={setLessons}
        />
      ) : (
        <div style={{ textAlign: 'center', padding: '40px', color: 'var(--graphite)' }}>
          Завантаження залів…
        </div>
      )}

      {/* ── Overwrite modal ─────────────────────────────────── */}
      {showModal && weekStatus && (
        <div className={s.modalOverlay} onClick={() => setShowModal(false)}>
          <div className={s.modal} onClick={e => e.stopPropagation()}>
            <div className={s.modalTitle}>На тижні вже є заняття</div>
            <div className={s.modalDesc}>
              Знайдено <strong>{weekStatus.lesson_count}</strong> занять
              {weekStatus.enrolled_lessons > 0 && (
                <>, з них <strong>{weekStatus.enrolled_lessons}</strong> мають записи студентів</>
              )}.
              Оберіть спосіб публікації:
            </div>
            <div className={s.modalActions}>
              <button className={s.modalBtnAppend} onClick={() => doPublish('append')}>
                <span className={s.modalBtnTitle}>Доповнити порожні слоти</span>
                <span className={s.modalBtnSub}>Будуть додані лише заняття без конфліктів по залу.</span>
              </button>
              <button
                className={s.modalBtnOverwrite}
                onClick={() => doPublish('overwrite')}
              >
                <span className={s.modalBtnTitle}>Перезаписати розклад повністю</span>
                <span className={s.modalBtnSub}>
                  {weekStatus.enrolled_lessons > 0
                    ? `${weekStatus.enrolled_lessons} занять із записами буде збережено, решта замінена.`
                    : 'Всі заняття тижня будуть видалені та замінені новим розкладом.'}
                </span>
              </button>
            </div>
            <button className={s.modalCancel} onClick={() => setShowModal(false)}>Скасувати</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Step3Moderation;
