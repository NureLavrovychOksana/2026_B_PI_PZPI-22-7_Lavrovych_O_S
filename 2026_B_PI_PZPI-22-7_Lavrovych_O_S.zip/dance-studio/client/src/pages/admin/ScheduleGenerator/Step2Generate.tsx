import { useEffect, useState } from 'react';
import { generateDraft } from '../../../api/schedule';
import type { WizardConfig, DraftLesson } from '../../../types/schedule';
import a from '../../../styles/admin.module.css';
import s from './Step2Generate.module.css';

interface Props {
  config:  WizardConfig;
  onBack:  () => void;
  onNext:  (lessons: DraftLesson[]) => void;
}

type Status = 'idle' | 'loading' | 'done' | 'error';

const Step2Generate = ({ config, onBack, onNext }: Props) => {
  const [status,  setStatus]  = useState<Status>('idle');
  const [lessons, setLessons] = useState<DraftLesson[]>([]);
  const [stats,   setStats]   = useState<{ total: number; placed: number; unplaced: number; warnings: number } | null>(null);
  const [error,   setError]   = useState('');

  const run = async () => {
    setStatus('loading');
    setError('');
    try {
      const result = await generateDraft(config);
      setLessons(result.lessons);
      setStats(result.stats);
      setStatus('done');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Помилка генерації';
      setError(msg);
      setStatus('error');
    }
  };

  useEffect(() => { run(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const totalGroups = config.group_requirements.length;
  const totalLessons = config.group_requirements.reduce((s, r) => s + r.lessons_per_week, 0);

  return (
    <div className={s.wrap}>

      <div className={s.card}>
        <div className={s.cardTitle}>ПАРАМЕТРИ ГЕНЕРАЦІЇ</div>
        <div className={s.paramGrid}>
          <span className={s.paramLabel}>Тиждень</span>
          <span className={s.paramVal}>{config.week_start}</span>
          <span className={s.paramLabel}>Груп</span>
          <span className={s.paramVal}>{totalGroups}</span>
          <span className={s.paramLabel}>Занять до розміщення</span>
          <span className={s.paramVal}>{totalLessons}</span>
          <span className={s.paramLabel}>Зали</span>
          <span className={s.paramVal}>{config.hall_ids.length}</span>
          <span className={s.paramLabel}>Час</span>
          <span className={s.paramVal}>{config.time_from} – {config.time_to}</span>
        </div>
      </div>

      {status === 'loading' && (
        <div className={s.card}>
          <div className={s.spinner}>
            <div className={s.spinnerRing} />
          </div>
          <div className={s.loadingTitle}>Генерація чорновика…</div>
        </div>
      )}

      {status === 'done' && stats && (
        <div className={s.card}>
          <div className={s.resultTitle}>✓ Чорновик успішно згенеровано</div>
          <div className={s.statsRow}>
            <div className={s.statItem}>
              <div className={s.statNum} style={{ color: 'var(--lime)' }}>{stats.placed}</div>
              <div className={s.statLabel}>РОЗМІЩЕНО</div>
            </div>
            <div className={s.statSep} />
            <div className={s.statItem}>
              <div className={s.statNum} style={{ color: stats.unplaced > 0 ? 'var(--error)' : 'var(--graphite)' }}>
                {stats.unplaced}
              </div>
              <div className={s.statLabel}>НЕ РОЗМІЩЕНО</div>
            </div>
            <div className={s.statSep} />
            <div className={s.statItem}>
              <div className={s.statNum} style={{ color: stats.warnings > 0 ? 'var(--warn)' : 'var(--graphite)' }}>
                {stats.warnings}
              </div>
              <div className={s.statLabel}>ПОПЕРЕДЖЕНЬ</div>
            </div>
          </div>
        </div>
      )}

      {status === 'error' && (
        <div className={s.card}>
          <div className={s.errorTitle}>✕ Помилка генерації</div>
          <div className={s.errorMsg}>{error}</div>
        </div>
      )}

      <div className={s.actions}>
        <button className={a.btnSecondary} onClick={onBack}>
          ← Назад
        </button>
        {status === 'done' && lessons.length > 0 && (
          <button className={a.btnPrimary} onClick={() => onNext(lessons)}>
            Перейти до модерації →
          </button>
        )}
        {status === 'error' && (
          <button className={a.btnPrimary} onClick={run}>
            Спробувати знову
          </button>
        )}
      </div>
    </div>
  );
};

export default Step2Generate;
