import type { DraftLesson } from '../../../types/schedule';
import s from './DraftCalendar.module.css';

export const LessonCard = ({
  lesson, isDragging, onDragStart,
}: {
  lesson: DraftLesson;
  isDragging: boolean;
  onDragStart: (e: React.DragEvent, l: DraftLesson) => void;
}) => {
  const colorCls = lesson.is_unplaced ? s.cardRed
    : lesson.warnings.length > 0     ? s.cardYellow
    : lesson.score >= 80              ? s.cardGreen
    :                                   s.cardYellow;

  return (
    <div
      className={`${s.card} ${colorCls} ${isDragging ? s.cardDragging : ''}`}
      draggable
      onDragStart={e => onDragStart(e, lesson)}
    >
      <div className={s.cardName}>{lesson.group_name}</div>
      <div className={s.cardMeta}>{lesson.style_name}</div>
      {lesson.start_time && (
        <div className={s.cardTime}>{lesson.start_time}–{lesson.end_time}</div>
      )}
    </div>
  );
};

export const UnplacedCard = ({ lesson, onDragStart }: {
  lesson: DraftLesson;
  onDragStart: (e: React.DragEvent, l: DraftLesson) => void;
}) => (
  <div className={s.unplacedCard} draggable onDragStart={e => onDragStart(e, lesson)}>
    <div className={s.unplacedName}>{lesson.group_name}</div>
    <div className={s.unplacedMeta}>{lesson.style_name} · {lesson.duration_min} хв</div>
    {lesson.unplaced_reason && (
      <div className={s.unplacedReason}>{lesson.unplaced_reason}</div>
    )}
  </div>
);
