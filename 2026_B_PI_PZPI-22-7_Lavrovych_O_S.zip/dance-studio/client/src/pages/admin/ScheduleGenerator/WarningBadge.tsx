import { useState } from 'react';
import type { ConstraintWarning } from '../../../types/schedule';
import { WARNING_ICONS } from './draftCalendar.utils';
import s from './DraftCalendar.module.css';

const WarningBadge = ({ warnings }: { warnings: ConstraintWarning[] }) => {
  const [open, setOpen] = useState(false);
  if (!warnings.length) return null;
  return (
    <div className={s.warnBadgeWrap} onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <div className={s.warnBadge}>
        <svg width="8" height="8" viewBox="0 0 24 24" fill="var(--warn)" stroke="none">
          <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
        </svg>
        {warnings.length}
      </div>
      {open && (
        <div className={s.warnTooltip}>
          {warnings.map((w, i) => (
            <div key={i} className={s.warnRow}>
              <span className={s.warnIcon}>{WARNING_ICONS[w.type] || '●'}</span>
              <span>{w.msg}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WarningBadge;
