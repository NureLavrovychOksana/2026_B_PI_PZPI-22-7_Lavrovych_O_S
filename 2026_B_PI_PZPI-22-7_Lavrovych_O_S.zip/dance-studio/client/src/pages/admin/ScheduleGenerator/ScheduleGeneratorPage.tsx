import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageHeader from '../../../components/ui/display/PageHeader';
import Step1Setup from './Step1Setup';
import Step2Generate from './Step2Generate';
import Step3Moderation from './Step3Moderation';
import { IconCheck } from '../../../components/ui/Icon';
import type { WizardConfig, DraftLesson } from '../../../types/schedule';
import s from './ScheduleGeneratorPage.module.css';

const STEPS = ['Налаштування', 'Генерація', 'Модерація'];

const ScheduleGeneratorPage = () => {
  const navigate = useNavigate();
  const [step,    setStep]    = useState<1 | 2 | 3>(1);
  const [config,  setConfig]  = useState<WizardConfig | null>(null);
  const [lessons, setLessons] = useState<DraftLesson[]>([]);

  const reset = () => { setStep(1); setConfig(null); setLessons([]); };

  return (
    <div className={s.page}>
      <PageHeader title="Автогенерація розкладу" />

      {/* ── Progress bar ──────────────────────────────────── */}
      <div className={s.progress}>
        {STEPS.map((label, i) => {
          const n = i + 1;
          const active = step === n;
          const done   = step > n;
          return (
            <div key={n} className={s.progressItem}>
              <div className={`${s.progressDot} ${active ? s.dotActive : done ? s.dotDone : ''}`}>
                {done ? <IconCheckStep /> : n}
              </div>
              <div className={`${s.progressLabel} ${active ? s.labelActive : ''}`}>{label}</div>
              {i < STEPS.length - 1 && <div className={`${s.progressLine} ${done ? s.lineDone : ''}`} />}
            </div>
          );
        })}
      </div>

      {/* ── Steps ─────────────────────────────────────────── */}
      {step === 1 && (
        <Step1Setup onNext={cfg => { setConfig(cfg); setStep(2); }} />
      )}
      {step === 2 && config && (
        <Step2Generate
          config={config}
          onBack={() => setStep(1)}
          onNext={ls => { setLessons(ls); setStep(3); }}
        />
      )}
      {step === 3 && (
        <Step3Moderation
          initialLessons={lessons}
          hallIds={config!.hall_ids}
          weekStart={config!.week_start}
          onPublished={() => navigate(`/admin/schedule?week=${config!.week_start}`)}
          onDiscard={reset}
        />
      )}
    </div>
  );
};

const IconCheckStep = () => <IconCheck size={12} strokeWidth={3} />;

export default ScheduleGeneratorPage;
