import { useEffect, useState } from 'react';
import { getGroupRequirements, getWeekStatus } from '../../../api/schedule';
import { getHalls } from '../../../api/halls';
import type { WeekStatus } from '../../../types/schedule';
import Spinner from '../../../components/ui/feedback/Spinner';
import type { GroupRequirement, WizardConfig } from '../../../types/schedule';
import type { Hall } from '../../../types';
import WeekPicker, { fmtWeekLabel, isoDate, getMondayOfWeek } from './WeekPicker';
import { IconCalendar, IconList, IconTable, IconClock, IconAlertTriangle } from '../../../components/ui/Icon';
import a from '../../../styles/admin.module.css';
import s from './Step1Setup.module.css';

const IcoCalendar = () => <IconCalendar size={14} strokeWidth={1.8} />;
const IcoList     = () => <IconList size={14} strokeWidth={1.8} />;
const IcoBuilding = () => <IconTable size={14} strokeWidth={1.8} />;
const IcoClock    = () => <IconClock size={14} strokeWidth={1.8} />;

const nextMonday = () => {
  const mon = getMondayOfWeek();
  mon.setDate(mon.getDate() + 7);
  return isoDate(mon);
};

const DAYS_UA = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];

const SectionTitle = ({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) => (
  <div className={s.sectionTitle}>
    <span className={s.sectionIcon}>{icon}</span>
    {children}
  </div>
);

interface Props { onNext: (config: WizardConfig) => void; }

const Step1Setup = ({ onNext }: Props) => {
  const [loading, setLoading]   = useState(true);
  const [reqs, setReqs]         = useState<GroupRequirement[]>([]);
  const [halls, setHalls]       = useState<Hall[]>([]);
  const [selectedGroups, setSelectedGroups] = useState<Set<number>>(new Set());
  const [selectedHalls,  setSelectedHalls]  = useState<Set<number>>(new Set());
  const [allowedDays,    setAllowedDays]    = useState<Set<number>>(new Set([0,1,2,3,4]));
  const [weekStart,  setWeekStart]  = useState(nextMonday);
  const [timeFrom,   setTimeFrom]   = useState('09:00');
  const [timeTo,     setTimeTo]     = useState('21:00');
  const [weekStatus, setWeekStatus] = useState<WeekStatus | null>(null);
  const [lpwOverride, setLpwOverride] = useState<Record<number, number>>({});

  useEffect(() => {
    Promise.all([getGroupRequirements(), getHalls()])
      .then(([r, h]) => {
        setReqs(r);
        setSelectedGroups(new Set(r.map(gr => gr.group_id)));
        setHalls(h);
        setSelectedHalls(new Set(h.map(hall => hall.id)));
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    setWeekStatus(null);
    getWeekStatus(weekStart).then(setWeekStatus).catch(() => {});
  }, [weekStart]);

  const toggleGroup = (id: number) =>
    setSelectedGroups(prev => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; });

  const toggleHall = (id: number) =>
    setSelectedHalls(prev => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; });

  const toggleDay = (d: number) =>
    setAllowedDays(prev => { const next = new Set(prev); next.has(d) ? next.delete(d) : next.add(d); return next; });

  const getLpw = (req: GroupRequirement) => lpwOverride[req.group_id] ?? req.lessons_per_week;

  const handleNext = () => {
    const selected = reqs
      .filter(r => selectedGroups.has(r.group_id))
      .map(r => ({ ...r, lessons_per_week: getLpw(r) }));
    if (!selected.length)    { alert('Оберіть хоча б одну групу'); return; }
    if (!selectedHalls.size) { alert('Оберіть хоча б один зал');   return; }
    if (!allowedDays.size)   { alert('Оберіть хоча б один день');  return; }
    onNext({
      week_start:         weekStart,
      group_requirements: selected,
      hall_ids:           [...selectedHalls],
      allowed_days:       [...allowedDays].sort(),
      time_from:          timeFrom,
      time_to:            timeTo,
      slot_step:          30,
    });
  };

  if (loading) return <Spinner centered />;

  return (
    <div className={s.wrap}>

      {/* ── Period ── */}
      <div className={s.section}>
        <SectionTitle icon={<IcoCalendar />}>Тиждень генерації</SectionTitle>
        <WeekPicker value={weekStart} onChange={setWeekStart} />
        <div className={s.weekSelected_label}>
          Обраний тиждень: <strong>{fmtWeekLabel(weekStart)}</strong>
        </div>
        {weekStatus?.has_lessons && (
          <div className={s.weekWarning}>
            <IconAlertTriangle size={14} />
            На цьому тижні вже є <strong>{weekStatus.lesson_count}</strong> занять
            {weekStatus.enrolled_lessons > 0 && <> (з них <strong>{weekStatus.enrolled_lessons}</strong> мають записи)</>}.
            При публікації буде запропоновано вибір: доповнити або замінити.
          </div>
        )}
      </div>

      {/* ── Groups ── */}
      <div className={s.section}>
        <div className={s.sectionHead}>
          <SectionTitle icon={<IcoList />}>Групи до розкладу</SectionTitle>
          <div className={s.badge}>{selectedGroups.size} / {reqs.length} обрано</div>
          <button className={s.selectAll} onClick={() => setSelectedGroups(new Set(reqs.map(r => r.group_id)))}>Всі</button>
          <button className={s.selectAll} onClick={() => setSelectedGroups(new Set())}>Жодної</button>
        </div>
        <div className={s.groupList}>
          {reqs.map(req => {
            const isSelected = selectedGroups.has(req.group_id);
            const lpw = getLpw(req);
            return (
              <div key={req.group_id} className={`${s.groupRow} ${isSelected ? s.groupSelected : s.groupDisabled}`}>
                <input type="checkbox" className={s.checkbox} checked={isSelected} onChange={() => toggleGroup(req.group_id)} />
                <div className={s.groupInfo}>
                  <span className={s.groupName}>{req.group_name}</span>
                  <span className={s.groupMeta}>{req.style_name} · {req.teacher_name}</span>
                </div>
                <div className={s.groupTags}>
                  <span className={s.tag}>{req.lesson_duration} хв</span>
                  {req.is_children && <span className={`${s.tag} ${s.tagChildren}`}>дитяча</span>}
                </div>
                <div className={s.lpwControl}>
                  <button className={s.lpwBtn}
                    onClick={() => setLpwOverride(p => ({ ...p, [req.group_id]: Math.max(1, lpw - 1) }))}
                    disabled={lpw <= 1}>−</button>
                  <span className={s.lpwVal}>{lpw}×/тиж</span>
                  <button className={s.lpwBtn}
                    onClick={() => setLpwOverride(p => ({ ...p, [req.group_id]: Math.min(7, lpw + 1) }))}
                    disabled={lpw >= 7}>+</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Halls ── */}
      <div className={s.section}>
        <SectionTitle icon={<IcoBuilding />}>Зали</SectionTitle>
        <div className={s.hallList}>
          {halls.map(hall => (
            <label key={hall.id} className={`${s.hallChip} ${selectedHalls.has(hall.id) ? s.hallSelected : ''}`}>
              <input type="checkbox" checked={selectedHalls.has(hall.id)} onChange={() => toggleHall(hall.id)} style={{ display: 'none' }} />
              <span>{hall.name}</span>
              <span className={s.hallCap}>ємн. {hall.capacity}</span>
            </label>
          ))}
        </div>
      </div>

      {/* ── Days + Time ── */}
      <div className={s.section}>
        <SectionTitle icon={<IcoClock />}>Дні та час</SectionTitle>
        <div className={s.twoCol}>
          <div>
            <div className={s.fieldLabel}>Дні генерації</div>
            <div className={s.daysList}>
              {DAYS_UA.map((label, i) => (
                <label key={i} className={`${s.dayChip} ${allowedDays.has(i) ? s.daySelected : ''}`}>
                  <input type="checkbox" checked={allowedDays.has(i)} onChange={() => toggleDay(i)} style={{ display: 'none' }} />
                  {label}
                </label>
              ))}
            </div>
          </div>
          <div className={s.timeRow}>
            <div><div className={s.fieldLabel}>З</div>
              <input type="time" className={s.input} value={timeFrom} onChange={e => setTimeFrom(e.target.value)} />
            </div>
            <div className={s.timeDash}>—</div>
            <div><div className={s.fieldLabel}>До</div>
              <input type="time" className={s.input} value={timeTo} onChange={e => setTimeTo(e.target.value)} />
            </div>
          </div>
        </div>
      </div>

      {/* ── Actions ── */}
      <div className={s.actions}>
        <span className={s.hint}>
          {reqs.filter(r => selectedGroups.has(r.group_id)).reduce((sum, r) => sum + r.lessons_per_week, 0)} занять до розміщення
        </span>
        <button className={`${a.btnPrimary} ${s.btnNext}`} onClick={handleNext}>
          Згенерувати чорновик →
        </button>
      </div>
    </div>
  );
};

export default Step1Setup;
