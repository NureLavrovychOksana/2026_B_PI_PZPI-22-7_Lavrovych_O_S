import { useState, useMemo } from 'react';
import { IconChevronLeft, IconChevronRight } from '../../../components/ui/Icon';
import s from './Step1Setup.module.css';

const getMondayOfWeek = (d = new Date()) => {
  const day = d.getDay();
  const mon = new Date(d);
  mon.setDate(d.getDate() - day + (day === 0 ? -6 : 1));
  mon.setHours(0, 0, 0, 0);
  return mon;
};

// toISOString() converts to UTC and shifts day in UTC+2/+3 — use local components
const isoDate = (d: Date) => {
  const y  = d.getFullYear();
  const m  = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${dd}`;
};

const fmtWeekLabel = (monStr: string) => {
  const mon = new Date(monStr);
  const sun = new Date(mon);
  sun.setDate(mon.getDate() + 6);
  const f = (d: Date) =>
    `${String(d.getDate()).padStart(2,'0')}.${String(d.getMonth()+1).padStart(2,'0')}`;
  return `${f(mon)} — ${f(sun)}`;
};

const IcoChevronLeft  = () => <IconChevronLeft size={14} />;
const IcoChevronRight = () => <IconChevronRight size={14} />;

interface Props { value: string; onChange: (v: string) => void; }

const WeekPicker = ({ value, onChange }: Props) => {
  const [offset, setOffset] = useState(0);

  const weeks = useMemo(() => {
    const thisMonday = getMondayOfWeek();
    return Array.from({ length: 10 }, (_, i) => {
      const mon = new Date(thisMonday);
      mon.setDate(thisMonday.getDate() + i * 7);
      const str = isoDate(mon);
      return { value: str, label: fmtWeekLabel(str), isPast: i === 0 };
    });
  }, []);

  const visible = weeks.slice(offset, offset + 4);

  return (
    <div className={s.weekPicker}>
      <button
        className={s.weekNav}
        onClick={() => setOffset(o => o - 1)}
        disabled={offset === 0}
      >
        <IcoChevronLeft />
      </button>
      <div className={s.weekList}>
        {visible.map(w => (
          <button
            key={w.value}
            className={`${s.weekOption} ${value === w.value ? s.weekSelected : ''} ${w.isPast ? s.weekCurrent : ''}`}
            onClick={() => onChange(w.value)}
          >
            <span className={s.weekLabel}>{w.label}</span>
            {w.isPast && <span className={s.weekTag}>поточний</span>}
          </button>
        ))}
      </div>
      <button
        className={s.weekNav}
        onClick={() => setOffset(o => o + 1)}
        disabled={offset + 4 >= weeks.length}
      >
        <IcoChevronRight />
      </button>
    </div>
  );
};

export { fmtWeekLabel, isoDate, getMondayOfWeek };
export default WeekPicker;
