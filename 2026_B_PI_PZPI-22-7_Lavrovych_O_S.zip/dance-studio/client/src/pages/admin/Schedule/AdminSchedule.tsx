import { useEffect, useState, useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { localToday } from '../../../utils/dateUtils';
import { getLessons, createLesson, updateLesson, deleteLesson } from '../../../api/lessons';
import { getGroups }   from '../../../api/groups';
import { getHalls }    from '../../../api/halls';
import PageHeader      from '../../../components/ui/display/PageHeader';
import ConfirmModal    from '../../../components/ui/overlay/ConfirmModal';
import Toast           from '../../../components/ui/feedback/Toast';
import Spinner         from '../../../components/ui/feedback/Spinner';
import LessonModal     from './LessonModal';
import ScheduleWeekGrid, {
  getMondayOfWeek,
  getWeekDates,
  formatWeekLabel,
} from '../../../components/schedule/ScheduleWeekGrid';
import AgendaView       from '../../../components/schedule/AgendaView';
import { ViewToggleBtn, DayPicker } from '../../../components/schedule/ViewToggle';
import type { ViewMode } from '../../../components/schedule/ViewToggle';
import useIsMobile      from '../../../hooks/useIsMobile';
import type { LessonFormData } from './LessonModal';
import { useToast }    from '../../../hooks/useToast';
import { IconChevronRight, IconPlus } from '../../../components/ui/Icon';
import type { Lesson, DanceGroup, Hall } from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './AdminSchedule.module.css';

const AdminSchedule = () => {
  const [searchParams] = useSearchParams();
  const isMobile = useIsMobile();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [groups, setGroups]   = useState<DanceGroup[]>([]);
  const [halls, setHalls]     = useState<Hall[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving]   = useState(false);
  const [week, setWeek]       = useState(searchParams.get('week') ?? getMondayOfWeek());
  const [viewMode, setViewMode]   = useState<ViewMode>('grid');
  const [activeDay, setActiveDay] = useState<number | null>(null);
  const [filterGroup, setFilterGroup] = useState('');
  const [modalLesson, setModalLesson] = useState<Lesson | null | undefined>(undefined);
  const [modalDate, setModalDate]     = useState('');
  const [deleteTarget, setDeleteTarget] = useState<Lesson | null>(null);
  const [conflicts, setConflicts]     = useState<any[]>([]);
  const { toasts, showToast, removeToast } = useToast();

  useEffect(() => { if (isMobile) setViewMode('agenda'); }, [isMobile]);

  const loadLessons = useCallback(() => {
    setLoading(true);
    getLessons({ week }).then(setLessons).finally(() => setLoading(false));
  }, [week]);

  useEffect(() => {
    Promise.all([getGroups(), getHalls()])
      .then(([g, h]) => { setGroups(g); setHalls(h); });
  }, []);

  useEffect(() => { loadLessons(); }, [loadLessons]);

  const today     = localToday();
  const weekDates = useMemo(() => getWeekDates(week), [week]);

  const shiftWeek = (dir: 1 | -1) => {
    const [y, m, d] = week.split('-').map(Number);
    const date = new Date(y, m - 1, d + dir * 7);
    setWeek(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`);
  };

  const filtered = useMemo(
    () => filterGroup ? lessons.filter(l => String(l.group_id) === filterGroup) : lessons,
    [lessons, filterGroup],
  );

  const handleSave = async (form: LessonFormData) => {
    setSaving(true);
    setConflicts([]);
    try {
      if (modalLesson) {
        await updateLesson(modalLesson.id, {
          group_id: Number(form.group_id), hall_id: Number(form.hall_id),
          lesson_date: form.lesson_date, start_time: form.start_time, end_time: form.end_time,
        });
        showToast('Заняття оновлено', 'success');
      } else {
        await createLesson({
          group_id: Number(form.group_id), hall_id: Number(form.hall_id),
          lesson_date: form.lesson_date, start_time: form.start_time, end_time: form.end_time,
        });
        showToast('Заняття створено', 'success');
      }
      setModalLesson(undefined);
      loadLessons();
    } catch (err: any) {
      if (err.response?.status === 409 && err.response?.data?.conflicts) {
        setConflicts(err.response.data.conflicts);
      } else {
        showToast(err.response?.data?.message || 'Помилка', 'error');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      await deleteLesson(deleteTarget.id);
      showToast('Заняття видалено', 'success');
      setDeleteTarget(null);
      setModalLesson(undefined);
      loadLessons();
    } catch {
      showToast('Помилка видалення', 'error');
    } finally {
      setSaving(false);
    }
  };

  const renderCard = (lesson: Lesson, mode?: 'agenda') => {
    if (mode === 'agenda') {
      return (
        <div className={s.agendaRow} onClick={() => { setModalLesson(lesson); setConflicts([]); }}>
          <div className={s.agendaTime}>
            <span className={s.agendaTimeStart}>{lesson.start_time.slice(0,5)}</span>
            <span className={s.agendaTimeEnd}>{lesson.end_time.slice(0,5)}</span>
          </div>
          <div className={s.agendaInfo}>
            <span className={s.agendaStyle}>{lesson.style_name}</span>
            <span className={s.agendaGroup}>{lesson.group_name}</span>
            <span className={s.agendaLevel}>{LEVEL_LABELS[lesson.group_level]}</span>
          </div>
          {lesson.hall_name && <span className={s.agendaHall}>{lesson.hall_name}</span>}
          <IconChevronRight className={s.agendaChevron} size={16} strokeWidth={1.8} />
        </div>
      );
    }
    return (
      <div className={s.lessonCell} onClick={() => { setModalLesson(lesson); setConflicts([]); }}>
        <span className={s.lessonStyle}>{lesson.style_name}</span>
        <span className={s.lessonLevel}>{LEVEL_LABELS[lesson.group_level]}</span>
        <span className={s.lessonHall}>{lesson.hall_name}</span>
        <span className={s.lessonTime}>{lesson.start_time.slice(0,5)}–{lesson.end_time.slice(0,5)}</span>
      </div>
    );
  };

  return (
    <div>
      <PageHeader
        title="Розклад"
        sub={formatWeekLabel(week)}
        actions={
          <button className={a.addBtn} onClick={() => { setModalDate(today); setModalLesson(null); setConflicts([]); }}>
            <IconPlus size={14} strokeWidth={1.8} />
            Додати заняття
          </button>
        }
      />

      <div className={a.toolbar}>
        {viewMode === 'grid' ? (
          <>
            <button className={s.navBtn} onClick={() => shiftWeek(-1)}>←</button>
            <span className={s.navLabel}>{formatWeekLabel(week)}</span>
            <button className={s.navBtn} onClick={() => shiftWeek(1)}>→</button>
            <button className={s.todayBtn} onClick={() => setWeek(getMondayOfWeek())}>Сьогодні</button>
          </>
        ) : (
          <>
            <button className={s.navBtn} onClick={() => shiftWeek(-1)}>←</button>
            <DayPicker weekDates={weekDates} today={today} activeDay={activeDay} onChange={setActiveDay} />
            <button className={s.navBtn} onClick={() => shiftWeek(1)}>→</button>
          </>
        )}
        <div className={a.spacer} />
        <select className={a.filterSelect} value={filterGroup} onChange={e => setFilterGroup(e.target.value)}>
          <option value="">Всі групи</option>
          {groups.filter(g => g.status === 'active').map(g => (
            <option key={g.id} value={g.id}>{g.name}</option>
          ))}
        </select>
        <ViewToggleBtn mode={viewMode} onChange={mode => { setViewMode(mode); setActiveDay(null); }} />
      </div>

      {loading ? <Spinner centered /> : viewMode === 'grid' ? (
        <ScheduleWeekGrid
          lessons={filtered}
          weekDates={weekDates}
          today={today}
          onEmptyClick={date => { setModalDate(date); setModalLesson(null); setConflicts([]); }}
          renderCard={renderCard}
        />
      ) : (
        <AgendaView
          lessons={filtered}
          weekDates={weekDates}
          today={today}
          activeDay={activeDay}
          renderCard={renderCard}
        />
      )}

      {modalLesson !== undefined && (
        <LessonModal
          lesson={modalLesson}
          groups={groups.filter(g => g.status !== 'closed')}
          halls={halls}
          defaultDate={modalDate}
          conflicts={conflicts}
          loading={saving}
          onSave={handleSave}
          onDelete={modalLesson ? () => setDeleteTarget(modalLesson) : undefined}
          onClose={() => { setModalLesson(undefined); setConflicts([]); }}
          onClearConflicts={() => setConflicts([])}
        />
      )}

      {deleteTarget && (
        <ConfirmModal
          title="Видалити заняття?"
          message={`${deleteTarget.style_name}, ${deleteTarget.lesson_date} ${deleteTarget.start_time.slice(0,5)}–${deleteTarget.end_time.slice(0,5)}`}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
          loading={saving}
        />
      )}

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default AdminSchedule;
