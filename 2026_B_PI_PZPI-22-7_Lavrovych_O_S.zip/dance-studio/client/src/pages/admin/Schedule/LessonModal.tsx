import { useState } from 'react';
import Modal     from '../../../components/ui/overlay/Modal';
import FormField from '../../../components/ui/form/FormField';
import { validateTimeRange, validateBusinessHours } from '../../../utils/validators';
import type { Lesson, DanceGroup, Hall } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './LessonModal.module.css';

interface LessonFormData {
  group_id:    string;
  hall_id:     string;
  lesson_date: string;
  start_time:  string;
  end_time:    string;
}

interface Props {
  lesson?:           Lesson | null;
  groups:            DanceGroup[];
  halls:             Hall[];
  defaultDate?:      string;
  conflicts:         any[];
  loading:           boolean;
  onSave:            (data: LessonFormData) => Promise<void>;
  onDelete?:         () => void;
  onClose:           () => void;
  onClearConflicts?: () => void;
}

const CONFLICT_LABELS: Record<string, string> = {
  hall:    'Зал зайнятий',
  teacher: 'Викладач зайнятий',
  group:   'Група вже має заняття',
};

const LessonModal = ({
  lesson, groups, halls, defaultDate,
  conflicts, loading, onSave, onDelete, onClose, onClearConflicts,
}: Props) => {
  const [form, setForm] = useState<LessonFormData>(
    lesson
      ? {
          group_id:    String(lesson.group_id),
          hall_id:     String(lesson.hall_id),
          lesson_date: lesson.lesson_date,
          start_time:  lesson.start_time.slice(0, 5),
          end_time:    lesson.end_time.slice(0, 5),
        }
      : { group_id: '', hall_id: '', lesson_date: defaultDate || '', start_time: '', end_time: '' }
  );
  const [errors, setErrors] = useState<Partial<LessonFormData>>({});

  const set = (field: keyof LessonFormData) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setForm(p => ({ ...p, [field]: e.target.value }));
      setErrors(p => ({ ...p, [field]: undefined }));
      onClearConflicts?.();
    };

  const validate = () => {
    const e: Partial<LessonFormData> = {};
    if (!form.group_id)    e.group_id    = 'Оберіть групу';
    if (!form.hall_id)     e.hall_id     = 'Оберіть зал';
    if (!form.lesson_date) e.lesson_date = 'Оберіть дату';
    if (!form.start_time)  e.start_time  = 'Вкажіть час';
    else {
      const bhErr = validateBusinessHours(form.start_time);
      if (bhErr) e.start_time = bhErr;
    }
    if (!form.end_time) {
      e.end_time = 'Вкажіть час';
    } else {
      const bhErr = validateBusinessHours(form.end_time);
      if (bhErr) e.end_time = bhErr;
    }
    if (!e.start_time && !e.end_time && form.start_time && form.end_time) {
      const rangeErr = validateTimeRange(form.start_time, form.end_time, 15);
      if (rangeErr) e.end_time = rangeErr;
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onSave(form);
  };

  return (
    <Modal
      title={lesson ? 'Редагувати заняття' : 'Нове заняття'}
      onClose={onClose}
      footer={
        <>
          {lesson && onDelete && (
            <button type="button" className={a.btnDanger} onClick={onDelete}>Видалити</button>
          )}
          <div style={{ flex: 1 }} />
          <button type="button" className={a.btnSecondary} onClick={onClose}>Скасувати</button>
          <button
            type="button"
            className={a.btnPrimary}
            disabled={loading || conflicts.length > 0}
            title={conflicts.length > 0 ? 'Виправте конфлікт розкладу перед збереженням' : undefined}
            onClick={handleSubmit}
          >
            {loading && <span className={a.spinner} />}
            {lesson ? 'Зберегти' : 'Створити'}
          </button>
        </>
      }
    >
      <FormField label="ГРУПА" error={errors.group_id}>
        <select
          className={`${a.input} ${errors.group_id ? a.inputError : ''}`}
          value={form.group_id}
          onChange={set('group_id')}
        >
          <option value="">Оберіть групу</option>
          {groups.filter(g => g.status === 'active').map(g => (
            <option key={g.id} value={g.id}>{g.name} — {g.style_name}</option>
          ))}
        </select>
      </FormField>

      <FormField label="ЗАЛ" error={errors.hall_id}>
        <select
          className={`${a.input} ${errors.hall_id ? a.inputError : ''}`}
          value={form.hall_id}
          onChange={set('hall_id')}
        >
          <option value="">Оберіть зал</option>
          {halls.map(h => (
            <option key={h.id} value={h.id}>{h.name} (до {h.capacity} осіб)</option>
          ))}
        </select>
      </FormField>

      <FormField label="ДАТА" error={errors.lesson_date}>
        <input
          type="date"
          className={`${a.input} ${errors.lesson_date ? a.inputError : ''}`}
          value={form.lesson_date}
          onChange={set('lesson_date')}
        />
      </FormField>

      <div className={a.formRow}>
        <FormField label="ПОЧАТОК" error={errors.start_time}>
          <input
            type="time"
            className={`${a.input} ${errors.start_time ? a.inputError : ''}`}
            value={form.start_time}
            onChange={set('start_time')}
          />
        </FormField>
        <FormField label="КІНЕЦЬ" error={errors.end_time}>
          <input
            type="time"
            className={`${a.input} ${errors.end_time ? a.inputError : ''}`}
            value={form.end_time}
            onChange={set('end_time')}
          />
        </FormField>
      </div>

      {conflicts.length > 0 && (
        <div className={s.conflictList}>
          <div className={s.conflictTitle}>⚠ КОНФЛІКТ РОЗКЛАДУ</div>
          {conflicts.map((c, i) => (
            <div key={i} className={s.conflictItem}>
              {CONFLICT_LABELS[c.conflict_type] || 'Конфлікт'} —{' '}
              {c.group_name}, {c.start_time?.slice(0, 5)}–{c.end_time?.slice(0, 5)}
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
};

export default LessonModal;
export type { LessonFormData };
