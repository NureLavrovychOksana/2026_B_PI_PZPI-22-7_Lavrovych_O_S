import EmptyState from '../../../components/ui/feedback/EmptyState';
import { IconCreditCard } from '../../../components/ui/Icon';
import type { Payment } from '../../../types';
import s from './StudentProfile.module.css';

const PAY_STATUS_LABEL: Record<string, string> = {
  pending:  'Очікує',
  success:  'Успішно',
  failed:   'Невдала',
  refunded: 'Повернуто',
};
const PAY_METHOD_LABEL: Record<string, string> = {
  cash:   'Готівка',
  card:   'Картка',
  liqpay: 'LiqPay',
};

const PaymentsTab = ({ payments }: { payments: Payment[] }) => (
  <div className={s.card}>
    {payments.length === 0 ? (
      <EmptyState
        icon={
          <span style={{ opacity: 0.3 }}><IconCreditCard size={32} strokeWidth={1.2} /></span>
        }
        title="Платежів ще немає"
      />
    ) : (
      <table className={s.payTable}>
        <thead>
          <tr>
            <th className={s.payTh}>Дата та час</th>
            <th className={s.payTh}>Продукт</th>
            <th className={s.payTh}>Метод</th>
            <th className={s.payTh} style={{ textAlign: 'right' }}>Сума</th>
            <th className={s.payTh} style={{ textAlign: 'center' }}>Статус</th>
          </tr>
        </thead>
        <tbody>
          {payments.map(p => (
            <tr key={p.id} className={s.payRow}>
              <td className={s.payTd}>
                {new Date(p.payment_date).toLocaleDateString('uk-UA', {
                  day: '2-digit', month: '2-digit', year: 'numeric',
                  hour: '2-digit', minute: '2-digit',
                })}
              </td>
              <td className={s.payTd}>{p.plan_name ?? '—'}</td>
              <td className={s.payTd} style={{ color: 'var(--graphite)' }}>
                {PAY_METHOD_LABEL[p.payment_method] ?? p.payment_method}
              </td>
              <td className={s.payTd} style={{ textAlign: 'right', fontFamily: 'var(--font-mono)' }}>
                ₴{p.amount.toLocaleString('uk-UA')}
              </td>
              <td className={s.payTd} style={{ textAlign: 'center' }}>
                <span className={`${s.payStatus} ${s[`payStatus_${p.status}`]}`}>
                  {PAY_STATUS_LABEL[p.status] ?? p.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    )}
  </div>
);

export default PaymentsTab;
