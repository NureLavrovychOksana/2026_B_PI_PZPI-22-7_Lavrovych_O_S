import { useEffect, useRef, useState } from 'react';
import { useNavigate }   from 'react-router-dom';
import { useAuth }       from '../../../context/AuthContext';
import { getStudentSubscriptions } from '../../../api/subscriptions';
import { getPaymentsByUser }        from '../../../api/payments';
import { getOwnProfile, updateOwnProfile, deleteOwnAccount } from '../../../api/users';
import { uploadUserAvatar } from '../../../api/lessons';
import Spinner      from '../../../components/ui/feedback/Spinner';
import Badge        from '../../../components/ui/feedback/Badge';
import Toast        from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import SettingsTab      from './SettingsTab';
import SubscriptionsTab from './SubscriptionsTab';
import PaymentsTab      from './PaymentsTab';
import type { StudentSubscription, Payment } from '../../../types';
import { IconCamera } from '../../../components/ui/Icon';
import a from '../../../styles/admin.module.css';
import s from './StudentProfile.module.css';

const serverOrigin = (import.meta.env.VITE_API_URL || 'http://localhost:5000/api').replace(/\/api$/, '');

type ProfileTab = 'settings' | 'subscriptions' | 'payments';

const StudentProfile = () => {
  const { user, logout, updateUser } = useAuth();
  const navigate = useNavigate();
  const { toasts, showToast, removeToast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [profile,   setProfile]   = useState<any>(null);
  const [allSubs,   setAllSubs]   = useState<StudentSubscription[]>([]);
  const [payments,  setPayments]  = useState<Payment[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [saving,    setSaving]    = useState(false);
  const [deleting,  setDeleting]  = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [avatarError, setAvatarError] = useState(false);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const [tab, setTab] = useState<ProfileTab>('settings');
  const [form, setForm] = useState({ first_name: '', last_name: '', phone: '' });

  useEffect(() => {
    if (!user) return;
    Promise.all([
      getOwnProfile(),
      getStudentSubscriptions(user.id),
      getPaymentsByUser(user.id),
    ]).then(([p, subs, pmts]) => {
      setProfile(p);
      setAllSubs(subs);
      setPayments(pmts);
      setAvatarUrl(p.avatar_url ?? null);
      setForm({ first_name: p.first_name ?? '', last_name: p.last_name ?? '', phone: p.phone ?? '' });
    }).finally(() => setLoading(false));
  }, [user]);

  const activeSubs   = allSubs.filter(s => { const e = s.effective_status ?? s.status; return e === 'active' || e === 'pending'; });
  const archivedSubs = allSubs.filter(s => { const e = s.effective_status ?? s.status; return e !== 'active' && e !== 'pending'; });
  const hasActiveSub  = activeSubs.some(s => (s.effective_status ?? s.status) === 'active');

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAvatarUploading(true);
    try {
      const res = await uploadUserAvatar(file);
      setAvatarUrl(res.avatar_url);
      setAvatarError(false);
      updateUser({ avatar_url: res.avatar_url });
      showToast('Аватар оновлено', 'success');
    } catch {
      showToast('Помилка завантаження', 'error');
    } finally {
      setAvatarUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateOwnProfile(form);
      updateUser({ first_name: form.first_name, last_name: form.last_name });
      showToast('Профіль оновлено', 'success');
    } catch (err: any) {
      showToast(err?.response?.data?.message ?? 'Помилка', 'error');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!confirmDel) { setConfirmDel(true); return; }
    setDeleting(true);
    try {
      await deleteOwnAccount();
      logout();
      navigate('/login');
    } catch (err: any) {
      showToast(err?.response?.data?.message ?? 'Помилка видалення', 'error');
      setConfirmDel(false);
    } finally { setDeleting(false); }
  };

  if (loading || !user) return <Spinner centered />;

  const initials = `${form.first_name[0] ?? ''}${form.last_name[0] ?? ''}`.toUpperCase();
  const regDate  = profile?.created_at
    ? new Date(profile.created_at).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' })
    : '—';
  const firstActiveSub = allSubs.find(s => (s.effective_status ?? s.status) === 'active')
    ?? allSubs.find(s => (s.effective_status ?? s.status) === 'pending');

  return (
    <div>
      <div className={s.breadcrumb}>
        <span className={s.breadcrumbItem}>Панель</span>
        <span className={s.breadcrumbSep}>/</span>
        <span>Профіль</span>
      </div>
      <h1 className={s.pageTitle}>Мій профіль</h1>

      {/* Hero */}
      <div className={s.hero}>
        <div className={s.avatarWrap}>
          {avatarUrl && !avatarError ? (
            <img src={`${serverOrigin}${avatarUrl}`} alt="avatar" className={s.avatarImg}
              onError={() => setAvatarError(true)} />
          ) : (
            <div className={s.avatarCircle}>{initials}</div>
          )}
          <button
            className={s.avatarEditBtn}
            onClick={() => fileInputRef.current?.click()}
            disabled={avatarUploading}
            title="Змінити фото"
            aria-label="Змінити фото профілю"
          >
            {avatarUploading
              ? <span className={a.spinner} style={{ width: 12, height: 12 }} />
              : <IconCamera size={12} />
            }
          </button>
          <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" style={{ display: 'none' }} onChange={handleAvatarChange} />
        </div>
        <div className={s.heroInfo}>
          <div className={s.heroName}>{form.last_name} {form.first_name}</div>
          <div className={s.heroSub}>Учень · ID #{String(user.id).padStart(5, '0')}</div>
          <div className={s.heroBadges}>
            {hasActiveSub
              ? <Badge variant="active" dot>Абонемент активний</Badge>
              : <Badge variant="neutral">Немає абонементу</Badge>
            }
            {firstActiveSub && (
              <span className={s.badgePlan}>
                {firstActiveSub.plan_name}
                {activeSubs.length > 1 ? ` +${activeSubs.length - 1}` : ''}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className={s.tabs}>
        {(['settings', 'subscriptions', 'payments'] as ProfileTab[]).map(t => (
          <button
            key={t}
            className={`${s.tab} ${tab === t ? s.tabActive : ''}`}
            onClick={() => setTab(t)}
          >
            {t === 'settings'      && 'Налаштування'}
            {t === 'subscriptions' && 'Мої абонементи'}
            {t === 'payments'      && 'Історія оплат'}
          </button>
        ))}
      </div>

      {tab === 'settings' && profile && (
        <SettingsTab
          form={form}
          setForm={setForm}
          email={profile.email}
          regDate={regDate}
          saving={saving}
          onSave={handleSave}
          activeSubs={activeSubs}
          deleting={deleting}
          confirmDel={confirmDel}
          onDelete={handleDelete}
          initialNotifPrefs={profile.notification_prefs ?? { email: true, sms: true, news: false, schedule: true }}
          showToast={showToast}
        />
      )}

      {tab === 'subscriptions' && (
        <SubscriptionsTab activeSubs={activeSubs} archivedSubs={archivedSubs} navigate={navigate} />
      )}

      {tab === 'payments' && (
        <PaymentsTab payments={payments} />
      )}

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default StudentProfile;
