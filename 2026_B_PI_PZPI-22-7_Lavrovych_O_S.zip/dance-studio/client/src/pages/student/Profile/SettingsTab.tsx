import { useRef, useState } from 'react';
import { updateNotifPrefs } from '../../../api/users';
import api from '../../../api/axios';
import FormField    from '../../../components/ui/form/FormField';
import SectionLabel from '../../../components/ui/display/SectionLabel';
import type { StudentSubscription } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './StudentProfile.module.css';

interface PwForm { current: string; next: string; confirm: string; }

interface Props {
  form:               { first_name: string; last_name: string; phone: string };
  setForm:            (fn: (prev: any) => any) => void;
  email:              string;
  regDate:            string;
  saving:             boolean;
  onSave:             () => void;
  activeSubs:         StudentSubscription[];
  deleting:           boolean;
  confirmDel:         boolean;
  onDelete:           () => void;
  initialNotifPrefs:  { email: boolean; sms: boolean; news: boolean; schedule: boolean };
  showToast:          (msg: string, type: 'success' | 'error') => void;
}

const SettingsTab = ({
  form, setForm, email, regDate, saving, onSave,
  activeSubs, deleting, confirmDel, onDelete,
  initialNotifPrefs, showToast,
}: Props) => {
  const [pwForm, setPwForm]       = useState<PwForm>({ current: '', next: '', confirm: '' });
  const [pwSaving, setPwSaving]   = useState(false);
  const [notifPrefs, setNotifPrefs] = useState(initialNotifPrefs);
  const [notifSaving, setNotifSaving] = useState(false);
  const notifSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handlePasswordSave = async () => {
    if (pwForm.next !== pwForm.confirm) { showToast('Паролі не збігаються', 'error'); return; }
    if (pwForm.next.length < 8)         { showToast('Мінімум 8 символів', 'error');   return; }
    setPwSaving(true);
    try {
      await api.put('/auth/change-password', { current_password: pwForm.current, new_password: pwForm.next });
      showToast('Пароль змінено', 'success');
      setPwForm({ current: '', next: '', confirm: '' });
    } catch (err: any) {
      showToast(err?.response?.data?.message ?? 'Помилка', 'error');
    } finally { setPwSaving(false); }
  };

  const handleNotifToggle = (key: keyof typeof notifPrefs) => {
    const next = { ...notifPrefs, [key]: !notifPrefs[key] };
    setNotifPrefs(next);
    if (notifSaveTimer.current) clearTimeout(notifSaveTimer.current);
    notifSaveTimer.current = setTimeout(async () => {
      setNotifSaving(true);
      try { await updateNotifPrefs(next); showToast('Налаштування збережено', 'success'); }
      catch { showToast('Помилка збереження', 'error'); }
      finally { setNotifSaving(false); }
    }, 600);
  };

  return (
    <div className={s.grid}>
      {/* Personal data + danger zone */}
      <div className={s.card}>
        <SectionLabel mb={16}>ОСОБИСТІ ДАНІ</SectionLabel>
        <div className={s.dataGrid}>
          <div>
            <div className={s.dataLabel}>ІМʼЯ</div>
            <input className={a.input} value={form.first_name}
              onChange={e => setForm((p: any) => ({ ...p, first_name: e.target.value }))} />
          </div>
          <div>
            <div className={s.dataLabel}>ПРІЗВИЩЕ</div>
            <input className={a.input} value={form.last_name}
              onChange={e => setForm((p: any) => ({ ...p, last_name: e.target.value }))} />
          </div>
        </div>
        <div className={s.dataLabel} style={{ marginTop: 12 }}>EMAIL</div>
        <div className={s.dataValue}>{email}</div>
        <div className={s.dataLabel} style={{ marginTop: 12 }}>ТЕЛЕФОН</div>
        <input className={a.input} value={form.phone} placeholder="+380..."
          onChange={e => setForm((p: any) => ({ ...p, phone: e.target.value }))} />
        <div className={s.dataLabel} style={{ marginTop: 12 }}>ДАТА РЕЄСТРАЦІЇ</div>
        <div className={s.dataValue}>{regDate}</div>
        <button className={a.btnPrimary} style={{ marginTop: 20 }} onClick={onSave} disabled={saving}>
          {saving && <span className={a.spinner} />}
          Зберегти
        </button>
        <div className={s.danger}>
          <div className={s.dangerLabel}>НЕБЕЗПЕЧНА ЗОНА</div>
          <div className={s.dangerRow}>
            <div>
              <div className={s.dangerTitle}>Видалити акаунт</div>
              <div className={s.dangerSub}>
                {activeSubs.length > 0
                  ? 'Неможливо видалити — є активний абонемент'
                  : 'Всі дані будуть видалені безповоротно'}
              </div>
            </div>
            <button
              className={s.dangerBtn}
              onClick={onDelete}
              disabled={deleting || activeSubs.length > 0}
              title={activeSubs.length > 0 ? 'Спочатку завершіть або скасуйте абонемент' : ''}
            >
              {deleting ? <span className={a.spinner} /> : confirmDel ? 'Підтвердити?' : 'Видалити акаунт'}
            </button>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Security */}
        <div className={s.card}>
          <SectionLabel mb={16}>БЕЗПЕКА</SectionLabel>
          <FormField label="ПОТОЧНИЙ ПАРОЛЬ">
            <input className={a.input} type="password" value={pwForm.current}
              onChange={e => setPwForm(p => ({ ...p, current: e.target.value }))} />
          </FormField>
          <FormField label="НОВИЙ ПАРОЛЬ">
            <input className={a.input} type="password" placeholder="Мінімум 8 символів" value={pwForm.next}
              onChange={e => setPwForm(p => ({ ...p, next: e.target.value }))} />
          </FormField>
          <FormField label="ПІДТВЕРДИТИ ПАРОЛЬ">
            <input className={a.input} type="password" placeholder="Повторіть пароль" value={pwForm.confirm}
              onChange={e => setPwForm(p => ({ ...p, confirm: e.target.value }))} />
          </FormField>
          <button
            className={a.btnSecondary}
            style={{ marginTop: 8 }}
            onClick={handlePasswordSave}
            disabled={pwSaving || !pwForm.current || !pwForm.next || !pwForm.confirm}
          >
            {pwSaving && <span className={a.spinner} />}
            Змінити пароль
          </button>
        </div>

        {/* Notifications */}
        <div className={s.card}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <SectionLabel mb={0}>СПОВІЩЕННЯ</SectionLabel>
            {notifSaving && (
              <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', color: 'var(--graphite)' }}>
                збереження...
              </span>
            )}
          </div>
          {([
            { key: 'email',    label: 'Email-нагадування про заняття', disabled: false },
            { key: 'sms',      label: 'Сповіщення за годину до заняття', disabled: false },
            { key: 'news',     label: 'Новини та акції',               disabled: true  },
            { key: 'schedule', label: 'Зміни в розкладі',              disabled: false },
          ] as const).map(({ key, label, disabled }) => (
            <div key={key} className={s.notifRow} style={disabled ? { opacity: 0.4 } : undefined}>
              <span className={s.notifLabel}>{label}</span>
              <button
                className={`${s.toggle} ${notifPrefs[key] ? s.toggleOn : ''}`}
                disabled={disabled}
                style={disabled ? { cursor: 'not-allowed' } : undefined}
                onClick={() => { if (!disabled) handleNotifToggle(key); }}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SettingsTab;
