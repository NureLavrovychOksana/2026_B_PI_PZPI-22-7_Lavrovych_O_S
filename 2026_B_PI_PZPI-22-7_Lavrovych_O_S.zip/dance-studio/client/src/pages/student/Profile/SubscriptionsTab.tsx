import type { NavigateFunction } from 'react-router-dom';
import EmptyState from '../../../components/ui/feedback/EmptyState';
import { IconShopping } from '../../../components/ui/Icon';
import type { StudentSubscription } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './StudentProfile.module.css';

const SUB_STATUS_LABEL: Record<string, string> = {
  active:    'Активний',
  pending:   'В черзі',
  exhausted: 'Вичерпано',
  expired:   'Термін сплив',
  cancelled: 'Скасовано',
};

const formatDate = (d: string) =>
  new Date(d).toLocaleDateString('uk-UA', { day: '2-digit', month: '2-digit', year: 'numeric' });

interface Props {
  activeSubs:   StudentSubscription[];
  archivedSubs: StudentSubscription[];
  navigate:     NavigateFunction;
}

const SubscriptionsTab = ({ activeSubs, archivedSubs, navigate }: Props) => {
  if (activeSubs.length === 0 && archivedSubs.length === 0) {
    return (
      <EmptyState
        icon={
          <span style={{ opacity: 0.3 }}><IconShopping size={32} strokeWidth={1.2} /></span>
        }
        title="Абонементів ще немає"
        action={
          <button className={a.btnPrimary} onClick={() => navigate('/student/subscription')}>
            Придбати абонемент
          </button>
        }
      />
    );
  }

  return (
    <div>
      {activeSubs.length > 0 && (
        <div className={s.subsSection}>
          <div className={s.subsSectionTitle}>Активні та в черзі</div>
          <div className={s.subsGrid}>
            {activeSubs.map((sub, idx) => {
              const isPrimary = idx === 0;
              return (
                <div key={sub.id} className={`${s.subCard} ${isPrimary ? s.subCardActive : s.subCardPending}`}>
                  <div className={s.subCardHead}>
                    <span className={s.subCardName}>{sub.plan_name}</span>
                    <span className={`${s.subCardBadge} ${isPrimary ? s.subCardBadgeActive : s.subCardBadgeQueue}`}>
                      {isPrimary ? 'АКТИВНИЙ' : 'В ЧЕРЗІ'}
                    </span>
                  </div>
                  <div className={s.subCardDetail}>
                    {sub.plan_type === 'UNLIMITED'
                      ? 'Необмежено занять'
                      : `${sub.sessions_left ?? 0} занять залишилось`}
                  </div>
                  <div className={s.subCardExp}>
                    {!isPrimary
                      ? 'Активується автоматично після завершення поточного'
                      : sub.expiry_date
                        ? `Дійсний до ${new Date(sub.expiry_date).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' })}`
                        : 'Без обмеження терміну'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {archivedSubs.length > 0 && (
        <div className={s.subsSection}>
          <div className={s.subsSectionTitle} style={{ opacity: 0.5 }}>Архівні</div>
          <div className={s.archivedList}>
            {archivedSubs.map(sub => {
              const eff = sub.effective_status ?? sub.status;
              return (
                <div key={sub.id} className={s.archivedRow}>
                  <div className={s.archivedName}>{sub.plan_name}</div>
                  <div className={s.archivedDetail}>
                    {sub.plan_type === 'UNLIMITED' ? '∞' : `${sub.sessions_left ?? 0}`} занять
                    {sub.expiry_date ? ` · до ${formatDate(sub.expiry_date)}` : ''}
                  </div>
                  <span className={s.archivedBadge}>{SUB_STATUS_LABEL[eff] ?? eff}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionsTab;
