import { useEffect, useState, useCallback, useMemo } from 'react';
import { useAuth }            from '../../../context/AuthContext';
import { localToday } from '../../../utils/dateUtils';
import { getLessons }         from '../../../api/lessons';
import { getEnrollmentsByStudent, selfEnroll, unenroll } from '../../../api/enrollments';
import PageHeader   from '../../../components/ui/display/PageHeader';
import Spinner      from '../../../components/ui/feedback/Spinner';
import Toast        from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import ScheduleWeekGrid, {
  getMondayOfWeek,
  getWeekDates,
  formatWeekLabel,
} from '../../../components/schedule/ScheduleWeekGrid';
import AgendaView       from '../../../components/schedule/AgendaView';
import { ViewToggleBtn, DayPicker } from '../../../components/schedule/ViewToggle';
import type { ViewMode } from '../../../components/schedule/ViewToggle';
import useIsMobile      from '../../../hooks/useIsMobile';
import type { Lesson }  from '../../../types';
import { LEVEL_LABELS } from '../../../types';
import a from '../../../styles/admin.module.css';
import s from './StudentSchedule.module.css';

const StudentSchedule = () => {
  const { user }                   = useAuth();
  const { toasts, showToast, removeToast } = useToast();
  const isMobile = useIsMobile();
  const [lessons,    setLessons]   = useState<Lesson[]>([]);
  const [enrolledIds, setEnrolled] = useState<Set<number>>(new Set());
  const [enrollMap,  setEnrollMap] = useState<Map<number, number>>(new Map());
  const [loading,    setLoading]   = useState(true);
  const [acting,     setActing]    = useState<number | null>(null);
  const [week,       setWeek]      = useState(getMondayOfWeek());
  const [viewMode,   setViewMode]  = useState<ViewMode>('grid');
  const [activeDay,  setActiveDay] = useState<number | null>(null);
  const [filterStyle, setFilterStyle] = useState('');

  useEffect(() => { if (isMobile) setViewMode('agenda'); }, [isMobile]);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const [lsns, enrollments] = await Promise.all([
      getLessons({ week }),
      getEnrollmentsByStudent(user.id),
    ]);
    setLessons(lsns);
    setEnrolled(new Set(enrollments.map((e: any) => e.lesson_id)));
    setEnrollMap(new Map(enrollments.map((e: any) => [e.lesson_id, e.id])));
    setLoading(false);
  }, [user, week]);

  useEffect(() => { load(); }, [load]);

  const today     = localToday();
  const weekDates = useMemo(() => getWeekDates(week), [week]);

  const shiftWeek = (dir: 1 | -1) => {
    const [y, m, d] = week.split('-').map(Number);
    const date = new Date(y, m - 1, d + dir * 7);
    setWeek(`${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`);
  };

  const styles = useMemo(
    () => [...new Set(lessons.map(l => l.style_name))].sort(),
    [lessons],
  );

  const filtered = useMemo(
    () => lessons.filter(l => l.status !== 'cancelled' && (!filterStyle || l.style_name === filterStyle)),
    [lessons, filterStyle],
  );

  const nowTime = new Date().toTimeString().slice(0, 5);

  const handleEnroll = async (lesson: Lesson) => {
    if (!user || acting !== null) return;
    const isEnrolled = enrolledIds.has(lesson.id);
    setActing(lesson.id);
    try {
      if (isEnrolled) {
        const enrollmentId = enrollMap.get(lesson.id);
        if (enrollmentId) {
          await unenroll(enrollmentId);
          setEnrolled(prev => { const ns = new Set(prev); ns.delete(lesson.id); return ns; });
          setEnrollMap(prev => { const m = new Map(prev); m.delete(lesson.id); return m; });
          showToast('Запис скасовано', 'success');
        }
      } else {
        const alreadyPast = lesson.lesson_date < today ||
          (lesson.lesson_date === today && lesson.end_time.slice(0, 5) <= nowTime);
        if (alreadyPast) { showToast('Не можна записатись на минуле заняття', 'error'); return; }
        try {
          const res = await selfEnroll(lesson.id);
          setEnrolled(prev => new Set(prev).add(lesson.id));
          setEnrollMap(prev => new Map(prev).set(lesson.id, res.id));
          showToast('Ви записані!', 'success');
        } catch (err: any) {
          if (err?.response?.data?.waitlist) {
            showToast('Місць немає. Перейдіть до "Записатись" щоб стати до листа очікування.', 'error');
          } else {
            showToast(err?.response?.data?.message ?? 'Помилка', 'error');
          }
        }
      }
    } finally { setActing(null); }
  };

  const renderCard = (lesson: Lesson, mode?: 'agenda') => {
    const isEnrolled = enrolledIds.has(lesson.id);
    const isPast     = lesson.lesson_date < today ||
      (lesson.lesson_date === today && lesson.end_time.slice(0, 5) <= nowTime);
    const isFull     = lesson.free_spots <= 0;
    const isActing   = acting === lesson.id;

    if (mode === 'agenda') {
      return (
        <button
          className={`${s.agendaRow} ${isEnrolled ? s.agendaEnrolled : ''} ${isPast ? s.agendaPast : ''} ${isFull && !isEnrolled ? s.agendaFull : ''}`}
          onClick={() => !isPast && handleEnroll(lesson)}
          disabled={isPast || isActing}
        >
          <div className={s.agendaTime}>
            <span className={s.agendaTimeStart}>{lesson.start_time.slice(0,5)}</span>
            <span className={s.agendaTimeEnd}>{lesson.end_time.slice(0,5)}</span>
          </div>
          <div className={s.agendaInfo}>
            <span className={s.agendaStyle}>{lesson.style_name}</span>
            <span className={s.agendaGroup}>{lesson.group_name}</span>
            <span className={s.agendaLevel}>{LEVEL_LABELS[lesson.group_level]}</span>
          </div>
          {lesson.hall_name && <span className={s.agendaHall}>{lesson.hall_name}</span>}
          <span className={s.agendaStatus}>
            {isActing ? '…' : isEnrolled ? '✓' : isFull ? 'Немає' : lesson.free_spots}
          </span>
        </button>
      );
    }

    return (
      <button
        className={`${s.lessonCell} ${isEnrolled ? s.lessonCellEnrolled : ''} ${isPast ? s.lessonCellPast : ''} ${isFull && !isEnrolled ? s.lessonCellFull : ''}`}
        onClick={() => !isPast && handleEnroll(lesson)}
        disabled={isPast || isActing}
        title={isEnrolled ? 'Скасувати запис' : isFull ? 'Немає місць' : 'Записатись'}
      >
        <span className={s.lessonStyle}>{lesson.style_name}</span>
        <span className={s.lessonLevel}>{LEVEL_LABELS[lesson.group_level]}</span>
        <span className={s.lessonHall}>{lesson.hall_name}</span>
        <span className={s.lessonTime}>{lesson.start_time.slice(0,5)}–{lesson.end_time.slice(0,5)}</span>
        <span className={s.lessonSpots}>
          {isActing ? '...' : isEnrolled ? '✓ Записаний' : isFull ? 'Немає місць' : `${lesson.free_spots} місць`}
        </span>
      </button>
    );
  };

  return (
    <div>
      <PageHeader title="Мій розклад" sub={formatWeekLabel(week)} />

      <div className={a.toolbar}>
        {viewMode === 'grid' ? (
          <>
            <button className={s.navBtn} onClick={() => shiftWeek(-1)}>←</button>
            <span className={s.navLabel}>{formatWeekLabel(week)}</span>
            <button className={s.navBtn} onClick={() => shiftWeek(1)}>→</button>
            <button className={s.todayBtn} onClick={() => setWeek(getMondayOfWeek())}>Сьогодні</button>
          </>
        ) : (
          <>
            <button className={s.navBtn} onClick={() => shiftWeek(-1)}>←</button>
            <DayPicker weekDates={weekDates} today={today} activeDay={activeDay} onChange={setActiveDay} />
            <button className={s.navBtn} onClick={() => shiftWeek(1)}>→</button>
          </>
        )}
        <div className={a.spacer} />
        {styles.length > 1 && (
          <select className={a.filterSelect} value={filterStyle} onChange={e => setFilterStyle(e.target.value)}>
            <option value="">Всі стилі</option>
            {styles.map(st => <option key={st} value={st}>{st}</option>)}
          </select>
        )}
        <ViewToggleBtn mode={viewMode} onChange={mode => { setViewMode(mode); setActiveDay(null); }} />
      </div>

      {loading ? <Spinner centered /> : viewMode === 'grid' ? (
        <ScheduleWeekGrid
          lessons={filtered}
          weekDates={weekDates}
          today={today}
          renderCard={renderCard}
        />
      ) : (
        <AgendaView
          lessons={filtered}
          weekDates={weekDates}
          today={today}
          activeDay={activeDay}
          renderCard={renderCard}
        />
      )}

      <div className={s.legend}>
        <span className={`${s.legendDot} ${s.legendEnrolled}`} /> Ви записані
        <span className={`${s.legendDot} ${s.legendFree}`} /> Є місця
        <span className={`${s.legendDot} ${s.legendFull}`} /> Немає місць
        <span className={`${s.legendDot} ${s.legendPast}`} /> Минуле
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default StudentSchedule;
