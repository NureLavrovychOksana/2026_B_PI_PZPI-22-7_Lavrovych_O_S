import { useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createCheckout, createCashCheckout } from '../../../api/payments';
import Toast       from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import { IconWallet, IconShield, IconInfo, IconCreditCard } from '../../../components/ui/Icon';
import s from './StudentCheckout.module.css';

type PayMethod = 'card' | 'cash';

interface CartItem {
  plan: { id: number; name: string; type: string; sessions_count: number; price: number };
}


const MOCK_ITEMS: CartItem[] = [
  { plan: { id: 1, name: 'Необмежений', type: 'UNLIMITED', sessions_count: 0, price: 2200 } },
  { plan: { id: 2, name: 'Стандарт',    type: 'COUNT',     sessions_count: 8, price: 1400 } },
];
const MOCK_TOTAL = 3600;

const StudentCheckout = () => {
  const location = useLocation();
  const navigate  = useNavigate();
  const { toasts, showToast, removeToast } = useToast();

  const items: CartItem[] = location.state?.items?.length ? location.state.items : MOCK_ITEMS;
  const total: number     = location.state?.total ?? MOCK_TOTAL;

  const [payMethod, setPayMethod] = useState<PayMethod>('card');
  const [loading,   setLoading]   = useState(false);
  const inFlight = useRef(false);

  const handlePay = async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    setLoading(true);
    try {
      if (payMethod === 'cash') {
        const res = await createCashCheckout(items[0].plan.id);
        inFlight.current = false;
        navigate('/student/payment-success', { state: { cashPayment: true, subscription: res.subscription } });
        return;
      }

      const res = await createCheckout(items[0].plan.id);
      if (res.data && res.signature) {
        (window as any).LiqPayCheckoutCallback = () => {
          (window as any).LiqPayCheckout
            .init({
              data:      res.data,
              signature: res.signature,
              embedTo:   '#liqpay_checkout',
              mode:      'popup',
            })
            .on('liqpay.callback', (d: any) => {
              if (d.status === 'success' || d.status === 'sandbox') {
                navigate('/student/payment-success', { state: { orderId: res.order_id } });
              } else {
                showToast('Оплата не пройшла: ' + (d.err_description || d.status), 'error');
              }
            })
            .on('liqpay.ready',  () => { setLoading(false); })
            .on('liqpay.close',  () => { setLoading(false); inFlight.current = false; });
        };

        const old = document.querySelector('script[src*="checkout.js"]');
        if (old) old.remove();
        delete (window as any).LiqPayCheckout;

        const s = document.createElement('script');
        s.src   = '//static.liqpay.ua/libjs/checkout.js';
        s.async = true;
        document.head.appendChild(s);
      } else {
        showToast('Оплату оброблено', 'success');
        navigate('/student/payments');
      }
    } catch (err: any) {
      showToast(err?.response?.data?.message ?? 'Помилка оплати', 'error');
      inFlight.current = false;
      setLoading(false);
    }
  };

  return (
    <div className={s.page}>
      {/* Breadcrumb + Title */}
      <div className={s.breadcrumb}>
        <Link to="/student/subscription" className={s.breadLink}>Магазин</Link>
        <span className={s.breadSep}>/</span>
        <span>Оплата</span>
      </div>
      <h1 className={s.pageTitle}>Оформлення</h1>

      <div className={s.layout}>
        {/* ── Left column ── */}
        <div className={s.leftCol}>

          {/* Payment method */}
          <section className={s.section}>
            <div className={s.sectionLabel}>СПОСІБ ОПЛАТИ</div>
            <div className={s.methods}>

              {/* Card */}
              <button
                className={`${s.method} ${payMethod === 'card' ? s.methodActive : ''}`}
                onClick={() => setPayMethod('card')}
              >
                <div className={s.methodIcon} style={{ background: '#1434CB', borderRadius: 4, padding: '3px 6px' }}>
                  <svg width="28" height="18" viewBox="0 0 50 30" fill="none">
                    <text x="2" y="22" fill="white" fontSize="16" fontWeight="800" fontFamily="Arial">VISA</text>
                  </svg>
                </div>
                <div className={s.methodInfo}>
                  <div className={s.methodName}>Банківська картка</div>
                  <div className={s.methodSub}>Visa, Mastercard</div>
                </div>
                {payMethod === 'card' && <span className={s.methodBadge}>Обрано</span>}
              </button>

              {/* Cash */}
              <button
                className={`${s.method} ${payMethod === 'cash' ? s.methodActive : ''}`}
                onClick={() => setPayMethod('cash')}
              >
                <div className={s.methodIcon} style={{ color: 'var(--lime)' }}>
                  <IconWallet size={22} strokeWidth={1.8} />
                </div>
                <div className={s.methodInfo}>
                  <div className={s.methodName}>Готівка</div>
                  <div className={s.methodSub}>В студії при наступному візиті</div>
                </div>
                {payMethod === 'cash' && <span className={s.methodBadge}>Обрано</span>}
              </button>
            </div>
          </section>

          {payMethod === 'card' && (
            <div className={s.liqpayNote}>
              <IconShield size={15} />
              <span>
                Дані картки вводяться у захищеній формі <strong>LiqPay</strong> після натискання «Сплатити».
                Ми не отримуємо та не зберігаємо реквізити картки.
              </span>
            </div>
          )}
          {payMethod === 'cash' && (
            <div className={s.liqpayNote}>
              <IconInfo size={15} />
              <span>
                Ваш абонемент буде зарезервовано. Зверніться до адміністратора в студії для оплати готівкою — він активує абонемент після підтвердження.
              </span>
            </div>
          )}
        </div>

        {/* ── Right column ── */}
        <div className={s.rightCol}>

          {/* Order summary */}
          <div className={s.orderCard}>
            <div className={s.orderLabel}>ЗАМОВЛЕННЯ</div>
            {items.map(item => (
              <div key={item.plan.id} className={s.orderItem}>
                <span className={s.orderItemName}>
                  {item.plan.name} · {item.plan.type === 'UNLIMITED' ? 'Необмежений' : `${item.plan.sessions_count} занять`}
                </span>
                <span className={s.orderItemPrice}>₴{item.plan.price.toLocaleString('uk-UA')}</span>
              </div>
            ))}
            <div className={s.orderDivider} />
            <div className={s.orderTotalRow}>
              <span className={s.orderTotalLabel}>Разом</span>
              <span className={s.orderTotalAmt}>₴{total.toLocaleString('uk-UA')}</span>
            </div>
          </div>

          {/* Pay button */}
          <div className={s.rightColPayArea}>
            <button
              className={`${s.payBtn} ${!loading ? s.payBtnActive : s.payBtnDisabled}`}
              disabled={loading}
              onClick={handlePay}
            >
              <IconCreditCard size={16} />
              {loading ? 'Обробка...' : payMethod === 'cash' ? `Підтвердити замовлення` : `Сплатити ₴${total.toLocaleString('uk-UA')}`}
            </button>
            <Link to="/student/subscription" className={s.backLink}>← Повернутись до магазину</Link>
          </div>
        </div>
      </div>

      {/* Sticky bottom pay bar */}
      <div className={s.stickyBar}>
        <div className={s.stickyMeta}>
          <span className={s.stickyLabel}>РАЗОМ</span>
          <span className={s.stickyTotal}>₴{total.toLocaleString('uk-UA')}</span>
        </div>
        <button
          className={`${s.stickyPayBtn} ${!loading ? s.stickyPayBtnActive : s.stickyPayBtnOff}`}
          disabled={loading}
          onClick={handlePay}
        >
          {loading ? 'Обробка...' : payMethod === 'cash' ? 'Підтвердити' : 'Сплатити'}
        </button>
      </div>

      <div id="liqpay_checkout" />
      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default StudentCheckout;
