import { useEffect, useState, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { localToday } from '../../../utils/dateUtils';
import { useAuth }           from '../../../context/AuthContext';
import { getStyles }         from '../../../api/styles';
import { getGroups }         from '../../../api/groups';
import { getLessons }        from '../../../api/lessons';
import { getEnrollmentsByStudent, selfEnroll, joinWaitlist, getMyWaitlist } from '../../../api/enrollments';
import { getActiveSubscriptions } from '../../../api/subscriptions';
import Spinner   from '../../../components/ui/feedback/Spinner';
import Toast     from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import EnrollStepsLeft    from './EnrollStepsLeft';
import EnrollCalendarBlock from './EnrollCalendarBlock';
import EnrollConfirmPanel  from './EnrollConfirmPanel';
import type { DanceStyle, DanceGroup, Lesson, GroupLevel, StudentSubscription } from '../../../types';
import { IconLayers } from '../../../components/ui/Icon';
import s from './StudentEnroll.module.css';

type LevelFilter = GroupLevel | 'all';

const StudentEnroll = () => {
  const { user } = useAuth();
  const { toasts, showToast, removeToast } = useToast();
  const [searchParams] = useSearchParams();
  const preGroupId  = searchParams.get('groupId')  ? Number(searchParams.get('groupId'))  : null;
  const preLessonId = searchParams.get('lessonId') ? Number(searchParams.get('lessonId')) : null;

  const [allStyles,  setAllStyles]  = useState<DanceStyle[]>([]);
  const [allGroups,  setAllGroups]  = useState<DanceGroup[]>([]);
  const [allLessons, setAllLessons] = useState<Lesson[]>([]);
  const [enrollments,setEnroll]     = useState<any[]>([]);
  const [waitlist,   setWaitlist]   = useState<any[]>([]);
  const [subs,       setSubs]       = useState<StudentSubscription[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [acting,     setActing]     = useState(false);

  const [selStyle,  setSelStyle]  = useState<number | null>(null);
  const [selLevel,  setSelLevel]  = useState<LevelFilter | null>(null);
  const [selGroup,  setSelGroup]  = useState<DanceGroup | null>(null);
  const [selDate,   setSelDate]   = useState<string | null>(null);
  const [selLesson, setSelLesson] = useState<Lesson | null>(null);

  const today = localToday();
  const [calYear,  setCalYear]  = useState(new Date().getFullYear());
  const [calMonth, setCalMonth] = useState(new Date().getMonth());

  useEffect(() => {
    if (!user) return;
    Promise.all([
      getStyles(), getGroups(), getLessons({}),
      getEnrollmentsByStudent(user.id), getMyWaitlist(), getActiveSubscriptions(user.id),
    ]).then(([st, gr, ls, en, wl, activeSubs]) => {
      setAllStyles(st);
      setAllGroups(gr.filter((g: DanceGroup) => g.status === 'active'));
      setAllLessons(ls.filter((l: Lesson) => l.status !== 'cancelled'));
      setEnroll(en); setWaitlist(wl); setSubs(activeSubs);
    }).finally(() => setLoading(false));
  }, [user]);

  useEffect(() => {
    if (loading || !preGroupId) return;
    const group = allGroups.find(g => g.id === preGroupId);
    if (!group) return;
    setSelStyle(group.style_id);
    setSelGroup(group);
    if (preLessonId) {
      const lesson = allLessons.find(l => l.id === preLessonId);
      if (lesson) {
        setSelDate(lesson.lesson_date);
        setSelLesson(lesson);
        const d = new Date(lesson.lesson_date + 'T12:00:00');
        setCalYear(d.getFullYear());
        setCalMonth(d.getMonth());
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading]);

  const availableStyleIds = useMemo(() => new Set(allGroups.map(g => g.style_id)), [allGroups]);
  const displayStyles     = useMemo(() => allStyles.filter(st => availableStyleIds.has(st.id)), [allStyles, availableStyleIds]);
  const filteredGroups    = useMemo(() => allGroups.filter(g => {
    if (selStyle && g.style_id !== selStyle) return false;
    if (selLevel && selLevel !== 'all' && g.level !== selLevel) return false;
    return true;
  }), [allGroups, selStyle, selLevel]);
  const nowTime = new Date().toTimeString().slice(0, 5);
  const isLessonEnrollable = (l: Lesson) =>
    l.lesson_date > today || (l.lesson_date === today && l.end_time.slice(0, 5) > nowTime);

  const groupLessons = useMemo(() =>
    selGroup ? allLessons.filter(l => l.group_id === selGroup.id && isLessonEnrollable(l)).sort((a, b) => a.lesson_date > b.lesson_date ? 1 : -1) : [],
    [allLessons, selGroup, today, nowTime]);
  const dotDates = useMemo(() => {
    if (selGroup) return new Set(groupLessons.map(l => l.lesson_date));
    if (filteredGroups.length === 0) return new Set<string>();
    const ids = new Set(filteredGroups.map(g => g.id));
    return new Set(allLessons.filter(l => ids.has(l.group_id) && isLessonEnrollable(l)).map(l => l.lesson_date));
  }, [selGroup, groupLessons, filteredGroups, allLessons, today, nowTime]);
  const dayLessons          = useMemo(() => selDate ? groupLessons.filter(l => l.lesson_date === selDate) : [], [groupLessons, selDate]);
  const enrolledLessonIds   = useMemo(() => new Set(enrollments.map((e: any) => e.lesson_id)), [enrollments]);
  const waitlistLessonIds   = useMemo(() => new Set(waitlist.map((w: any) => w.lesson_id)), [waitlist]);

  const isFormValid = selStyle !== null && selGroup !== null && selDate !== null && selLesson !== null;

  const pickStyle = (id: number)     => { setSelStyle(id);  setSelLevel(null); setSelGroup(null); setSelDate(null); setSelLesson(null); };
  const pickLevel = (lv: LevelFilter) => { setSelLevel(lv); setSelGroup(null); setSelDate(null); setSelLesson(null); };
  const pickGroup = (g: DanceGroup)  => { setSelGroup(g);   setSelDate(null);  setSelLesson(null); };
  const pickDate  = (d: string)      => { setSelDate(d);    setSelLesson(null); };
  const prevMonth = () => calMonth === 0  ? (setCalMonth(11), setCalYear(y => y - 1)) : setCalMonth(m => m - 1);
  const nextMonth = () => calMonth === 11 ? (setCalMonth(0),  setCalYear(y => y + 1)) : setCalMonth(m => m + 1);

  const handleConfirm = async () => {
    if (!selLesson || !user || acting) return;
    setActing(true);
    try {
      if (selLesson.free_spots > 0) {
        const res = await selfEnroll(selLesson.id);
        setEnroll(prev => [...prev, { lesson_id: selLesson.id, id: res.id }]);
        showToast('Ви записані на заняття! Одна сесія абонементу заморожена.', 'success');
      } else {
        const res = await joinWaitlist(selLesson.id);
        setWaitlist(prev => [...prev, { lesson_id: selLesson.id, id: res.id }]);
        showToast('Ви у списку очікування. Ми повідомимо, коли звільниться місце.', 'success');
      }
    } catch (err: any) {
      showToast(err?.response?.data?.message ?? 'Помилка при записі', 'error');
    } finally { setActing(false); }
  };

  if (loading) return <Spinner centered />;

  const isFull        = selLesson ? selLesson.free_spots <= 0 : false;
  const isEnrolled    = selLesson ? enrolledLessonIds.has(selLesson.id) : false;
  const isOnWaitlist  = selLesson ? waitlistLessonIds.has(selLesson.id) : false;
  const hasSession    = subs.some(s => s.plan_type === 'UNLIMITED' || ((s.sessions_left ?? 0) - (s.sessions_frozen ?? 0)) > 0);
  const noSessionBtn  = isFormValid && !isFull && !isEnrolled && !isOnWaitlist && !hasSession;
  const confirmLabel  = !isFormValid ? '✓ Підтвердити запис'
    : isEnrolled ? '✓ Ви вже записані'
    : isOnWaitlist ? '⏳ Ви вже в черзі'
    : noSessionBtn ? 'Немає доступних занять'
    : isFull ? '⏳ Встати в лист очікування'
    : '✓ Підтвердити запис';

  return (
    <div>
      <div className={s.pageHead}>
        <div>
          <div className={s.breadcrumb}>
            <Link to="/student/schedule" className={s.breadLink}>Мій розклад</Link>
            <span className={s.breadSep}>/</span>
            <span>Записатись</span>
          </div>
          <h1 className={s.pageTitle}>Запис на заняття</h1>
          <div className={s.pageSub}>Оберіть стиль, викладача та час</div>
        </div>
        {subs.length > 0 && (() => {
          const hasUnlimited = subs.some(s => s.plan_type === 'UNLIMITED');
          const total = hasUnlimited ? '∞' : subs.reduce((acc, s) => acc + (s.sessions_left ?? 0), 0);
          return (
            <div className={s.sessionsBadge}>
              <IconLayers size={13} />
              {total} занять залишилось
            </div>
          );
        })()}
      </div>

      <div className={s.layout}>
        <div className={s.steps}>
          <EnrollStepsLeft
            displayStyles={displayStyles} selStyle={selStyle} selLevel={selLevel}
            selGroup={selGroup} filteredGroups={filteredGroups} allGroups={allGroups}
            onPickStyle={pickStyle} onPickLevel={pickLevel} onPickGroup={pickGroup}
          />
        </div>
        <div className={s.sideCol}>
          <EnrollCalendarBlock
            calYear={calYear} calMonth={calMonth} dotDates={dotDates}
            selDate={selDate} today={today} dayLessons={dayLessons} selLesson={selLesson}
            enrolledLessonIds={enrolledLessonIds} waitlistLessonIds={waitlistLessonIds}
            onSelect={pickDate} onPrev={prevMonth} onNext={nextMonth}
            onSelectLesson={l => setSelLesson(l)}
          />
          <EnrollConfirmPanel
            selStyle={selStyle} displayStyles={displayStyles} selLevel={selLevel}
            selGroup={selGroup} selDate={selDate} selLesson={selLesson} subs={subs}
            isFormValid={isFormValid} confirmBtnDisabled={!isFormValid || acting || isEnrolled || isOnWaitlist || noSessionBtn}
            confirmBtnLabel={confirmLabel} acting={acting} onConfirm={handleConfirm}
          />
        </div>
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default StudentEnroll;
