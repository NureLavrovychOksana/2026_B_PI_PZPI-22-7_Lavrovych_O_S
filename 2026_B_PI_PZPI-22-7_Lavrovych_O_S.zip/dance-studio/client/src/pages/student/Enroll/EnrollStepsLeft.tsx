import type { DanceStyle, DanceGroup } from '../../../types';
import { LEVEL_LABELS as LVLS } from '../../../types';
import s from './StudentEnroll.module.css';

type LevelFilter = import('../../../types').GroupLevel | 'all';

const TeacherCard = ({ group, selected, onClick }: { group: DanceGroup; selected: boolean; onClick: () => void }) => {
  const initials = `${group.teacher_first_name?.[0] ?? ''}${group.teacher_last_name?.[0] ?? ''}`.toUpperCase();
  return (
    <button className={`${s.teacherCard} ${selected ? s.teacherCardSelected : ''}`} onClick={onClick}>
      <div className={s.teacherAvatar}>{initials}</div>
      <div className={s.teacherInfo}>
        <div className={s.teacherName}>{group.teacher_first_name} {group.teacher_last_name}</div>
        <div className={s.teacherSub}>{group.style_name} · {LVLS[group.level] ?? group.level}</div>
      </div>
      {selected && <span className={s.teacherCheck}>Обрано</span>}
    </button>
  );
};

interface Props {
  displayStyles:  DanceStyle[];
  selStyle:       number | null;
  selLevel:       LevelFilter | null;
  selGroup:       DanceGroup | null;
  filteredGroups: DanceGroup[];
  allGroups:      DanceGroup[];
  onPickStyle:    (id: number) => void;
  onPickLevel:    (lv: LevelFilter) => void;
  onPickGroup:    (g: DanceGroup) => void;
}

const EnrollStepsLeft = ({
  displayStyles, selStyle, selLevel, selGroup,
  filteredGroups, allGroups,
  onPickStyle, onPickLevel, onPickGroup,
}: Props) => (
  <>
    <div className={s.step}>
      <div className={s.stepHead}><span className={s.stepNum}>1</span>ОБЕРІТЬ СТИЛЬ</div>
      <div className={s.styleGrid}>
        {displayStyles.map(st => (
          <button key={st.id} className={`${s.styleCard} ${selStyle === st.id ? s.styleCardSel : ''}`} onClick={() => onPickStyle(st.id)}>
            <div className={s.styleName}>{st.name}</div>
            <div className={s.styleHalls}>
              {[...new Set(allGroups.filter(g => g.style_id === st.id).map(g => g.hall_name))].join(', ')}
            </div>
          </button>
        ))}
      </div>
    </div>

    <div className={s.step}>
      <div className={s.stepHead}><span className={s.stepNum}>2</span>РІВЕНЬ</div>
      <div className={s.levelRow}>
        {(['first_step', 'starter', 'learner', 'master', 'pro'] as const).map(lv => (
          <button key={lv} className={`${s.levelBtn} ${selLevel === lv ? s.levelBtnActive : ''}`} onClick={() => onPickLevel(lv)}>
            {LVLS[lv]}
          </button>
        ))}
        <button className={`${s.levelBtn} ${selLevel === 'all' ? s.levelBtnActive : ''}`} onClick={() => onPickLevel('all')}>
          Всі рівні
        </button>
      </div>
    </div>

    <div className={s.step}>
      <div className={s.stepHead}><span className={s.stepNum}>3</span>ВИКЛАДАЧ</div>
      {filteredGroups.length === 0 ? (
        <div className={s.empty}>Немає груп для обраного фільтру</div>
      ) : (
        <div className={s.teacherList}>
          {filteredGroups.map(g => (
            <TeacherCard key={g.id} group={g} selected={selGroup?.id === g.id} onClick={() => onPickGroup(g)} />
          ))}
        </div>
      )}
    </div>
  </>
);

export default EnrollStepsLeft;
