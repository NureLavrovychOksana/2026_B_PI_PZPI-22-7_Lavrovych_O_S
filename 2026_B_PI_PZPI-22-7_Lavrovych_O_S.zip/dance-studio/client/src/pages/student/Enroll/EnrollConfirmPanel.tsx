import type { DanceStyle, DanceGroup, Lesson, StudentSubscription } from '../../../types';
import { LEVEL_LABELS as LVLS } from '../../../types';
import { IconInfo } from '../../../components/ui/Icon';
import s from './StudentEnroll.module.css';

type LevelFilter = import('../../../types').GroupLevel | 'all';

interface Props {
  selStyle:            number | null;
  displayStyles:       DanceStyle[];
  selLevel:            LevelFilter | null;
  selGroup:            DanceGroup | null;
  selDate:             string | null;
  selLesson:           Lesson | null;
  subs:                StudentSubscription[];
  isFormValid:         boolean;
  confirmBtnDisabled:  boolean;
  confirmBtnLabel:     string;
  acting:              boolean;
  onConfirm:           () => void;
}

const EnrollConfirmPanel = ({
  selStyle, displayStyles, selLevel, selGroup, selDate, selLesson,
  subs, isFormValid, confirmBtnDisabled, confirmBtnLabel, acting, onConfirm,
}: Props) => (
  <div className={s.confirm}>
    <div className={s.confirmTitle}>ПІДТВЕРДЖЕННЯ</div>

    <div className={s.confirmRows}>
      <div className={s.confirmRow}>
        <span className={s.confirmKey}>Стиль</span>
        <span className={s.confirmVal}>{selStyle ? displayStyles.find(st => st.id === selStyle)?.name ?? '—' : '—'}</span>
      </div>
      <div className={s.confirmRow}>
        <span className={s.confirmKey}>Рівень</span>
        <span className={s.confirmVal}>
          {selLevel === null || selLevel === 'all' ? 'Всі рівні' : LVLS[selLevel as keyof typeof LVLS]}
        </span>
      </div>
      <div className={s.confirmRow}>
        <span className={s.confirmKey}>Викладач</span>
        <span className={s.confirmVal}>
          {selGroup ? `${selGroup.teacher_first_name} ${selGroup.teacher_last_name}` : '—'}
        </span>
      </div>
      <div className={s.confirmRow}>
        <span className={s.confirmKey}>Дата</span>
        <span className={s.confirmVal}>
          {selDate ? new Date(selDate).toLocaleDateString('uk-UA', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
        </span>
      </div>
      <div className={s.confirmRow}>
        <span className={s.confirmKey}>Час</span>
        <span className={`${s.confirmVal} ${selLesson ? s.confirmValActive : ''}`}>
          {selLesson ? selLesson.start_time.slice(0, 5) : '—'}
        </span>
      </div>
      <div className={s.confirmRow}>
        <span className={s.confirmKey}>Зал</span>
        <span className={s.confirmVal}>{selGroup?.hall_name ?? '—'}</span>
      </div>
      <div className={s.confirmRow}>
        <span className={s.confirmKey}>Списати занять</span>
        <span className={s.confirmVal} style={{ color: 'var(--graphite)', fontSize: 11 }}>
          {subs.length === 0
            ? 'Немає абонементу'
            : subs[0].plan_type === 'UNLIMITED'
              ? `1 заняття (${subs[0].plan_name})`
              : `1 з "${subs[0].plan_name}" (доступно: ${(subs[0].sessions_left ?? 0) - (subs[0].sessions_frozen ?? 0)})`}
        </span>
      </div>
    </div>

    <button
      className={`${s.confirmBtn} ${isFormValid && !confirmBtnDisabled ? s.confirmBtnActive : s.confirmBtnDisabled}`}
      disabled={confirmBtnDisabled}
      onClick={onConfirm}
    >
      {acting ? (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={s.spin}>
          <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4"/>
        </svg>
      ) : confirmBtnLabel}
    </button>

    <div className={s.freezeNote}>
      <IconInfo size={11} />
      Сесія заморожується при записі. Розморожується при скасуванні або поважній причині.
    </div>
  </div>
);

export default EnrollConfirmPanel;
