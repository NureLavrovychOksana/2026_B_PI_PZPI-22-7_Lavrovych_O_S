import MiniCalendar from '../../../components/ui/display/MiniCalendar';
import type { Lesson } from '../../../types';
import { IconSlashCircle } from '../../../components/ui/Icon';
import s from './StudentEnroll.module.css';

const SlotBtn = ({ lesson, selected, alreadyEnrolled, onWaitlist, onClick }: {
  lesson: Lesson; selected: boolean; alreadyEnrolled: boolean; onWaitlist: boolean; onClick: () => void;
}) => {
  const isFull = lesson.free_spots <= 0;
  return (
    <button
      className={[s.slotBtn, selected ? s.slotBtnSelected : '', alreadyEnrolled ? s.slotBtnEnrolled : '', onWaitlist ? s.slotBtnWaitlist : ''].join(' ')}
      onClick={onClick}
    >
      <div className={s.slotTime}>{lesson.start_time.slice(0, 5)}</div>
      <div className={s.slotMeta}>
        {alreadyEnrolled ? <span className={s.slotTag}>✓ Записаний</span>
          : onWaitlist ? <span className={s.slotTagWait}>⏳ В черзі</span>
          : isFull     ? <span className={s.slotTagFull}>Немає місць</span>
          : <span className={s.slotSpots}>{lesson.free_spots} місць</span>}
      </div>
    </button>
  );
};

interface Props {
  calYear:          number;
  calMonth:         number;
  dotDates:         Set<string>;
  selDate:          string | null;
  today:            string;
  dayLessons:       Lesson[];
  selLesson:        Lesson | null;
  enrolledLessonIds: Set<number>;
  waitlistLessonIds: Set<number>;
  onSelect:         (d: string) => void;
  onPrev:           () => void;
  onNext:           () => void;
  onSelectLesson:   (l: Lesson | null) => void;
}

const EnrollCalendarBlock = ({
  calYear, calMonth, dotDates, selDate, today, dayLessons, selLesson,
  enrolledLessonIds, waitlistLessonIds, onSelect, onPrev, onNext, onSelectLesson,
}: Props) => (
  <div className={s.step}>
    <div className={s.stepHead}><span className={s.stepNum}>4</span>ДАТА ТА ЧАС</div>
    <MiniCalendar
      year={calYear} month={calMonth}
      dotDates={dotDates} selected={selDate} today={today}
      onSelect={onSelect} onPrev={onPrev} onNext={onNext}
      s={s}
    />
    <div className={s.slots}>
      <div className={s.slotsLabel}>ВІЛЬНИЙ ЧАС</div>
      {!selDate ? (
        <div className={s.slotsEmpty}>Оберіть дату на календарі</div>
      ) : dayLessons.length === 0 ? (
        <div className={s.slotsEmpty}>
          <span style={{ opacity: 0.3 }}><IconSlashCircle size={20} strokeWidth={1.5} /></span>
          У цей день немає занять
        </div>
      ) : (
        <div className={s.slotList}>
          {dayLessons.map(l => (
            <SlotBtn
              key={l.id} lesson={l}
              selected={selLesson?.id === l.id}
              alreadyEnrolled={enrolledLessonIds.has(l.id)}
              onWaitlist={waitlistLessonIds.has(l.id)}
              onClick={() => onSelectLesson(selLesson?.id === l.id ? null : l)}
            />
          ))}
        </div>
      )}
    </div>
  </div>
);

export default EnrollCalendarBlock;
