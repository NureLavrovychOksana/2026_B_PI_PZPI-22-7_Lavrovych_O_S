import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext';
import { confirmCheckout } from '../../../api/payments';
import { getActiveSubscriptions } from '../../../api/subscriptions';
import Spinner from '../../../components/ui/feedback/Spinner';
import type { StudentSubscription } from '../../../types';
import { IconCheck, IconWallet } from '../../../components/ui/Icon';
import s from './StudentPaymentSuccess.module.css';

const DESTINATIONS = {
  schedule: '/student/enroll',
  cabinet:  '/student',
} as const;

type LocationState = { orderId?: string; cashPayment?: boolean; subscription?: StudentSubscription } | null;

const StudentPaymentSuccess = () => {
  const { user }  = useAuth();
  const navigate  = useNavigate();
  const location  = useLocation();
  const state = location.state as LocationState;
  const orderId    = state?.orderId;
  const cashPayment = state?.cashPayment;

  const [sub,     setSub]     = useState<StudentSubscription | null>(state?.subscription ?? null);
  const [loading, setLoading] = useState(!cashPayment);
  const [failed,  setFailed]  = useState(false);

  useEffect(() => {
    if (cashPayment || !user) return;
    let cancelled = false;

    (async () => {
      try {
        const result = orderId
          ? (await confirmCheckout(orderId)).subscription
          : (await getActiveSubscriptions(user.id))[0] ?? null;
        if (!cancelled) setSub(result);
      } catch {
        if (!cancelled) setFailed(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [user, orderId, cashPayment]);

  if (loading) return <Spinner centered />;

  const expiry = sub?.expiry_date
    ? new Date(sub.expiry_date).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' })
    : null;

  return (
    <div className={s.wrap}>
      <div className={s.card}>
        <div className={s.icon}>
          {cashPayment ? (
            <IconWallet size={36} />
          ) : (
            <IconCheck size={36} />
          )}
        </div>

        <h1 className={s.title}>
          {cashPayment ? 'Запит зареєстровано!' : 'Оплату успішно здійснено!'}
        </h1>

        {cashPayment && (
          <p className={s.sub}>
            Зверніться до адміністратора в студії для оплати готівкою.
            Абонемент буде активовано після підтвердження оплати.
          </p>
        )}

        {sub ? (
          <div className={s.plan}>
            <div className={s.planLabel}>{sub.status === 'pending' ? 'КУПЛЕНО — В ЧЕРЗІ' : 'ВАШ АБОНЕМЕНТ'}</div>
            <div className={s.planName}>{sub.plan_name}</div>
            <div className={s.planMeta}>
              {sub.plan_type === 'UNLIMITED' ? 'Необмежено занять' : `${sub.sessions_left} занять`}
            </div>
            {sub.status === 'pending' ? (
              <div className={s.planExpiry}>Активується автоматично після закінчення поточного абонементу</div>
            ) : (
              expiry && <div className={s.planExpiry}>Дійсний до {expiry}</div>
            )}
          </div>
        ) : !cashPayment ? (
          <p className={s.sub}>
            {failed
              ? 'Не вдалося завантажити деталі абонементу. Перевірте розділ «Абонементи» за хвилину.'
              : 'Абонемент активується протягом кількох хвилин.'}
          </p>
        ) : null}

        <div className={s.actions}>
          <button className={s.btnPrimary} onClick={() => navigate(DESTINATIONS.schedule)}>
            Записатися на заняття
          </button>
          <button className={s.btnGhost} onClick={() => navigate(DESTINATIONS.cabinet)}>
            До кабінету
          </button>
        </div>
      </div>
    </div>
  );
};

export default StudentPaymentSuccess;
