import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell,
  PieChart, Pie,
} from 'recharts';
import s from './StudentAttendance.module.css';

type Period = 'week' | 'month' | '3months' | 'year';

const PERIOD_LABELS: Record<Period, string> = {
  week:      'Тиждень',
  month:     'Місяць',
  '3months': '3 місяці',
  year:      'Весь рік',
};
const DONUT_COLORS = ['#c8fa3a', '#1e3a6e', '#6b7280'];

const BarTip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className={s.chartTip}>
      <div className={s.chartTipLabel}>{label}</div>
      <div className={s.chartTipVal}>{payload[0].value} занять</div>
    </div>
  );
};

interface ChartPoint { name: string; value: number; }
interface StylePoint { name: string; value: number; pct: number; }

interface Props {
  period:    Period;
  onPeriod:  (p: Period) => void;
  barData:   ChartPoint[];
  styleData: StylePoint[];
}

const AttendanceCharts = ({ period, onPeriod, barData, styleData }: Props) => (
  <div className={s.analyticsCard}>
    <div className={s.analyticsHead}>
      <div className={s.analyticsTitle}>АНАЛІТИКА АКТИВНОСТІ</div>
      <div className={s.periodTabs}>
        {(Object.keys(PERIOD_LABELS) as Period[]).map(p => (
          <button
            key={p}
            className={`${s.periodTab} ${period === p ? s.periodTabActive : ''}`}
            onClick={() => onPeriod(p)}
          >
            {PERIOD_LABELS[p]}
          </button>
        ))}
      </div>
    </div>

    <div className={s.analyticsGrid}>
      {/* Bar chart */}
      <div className={s.chartBlock}>
        <div className={s.chartBlockTitle}>Динаміка занять</div>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={barData} margin={{ top: 8, right: 4, bottom: 0, left: -28 }} barCategoryGap="32%">
            <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.05)" />
            <XAxis dataKey="name"
              tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11, fontFamily: 'monospace' }}
              axisLine={false} tickLine={false} />
            <YAxis allowDecimals={false}
              tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10, fontFamily: 'monospace' }}
              axisLine={false} tickLine={false} />
            <Tooltip content={<BarTip />} cursor={{ fill: 'rgba(255,255,255,0.04)' }} />
            <Bar dataKey="value" radius={[4, 4, 0, 0]} maxBarSize={40}>
              {barData.map((entry, i) => (
                <Cell key={i} fill="#c8fa3a" fillOpacity={entry.value > 0 ? 1 : 0.15} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Donut chart */}
      <div className={s.chartBlock}>
        <div className={s.chartBlockTitle}>Улюблені стилі</div>
        <div className={s.donutWrap}>
          <PieChart width={160} height={160}>
            <Pie
              data={styleData.length ? styleData : [{ name: 'Немає даних', value: 1, pct: 0 }]}
              cx={75} cy={75} innerRadius={48} outerRadius={72}
              paddingAngle={styleData.length > 1 ? 3 : 0}
              dataKey="value" isAnimationActive animationDuration={600} animationEasing="ease-out"
            >
              {(styleData.length ? styleData : [{ name: 'Немає даних', value: 1, pct: 0 }]).map((_, i) => (
                <Cell key={i} fill={styleData.length ? DONUT_COLORS[i % DONUT_COLORS.length] : '#2a2a27'} />
              ))}
            </Pie>
            {styleData.length > 0 && (
              <Tooltip
                formatter={(val: any, name: any) => [`${val} занять`, name]}
                contentStyle={{ background: '#1c1c1a', border: '1px solid #2a2a27', borderRadius: 8, fontSize: 12 }}
                labelStyle={{ display: 'none' }}
                itemStyle={{ color: '#fff' }}
              />
            )}
          </PieChart>

          <div className={s.donutLegend}>
            {styleData.length
              ? styleData.map((item, i) => (
                  <div key={item.name} className={s.legendRow}>
                    <span className={s.legendDot} style={{ background: DONUT_COLORS[i % DONUT_COLORS.length] }} />
                    <span className={s.legendName}>{item.name}</span>
                    <span className={s.legendPct}>{item.pct}%</span>
                  </div>
                ))
              : <div className={s.legendEmpty}>Немає даних за вибраний період</div>
            }
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default AttendanceCharts;
