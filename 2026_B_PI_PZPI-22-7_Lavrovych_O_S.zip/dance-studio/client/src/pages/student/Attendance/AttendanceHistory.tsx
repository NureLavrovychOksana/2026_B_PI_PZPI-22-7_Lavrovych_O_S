import type { NavigateFunction } from 'react-router-dom';
import s from './StudentAttendance.module.css';

const StatusBadge = ({ status }: { status: string }) => {
  const cfg = {
    present: { label: 'Відвідано',           cls: s.badgeGreen },
    excused: { label: 'Пропуск (Збережено)', cls: s.badgeGrey  },
    absent:  { label: 'Пропуск (Списано)',   cls: s.badgeRed   },
  }[status] ?? { label: status, cls: s.badgeGrey };
  return <span className={`${s.badge} ${cfg.cls}`}>{cfg.label}</span>;
};

interface Props {
  grouped:  Map<string, any[]>;
  navigate: NavigateFunction;
}

const AttendanceHistory = ({ grouped, navigate }: Props) => {
  const fmtMonth = (key: string) => {
    const [y, m] = key.split('-').map(Number);
    const label = new Date(y, m - 1).toLocaleDateString('uk-UA', { month: 'long', year: 'numeric' });
    return label.charAt(0).toUpperCase() + label.slice(1);
  };

  return (
    <div className={s.historyCard}>
      <div className={s.historyTitle}>ІСТОРІЯ ЗАНЯТЬ</div>

      {grouped.size === 0 ? (
        <div className={s.empty}>Немає занять за вибраний період</div>
      ) : (
        [...grouped.entries()].map(([key, rows]) => (
          <div key={key} className={s.monthGroup}>
            <div className={s.monthLabel}>{fmtMonth(key)}</div>

            {rows.map((r, i) => {
              const date      = new Date(r.lesson_date ?? r.marked_at ?? '');
              const time      = r.start_time?.slice(0, 5) ?? '—';
              const dateStr   = date.toLocaleDateString('uk-UA', { day: 'numeric', month: 'short', year: 'numeric' });
              const isPresent = r.status === 'present';

              return (
                <div
                  key={r.id ?? i}
                  className={s.historyRow}
                  style={{ cursor: isPresent ? 'pointer' : 'default' }}
                  onClick={() => isPresent && navigate(`/teacher/lessons/${r.lesson_id}`)}
                >
                  <div className={s.rowDateTime}>
                    <div className={s.rowTime}>{time}</div>
                    <div className={s.rowDate}>{dateStr}</div>
                  </div>
                  <div className={s.rowDetails}>
                    <div className={s.rowStyle}>{r.style_name ?? r.group_name ?? '—'}</div>
                    <div className={s.rowTeacher}>
                      {r.teacher_name ?? '—'}
                      {r.hall ? ` · ${r.hall}` : ''}
                    </div>
                  </div>
                  <div className={s.rowRight}>
                    <StatusBadge status={r.status} />
                  </div>
                </div>
              );
            })}
          </div>
        ))
      )}
    </div>
  );
};

export default AttendanceHistory;
