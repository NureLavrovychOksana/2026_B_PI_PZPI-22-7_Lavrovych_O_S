import { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth }               from '../../../context/AuthContext';
import { getAttendanceByStudent } from '../../../api/attendance';
import Spinner          from '../../../components/ui/feedback/Spinner';
import AttendanceCharts from './AttendanceCharts';
import AttendanceHistory from './AttendanceHistory';
import { IconZap } from '../../../components/ui/Icon';
import s from './StudentAttendance.module.css';

type Period = 'week' | 'month' | '3months' | 'year';

const PERIOD_DAYS: Record<Period, number> = {
  week: 7, month: 30, '3months': 90, year: 365,
};


const StudentAttendance = () => {
  const { user }  = useAuth();
  const navigate  = useNavigate();
  const [records,      setRecords]      = useState<any[]>([]);
  const [loading,      setLoading]      = useState(true);
  const [period,       setPeriod]       = useState<Period>('month');

  useEffect(() => {
    if (!user) return;
    getAttendanceByStudent(user.id)
      .then(d => {
        setRecords(Array.isArray(d) ? d : (d?.records ?? []));
      })
      .catch(() => setRecords([]))
      .finally(() => setLoading(false));
  }, [user]);

  const filteredRecords = useMemo(() => {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - PERIOD_DAYS[period]);
    const cut = cutoff.toISOString().slice(0, 10);
    return records.filter(r => (r.lesson_date ?? r.marked_at ?? '') >= cut);
  }, [records, period]);

  const streak = useMemo(() => {
    const dates = records
      .filter(r => r.status === 'present')
      .map(r => r.lesson_date ?? r.marked_at ?? '')
      .filter(Boolean)
      .sort((a, b) => b.localeCompare(a));
    let n = 0; let prev: string | null = null;
    for (const d of dates) {
      if (!prev) { n = 1; prev = d; continue; }
      const diff = (new Date(prev).getTime() - new Date(d).getTime()) / 86_400_000;
      if (diff <= 8) { n++; prev = d; } else break;
    }
    return n;
  }, [records]);

  const totalPresent  = records.filter(r => r.status === 'present').length;
  const thisMonth     = new Date().toISOString().slice(0, 7);
  const monthRecs     = records.filter(r => (r.lesson_date ?? '').startsWith(thisMonth));
  const monthPresent  = monthRecs.filter(r => r.status === 'present').length;
  const attendancePct = monthRecs.length ? Math.round((monthPresent / monthRecs.length) * 100) : 0;

  const barData = useMemo(() => {
    const present = filteredRecords.filter(r => r.status === 'present');

    if (period === 'week') {
      const labels = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'];
      const counts = [0, 0, 0, 0, 0, 0, 0];
      present.forEach(r => {
        const dow = (new Date(r.lesson_date ?? r.marked_at ?? '').getDay() + 6) % 7;
        counts[dow]++;
      });
      return labels.map((name, i) => ({ name, value: counts[i] }));
    }

    if (period === 'month') {
      const labels = ['Тиж 1', 'Тиж 2', 'Тиж 3', 'Тиж 4', 'Тиж 5'];
      const counts = [0, 0, 0, 0, 0];
      present.forEach(r => {
        const day = new Date(r.lesson_date ?? r.marked_at ?? '').getDate();
        counts[Math.min(Math.floor((day - 1) / 7), 4)]++;
      });
      const now = new Date();
      const weeksCount = Math.ceil(new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate() / 7);
      return labels.slice(0, weeksCount).map((name, i) => ({ name, value: counts[i] }));
    }

    const MONTHS = ['Січ', 'Лют', 'Бер', 'Кві', 'Тра', 'Чер', 'Лип', 'Сер', 'Вер', 'Жов', 'Лис', 'Гру'];
    const numMonths = period === '3months' ? 3 : 12;
    const map: Record<string, number> = {};
    present.forEach(r => {
      const key = (r.lesson_date ?? r.marked_at ?? '').slice(0, 7);
      map[key] = (map[key] ?? 0) + 1;
    });
    const now = new Date();
    return Array.from({ length: numMonths }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (numMonths - 1 - i), 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      return { name: MONTHS[d.getMonth()], value: map[key] ?? 0 };
    });
  }, [filteredRecords, period]);

  const styleData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredRecords.filter(r => r.status === 'present').forEach(r => {
      const n = r.style_name ?? r.group_name ?? 'Інше';
      map[n] = (map[n] ?? 0) + 1;
    });
    const total = Object.values(map).reduce((a, b) => a + b, 0) || 1;
    return Object.entries(map)
      .sort((a, b) => b[1] - a[1])
      .map(([name, value]) => ({ name, value, pct: Math.round((value / total) * 100) }));
  }, [filteredRecords]);

  const grouped = useMemo(() => {
    const sorted = [...filteredRecords].sort((a, b) =>
      (b.lesson_date ?? b.marked_at ?? '').localeCompare(a.lesson_date ?? a.marked_at ?? '')
    );
    const map = new Map<string, typeof sorted>();
    sorted.forEach(r => {
      const key = (r.lesson_date ?? r.marked_at ?? '').slice(0, 7);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(r);
    });
    return map;
  }, [filteredRecords]);

  if (loading || !user) return <Spinner centered />;

  return (
    <div>
      <div className={s.pageHead}>
        <div className={s.pageTitle}>Моя відвідуваність</div>
      </div>

      {/* KPI cards */}
      <div className={s.kpiRow}>
        <div className={s.kpi}>
          <div className={s.kpiTop}>
            <span className={s.kpiValue} style={{ color: '#c8fa3a' }}>{streak}</span>
            <span className={s.kpiFireIcon} style={{ color: 'var(--lime)' }}>
              <IconZap size={26} />
            </span>
          </div>
          <div className={s.kpiLabel}>Серія занять</div>
        </div>
        <div className={s.kpi}>
          <div className={s.kpiTop}><span className={s.kpiValue}>{totalPresent}</span></div>
          <div className={s.kpiLabel}>Всього пройдено</div>
        </div>
        <div className={s.kpi}>
          <div className={s.kpiTop}><span className={s.kpiValue}>{attendancePct}%</span></div>
          <div className={s.kpiLabel}>Відсоток відвідуваності</div>
        </div>
      </div>

      <AttendanceCharts
        period={period}
        onPeriod={setPeriod}
        barData={barData}
        styleData={styleData}
      />

      <AttendanceHistory
        grouped={grouped}
        navigate={navigate}
      />
    </div>
  );
};

export default StudentAttendance;
