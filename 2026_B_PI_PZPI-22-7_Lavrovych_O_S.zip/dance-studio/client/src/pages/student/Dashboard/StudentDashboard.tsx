import { useEffect, useState } from 'react';
import { Link }              from 'react-router-dom';
import { useAuth }           from '../../../context/AuthContext';
import { getActiveSubscriptions } from '../../../api/subscriptions';
import { getEnrollmentsByStudent, unenroll } from '../../../api/enrollments';
import { getAttendanceByStudent }  from '../../../api/attendance';
import Spinner     from '../../../components/ui/feedback/Spinner';
import Badge       from '../../../components/ui/feedback/Badge';
import Button      from '../../../components/ui/form/Button';
import ProgressBar from '../../../components/ui/display/ProgressBar';
import NotifBell   from '../../../components/ui/display/NotifBell';
import { Quick, IconLayers, IconClock, IconActivity, IconLightning } from './DashboardComponents';
import { IconCirclePlus, IconShopping, IconClipboard, IconUser } from '../../../components/ui/Icon';
import DashboardGrid from './DashboardGrid';
import type { StudentSubscription } from '../../../types';
import s from './StudentDashboard.module.css';

const StudentDashboard = () => {
  const { user } = useAuth();
  const [subs,        setSubs]        = useState<StudentSubscription[]>([]);
  const [enrollments, setEnroll]      = useState<any[]>([]);
  const [attendance,  setAttend]      = useState<any[]>([]);
  const [loading,     setLoading]     = useState(true);

  useEffect(() => {
    if (!user) return;
    Promise.all([
      getActiveSubscriptions(user.id),
      getEnrollmentsByStudent(user.id),
      getAttendanceByStudent(user.id),
    ]).then(([activeSubs, e, att]) => {
      setSubs(activeSubs);
      setEnroll(e || []);
      setAttend(att || []);
    }).finally(() => setLoading(false));
  }, [user]);

  const handleCancel = async (enrollId: number) => {
    await unenroll(enrollId);
    setEnroll(prev => prev.filter(e => e.id !== enrollId));
  };

  if (loading || !user) return <Spinner centered />;

  const today       = new Date();
  const monthName   = today.toLocaleDateString('uk-UA', { month: 'long', year: 'numeric' });
  const monthIdx    = today.getMonth();
  const yearIdx     = today.getFullYear();
  const daysInMonth = new Date(yearIdx, monthIdx + 1, 0).getDate();

  const monthAtt     = attendance.filter((a: any) => {
    const d = new Date(a.lesson_date || a.marked_at);
    return d.getMonth() === monthIdx && d.getFullYear() === yearIdx;
  });
  const totalMonth   = monthAtt.length;
  const presentMonth = monthAtt.filter((a: any) => a.status === 'present').length;
  const attPercent   = totalMonth ? Math.round((presentMonth / totalMonth) * 100) : 0;
  const chartData    = monthAtt.map((a: any) => ({
    day: new Date(a.lesson_date || a.marked_at).getDate(),
    present: a.status === 'present',
  }));

  const upcoming = [...enrollments]
    .filter(e => new Date(e.lesson_date) >= new Date(today.toDateString()))
    .sort((a, b) => `${a.lesson_date} ${a.start_time ?? ''}` < `${b.lesson_date} ${b.start_time ?? ''}` ? -1 : 1)
    .slice(0, 4);
  const nextLesson = upcoming[0];

  const hasUnlimited      = subs.some(s => s.plan_type === 'UNLIMITED');
  const firstSub          = subs[0] ?? null;
  const totalSessionsLeft = hasUnlimited ? null : subs.reduce((acc, s) => acc + (s.sessions_left ?? 0), 0);
  const subProgress       = hasUnlimited ? 100 : firstSub?.plan_sessions_count
    ? ((firstSub.sessions_left ?? 0) / firstSub.plan_sessions_count) * 100 : 0;
  const extraSubsCount    = subs.length > 1 ? subs.length - 1 : 0;
  const totalAttended     = attendance.filter((a: any) => a.status === 'present').length;

  const trialSub = subs.find(sub => sub.plan_price === 0 && (sub.sessions_left ?? 0) > 0);

  return (
    <div>
      {trialSub && (
        <div className={s.trialBanner}>
          <IconLayers size={16} />
          У вас є <strong>1 безкоштовне пробне заняття</strong> — скористайтесь ним просто зараз!
          <Link to="/student/enroll" className={s.trialBtn}>Записатись →</Link>
        </div>
      )}
      <div className={s.headerRow}>
        <div>
          <h1 className={s.greetingTitle}>
            Вітаємо, {user.first_name}!
            <IconLightning />
          </h1>
          <div className={s.greetingSub}>
            {today.toLocaleDateString('uk-UA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </div>
        </div>
        <div className={s.headerActions}>
          <NotifBell to="/student/notifications" />
          <Button href="/student/subscription">
            <IconShopping size={14} />
            Купити абонемент
          </Button>
        </div>
      </div>

      <div className={s.subCard}>
        <div className={s.subLeft}>
          <div className={s.subInfo}>
            <div className={s.subName}>{user.last_name} {user.first_name}</div>
            <div className={s.subId}>ID #{String(user.id).padStart(5, '0')}</div>
            {subs.length > 0
              ? <Badge variant="active" dot className={s.subBadge}>Абонемент активний</Badge>
              : <Badge variant="neutral" className={s.subBadge}>Немає абонементу</Badge>
            }
          </div>
        </div>
        {firstSub?.expiry_date && (
          <div className={s.subRight}>
            <div className={s.expiryLabel}>Діє до</div>
            <div className={s.expiryDate}>
              {new Date(firstSub.expiry_date).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' })}
            </div>
          </div>
        )}
      </div>

      <div className={s.kpiRow}>
        <div className={`${s.kpi} ${s.kpiAccent}`}>
          <div className={s.kpiLabel}><IconLayers />ЗАНЯТЬ ЗАЛИШИЛОСЬ</div>
          <div className={`${s.kpiValue} ${s.kpiLime}`}>
            {hasUnlimited ? '∞' : (subs.length > 0 ? totalSessionsLeft : '—')}
          </div>
          <div className={s.kpiSub}>
            {firstSub
              ? (hasUnlimited ? 'Необмежено · ' : `з ${firstSub.plan_sessions_count} · `)
                + firstSub.plan_name
                + (extraSubsCount > 0 ? ` +${extraSubsCount} ще` : '')
              : 'Немає активного абонементу'
            }
          </div>
          {subs.length > 0 && (
            <div style={{ marginTop: 18 }}>
              <ProgressBar value={subProgress} glow />
            </div>
          )}
        </div>
        <div className={s.kpi}>
          <div className={s.kpiLabel}><IconClock />НАСТУПНЕ ЗАНЯТТЯ</div>
          {nextLesson ? (
            <>
              <div className={s.kpiValue}>{nextLesson.start_time?.slice(0, 5)}</div>
              <div className={s.kpiSub}>{nextLesson.style_name} · {nextLesson.hall_name}</div>
            </>
          ) : (
            <>
              <div className={`${s.kpiValue} ${s.kpiMuted}`}>—</div>
              <div className={s.kpiSub}>Немає записів</div>
            </>
          )}
        </div>
        <div className={s.kpi}>
          <div className={s.kpiLabel}><IconActivity />ВІДВІДАНО ВСЬОГО</div>
          <div className={s.kpiValue}>{totalAttended}</div>
          <div className={s.kpiSub}>занять</div>
        </div>
      </div>

      <DashboardGrid
        upcoming={upcoming} monthName={monthName} chartData={chartData}
        daysInMonth={daysInMonth} totalMonth={totalMonth} attPercent={attPercent}
        onCancel={handleCancel}
      />

      <div className={s.quickSection}>
        <div className={s.quickTitle}>Швидкі дії</div>
        <div className={s.quickGrid}>
          <Quick to="/student/enroll" label="Записатись"
            icon={<IconCirclePlus size={22} strokeWidth={1.5} />} />
          <Quick to="/student/subscription" label="Купити абонемент"
            icon={<IconShopping size={22} strokeWidth={1.5} />} />
          <Quick to="/student/attendance" label="Відвідуваність"
            icon={<IconClipboard size={22} strokeWidth={1.5} />} />
          <Quick to="/student/profile" label="Профіль"
            icon={<IconUser size={22} strokeWidth={1.5} />} />
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
