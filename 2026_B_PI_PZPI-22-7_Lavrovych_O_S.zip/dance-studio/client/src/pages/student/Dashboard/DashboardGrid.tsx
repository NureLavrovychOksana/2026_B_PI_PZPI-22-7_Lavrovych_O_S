import { Link } from 'react-router-dom';
import { EnrollRow, AttendanceChart } from './DashboardComponents';
import { IconCalendar, IconCirclePlus, IconBarChart } from '../../../components/ui/Icon';
import s from './StudentDashboard.module.css';

interface Props {
  upcoming:     any[];
  monthName:    string;
  chartData:    { day: number; present: boolean }[];
  daysInMonth:  number;
  totalMonth:   number;
  attPercent:   number;
  onCancel:     (id: number) => void;
}

const DashboardGrid = ({ upcoming, monthName, chartData, daysInMonth, totalMonth, attPercent, onCancel }: Props) => (
  <div className={s.grid}>
    <div className={s.card}>
      <div className={s.cardHead}>
        <IconCalendar size={13} strokeWidth={1.8} />
        <span className={s.cardTitle}>МОЇ ЗАПИСИ</span>
        <Link to="/student/schedule" className={s.cardLink}>Всі</Link>
      </div>
      <div className={s.enrollList}>
        {upcoming.length === 0
          ? <div className={s.empty}>Немає майбутніх занять</div>
          : upcoming.map(e => <EnrollRow key={e.id} item={e} onCancel={onCancel} />)
        }
      </div>
      <Link to="/student/enroll" className={s.enrollBtn}>
        <IconCirclePlus size={13} />
        Записатись на заняття
      </Link>
    </div>

    <div className={s.card}>
      <div className={s.cardHead}>
        <IconBarChart size={13} strokeWidth={1.8} />
        <span className={s.cardTitle}>ПРОГРЕС МІСЯЦЯ ({monthName.toUpperCase()})</span>
      </div>
      <div className={s.chartWrap}>
        <AttendanceChart data={chartData} daysInMonth={daysInMonth} />
        <div className={s.chartDates}>
          {[1, 8, 15, 22, 29].map(d => <span key={d}>{d}</span>)}
        </div>
      </div>
      <div className={s.monthStats}>
        <div className={s.monthStat}>
          <div className={s.monthVal}>{totalMonth}</div>
          <div className={s.monthLabel}>занять цього місяця</div>
        </div>
        <div className={s.monthStat}>
          <div className={`${s.monthVal} ${s.kpiLime}`}>{attPercent}%</div>
          <div className={s.monthLabel}>відвідуваність</div>
        </div>
      </div>
    </div>
  </div>
);

export default DashboardGrid;
