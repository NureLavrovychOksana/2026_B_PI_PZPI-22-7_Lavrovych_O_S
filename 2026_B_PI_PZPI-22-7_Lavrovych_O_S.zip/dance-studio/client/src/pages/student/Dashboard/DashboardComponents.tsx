import { Link } from 'react-router-dom';
import {
  IconLayers as _IconLayers,
  IconClock as _IconClock,
  IconActivity as _IconActivity,
  IconX,
} from '../../../components/ui/Icon';
import s from './StudentDashboard.module.css';

export const Quick = ({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) => (
  <Link to={to} className={s.quick}>
    <div className={s.quickIcon}>{icon}</div>
    <div className={s.quickLabel}>{label}</div>
  </Link>
);

export const AttendanceChart = ({ data, daysInMonth }: { data: { day: number; present: boolean }[]; daysInMonth: number }) => {
  const W = 340; const H = 90;
  const bw = Math.max(4, Math.floor(W / daysInMonth) - 2);
  return (
    <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      {Array.from({ length: daysInMonth }, (_, i) => {
        const day = i + 1;
        const entry = data.find(x => x.day === day);
        const x = i * (W / daysInMonth) + 1;
        return (
          <g key={i}>
            <rect x={x} y={44} width={bw} height={H - 48} rx={1} fill="#2a2a27" opacity={0.5} />
            {entry?.present && <rect x={x} y={6} width={bw} height={H - 12} rx={2} fill="#c8fa3a" />}
          </g>
        );
      })}
    </svg>
  );
};

export const EnrollRow = ({ item, onCancel }: { item: any; onCancel: (id: number) => void }) => {
  const date = new Date(item.lesson_date);
  const isPast = date < new Date(new Date().toDateString());
  return (
    <div className={`${s.enrollRow} ${isPast ? s.enrollRowPast : ''}`}>
      <div className={s.enrollTime}>
        <div className={s.enrollHour}>{item.start_time?.slice(0, 5)}</div>
        <div className={s.enrollDate}>
          {date.toLocaleDateString('uk-UA', { day: 'numeric', month: 'short', year: 'numeric' })}
        </div>
      </div>
      <div className={s.enrollInfo}>
        <div className={s.enrollStyle}>{item.style_name}</div>
        <div className={s.enrollHall}>{item.hall_name}</div>
      </div>
      {!isPast && (
        <button className={s.enrollCancel} onClick={() => onCancel(item.id)} title="Скасувати запис" aria-label="Скасувати запис">
          <IconX size={10} strokeWidth={2.5} />
        </button>
      )}
    </div>
  );
};

export const IconLayers   = () => <_IconLayers size={13} />;
export const IconClock    = () => <_IconClock size={13} />;
export const IconActivity = () => <_IconActivity size={13} />;

export const IconLightning = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
  </svg>
);
