import { useEffect, useState } from 'react';
import { getMyNotifications, markRead, markAllRead } from '../../../api/notifications';
import PageHeader from '../../../components/ui/display/PageHeader';
import Spinner    from '../../../components/ui/feedback/Spinner';
import { IconCircleCheck, IconClock, IconCreditCard, IconCalendar, IconBell } from '../../../components/ui/Icon';
import type { Notification } from '../../../types';
import s from './StudentNotifications.module.css';

const TYPE_ICON: Record<string, React.ReactNode> = {
  waitlist_promoted: <IconCircleCheck size={16} />,
  lesson_reminder:   <IconClock size={16} />,
  subscription:      <IconCreditCard size={16} />,
  schedule_change:   <IconCalendar size={16} />,
  default:           <IconBell size={16} />,
};

const normalizeDate = (s: string) =>
  s.includes('Z') || s.includes('+') ? s : s.replace(' ', 'T') + 'Z';

const timeAgo = (dateStr: string) => {
  const diff = Date.now() - new Date(normalizeDate(dateStr)).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return 'щойно';
  if (m < 60) return `${m} хв тому`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} год тому`;
  const d = Math.floor(h / 24);
  if (d < 7)  return `${d} д тому`;
  return new Date(normalizeDate(dateStr)).toLocaleDateString('uk-UA', { day: 'numeric', month: 'short' });
};

const StudentNotifications = () => {
  const [items,   setItems]   = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [marking, setMarking] = useState(false);

  useEffect(() => {
    getMyNotifications().then(setItems).finally(() => setLoading(false));
  }, []);

  const unread = items.filter(n => !n.is_read).length;

  const handleRead = async (id: number) => {
    setItems(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
    await markRead(id).catch(() => {});
  };

  const handleReadAll = async () => {
    setMarking(true);
    await markAllRead().catch(() => {});
    setItems(prev => prev.map(n => ({ ...n, is_read: true })));
    setMarking(false);
  };

  if (loading) return <Spinner centered />;

  return (
    <div>
      <div className={s.header}>
        <PageHeader
          title="Сповіщення"
          sub={unread > 0 ? `${unread} непрочитаних` : 'Всі прочитані'}
        />
        {unread > 0 && (
          <button className={s.readAllBtn} onClick={handleReadAll} disabled={marking}>
            {marking ? '...' : 'Позначити всі прочитаними'}
          </button>
        )}
      </div>

      {items.length === 0 ? (
        <div className={s.empty}>
          <div className={s.emptyIcon}>
            <IconBell size={40} strokeWidth={1.5} />
          </div>
          <div className={s.emptyTitle}>Немає сповіщень</div>
          <div className={s.emptySub}>Тут з'являтимуться важливі повідомлення</div>
        </div>
      ) : (
        <div className={s.list}>
          {items.map(n => (
            <div
              key={n.id}
              className={`${s.item} ${!n.is_read ? s.itemUnread : ''}`}
              onClick={() => !n.is_read && handleRead(n.id)}
            >
              <div className={`${s.iconWrap} ${s[`icon_${n.type}`] ?? s.icon_default}`}>
                {TYPE_ICON[n.type] ?? TYPE_ICON.default}
              </div>
              <div className={s.content}>
                <div className={s.title}>{n.title}</div>
                {n.body && <div className={s.body}>{n.body}</div>}
                <div className={s.time}>{timeAgo(n.created_at)}</div>
              </div>
              {!n.is_read && <div className={s.unreadDot} />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default StudentNotifications;
