import { useState } from 'react';
import type { SubscriptionPlan } from '../../../types';
import { IconCheck, IconChevronDown } from '../../../components/ui/Icon';
import s from './StudentSubscription.module.css';

const CheckIcon = () => <IconCheck size={13} strokeWidth={2.5} />;

interface PlanCardProps {
  plan:     SubscriptionPlan;
  cartHas:  boolean;
  onAdd:    () => void;
  onRemove: () => void;
  popular?: boolean;
}

export const PlanCard = ({ plan, cartHas, onAdd, onRemove, popular }: PlanCardProps) => {
  const isFree = plan.price === 0;
  const features: string[] = [
    plan.type === 'UNLIMITED' ? 'Необмежено занять' : `${plan.sessions_count} занять`,
    'Будь-який стиль',
    ...(plan.type === 'UNLIMITED' ? ['Всі стилі', 'Пріоритетний запис', 'Запис відео', 'Особиста консультація'] : []),
    ...(!isFree && plan.type === 'COUNT' ? ['Скасування за 2г'] : []),
    ...(plan.sessions_count && plan.sessions_count >= 8 && !isFree ? ['Запис відео'] : []),
    ...(isFree ? ['1 пробне заняття', 'Без зобов\'язань'] : []),
  ];

  return (
    <div className={`${s.planCard} ${popular ? s.planCardPopular : ''}`}>
      {popular && <div className={s.popularBadge}>ПОПУЛЯРНИЙ</div>}
      <div className={s.planName}>{plan.name}</div>
      <div className={s.planPrice}>
        {isFree ? <span className={s.planPriceFree}>БЕЗКОШТОВНО</span> : <>₴{plan.price.toLocaleString('uk-UA')}</>}
      </div>
      <div className={s.planPeriod}>
        {plan.type === 'UNLIMITED' ? 'Необмежено занять · 1 місяць' : `${plan.sessions_count} занять · 1 місяць`}
      </div>
      <div className={s.planFeatures}>
        {features.map((f, i) => (
          <div key={i} className={s.planFeature}>
            <span className={s.featureIcon}><CheckIcon /></span>
            {f}
          </div>
        ))}
      </div>
      {cartHas ? (
        <button className={`${s.addBtn} ${s.addBtnRemove}`} onClick={onRemove}>Видалити</button>
      ) : (
        <button className={`${s.addBtn} ${popular ? s.addBtnPopular : ''}`} onClick={onAdd}>
          {isFree ? 'Спробувати' : 'Придбати'}
        </button>
      )}
    </div>
  );
};

export const FAQ_ITEMS = [
  { q: 'Як скасувати запис на заняття?', a: 'Зайдіть у розділ "Мій розклад" або "Панель" і натисніть × поряд із заняттям. Скасування доступне не пізніше ніж за 2 години до початку.' },
  { q: 'Чи можна перенести заняття?', a: 'Так. Скасуйте поточний запис та запишіться на інший зручний час через розділ "Записатись".' },
  { q: 'Що буде, якщо місця скінчаться?', a: 'Ви можете встати до листа очікування. Якщо хтось скасує запис, ви автоматично займете місце і отримаєте сповіщення.' },
  { q: 'Як довго діє абонемент?', a: 'Кожен абонемент діє 30 днів з моменту активації. Невикористані заняття не переносяться.' },
];

export const FaqItem = ({ q, a }: { q: string; a: string }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className={s.faqItem}>
      <button className={s.faqQ} onClick={() => setOpen(p => !p)}>
        {q}
        <span style={{ display: 'flex', transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s', flexShrink: 0 }}>
          <IconChevronDown size={14} />
        </span>
      </button>
      {open && <div className={s.faqA}>{a}</div>}
    </div>
  );
};
