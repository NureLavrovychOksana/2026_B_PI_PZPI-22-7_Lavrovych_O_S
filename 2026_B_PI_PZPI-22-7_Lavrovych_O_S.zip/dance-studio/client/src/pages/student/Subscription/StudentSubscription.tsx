import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth }   from '../../../context/AuthContext';
import { getPlans, getStudentSubscriptions } from '../../../api/subscriptions';
import PageHeader  from '../../../components/ui/display/PageHeader';
import NotifBell   from '../../../components/ui/display/NotifBell';
import Spinner     from '../../../components/ui/feedback/Spinner';
import Toast       from '../../../components/ui/feedback/Toast';
import { useToast } from '../../../hooks/useToast';
import { PlanCard, FaqItem, FAQ_ITEMS } from './SubscriptionPlanCard';
import type { SubscriptionPlan, StudentSubscription } from '../../../types';
import { IconShopping, IconX } from '../../../components/ui/Icon';
import s from './StudentSubscription.module.css';
import a from '../../../styles/admin.module.css';

interface CartItem { plan: SubscriptionPlan; }

const STATUS_LABEL: Record<string, string> = {
  active:    'АКТИВНИЙ',
  pending:   'ОЧІКУЄ АКТИВАЦІЇ',
  exhausted: 'ВИЧЕРПАНО',
  expired:   'ТЕРМІН СПЛИВ',
  cancelled: 'СКАСОВАНО',
};

const StudentSubscription = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toasts, showToast, removeToast } = useToast();
  const [plans,   setPlans]   = useState<SubscriptionPlan[]>([]);
  const [subs,    setSubs]    = useState<StudentSubscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [cart,    setCart]    = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [promo,   setPromo]   = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const cartRef      = useRef<HTMLDivElement>(null);
  const skipSaveRef  = useRef(false);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (cartRef.current && !cartRef.current.contains(e.target as Node)) setCartOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    if (!user) return;
    try {
      const saved = localStorage.getItem(`dance_cart_${user.id}`);
      if (saved) {
        skipSaveRef.current = true;
        setCart(JSON.parse(saved));
      }
    } catch {}
  }, [user?.id]);

  useEffect(() => {
    if (!user) return;
    if (skipSaveRef.current) { skipSaveRef.current = false; return; }
    localStorage.setItem(`dance_cart_${user.id}`, JSON.stringify(cart));
  }, [cart, user?.id]);

  useEffect(() => {
    if (!user) return;
    Promise.all([getPlans(), getStudentSubscriptions(user.id)])
      .then(([p, list]) => { setPlans(p); setSubs(list); })
      .finally(() => setLoading(false));
  }, [user]);

  const addToCart    = (plan: SubscriptionPlan) =>
    setCart(prev => prev.find(c => c.plan.id === plan.id) ? prev : [...prev, { plan }]);
  const removeFromCart = (planId: number) => setCart(prev => prev.filter(c => c.plan.id !== planId));

  const total      = cart.reduce((acc, c) => acc + c.plan.price, 0);
  const discount   = promoApplied ? Math.round(total * 0.1) : 0;
  const finalTotal = total - discount;

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setCartOpen(false);
    navigate('/student/checkout', { state: { items: cart, total: finalTotal } });
    setCart([]);
  };

  const applyPromo = () => {
    if (promo.toLowerCase() === 'dance10') {
      setPromoApplied(true);
      showToast('Промо-код застосовано: -10%', 'success');
    } else {
      showToast('Невірний промо-код', 'error');
    }
  };

  if (loading || !user) return <Spinner centered />;

  const popularPlanId = plans.find(p => p.sessions_count === 8)?.id;

  return (
    <div>
      <div className={s.topRow}>
        <PageHeader title="Магазин абонементів" />
        <div className={s.topActions}>
          <NotifBell to="/student/notifications" />

          <div className={s.cartWrap} ref={cartRef}>
            <button className={s.cartBtn} onClick={() => setCartOpen(p => !p)}>
              <IconShopping size={15} />
              Кошик
              {cart.length > 0 && <span className={s.cartBadge}>{cart.length}</span>}
            </button>

            {cartOpen && (
              <div className={s.cartDropdown}>
                <div className={s.cartHeader}>Кошик</div>
                <div className={s.cartItems}>
                  {cart.length === 0 ? (
                    <div className={s.cartEmpty}>Кошик порожній</div>
                  ) : cart.map((c, i) => (
                    <div key={c.plan.id} className={`${s.cartItem} ${i > 0 ? s.cartItemBorder : ''}`}>
                      <div className={s.cartItemBody}>
                        <div className={s.cartItemName}>
                          {c.plan.name} · {c.plan.type === 'UNLIMITED' ? 'Необмежений' : `${c.plan.sessions_count} занять`}
                        </div>
                        <div className={s.cartItemPrice}>₴{c.plan.price.toLocaleString('uk-UA')}</div>
                      </div>
                      <button className={s.cartRemove} onClick={() => removeFromCart(c.plan.id)} title="Видалити" aria-label="Видалити з кошика">
                        <IconX size={10} strokeWidth={2.5} />
                      </button>
                    </div>
                  ))}
                </div>
                <div className={s.cartFooter}>
                  <div className={s.cartTotal}>
                    Разом: <span className={s.cartTotalAmt}>₴{finalTotal.toLocaleString('uk-UA')}</span>
                    {promoApplied && <span className={s.cartDiscount}> −10%</span>}
                  </div>
                  <button className={s.checkoutBtn} onClick={handleCheckout} disabled={cart.length === 0}>
                    Оформити →
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {subs.filter(sub => { const e = sub.effective_status ?? sub.status; return e === 'active' || e === 'pending'; }).length > 0 && (() => {
        const activeSubs = subs.filter(sub => { const e = sub.effective_status ?? sub.status; return e === 'active' || e === 'pending'; });
        const cols = Math.min(activeSubs.length, 4);
        return (
        <div className={s.subsSection}>
          <div className={s.plansLabel}>Мої абонементи</div>
          <div className={s.subsGrid} style={{ '--sub-cols': cols } as React.CSSProperties}>
            {activeSubs.map(sub => {
              const eff = sub.effective_status ?? sub.status;
              const isPending = eff === 'pending';
              const archived  = eff !== 'active' && eff !== 'pending';
              const progress = isPending ? 0 : sub.plan_type === 'UNLIMITED' ? 100
                : (sub.sessions_left != null && sub.plan_sessions_count)
                  ? (sub.sessions_left / sub.plan_sessions_count) * 100 : 0;
              return (
                <div key={sub.id} className={`${s.currentSub} ${isPending ? s.currentSubPending : ''} ${archived ? s.currentSubArchived : ''}`}>
                  <div className={s.currentSubTop}>
                    <div className={s.currentSubLabel}>{STATUS_LABEL[eff] ?? eff.toUpperCase()}</div>
                    {isPending && <span className={s.pendingBadge}>В ЧЕРЗІ</span>}
                    {archived  && <span className={s.archivedBadge}>АРХІВ</span>}
                  </div>
                  <div className={s.currentSubName}>
                    {sub.plan_name}
                    {sub.plan_type !== 'UNLIMITED' && ` · ${sub.sessions_left ?? 0} занять`}
                    {sub.plan_type === 'UNLIMITED' && ' · Необмежений'}
                  </div>
                  <div className={s.currentSubExp}>
                    {isPending
                      ? 'Активується автоматично після завершення поточного'
                      : sub.expiry_date
                        ? `Дійсний до ${new Date(sub.expiry_date).toLocaleDateString('uk-UA', { day: 'numeric', month: 'long', year: 'numeric' })}`
                        : 'Без обмеження терміну'}
                  </div>
                  <div className={s.subProgressTrack}>
                    <div className={s.subProgressFill} style={{ width: `${progress}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        );
      })()}

      <div className={s.plansLabel}>Тарифи</div>
      <div className={s.plansGrid}>
        {plans.map(plan => (
          <PlanCard
            key={plan.id} plan={plan}
            cartHas={cart.some(c => c.plan.id === plan.id)}
            onAdd={() => addToCart(plan)}
            onRemove={() => removeFromCart(plan.id)}
            popular={plan.id === popularPlanId}
          />
        ))}
      </div>

      <div className={s.promoSection}>
        <div className={s.promoLabel}>ПРОМО-КОД</div>
        <div className={s.promoRow}>
          <input className={s.promoInput} placeholder="Введіть промо-код" value={promo}
            onChange={e => setPromo(e.target.value)} disabled={promoApplied} />
          <button className={a.btnSecondary} onClick={applyPromo} disabled={promoApplied || !promo}>
            {promoApplied ? 'Застосовано ✓' : 'Застосувати'}
          </button>
        </div>
        {promoApplied && <div className={s.promoSuccess}>Знижка -10% застосована</div>}
      </div>

      <div className={s.faqSection}>
        <div className={s.faqTitle}>Часті питання</div>
        {FAQ_ITEMS.map((item, i) => <FaqItem key={i} q={item.q} a={item.a} />)}
      </div>

      <Toast items={toasts} onRemove={removeToast} />
    </div>
  );
};

export default StudentSubscription;
