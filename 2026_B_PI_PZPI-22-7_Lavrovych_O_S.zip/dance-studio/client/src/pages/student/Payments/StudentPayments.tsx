import { useEffect, useState } from 'react';
import { useAuth } from '../../../context/AuthContext';
import PageHeader from '../../../components/ui/display/PageHeader';
import Spinner    from '../../../components/ui/feedback/Spinner';
import { getPaymentsByUser } from '../../../api/payments';
import s from './StudentPayments.module.css';

const fmtDate = (d: string) =>
  new Date(d).toLocaleDateString('uk-UA', { day: 'numeric', month: 'short', year: 'numeric' });

const METHOD_LABELS: Record<string, string> = {
  card:     'Картка',
  monobank: 'Monobank',
  cash:     'Готівка',
  liqpay:   'LiqPay',
};

const StudentPayments = () => {
  const { user } = useAuth();
  const [payments, setPayments] = useState<any[]>([]);
  const [loading,  setLoading]  = useState(true);

  useEffect(() => {
    if (!user) return;
    getPaymentsByUser(user.id)
      .then(setPayments)
      .catch(() => setPayments([]))
      .finally(() => setLoading(false));
  }, [user]);

  if (loading) return <Spinner centered />;

  return (
    <div>
      <PageHeader title="Мої платежі" sub={`${payments.length} записів`} />

      {payments.length === 0 ? (
        <div className={s.empty}>Платежів поки немає</div>
      ) : (
        <div className={s.list}>
          {payments.map(p => (
            <div key={p.id} className={s.row}>
              <div className={s.rowLeft}>
                <div className={s.amount}>₴{Number(p.amount).toLocaleString('uk-UA')}</div>
                <div className={s.plan}>{p.plan_name ?? '—'}</div>
              </div>
              <div className={s.rowMeta}>
                <span className={`${s.status} ${p.status === 'success' ? s.statusOk : s.statusFail}`}>
                  {p.status === 'success' ? 'Сплачено' : p.status}
                </span>
                <span className={s.method}>{METHOD_LABELS[p.payment_method] ?? p.payment_method}</span>
                <span className={s.date}>{fmtDate(p.payment_date)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default StudentPayments;
