import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '../../../context/AuthContext';
import { confirmCheckout } from '../../../api/payments';
import Spinner from '../../../components/ui/feedback/Spinner';
import { IconCheck, IconX } from '../../../components/ui/Icon';
import s from './PaymentResult.module.css';

const PaymentResult = () => {
  const [params]  = useSearchParams();
  const { user }  = useAuth();
  const orderId   = params.get('order_id') ?? '';

  const [status, setStatus]   = useState<'loading' | 'success' | 'fail'>('loading');

  useEffect(() => {
    if (!orderId || !user) {
      setStatus('fail');
      return;
    }

    confirmCheckout(orderId)
      .then(() => setStatus('success'))
      .catch(() => setStatus('fail'));
  }, [orderId, user]);

  if (status === 'loading') return <Spinner centered />;

  const isOk = status === 'success';

  return (
    <div className={s.wrap}>
      <div className={s.card}>
        <div className={`${s.icon} ${isOk ? s.iconOk : s.iconFail}`}>
          {isOk ? (
            <IconCheck size={36} />
          ) : (
            <IconX size={36} />
          )}
        </div>

        <h1 className={s.title}>{isOk ? 'Оплата успішна' : 'Помилка оплати'}</h1>
        <p className={s.sub}>
          {isOk
            ? 'Ваш абонемент активовано. Можете записуватися на заняття.'
            : 'Платіж не пройшов. Спробуйте ще раз або оберіть інший спосіб оплати.'}
        </p>

        <div className={s.actions}>
          <Link to="/student" className={`${s.btn} ${s.btnPrimary}`}>На головну</Link>
          {!isOk && (
            <Link to="/student/subscription" className={`${s.btn} ${s.btnGhost}`}>
              До абонементів
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaymentResult;
